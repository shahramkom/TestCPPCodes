
    CREATE PROCEDURE  [dbo].[USP_DNS_Update]
    
        @HostName	nvarchar(300),
        @IP			nvarchar(15),
        @DNSID	int	

    AS
    BEGIN
        SET NOCOUNT ON;

        UPDATE TDNS
        SET
    
        HostName = @HostName,	
        IP = @IP	

        WHERE DNSID = @DNSID	
    
    END

    go

