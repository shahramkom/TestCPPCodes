CREATE PROCEDURE [dbo].[USP_CreateRepLogTable]
AS
BEGIN
	DECLARE @myServerID AS INT
	SELECT @myServerID = convert(INT, [value]) FROM Tsetting Where [property] = 'ServerID'
	
	IF (dbo.IsPrimaryServer(@myServerID) = 1)
	BEGIN
		DECLARE CursSecID CURSOR FAST_FORWARD FOR SELECT ServerID,SlaveIP FROM RepConfig
		OPEN CursSecID
		DECLARE @ServerID AS INT
		DECLARE @SlaveIP AS VARCHAR(15)

		FETCH NEXT FROM CursSecID INTO @ServerID, @SlaveIP
		WHILE @@FETCH_STATUS=0
		BEGIN
			IF(@ServerID <> @myServerID)
			BEGIN
				DECLARE @tableName AS VARCHAR(20)
				SET @tableName = 'RepSecLog' + Convert(Varchar(5), @serverID)
				DECLARE @tableScript AS NVARCHAR(max)
				IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].['+@tableName+']') AND type in (N'U'))
                BEGIN
					SET @tableScript = 'CREATE TABLE [dbo].[' + @tableName + '](
					    [ID] [int] IDENTITY(1,1) NOT NULL,
					    [RecordID] [int] NOT NULL,
					    [ActionType] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
					    [Command] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
					    [GID] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
					    [AssignedGrpIDs] [varchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
					    [AssignedUsrIDs] [varchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
						[CreateTime] [varchar](20) NOT NULL DEFAULT ((CONVERT(varchar(20),GETDATE(),20))),
                        PRIMARY KEY(ID)
                        )'
				 	EXEC dbo.sp_executesql @statement = @tableScript
                END
			END
			ELSE
			BEGIN
				IF(@SlaveIP IS NOT NULL)
				BEGIN
					SET @tableName = 'RepSlaveLog'
					IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].['+@tableName+']') AND type in (N'U'))
                    BEGIN
					    SET @tableScript = 'CREATE TABLE [dbo].[' + @tableName + '](
						    [ID] [int] IDENTITY(1,1) NOT NULL,
						    [RecordID] [int] NOT NULL,
						    [ActionType] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
						    [Command] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
						    [GID] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
						    [AssignedGrpIDs] [varchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
						    [AssignedUsrIDs] [varchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
							[CreateTime] [varchar](20) NOT NULL DEFAULT ((CONVERT(varchar(20),GETDATE(),20))),
					        PRIMARY KEY(ID)
                        )'
					    EXEC dbo.sp_executesql @statement = @tableScript
                    END
				END
			END
			FETCH NEXT FROM CursSecID INTO @ServerID, @SlaveIP
		END
        CLOSE CursSecID
		DEALLOCATE CursSecID

        DECLARE @counter AS INT
        SET @counter = 1
        WHILE (@counter < 255 )
        BEGIN
            IF NOT EXISTS(SELECT * FROM dbo.RepConfig WHERE ServerID = @counter)
            BEGIN
                SET @tableName = 'RepSecLog' + CONVERT(VARCHAR(3), @counter)
                IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].['+@tableName+']') AND type in (N'U'))
                BEGIN
                    SET @tableScript = 'DROP TABLE [dbo].[' + @tableName + ']'
		            EXEC dbo.sp_executesql @statement = @tableScript
                END
            END
            SET @counter = @counter + 1
        END
	END
	ELSE
	BEGIN
		IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RepPrimaryLog]') AND type in (N'U'))
		BEGIN	
    		SET @tableScript = 'CREATE TABLE [dbo].[RepPrimaryLog](
					[ID] [int] IDENTITY(1,1) NOT NULL,
					[RecordID] [int] NOT NULL,
					[ActionType] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
					[Command] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
					[GID] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
					[AssignedGrpIDs] [varchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
					[AssignedUsrIDs] [varchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
					[CreateTime] [varchar](20) NOT NULL DEFAULT ((CONVERT(varchar(20),GETDATE(),20))),
				    PRIMARY KEY(ID)
                    )'
		    EXEC dbo.sp_executesql @statement = @tableScript
        END
        IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RepSlaveLog]') AND type in (N'U'))
		BEGIN	
		    SET @tableScript = 'CREATE TABLE [dbo].[RepSlaveLog](
					[ID] [int] IDENTITY(1,1) NOT NULL,
					[RecordID] [int] NOT NULL,
					[ActionType] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
					[Command] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
					[GID] [varchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
					[AssignedGrpIDs] [varchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
					[AssignedUsrIDs] [varchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
					[CreateTime] [varchar](20) NOT NULL DEFAULT ((CONVERT(varchar(20),GETDATE(),20))),
				    PRIMARY KEY(ID)
                    )'
			EXEC dbo.sp_executesql @statement = @tableScript
        END
	END	
END

go

