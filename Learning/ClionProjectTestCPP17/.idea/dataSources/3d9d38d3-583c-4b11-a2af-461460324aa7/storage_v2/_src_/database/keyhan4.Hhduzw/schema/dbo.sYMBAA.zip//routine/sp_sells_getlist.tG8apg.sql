CREATE PROCEDURE [dbo].[sp_Sells_GetList]
AS

select 
	sells.Code	as N'ßÏ',	
	CustomerName    as N'ÎÑíÏÇÑ',	
	ProductName 	as N'ãÍÕæá',	
	ProductVer      as N'æäå',	
	SettingName	as N'ãÏá',		
	Number		as N'ÊÚÏÇÏ',	
	DeliveryDate	as N'ÊÇÑíÎ',	
	FactorNumber	as N'ÔãÇÑå ÝÇßÊæÑ'	
from sells, Customers, Products, KeyASettings
where   ( sells.CustomerCode   = Customers.CustomerCode and 
	  Products.SettingCode = KeyASettings.SettingCode and
	  Products.Code        = Sells.ProductCode
	)
go

