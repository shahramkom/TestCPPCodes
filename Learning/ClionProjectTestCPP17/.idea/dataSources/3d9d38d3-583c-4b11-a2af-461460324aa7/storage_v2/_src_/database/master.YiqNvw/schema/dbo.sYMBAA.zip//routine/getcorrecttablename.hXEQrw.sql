/******************************************************************************************************************************************************/--
CREATE FUNCTION dbo.GetCorrectTableName(@TableName VARCHAR(50),@AssignType VARCHAR(20))
RETURNS VARCHAR(50)
BEGIN
	IF(@TableName = 'TUser')
		RETURN 'TUserGroups'
	IF(@TableName = 'TPolicySet') 
		IF (@AssignType = 'Assign-Users')
			RETURN 'TUserPolicySet'
		ELSE IF(@AssignType = 'Assign-Groups')
			RETURN 'TGroupPolicySet'
	
	IF(@TableName = 'TScript') 
		IF (@AssignType = 'Assign-Users')
			RETURN 'TUserScripts'
		ELSE IF(@AssignType = 'Assign-Groups')
			RETURN 'TgroupScript'

	IF(@TableName = 'TTimeRole') 
		IF (@AssignType = 'Assign-Users')
			RETURN 'TUserTimeSet'
		ELSE IF(@AssignType = 'Assign-Groups')
			RETURN 'TgroupTimeset'

	IF(@TableName = 'TDNS') 
		IF (@AssignType = 'Assign-Users')
			RETURN 'TUserDNS'
		ELSE IF(@AssignType = 'Assign-Groups')
			RETURN 'TgroupDNS'

	IF(@TableName = 'TInterface') 
		IF (@AssignType = 'Assign-Users')
			RETURN 'TUserInterface'
		ELSE IF(@AssignType = 'Assign-Groups')
			RETURN 'TGroupInterface'
	RETURN @TableName
END
go

