
CREATE PROCEDURE [dbo].[USP_User_Group_Interface]
	@WhereStm as nvarchar(MAX)
AS
BEGIN

DECLARE @BaseSTM AS nvarchar(MAX)
SET @BaseSTM = '
SELECT ID , Name+'' (''+InterfaceBindingStatus+'')'' as ReprotColumn  FROM (                  
SELECT distinct TGroup.GroupID As ID , TGroup.GroupName AS Name ,dbo.fnGroupInterfaceNames(TGroup.GroupID) as InterfaceBindingStatus
FROM    TGroup )as T'

IF(@WhereStm IS NOT NULL)
	SET	@BaseSTM = @BaseSTM+' WHERE '+@WhereStm

SET @BaseSTM =  @BaseSTM+'
SELECT ID , Name+'' (''+InterfaceBindingStatus+'')'' as ReprotColumn  FROM (
SELECT distinct TUser.UserID as ID , TUser.UserName As Name, dbo.RetrieveInterfaceNames(TUser.UserID)  as InterfaceBindingStatus
FROM    TUser ) as T
'
IF(@WhereStm IS NOT NULL)
	SET	@BaseSTM = @BaseSTM+' WHERE '+@WhereStm
--select @BaseSTM
EXEC dbo.sp_executesql @BaseSTM     
END
go

