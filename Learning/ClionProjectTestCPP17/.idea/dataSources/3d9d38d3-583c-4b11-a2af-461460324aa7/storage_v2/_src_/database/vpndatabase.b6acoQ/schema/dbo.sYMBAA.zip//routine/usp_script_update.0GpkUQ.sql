
    CREATE PROCEDURE  [dbo].[USP_Script_Update]
    
        @ScriptTitle nvarchar(50),
        @ScriptText	nvarchar(300),
        @ScriptActivity	bit,
        @ScriptID	int	
    AS
    BEGIN
        SET NOCOUNT ON;

        UPDATE TScript
        SET
            ScriptTitle=@ScriptTitle,	
            ScriptText = @ScriptText,	
            ScriptActivity = @ScriptActivity
        WHERE
            ScriptID = @ScriptID	
    END

    go

