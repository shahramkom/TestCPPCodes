
    CREATE PROCEDURE [dbo].[USP_SelectTUserFirewallPolicyFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        
    declare  @PSID nvarchar(200),@InsertScript nvarchar(4000)

     Declare TUserFirewallPolicy_cursor Cursor FAST_FORWARD
        For
        Select 
                  PSID,[output] 
            FROM tbl_InsertGroupScript   
            where tableName = 'TUserFirewallPolicy'
            OPEN TUserFirewallPolicy_cursor

    FETCH NEXT FROM TUserFirewallPolicy_cursor
    INTO @PSID,@InsertScript

    WHILE @@FETCH_STATUS = 0
    begin 

    ----		if(exists (select PSID from TTUserFirewallPolicy where PSName = @PSName ))
    ----		Begin
    ----			if(@Replace = '1')
    ----				 Delete from TTUserFirewallPolicy   where PSName = @PSName	
    ----		End
            Begin TRY
            SET IDENTITY_INSERT TUserFirewallPolicy ON
            exec sp_executesql @InsertScript	
            SET IDENTITY_INSERT TUserFirewallPolicy OFF	
            END TRY
            BEGIN CATCH
				INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectTUserFirewallPolicyFromImportedBackupData')	  
            END CATCH
            
            
            FETCH NEXT FROM TUserFirewallPolicy_cursor 
             INTO @PSID,@InsertScript
    
        end
        CLOSE TUserFirewallPolicy_cursor;
        DEALLOCATE TUserFirewallPolicy_cursor;
    END

    go

