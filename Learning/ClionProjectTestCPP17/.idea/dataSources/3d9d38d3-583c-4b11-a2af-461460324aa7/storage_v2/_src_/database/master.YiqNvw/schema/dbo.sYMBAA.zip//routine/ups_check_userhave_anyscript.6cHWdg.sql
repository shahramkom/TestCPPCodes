CREATE PROCEDURE [dbo].[UPS_Check_UserHave_AnyScript] 
	@UserID BIGINT,
	@AllRelatedGroupsOfUser nvarchar(2000)
AS
BEGIN
	DECLARE @Count TINYINT
	SELECT @Count = COUNT(ScriptID) FROM TUserscripts WHERE UserID = @UserID
	if( @Count > 0)
	BEGIN
		SELECT 1 AS Script
		RETURN
	END	
	DECLARE @execSql  as NVARCHAR(2000)
	SET @execSql = 'SELECT @Count = COUNT(GroupID) FROM TGroupScript WHERE GroupID in('+@AllRelatedGroupsOfUser+')'
	EXEC SP_EXECUTESQL @execSql, N'@Count TINYINT OUTPUT', @Count OUTPUT
	if( @Count > 0)
	BEGIN
		SELECT 1  AS Script
		RETURN
	END	
	SELECT 0  AS Script
END
go

