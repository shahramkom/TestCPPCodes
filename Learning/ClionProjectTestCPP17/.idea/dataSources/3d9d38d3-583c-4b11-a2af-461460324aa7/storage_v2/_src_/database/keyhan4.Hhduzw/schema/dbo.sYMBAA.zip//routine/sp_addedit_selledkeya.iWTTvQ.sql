CREATE PROCEDURE [dbo].[sp_AddEdit_SelledKeyA] 
	@PurchaseCode		int,
	@SettingCode			int,
	@CustomerCode		int,
	@Number			int,
	@BorrowFlag			varchar(10),
	@DeliveryDate			datetime,
	@FactorDate			datetime,
	@FactorNumber			varchar(10),
	@WarrantyRevokeDate		datetime
 AS
	-- Calculate the value of LoginFlag
	declare @LoanFlag bit
	select @LoanFlag = 0
	if (@BorrowFlag = 'true')
		set @LoanFlag = 1
	-- for Add
	if (@PurchaseCode = 0)
	begin
		Insert PurchasedKeyA (SettingCode, CustomerCode, Number, LoanFlag, DeliveryDate, FactorDate, FactorNumber, WarrantyRevokeDate)
		       	      values      (@SettingCode, @CustomerCode, @Number, @LoanFlag, @DeliveryDate, @FactorDate, @FactorNumber, @WarrantyRevokeDate)		
		select N'Ñ˜æÑÏ ãæÑÏ äÙÑ ÈÇ ãæÝÞíÊ Èå ÇíÇå ÏÇÏå ÇÖÇÝå ÔÏ.' as ErrMsg, 0 as RetCode, @@identity as PurchaseCode
		return ;
	end

	-- for Edit
	Update PurchasedKeyA 
	set 
		SettingCode 		= @SettingCode ,
		CustomerCode		= @CustomerCode, 
		LoanFlag 		= @LoanFlag, 
		DeliveryDate 		= @DeliveryDate, 
		FactorDate		= @FactorDate, 
		FactorNumber 		= @FactorNumber, 
		WarrantyRevokeDate	= @WarrantyRevokeDate
	where 	(@PurchaseCode = PurchaseCode)

	select N'Ñ˜æÑÏ ãæÑÏ äÙÑ ÈÇ ãæÝÞíÊ æíÑÇíÔ ÔÏ.' as ErrMsg, 10 as RetCode, @PurchaseCode as PurchaseCode
go

