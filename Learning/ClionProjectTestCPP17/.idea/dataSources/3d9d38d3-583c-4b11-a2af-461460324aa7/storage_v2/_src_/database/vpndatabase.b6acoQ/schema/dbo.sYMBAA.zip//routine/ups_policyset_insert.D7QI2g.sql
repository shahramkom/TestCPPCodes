
    CREATE PROCEDURE [dbo].[UPS_PolicySet_Insert]
    
        @PSName  nvarchar(200)
		,@PSDescription nvarchar(500)= NULL
        ,@PSID	 INT =NULL output 
    AS
    BEGIN
        SET NOCOUNT ON;
        declare @pscount int 
        select @pscount=count(*) from  TPolicySet where PSName=@PSName 
        if(@pscount>0)
        begin
            Raiserror('The entered policy set name already exist. Please choose another name.', 16 , 10 )
            return;
        end
       INSERT INTO TPolicySet
        (
        PSName ,
		PSDescription
        )
        values
        (
        @PSName ,
		@PSDescription
        )
        SET @PSID = @@IDENTITY
    

    END

    go

