
        CREATE PROCEDURE [dbo].[USP_SelectTUserPolicySetFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        
    declare @groupID nvarchar(200), @UserID nvarchar(200),@InsertScript nvarchar(4000)

     Declare TUserPolicySet_cursor Cursor FAST_FORWARD
        For
        Select 
                 UserID,GroupID,[output] 
            FROM tbl_InsertGroupScript   
            where tableName = 'TUserPolicySet'
            OPEN TUserPolicySet_cursor

    FETCH NEXT FROM TUserPolicySet_cursor
    INTO @UserID,@groupID,@InsertScript

    WHILE @@FETCH_STATUS = 0
    begin 

    --		if(exists (select UserID from TPolicySet where PSName = @PSName ))
    --		Begin
    --			if(@Replace = '1')
    --				 Delete from TPolicySet   where PSName = @PSName	
    --		End
            BEGIN TRY
             exec sp_executesql @InsertScript	
            END TRY
            BEGIN CATCH
				 INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript 
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectTUserPolicySetFromImportedBackupData') 
            END CATCH
        
            
            
            FETCH NEXT FROM TUserPolicySet_cursor 
             INTO @UserID,@groupID,@InsertScript
    
        end
        CLOSE TUserPolicySet_cursor;
        DEALLOCATE TUserPolicySet_cursor;		
    END

        go

