CREATE PROCEDURE [dbo].[updateProgramHistoryValidField]
AS
BEGIN
	update [Keyhan4].[dbo].[ProgramHistory] set valid = 0
	DECLARE @LoopCounter NVARCHAR(50) , @MaxProfileId NVARCHAR(50)
	SELECT @LoopCounter = min(ModuleSerial) , @MaxProfileId = max(ModuleSerial) 
	FROM [Keyhan4].[dbo].[ProgramHistory]
	WHILE ( @LoopCounter IS NOT NULL AND  @LoopCounter <= @MaxProfileId)
	begin
		DECLARE @maxIDConter INT
		SELECT @maxIDConter = max(ID)
		FROM [Keyhan4].[dbo].[ProgramHistory]
		where ModuleSerial = @LoopCounter
		
		update [Keyhan4].[dbo].[ProgramHistory] set valid = 1 where ID = @maxIDConter

		SELECT @LoopCounter  = min(ModuleSerial) FROM [Keyhan4].[dbo].[ProgramHistory]
		WHERE ModuleSerial > @LoopCounter
   end

END
go

