/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_Select_UserGID] 
    @userID INT
AS
BEGIN
    SELECT GID from TUser WHERE UserID = @userID
END
go

