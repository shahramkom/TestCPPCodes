
    Create PROCEDURE [dbo].[USP_Update_LicenseCounter]
    AS
    BEGIN
		Declare @oldRemainingDays int

		set @oldRemainingDays = Null

		select @oldRemainingDays = [value] from TSetting Where [Property] = N'RemainingExpireDays'
	
		if @oldRemainingDays is not Null
		begin
			set @oldRemainingDays = @oldRemainingDays - 1
			update TSetting set [value] = @oldRemainingDays where [Property] = N'RemainingExpireDays'
		end
    END

    go

