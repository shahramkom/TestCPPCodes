
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesServices_Update] 
   @ID  bigint,
   @ProtocolName nvarchar(50),
   @ProtocolType nvarchar(20),
   @SourcePort nvarchar(50),
   @DestinationPort nvarchar(50),
   @IconIndex int
   AS
   BEGIN

	UPDATE [dbo].[TNewPoliciesServices]
	   SET [ProtocolName] = @ProtocolName
		  ,[ProtocolType] = @ProtocolType
		  ,[SourcePort] =   @SourcePort
		  ,[DestinationPort] = @DestinationPort
		  ,[IconIndex] = @IconIndex
	 WHERE ID = @ID

   END

   go

