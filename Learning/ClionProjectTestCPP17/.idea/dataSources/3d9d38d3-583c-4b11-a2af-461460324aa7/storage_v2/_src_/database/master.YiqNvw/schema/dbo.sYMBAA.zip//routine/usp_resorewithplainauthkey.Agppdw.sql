
    --				<Then backup Database and after perform Database Encrypt DataBase>
    CREATE PROCEDURE  [dbo].[USP_ResorewithPlainAuthKey] 
        -- Add the parameters for the stored procedure here
     
     
        AS
    BEGIN
            -- SET NOCOUNT ON added to prevent extra result sets from
            -- interfering with SELECT statements.
            SET NOCOUNT ON;
        declare @tempAuthkey nvarchar(64)
        declare @EncAuthKey nvarchar(64)
        declare @UserID int 
        begin tran t1
        IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BackupPlainAuthTUser]') AND type in (N'U'))
            Begin
              DECLARE UserID_cursor CURSOR FAST_FORWARD READ_ONLY FOR 
            select  UserID from  BackupPlainAuthTUser 		

        OPEN UserID_cursor

        FETCH NEXT FROM UserID_cursor
        into @UserID

        if @@FETCH_STATUS != 0
        begin
            close UserID_cursor
            DEALLOCATE UserID_cursor  
            rollback tran t1;
            return	
        end
        WHILE @@FETCH_STATUS = 0
        BEGIN
                
    --		begin try
    --			DROP TABLE #Table
    --		end try
    --		begin catch
    --		RAISERROR ('Error raised in TRY block111.', 16, 1);
    --		end catch

            create table #Table(
                CommandLine nvarchar(200),
                Param1		nvarchar(200),
                [Output]	nvarchar(64)
            )
            select @tempAuthkey =  AuthenticationKey from BackupPlainAuthTUser where UserID = @UserID
            insert #Table EXEC Master..XYRunProc 'Encrypt' ,@tempAuthkey			
            select @EncAuthKey = [Output] from #Table where CommandLine='Encrypt'
            --select @AuthenticationKey
            drop table #Table
            begin try
                update  TUser 
            set
               AuthenticationKey = @EncAuthKey
            where UserID=@UserID
            end try
            begin catch
            drop table BackupPlainAuthTUser
            RAISERROR ('Error raised in TRY Update TUSER.', 16, 1);
            end catch
        
        
            FETCH NEXT FROM UserID_cursor
            into @UserID
        END
        close UserID_cursor
        DEALLOCATE UserID_cursor
            begin try
                DROP TABLE BackupPlainAuthTUser
            end	 try
            begin catch
            RAISERROR ('Error raised in drop BackupPlainAuthTUser.', 16, 1);
            end catch
    
    
            End
        commit tran t1	
    END


    go

