
CREATE PROCEDURE [dbo].[USP_CH_Rule_Delete] 
    @RuleID int = 0
AS
	BEGIN
		DELETE FROM HealthCheckRules    WHERE RuleID =  @RuleID
		--UPDATE [dbo].[HealthCheckProfiles]
		--SET [RuleIDs] = REPLACE(RuleIDs,cast(@RuleID as varchar(10))+'_','')
		--WHERE RuleIDs like '%'+cast(@RuleID as varchar(10))+'_%'
        --
		--UPDATE [dbo].[HealthCheckProfiles]
		--SET [RuleIDs] = REPLACE(RuleIDs,',,','')
		--
		--UPDATE [dbo].[HealthCheckProfiles]
		--SET [RuleIDs] = REPLACE(RuleIDs,',','')
		--WHERE charindex(',',[RuleIDs] ,LEN([RuleIDs]))>0
		--
		--UPDATE [dbo].[HealthCheckProfiles]
		--SET [RuleIDs] = REPLACE(RuleIDs,',','')
		--WHERE charindex(',',[RuleIDs] ,1) = 1
END
go

