
    CREATE PROCEDURE [dbo].[UPS_Insert_logs_programKeyA_Manger] 
        -- Add the parameters for the stored procedure here
        @userID        int , 
        @logType       nvarchar(50),
        @operationType nvarchar(50),
        @logEvent      nvarchar(50),
        @rowID		   nvarchar(max),
        @decription    nvarchar(max),
        @operationDate nvarchar(10),
        @operationTime nvarchar(8)
        
    AS
    BEGIN	
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
      declare @out nvarchar(500)
      declare @PSID int 
      declare @PSName nvarchar(500)
      declare @PSNames nvarchar(500)
      declare @sumPsName nvarchar(500)
    set @PSID=0
    --select @out = reverse(substring( reverse(@decription),1,(patindex('%;%',reverse(@decription)))))--as ali 
    select @out=substring(@decription ,patindex('%groupID=%',@decription)+8,100)  
    --insert into temp(groupID)values (@out)
    select @out
    if(@out!='')
    begin
    DECLARE PSName_cursor CURSOR FAST_FORWARD READ_ONLY FOR 
    select  PSName from  TPolicySet where PSID in
    (select  PSID from TGroupPolicySet where GroupID=@out) 

    OPEN PSName_cursor

    FETCH NEXT FROM PSName_cursor
    into @PSName

    if @@FETCH_STATUS != 0
    begin
        close PSName_cursor
        DEALLOCATE PSName_cursor  
        return	
    end
    WHILE @@FETCH_STATUS = 0
    BEGIN
    select @PSID=@PSID+1
    if(@PSID=1)
      SELECT @PsNames ='PolicySet_Name='+@PSName+'; '
    else
      SELECT @PsNames=STUFF ( @PsNames, LEN( @PsNames)+1 ,LEN('PolicySet_Name='+@PSName+';') ,'PolicySet_Name='+@PSName+'; ' )
    FETCH NEXT FROM PSName_cursor
    into @PSName
    END
    close PSName_cursor
    DEALLOCATE PSName_cursor
    SELECT @PsNames
    -- insert into temp(PSName)values(@PSNames)
     --insert into temp(PSName)values(@PSNames)
    --select @PSID= PSID from TGroupPolicySet where GroupID=@out
    --insert into temp(PSID)values(@PSID)
    --select @PSName= PSName from  TPolicySet where PSID=@PSID 
    --select @PSNames=@PSNames+@PSName
     --insert into temp(PSName)values(@PSName)

    declare @grpName nvarchar(500)
    select @grpName=  GroupName from TGroup where GRoupID=@out     
    --insert into temp(groupName)values(@grpName)
    select @grpName='GroupName='+@grpName+';'+@PsNames
    --insert into temp(groupName)values(@grpName)
    select @decription=STUFF ( @decription , patindex('%groupID=%',@decription) , LEN ( @grpName ) ,@grpName )
    --insert into temp(decription)values(@decription)
    --select @decription= REPLACE ( @decription , '%groupID=%' , @grpName)
    --insert into temp(groupName)values(@decription)
    end
        INSERT INTO managerLog(userID,logType,operationType,logEvent,rowID,decription,operationDate,operationTime)
        VALUES(@userID,@logType,@operationType,@logEvent,@rowID,@decription,@operationDate,@operationTime);

    END

    go

