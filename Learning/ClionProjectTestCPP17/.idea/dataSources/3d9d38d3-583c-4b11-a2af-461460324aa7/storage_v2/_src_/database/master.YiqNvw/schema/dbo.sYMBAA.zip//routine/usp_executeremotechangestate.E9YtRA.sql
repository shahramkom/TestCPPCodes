CREATE PROCEDURE [dbo].[USP_ExecuteRemoteChangeState]
    @serversID TINYINT,
    @lastSuccessfulRun VARCHAR(20) = NULL,
	@runningState TINYINT = 255 -- Unknow
AS
BEGIN
    DECLARE @currentServerID AS INT
    SET @currentServerID = dbo.GetCurrentServerID()

    IF EXISTS(SELECT * FROM dbo.RepConfig WHERE @serversID = ServerID)
    BEGIN
        IF EXISTS(SELECT * FROM dbo.RepServersState WHERE ServerID = @serversID)
        BEGIN
            IF (@lastSuccessfulRun IS NULL)
                SELECT @lastSuccessfulRun = LastSuccessfulRun FROM dbo.RepServersState

            IF (@currentServerID = 1)
            BEGIN
                IF (@runningState <> 0)
                BEGIN
                    UPDATE dbo.RepServersState SET LastSuccessfulRun = @lastSuccessfulRun, RunningState = @runningState WHERE ServerID = @serversID    
                    IF(@serversID = 1 AND (@runningState = 1 OR @runningState = 2 OR @runningState = 4 OR @runningState = 255))
                        UPDATE dbo.RepServersState SET RunningState = 1 WHERE ServerID <> @serversID
                END
            END
            ELSE
            BEGIN
                UPDATE dbo.RepServersState SET LastSuccessfulRun = @lastSuccessfulRun, RunningState = @runningState
            END
		END
        ELSE
        BEGIN
            IF (@lastSuccessfulRun IS NULL)
                SET @lastSuccessfulRun = CONVERT([nvarchar](20),getdate(),(20))

            IF (@runningState <> 0 OR 
                (@currentServerID <> 1 AND @runningState = 0))
            BEGIN
                INSERT INTO dbo.RepServersState(ServerID, LastSuccessfulRun, RunningState )
                VALUES  ( @serversID, @lastSuccessfulRun, @runningState )
            END
        END
    END

    IF ((@currentServerID <> 1) AND @runningState = 0)
    BEGIN
        IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RepPrimaryLog]') AND type in (N'U'))
		BEGIN
			DELETE FROM RepPrimaryLog	
		END
		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RepSlaveLog]') AND type in (N'U'))
		BEGIN	
			DELETE FROM RepSlaveLog
		END
    END
END
go

