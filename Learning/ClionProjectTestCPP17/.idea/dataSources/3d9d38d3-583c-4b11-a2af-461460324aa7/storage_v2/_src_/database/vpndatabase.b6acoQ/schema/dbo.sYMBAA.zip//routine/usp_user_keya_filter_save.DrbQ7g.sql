
CREATE  PROCEDURE  [dbo].[USP_USER_KEYA_FILTER_SAVE]
    @UserID	int,
    @CurrentSerial nvarchar(50),
    @Date nvarchar(20) = NULL,
    @NewSerial nvarchar(50) = NULL
AS
BEGIN
    DECLARE @CurrentDate AS NVARCHAR(10)
    SELECT @CurrentDate = CONVERT(NVARCHAR(10),GETDATE(),20)	

    DECLARE @gid AS VARCHAR(25)
	DECLARE @version AS INT
	SET @gid = NULL
	SET @version = 0
	SELECT @gid = GID FROM dbo.TUserkeya WHERE UserID = @UserID	AND KeyaSerial = @CurrentSerial
	
	IF (@gid IS NOT NULL )
	BEGIN
		DECLARE @first AS INT
		DECLARE @second AS INT

		SET @first = CHARINDEX(',',@gid)
		SET @second = CHARINDEX(',', @gid, @first + 1)
		SET @version = SUBSTRING(@gid, @first + 1, @second - @first -1) + 1
	END

    IF(@NewSerial is NULL)
	    UPDATE TUserKeya set [Date] = @CurrentDate,   [GID] =  dbo.GenerateGID(-1, @version, NULL) WHERE ((UserID= @UserID) AND (KeyaSerial = @CurrentSerial))
    ELSE
	    UPDATE TUserKeya set KeyaSerial = @NewSerial, [Date] = @CurrentDate, [GID] =  dbo.GenerateGID(-1, @version, NULL) WHERE ((UserID= @UserID) AND (KeyaSerial = @CurrentSerial) AND ([Date] = @Date))
END
go

