

    CREATE PROCEDURE [dbo].[USP_TNewPolicyMain_Order_Change]

        @ID  bigint,
        @PolicyOrder int,

        @ID1  bigint,
        @PolicyOrder1 int
    AS
    BEGIN

        UPDATE TNewPolicyMainTable 	
        SET
        PolicyOrder=@PolicyOrder1
        where 
        ID=@ID

        UPDATE TNewPolicyMainTable 	
        SET
        PolicyOrder=@PolicyOrder
        where 
        ID=@ID1

    END

    go

