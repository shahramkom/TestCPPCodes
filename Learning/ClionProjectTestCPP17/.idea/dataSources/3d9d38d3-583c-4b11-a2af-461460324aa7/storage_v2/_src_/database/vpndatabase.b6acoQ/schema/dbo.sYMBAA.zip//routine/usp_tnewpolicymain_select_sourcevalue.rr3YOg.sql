
      CREATE PROCEDURE [dbo].[USP_TNewPolicyMain_Select_SourceValue] 
    @MainID  bigint
   AS
   BEGIN
		DECLARE @SourceType as tinyint
		DECLARE @SourceValue as nvarchar(50)
		SELECT @SourceType = sourceTunnelType , @SourceValue = sourceTunnelValue FROM TNewPolicyMainTable  WHERE ID = @MainID
		IF(@SourceType = 4) --ANY TYPE
		BEGIN
			SELECT 'Any'
		END
		ELSE IF(@SourceType = 0) --USER TYPE
		BEGIN
			if(@SourceValue != 'UseRs:AnY')
				select USERNAME,SubNetIP from TUSER WHERE USERID = cast(@SourceValue as int)
			else
				Select 'UseRs:AnY'
		END
		ELSE IF(@SourceType = 1) --GROUP TYPE
		BEGIN
			select GROUPNAME from TGROUP WHERE GROUPID = cast(@SourceValue as int)
		END
		ELSE
		BEGIN
			SELECT @SourceValue
		END
   END

      go

