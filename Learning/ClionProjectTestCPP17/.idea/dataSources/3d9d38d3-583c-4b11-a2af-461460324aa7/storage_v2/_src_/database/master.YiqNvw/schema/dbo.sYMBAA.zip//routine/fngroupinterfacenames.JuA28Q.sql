
	CREATE FUNCTION [dbo].[fnGroupInterfaceNames](@GroupID int)
	RETURNS nvarchar(max)
	AS
	BEGIN
		DECLARE @InterfaceNames as nvarchar(max)
		select @InterfaceNames = coalesce(@InterfaceNames + ',','') + InterfaceName from TInterface as ti,TGroupInterface as tgi 
		where (tgi.GroupID = @GroupID and ti.InterfaceID = tgi.InterfaceID)
		IF(@InterfaceNames is NULL)
			RETURN 'Unbound'
		RETURN @InterfaceNames
	END

  go

