/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetAllReplicateGroups]()
	RETURNS varchar(MAX)
AS
BEGIN
	DECLARE @GroupIDs VARCHAR(MAX)
	
	SELECT @GroupIDs = STUFF ((SELECT ','+ CAST( RepGroupID AS VARCHAR(25))
	FROM RepServersGroups FOR XML PATH('')) , 1 ,1 , '')
	
	RETURN @GroupIDs
END
go

