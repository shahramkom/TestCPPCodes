
  Create PROCEDURE [dbo].[USP_TNewPoliciesSearch_ServiceName] 
	@ServiceName nvarchar(20)
	AS
	BEGIN
		if (@serviceName = 'All')
		begin
			exec USP_TNewPolicyMain_Select
			return
		end	
		SELECT     *, dbo.SelModernPolGroupsUsers(MP.ID) AS Assignments
		FROM         dbo.TNewPolicyMainTable AS MP INNER JOIN
                      dbo.TNewPoliciesServices ON MP.ServicesID = dbo.TNewPoliciesServices.ID
		WHERE     (dbo.TNewPoliciesServices.ProtocolName = @ServiceName)
		ORDER BY MP.ApplyTime DESC, MP.PolicyOrder
	END

  go

