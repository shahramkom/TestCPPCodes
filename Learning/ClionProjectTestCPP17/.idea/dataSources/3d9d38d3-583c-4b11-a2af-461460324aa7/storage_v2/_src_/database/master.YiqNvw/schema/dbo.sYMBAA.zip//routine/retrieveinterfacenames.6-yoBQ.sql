
	create FUNCTION [dbo].[RetrieveInterfaceNames](@userID int)
	RETURNS nvarchar(max)
	AS
	BEGIN
		-- Declare the return variable here
		DECLARE @InterfaceNames as nvarchar(max)
		select @InterfaceNames = coalesce(@InterfaceNames + ',','') + InterfaceName from TInterface as ti,TUserInterface as tui 
		where (tui.UserID = @userID and ti.InterfaceID = tui.InterfaceID)
		-- Return the result of the function
				IF(@InterfaceNames is NULL)
			RETURN 'Unbound'
	
		RETURN @InterfaceNames

	END

  go

