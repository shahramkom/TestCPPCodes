CREATE PROCEDURE [dbo].[USP_GroupAssigned_PoliciesSAP] 
	@GroupID int
AS
BEGIN
	select SAP.* from TGroup g inner join TGroupPolicySet r on g.GroupID= r.GroupId inner join TServerAccessPolicy SAP on SAP.PSID = r.PSID where g.GroupID = @GroupID and SAP.Status=1 order by r.PriorityOrder, SAP.POrder asc
END
go

