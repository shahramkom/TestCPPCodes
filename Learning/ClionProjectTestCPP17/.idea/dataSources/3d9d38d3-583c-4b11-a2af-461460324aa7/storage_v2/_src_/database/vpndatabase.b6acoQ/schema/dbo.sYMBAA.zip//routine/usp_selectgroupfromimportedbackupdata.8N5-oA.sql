
		CREATE PROCEDURE [dbo].[USP_SelectGroupFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        select @Replace	
    declare @groupName nvarchar(500) ,@groupID nvarchar(200),@InsertScript nvarchar(4000)

     Declare Group_cursor Cursor FAST_FORWARD 
        For
        Select 
                  GroupName,GroupID,[output] 
            FROM tbl_InsertGroupScript   
            where tableName = 'TGroup'
            OPEN Group_cursor

    FETCH NEXT FROM Group_cursor
    INTO @groupName,@groupID,@InsertScript

    WHILE @@FETCH_STATUS = 0
    begin 
        
            set @groupName =  replace(@groupName,'NSpecial users','special users')
            if(exists (select groupid from tgroup where ((groupname = @groupName  ) and (groupid != @groupid))))
            Begin
				if(@Replace = 1)
                begin 
					Delete from TGroup  where ((groupname = @groupName ) and (groupid != @groupid))	
                end	
            End
            BEGIN TRY
            
                SET IDENTITY_INSERT TGroup ON
                exec sp_executesql @InsertScript	
                SET IDENTITY_INSERT TGroup OFF	
		update TGroup set InterfaceBindingStatus = 'False' where GroupID = @groupID	
            END TRY
            BEGIN CATCH
				INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectGroupFromImportedBackupData')
            
            
            END CATCH;  	
            FETCH NEXT FROM Group_cursor 
             INTO @groupName,@groupID,@InsertScript
    
        end
        CLOSE Group_cursor;
        DEALLOCATE Group_cursor;				
    END


    go

