

        CREATE PROCEDURE [dbo].[USP_SelectParentandChildGroupID]
        -- Add the parameters for the stored procedure here
        @GroupID int 
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
            
        declare @GID int , @ParentID nvarchar(200),@childID nvarchar(200) 
        set @GID = @GroupID
        set @ParentID = ''
        while @GID != 0 and @GID != null
        begin
          select  @GID =  dbo.GetGroupParent(@GID)
        if (@GID != 0 And @GID is not null)
          set @ParentID =@ParentID + cast(@GID as nvarchar(50))+ ',' 

        end
        
        declare @PID int
        
        begin try
            DROP TABLE #tbl_InsertGroupScript
        end try
        begin catch
        --RAISERROR ('Error raised in TRY block.', 16, 1);
        end catch

        create table #tbl_InsertGroupScript(
            [Output]	int
        )
        insert into #tbl_InsertGroupScript select @GroupID
        declare @i int
        set @i = 3
        while @i>0
        begin 
          insert into #tbl_InsertGroupScript SELECT  GroupID FROM TGROUP WHERE ParentID in (select [output] from #tbl_InsertGroupScript)
          set @i = @i -1
        end
        set @childID = ''
        DECLARE cursCol CURSOR FAST_FORWARD FOR 
        SELECT distinct([output]) FROM #tbl_InsertGroupScript
        OPEN cursCol
        FETCH NEXT FROM cursCol INTO @PID
        WHILE @@FETCH_STATUS=0
        BEGIN
            set @childID = @childID + cast(@PID as nvarchar(50))+ ',' 
            FETCH NEXT FROM cursCol INTO @PID
        
        END
    
        set @childID = left( @childID,len(@childID)-1)
        select @ParentID + @childID
    
 
    
        drop table #tbl_InsertGroupScript
        
            CLOSE cursCol
            DEALLOCATE cursCol

    
        END


        go

