
	  CREATE PROCEDURE [dbo].[USP_TNewPoliciesGrpModernPol_SelectByID] 
        -- Add the parameters for the stored procedure here
        @ModernPolicyID int 
    AS
    BEGIN
		SELECT     dbo.TGroup.GroupName
		FROM         dbo.TNewPolicyGroupAssign INNER JOIN
							  dbo.TGroup ON dbo.TNewPolicyGroupAssign.GroupID = dbo.TGroup.GroupID
		WHERE     (dbo.TNewPolicyGroupAssign.ModernPID = @ModernPolicyID)
    END

    go

