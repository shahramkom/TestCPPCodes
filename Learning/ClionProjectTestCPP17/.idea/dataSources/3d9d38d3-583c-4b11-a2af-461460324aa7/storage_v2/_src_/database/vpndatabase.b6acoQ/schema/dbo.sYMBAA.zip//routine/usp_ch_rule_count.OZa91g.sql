CREATE PROCEDURE [dbo].[USP_CH_Rule_Count]
  @CHP_ProfileID			int
AS
BEGIN
	SELECT COUNT(*) FROM [HealthCheckRules] 
END
go

