
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesServices_SelectByID] 
   @ID  bigint
   AS
   BEGIN
	SELECT [ID]
      ,[ProtocolName]
      ,[ProtocolType]
      ,[SourcePort]
      ,[DestinationPort]
	  ,[IconIndex]
	FROM [dbo].[TNewPoliciesServices]
	Where ID = @ID
   END

   go

