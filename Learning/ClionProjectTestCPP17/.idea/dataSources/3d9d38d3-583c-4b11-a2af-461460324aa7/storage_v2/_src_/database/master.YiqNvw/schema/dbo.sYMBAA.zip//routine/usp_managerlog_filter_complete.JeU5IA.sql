

    CREATE PROCEDURE [dbo].[USP_MANAGERLOG_FILTER_COMPLETE] 
        -- Add the parameters for the stored procedure here
        @L_UserID		  bigint=NULL,
        @L_logType		  nvarchar(50)=NULL,
        @L_InsertType	  nvarchar(50)=NULL,
        @L_DeleteType     nvarchar(50)=NULL,
        @L_UpdateType     nvarchar(50)=NULL,
        @L_AssignType	  nvarchar(50)=NULL,
        @L_DeAssignType	  nvarchar(50)=NULL,
        @L_ConnectType	  nvarchar(50)=NULL,
        @L_Disconnect     nvarchar(50)=NULL,
        @L_BackupType     nvarchar(50)=NULL,
        @L_RestoreType	  nvarchar(50)=NULL,
        @L_ImportType	  nvarchar(50)=NULL,
        @L_logEvent		  nvarchar(500)=NULL,
        @L_rowID		  nvarchar(max)=NULL,
        @L_decription	  nvarchar(max)=NULL,
        @L_startDate	  nvarchar(10)=NULL,
        @L_startTime	  nvarchar(8)=NULL,
        @L_endDate		  nvarchar(10)=NULL,
        @L_endTime		  nvarchar(8)=NULL,
		@L_ClientID		  bigint = NULL,
        @pageSize int = NULL,
        @pageNum int = 1	  									
    AS
      SET NOCOUNT ON
      declare @filter nvarchar(max)
      if (@L_UserID is not null)
        set @filter = isnull(@filter ,'') +  '(userID = ' + isnull(cast(@L_UserID as nvarchar(20)) , '') +')AND' 
	if (@L_ClientID is not null)
        set @filter = isnull(@filter ,'') +  '(ClientID = ' + isnull(cast(@L_ClientID as nvarchar(20)) , '') +')AND' 
    if (@L_logType is not null)	
        set @filter = isnull(@filter ,'') +  '(logType = '''+@L_logType+''')AND'	
    if (@L_logEvent is not null)	
        set @filter = isnull(@filter ,'') +  '(' +@L_logEvent+ ')AND'	
    if (@L_rowID is not null)	
        set @filter = isnull(@filter ,'') +  '(rowID = '''+@L_rowID+''')AND'	
    if (@L_decription is not null)	
        set @filter = isnull(@filter ,'') +  '(decription = '''+@L_decription+''')AND'
    
    if (@L_startDate = @L_endDate)	
        set @filter = isnull(@filter ,'') +  '(operationDate = '''+@L_startDate+''' AND operationTime >= '''+ @L_startTime+''' AND operationTime <= '''+@L_endTime+''')AND'
    else
        set @filter = isnull(@filter ,'') +  '(((operationDate > '''+@L_startDate+''') AND (operationDate < '''+ @L_endDate  +''')) OR ((operationDate = '''+@L_startDate + ''' AND operationTime >= '''+ @L_startTime+''' )) OR '
            + ' ((operationDate = '''+@L_endDate + ''' AND operationTime <= '''+ @L_endTime+''' )))AND'

    --set @filter = substring(@filter , 0 , LEN(@filter) - 2)
    if(@L_InsertType is not null OR @L_DeleteType is not null OR @L_UpdateType is not null or @L_ConnectType is not null OR @L_Disconnect is not null OR @L_BackupType is not null or @L_RestoreType is not null or @L_ImportType is not null or @L_AssignType is not NULL or @L_DeAssignType is not NULL )
        begin
            set @filter = isnull(@filter ,'')+ '('
            if (@L_DeleteType is not null)
                set @filter = isnull(@filter ,'') +  '(operationType = '''+@L_DeleteType +''')OR'
            if (@L_UpdateType is not null)
			begin
                set @filter = isnull(@filter ,'') +  '(operationType = '''+@L_UpdateType +''')OR'
				set @filter = isnull(@filter ,'') +  '(operationType = ''MULTIEDIT'')OR'
            end
			if (@L_AssignType is not NULL)
                set @filter = isnull(@filter ,'') +  '(operationType = '''+@L_AssignType +''')OR'
            if (@L_DeAssignType is not NULL)
                set @filter = isnull(@filter ,'') +  '(operationType = '''+@L_DeAssignType +''')OR'			
            if (@L_ConnectType is not null)
                set @filter = isnull(@filter ,'') +  '(operationType = '''+@L_ConnectType +''')OR'	
            if (@L_Disconnect is not null)
                set @filter = isnull(@filter ,'') +  '(operationType = '''+@L_Disconnect +''')OR'
            if (@L_BackupType is not null)
                set @filter = isnull(@filter ,'') +  '(operationType = '''+@L_BackupType +''')OR'
            if (@L_RestoreType is not null)
                set @filter = isnull(@filter ,'') +  '(operationType = '''+@L_RestoreType +''')OR'
            if (@L_ImportType is not null)
                set @filter = isnull(@filter ,'') +  '(operationType = '''+@L_ImportType +''')OR'
            if (@L_InsertType is not null)
                set @filter = isnull(@filter ,'') +  '(operationType = '''+@L_InsertType +''')OR'			
            set @filter = substring(@filter , 0 , LEN(@filter) - 1)			
            set @filter = isnull(@filter ,'')+ ')'
        end	
    else 
	begin
        set @filter = substring(@filter , 0 , LEN(@filter) - 2)	
		set @filter = isnull(@filter ,'') + 'AND ' + '(operationType = ''NULL'')'
	end
      select @filter
       declare 	@datasrc nvarchar(200)
       set 	@datasrc = ' managerLog '	
       declare @orderBy nvarchar(200)
       set @orderBy = ' operationDate DESC, operationTime DESC ' 
 
    declare  @fieldlist nvarchar(200) 
    set @fieldlist= '[No],
            operationDate as Date,operationTime as Time,userID as ManagerID,ClientID as ClientID, operationType,logEvent,rowID,decription'
     DECLARE
         @STMT nvarchar(max)         -- SQL to execute
        ,@recct int                  -- total # of records (for GridView paging interface)

     IF LTRIM(RTRIM(@filter)) = '' SET @filter = '1 = 1'
      IF @pageSize IS NULL BEGIN
        SET @STMT =  'SELECT   ' + @fieldlist + 
                     'FROM     ' + @datasrc +
                     'WHERE    ' + @filter + 
                     'ORDER BY ' + @orderBy
      
        
         EXEC (@STMT)                 -- return requested records 
      END ELSE BEGIN
        SET @STMT =  'SELECT  @recct = COUNT(*)
                     FROM     ' + @datasrc + '
                      WHERE    ' + @filter
        --select @STMT
        EXEC sp_executeSQL @STMT, @params = N'@recct INT OUTPUT', @recct = @recct OUTPUT
    
        --if (@recct between @pageSize * @pageNum and (@pageSize-1) * @pageNum)
        --select @pageSize * @pageNum , @recct , @pageSize * (@pageNum - 1 ) , @recct
        if (@pageSize * @pageNum > @recct and @pageSize * (@pageNum - 1 ) > @recct)
        begin
            select 'return'
            return;
        end
    
 
        SELECT @recct AS recct       -- return the total # of records

        DECLARE
         @lbound int,
         @ubound int

        SET @pageNum = ABS(@pageNum)
        SET @pageSize = ABS(@pageSize)
        IF @pageNum < 1 SET @pageNum = 1
        IF @pageSize < 1 SET @pageSize = 1
        SET @lbound = ((@pageNum - 1) * @pageSize)
        SET @ubound = @lbound + @pageSize + 1
        IF @lbound >= @recct BEGIN
          SET @ubound = @recct + 1
          SET @lbound = @ubound - (@pageSize + 1) -- return the last page of records if                                               -- no records would be on the
                                                  -- specified page
        END
        SET @STMT =  'SELECT  ' + @fieldlist + '
                      FROM    (
                                SELECT  ROW_NUMBER() OVER(ORDER BY ' + @orderBy + ') AS row, *
                                FROM    ' + @datasrc + '
                                WHERE   ' + @filter + '
                              ) AS tbl
                      WHERE
                              row > ' + CONVERT(varchar(9), @lbound) + ' AND
                              row < ' + CONVERT(varchar(9), @ubound)
    
        EXEC (@STMT)                 -- return requested records 
      END

    go

