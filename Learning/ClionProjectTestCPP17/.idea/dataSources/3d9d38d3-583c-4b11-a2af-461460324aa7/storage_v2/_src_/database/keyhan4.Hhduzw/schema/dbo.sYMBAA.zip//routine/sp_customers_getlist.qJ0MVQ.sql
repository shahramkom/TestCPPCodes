CREATE PROCEDURE [dbo].[sp_Customers_GetList]          
AS
	select 
		[CustomerCode]   as N'ßÏ',
		[CustomerName]  as N'äÇã',
		[Address]  	 as N'ÂÏÑÓ',
		[PresidentName]  as N'ãÏíÑ ÚÇãá',
		[Delegates]  	 as N'äãÇíäÏå',
		[WorkArea]  	 as N'Òãíäå ˜ÇÑí'
--		[EmailAddress]    as N'ÓÊ Çá˜ÊÑæäí˜',
--		[Phone] 	 as N'ÊáÝä'
--		[Fax]  		 as N'ÏæÑäãÇ',
--		[WebAddress]  	 as N'ÊÇÑäãÇ',
--		[Description]       as N'ÊæÖíÍÇÊ'
	from  Customers
	where (CustomerCode > 0)
go

