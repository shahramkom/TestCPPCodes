/*************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[USP_SelectHealthCheckFromImportedBackupData] 
	@Replace bit
	AS
BEGIN
	SET NOCOUNT ON;
	declare @InsertScript nvarchar(4000)
	declare @tableName nvarchar(4000)
	declare @HealthCheckID nvarchar(4000)
	declare @HealthCheckName nvarchar(4000)

	Declare HealthCheck_cursor Cursor FAST_FORWARD
	For
	Select [output], tableName, HealthCheckID, HealthCheckName 
		FROM tbl_InsertGroupScript   
		where  tableName = 'HealthCheckProfiles' 
			or tableName = 'HealthCheckRules'
			or tableName = 'HealthCheckGroupAssign'
			or tableName = 'HealthCheckUserAssign'

	OPEN HealthCheck_cursor

	FETCH NEXT FROM HealthCheck_cursor
	INTO @InsertScript, @tableName, @HealthCheckID, @HealthCheckName

	WHILE @@FETCH_STATUS = 0
	begin 
		if ( @tableName =  'HealthCheckProfiles')
		begin
		if(exists (select ProfileID from HealthCheckProfiles where Name = @HealthCheckName ))
			Begin
				if(@Replace = '1') 	Delete from HealthCheckProfiles   where ProfileID = @HealthCheckID	
				BEGIN TRY
					SET IDENTITY_INSERT HealthCheckProfiles ON
					exec sp_executesql @InsertScript	
					SET IDENTITY_INSERT HealthCheckProfiles OFF
				END TRY
				BEGIN CATCH
					INSERT INTO [VPNDataBase].[dbo].[TSqlError]
					([userid]
					,[moment]
					,[operate]
					,[errorcode]
					,[errortext]
					,[comment])
				VALUES
					(1
					,GETDATE()
					,@InsertScript
					,@@Error
					,Error_MESSAGE()
					,N'USP_SelectHealthCheckFromImportedBackupData')   	
				END CATCH
			End
			else
			begin
				BEGIN TRY
					SET IDENTITY_INSERT HealthCheckProfiles ON
					exec sp_executesql @InsertScript	
					SET IDENTITY_INSERT HealthCheckProfiles OFF
				END TRY
				BEGIN CATCH
					INSERT INTO [VPNDataBase].[dbo].[TSqlError]
					([userid]
					,[moment]
					,[operate]
					,[errorcode]
					,[errortext]
					,[comment])
				VALUES
					(1
					,GETDATE()
					,@InsertScript
					,@@Error
					,Error_MESSAGE()
					,N'USP_SelectHealthCheckFromImportedBackupData')   	
				END CATCH
			end
		end
		else if ( @tableName =  'HealthCheckRules')
		begin
			if(exists (select RuleID from HealthCheckRules where Name = @HealthCheckName ))
			Begin
				if(@Replace = '1') 	Delete from HealthCheckRules WHERE Name = @HealthCheckName	
				BEGIN TRY
					SET IDENTITY_INSERT HealthCheckRules ON
					exec sp_executesql @InsertScript	
					SET IDENTITY_INSERT HealthCheckRules OFF
				END TRY
				BEGIN CATCH
					INSERT INTO [VPNDataBase].[dbo].[TSqlError]
					([userid]
					,[moment]
					,[operate]
					,[errorcode]
					,[errortext]
					,[comment])
				VALUES
					(1
					,GETDATE()
					,@InsertScript
					,@@Error
					,Error_MESSAGE()
					,N'USP_SelectHealthCheckFromImportedBackupData')   	
				END CATCH
			End
			else
			begin
				BEGIN TRY
					SET IDENTITY_INSERT HealthCheckRules ON
					exec sp_executesql @InsertScript	
					SET IDENTITY_INSERT HealthCheckRules OFF
				END TRY
				BEGIN CATCH
					INSERT INTO [VPNDataBase].[dbo].[TSqlError]
					([userid]
					,[moment]
					,[operate]
					,[errorcode]
					,[errortext]
					,[comment])
				VALUES
					(1
					,GETDATE()
					,@InsertScript
					,@@Error
					,Error_MESSAGE()
					,N'USP_SelectHealthCheckFromImportedBackupData')   	
				END CATCH
			end
		end
		else if ( @tableName =  'HealthCheckGroupAssign')
		begin
			if(exists (select GroupID from HealthCheckGroupAssign where GroupID = @HealthCheckName and ProfileID = @HealthCheckID ))
			Begin
				if(@Replace = '1')
				begin
					Delete from HealthCheckGroupAssign  where GroupID = @HealthCheckName and ProfileID = @HealthCheckID	
					BEGIN TRY
						--SET IDENTITY_INSERT TNewPolicyGroupAssign ON
						exec sp_executesql @InsertScript	
						--SET IDENTITY_INSERT TNewPolicyGroupAssign OFF
					END TRY
					BEGIN CATCH
						INSERT INTO [VPNDataBase].[dbo].[TSqlError]
						([userid]
						,[moment]
						,[operate]
						,[errorcode]
						,[errortext]
						,[comment])
					VALUES
						(1
						,GETDATE()
						,@InsertScript
						,@@Error
						,Error_MESSAGE()
						,N'USP_SelectHealthCheckFromImportedBackupData')   	
					END CATCH
				end
			End
			else
			begin
				 BEGIN TRY
					--SET IDENTITY_INSERT TNewPolicyGroupAssign ON
					exec sp_executesql @InsertScript
					--SET IDENTITY_INSERT TNewPolicyGroupAssign OfF						
				END TRY
				BEGIN CATCH
					INSERT INTO [VPNDataBase].[dbo].[TSqlError]
					([userid]
					,[moment]
					,[operate]
					,[errorcode]
					,[errortext]
					,[comment])
				VALUES
					(1
					,GETDATE()
					,@InsertScript
					,@@Error
					,Error_MESSAGE()
					,N'USP_SelectHealthCheckFromImportedBackupData')   	
				END CATCH
			end
		end
		else if ( @tableName =  'HealthCheckUserAssign')
		begin
			if(exists (select UserID from HealthCheckUserAssign where UserID = @HealthCheckName and ProfileID = @HealthCheckID ))
			Begin
				if(@Replace = '1')
				begin
					Delete from HealthCheckUserAssign  where UserID = @HealthCheckName and ProfileID = @HealthCheckID	
					BEGIN TRY
						--SET IDENTITY_INSERT TNewPolicyUserAssign ON
						exec sp_executesql @InsertScript	
						--SET IDENTITY_INSERT TNewPolicyUserAssign OFF
					END TRY
					BEGIN CATCH
						INSERT INTO [VPNDataBase].[dbo].[TSqlError]
						([userid]
						,[moment]
						,[operate]
						,[errorcode]
						,[errortext]
						,[comment])
					VALUES
						(1
						,GETDATE()
						,@InsertScript
						,@@Error
						,Error_MESSAGE()
						,N'USP_SelectHealthCheckFromImportedBackupData')   	
					END CATCH
				end
			End
			else
			begin
				 BEGIN TRY
					--SET IDENTITY_INSERT TNewPolicyUserAssign ON
					exec sp_executesql @InsertScript
					--SET IDENTITY_INSERT TNewPolicyUserAssign OfF						
				END TRY
				BEGIN CATCH
					INSERT INTO [VPNDataBase].[dbo].[TSqlError]
					([userid]
					,[moment]
					,[operate]
					,[errorcode]
					,[errortext]
					,[comment])
				VALUES
					(1
					,GETDATE()
					,@InsertScript
					,@@Error
					,Error_MESSAGE()
					,N'USP_SelectHealthCheckFromImportedBackupData')   	
				END CATCH
			end
		end
		FETCH NEXT FROM HealthCheck_cursor 
			INTO @InsertScript, @tableName, @HealthCheckID, @HealthCheckName
	end
	CLOSE HealthCheck_cursor;
	DEALLOCATE HealthCheck_cursor;		
END
go

