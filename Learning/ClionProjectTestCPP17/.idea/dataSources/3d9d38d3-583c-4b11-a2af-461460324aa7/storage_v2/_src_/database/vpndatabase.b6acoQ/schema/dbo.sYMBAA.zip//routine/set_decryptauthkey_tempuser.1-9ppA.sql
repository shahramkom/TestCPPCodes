
    CREATE PROCEDURE [dbo].[Set_DecryptAuthKey_tempUser]
        -- Add the parameters for the stored procedure here
        @UserID int
    AS
    BEGIN
        declare @EncAuthKey nvarchar(64)	
    
        begin try
            DROP TABLE #Table
        end try
        begin catch	
        end catch

        create table #Table(
            CommandLine nvarchar(200),
            Param1		nvarchar(200),
            [Output]	nvarchar(64)
        )
        declare @decryptedAuthkey nvarchar(64)

        select @EncAuthKey = AuthenticationKey from TUser where UserID =@UserID
        insert #Table EXEC Master..XYRunProc 'Decrypt' ,@EncAuthKey
        select @decryptedAuthkey = [Output] from #Table 
        update  BackupPlainAuthTUser set  AuthenticationKey = @decryptedAuthkey where UserID = @UserID
        drop table #Table
    END


    go

