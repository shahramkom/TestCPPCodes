
    CREATE PROCEDURE [dbo].[UPS_Insert_logs_SettingServer] 
        -- Add the parameters for the stored procedure here
    
    
        @userID        int , 
        @logType       nvarchar(50),
        @operationType nvarchar(50),
        @logEvent      nvarchar(50),
        @rowID		   nvarchar(max),
        @decription    nvarchar(max),
        @operationDate nvarchar(10),
        @operationTime nvarchar(8)
        
    AS
    BEGIN	
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        INSERT INTO settingServerLog(userID,logType,operationType,logEvent,rowID,decription,operationDate,operationTime)
        VALUES(@userID,@logType,@operationType,@logEvent,@rowID,@decription,@operationDate,@operationTime);

    END

    go

