
	  CREATE PROCEDURE [dbo].[USP_TNewPoliciesUserModernPol_SelectByID] 
        @ModernPolicyID int 
    AS
    BEGIN
		SELECT     dbo.TUser.UserName
		FROM         dbo.TNewPolicyUserAssign INNER JOIN
							  dbo.TUser ON dbo.TNewPolicyUserAssign.UserID = dbo.TUser.UserID
		WHERE     (dbo.TNewPolicyUserAssign.ModernPID = @ModernPolicyID)
    END

    go

