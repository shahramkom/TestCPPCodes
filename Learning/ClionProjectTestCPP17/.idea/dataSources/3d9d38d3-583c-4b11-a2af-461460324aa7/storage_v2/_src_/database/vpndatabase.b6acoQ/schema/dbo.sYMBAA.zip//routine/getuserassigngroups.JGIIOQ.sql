/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.GetUserAssignGroups(@UserID INT)
	RETURNS varchar(MAX) --This Function Return secondary Server ID
AS
BEGIN
	DECLARE @UserGroupIDs VARCHAR(MAX)
	SELECT @UserGroupIDs = STUFF ((SELECT ','+ CAST(TUserGroups.GroupID AS VARCHAR(30))
	FROM dbo.TUserGroups WHERE TUserGroups.UserID = @UserID ORDER BY GPriority ASC	FOR XML PATH('')) , 1 ,1 , '') 
	RETURN @UserGroupIDs
END
go

