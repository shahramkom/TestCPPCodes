/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[IsCommandExecutable](@UserID int , @RecordGID VARCHAR(25))
RETURNS BIT
BEGIN
	DECLARE @RetVal BIT
	DECLARE @MyRecordVersion INT
	DECLARE @RcvRecordVersion INT
	SELECT @MyRecordVersion = dbo.GetVersionFromUserGID(@UserID)
	SELECT @RcvRecordVersion = dbo.GetVersionFromGID(@RecordGID)
	IF(@RcvRecordVersion > @MyRecordVersion)
	BEGIN
		SET @RetVal = 1
	END
	ELSE IF(@RcvRecordVersion = @MyRecordVersion)
	BEGIN
		DECLARE @MyRecordDateTime DATETIME
		DECLARE @RcvRecordDateTime DATETIME
		SELECT @MyRecordDateTime = dbo.GetDateTimeFromUserGID(@UserID)
		SELECT @RcvRecordDateTime = dbo.GetDateTimeFromGID(@RecordGID)
		IF(@RcvRecordDateTime > @MyRecordDateTime)
			SET @RetVal = 1
		ELSE
			SET @RetVal = 0
	END
	ELSE IF(@RcvRecordVersion < @MyRecordVersion)
	BEGIN
		SET @RetVal = 0
	END
	RETURN @RetVal
END
go

