/******************************************************************************************************************************************************/---------
CREATE FUNCTION dbo.GetLatestPriorityByRecordID(@TableName VARCHAR (50),@CurrentID INT)
RETURNS INT
BEGIN
	DECLARE @RetVal AS INT
	IF(@TableName = 'TUserGroups')
		SELECT @RetVal = MAX(GPriority) FROM TUserGroups WHERE UserID = @CurrentID
	ELSE IF(@TableName = 'TUserPolicySet')
		SELECT @RetVal = MAX(PolPriority) FROM TUserPolicySet WHERE UserID = @CurrentID
	ELSE IF(@TableName = 'TGroupPolicySet')
		SELECT @RetVal = MAX(PriorityOrder) FROM TGroupPolicySet WHERE GroupID = @CurrentID
	ELSE IF(@TableName = 'TUserTimeSet')
		SELECT @RetVal = MAX(TPriority) FROM TUserTimeSet WHERE UserID = @CurrentID
	ELSE IF(@TableName = 'TgroupTimeset')
		SELECT @RetVal = MAX(PriorityOrder) FROM TgroupTimeset WHERE GroupID = @CurrentID
	IF(@RetVal IS NULL)
		SET @RetVal = 1
	ELSE
		SET @RetVal = @RetVal + 1		
	RETURN @RetVal
END
go

