/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE USP_CheckDuplicateRecord
@TableName VARCHAR(50),
@TableIDFieldName VARCHAR(50),
@TableIDFieldValue INT,
@GroupIDFieldName VARCHAR(50),
@GroupIDFieldValue INT,
@Outputval INT OUTPUT
AS
BEGIN
	DECLARE @RecCount AS INT 

	DECLARE @ExecCommand AS NVARCHAR(MAX)
	SET @ExecCommand = ' SELECT @RecCount = COUNT(*) FROM ' + @TableName +
				       ' where (('+@TableIDFieldName+'='+CAST(@TableIDFieldValue AS VARCHAR(20))+') AND ('+
					   @GroupIDFieldName+'='+CAST(@GroupIDFieldValue AS VARCHAR(20))+'))'
	EXEC SP_EXECUTESQL  @ExecCommand
					  , N'@RecCount INT OUTPUT'
					  , @RecCount OUTPUT
	SELECT @Outputval = @RecCount
END
go

