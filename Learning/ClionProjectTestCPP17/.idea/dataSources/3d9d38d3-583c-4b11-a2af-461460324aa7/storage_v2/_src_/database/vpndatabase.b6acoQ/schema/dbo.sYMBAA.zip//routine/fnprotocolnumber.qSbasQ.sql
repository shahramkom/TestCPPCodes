
	CREATE FUNCTION [dbo].[fnProtocolNumber]
	(
		@ProtocolName VARCHAR(15),
		@TableProtocolNum  TINYINT
	)
	RETURNS TINYINT
	AS
	BEGIN
		IF(UPPER(@ProtocolName) ='ANY' )
			RETURN 0
		IF(UPPER(@ProtocolName) ='ICMP' )
			RETURN 1
		IF(UPPER(@ProtocolName) ='TCP' )
			RETURN 6
		IF(UPPER(@ProtocolName) ='EGP' )
			RETURN 8	
		IF(UPPER(@ProtocolName) ='UDP' )
			RETURN 17
		IF(UPPER(@ProtocolName) ='HMP' )
			RETURN 20
		IF(UPPER(@ProtocolName) ='XNS_IDP' )
			RETURN 22
		IF(UPPER(@ProtocolName) ='RDP' )
			RETURN 27
		IF(UPPER(@ProtocolName) ='ESP' )
			RETURN 50
		IF(UPPER(@ProtocolName) ='AH' )
			RETURN 51
		IF(UPPER(@ProtocolName) ='RVD' )
			RETURN 66
		IF(UPPER(@ProtocolName) ='RAW' )
			RETURN 255
		RETURN @TableProtocolNum 
	END
  go

