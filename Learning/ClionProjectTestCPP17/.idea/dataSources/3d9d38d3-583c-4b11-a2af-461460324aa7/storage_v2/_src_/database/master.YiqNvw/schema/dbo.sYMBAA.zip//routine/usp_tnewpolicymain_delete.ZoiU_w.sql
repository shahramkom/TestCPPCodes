
   CREATE PROCEDURE [dbo].[USP_TNewPolicyMain_Delete] 
   @ID  bigint
   AS
   BEGIN
	   DELETE FROM [dbo].[TNewPolicyMainTable]   WHERE ID = @ID
	   DELETE FROM [dbo].[TNewPoliciesDetails]   WHERE MainID = @ID
	   DELETE FROM [TNewPolicyGroupAssign] WHERE ModernPID = @ID
	   DELETE FROM [TNewPolicyUserAssign] WHERE  ModernPID = @ID
   END


   go

