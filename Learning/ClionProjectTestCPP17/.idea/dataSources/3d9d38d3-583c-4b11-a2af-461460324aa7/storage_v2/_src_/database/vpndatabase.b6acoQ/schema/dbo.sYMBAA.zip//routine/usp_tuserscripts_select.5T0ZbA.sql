
    CREATE PROCEDURE  [dbo].[USP_TUserscripts_Select]
        @UserID   int
    AS
    BEGIN
         SELECT  s.ScriptTitle FROM  TScript s inner join TUserscripts us on s.ScriptID = us.ScriptID
 
             WHERE us.UserID = @UserID
    END


    go

