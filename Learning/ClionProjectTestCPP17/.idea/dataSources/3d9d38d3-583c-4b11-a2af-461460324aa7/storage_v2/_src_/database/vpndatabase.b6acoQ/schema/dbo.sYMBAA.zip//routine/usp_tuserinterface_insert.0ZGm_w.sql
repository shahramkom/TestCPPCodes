
	Create PROCEDURE [dbo].[USP_TUserInterface_Insert]
		-- Add the parameters for the stored procedure here
		@InterfaceIDs as nvarchar(500),
		@UserID as int
	
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;
		declare @Statement as nvarchar(1000)
		declare @intFID as nvarchar(10)
		declare interface_Cursor cursor for select * from dbo.Splitfn(@interfaceIDs,'#')
		open interface_Cursor
		fetch next from interface_Cursor into @intFID
		while @@FETCH_STATUS = 0
		begin
		if(@intFID is not null)
		begin
			set @Statement = 'insert into TUserInterface (InterfaceID , userID) values ('
			set @Statement = isnull(@Statement ,'') + CONVERT(nvarchar(20),@intFID) + ',' + CONVERT(nvarchar(20),@UserID)+ ')'
			exec sp_executesql @Statement
		end
		fetch next from interface_Cursor into @intFID
		end
		CLOSE interface_Cursor;	
		DEALLOCATE interface_Cursor;
	END

  go

