

    CREATE PROCEDURE [dbo].[USP_GetUserSAP] 
    --@userID nvarchar(50),
    @GroupID nvarchar(50)
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;	
        select * from TGroup g inner join TGroupPolicySet r on g.GroupID = r.GroupId
        inner join TServerAccessPolicy SAP on SAP.PSID = r.PSID
        where g.GroupID = @GroupID  order by PriorityOrder, POrder
        
        
    END


    go

