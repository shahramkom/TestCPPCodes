


    CREATE PROCEDURE [dbo].[USP_SelectSysLogConnectionStatus]
    AS
    BEGIN
        SELECT * FROM TSysLogTCPConnectionStatus
    END

    go

