
    CREATE PROCEDURE [dbo].[USP_SelectGroupIDFromGroupName] 
        -- Add the parameters for the stored procedure here
            @groupName nvarchar(500)
    AS
    BEGIN
      SET NOCOUNT ON
      SELECT GroupID FROM TGroup where GroupName = @groupName
      END

    go

