
     CREATE PROCEDURE  [dbo].[USP_ActiveDirectory_Synch] 
        @Owner	 	int				
    AS
    BEGIN

        Declare @UserName			nvarchar(200)	
        Declare @AccountDisable		tinyInt			 
        Declare @FirstName nvarchar(200)				 
        Declare @LastName nvarchar(200)			 
        Declare @Company	 nvarchar(200)		 
        Declare @Office	 nvarchar(200)			 
        Declare @Province nvarchar(200)			
        Declare @Town	nvarchar(200)			
        Declare @Notes	 nvarchar(max)			  
        Declare @Email	 nvarchar(200)			  
        Declare @Cell	 nvarchar(50)			 
        Declare @PersonnelCode	 nvarchar(10)			  
        Declare @Phone	 nvarchar(200)			  
        Declare @NationalID	     nvarchar(10)	 
        Declare @Adress	 nvarchar(max)			 
        Declare @PostalCode	nvarchar(200)		

    Declare Ad_cursor Cursor 
     For
        Select [UserName],
        [AccountDisable],
        [FirstName],
        [LastName],
        [Company],
        [Office],
        [Province],
        [Town],
        [Notes],
        [Email],
        [Cell],
        [PersonnelCode],
        [Phone],
        [NationalID],
        [Adress],
        [PostalCode]
        FROM TADTempUser
        Where Exist_Status= 1 

    OPEN Ad_cursor

    FETCH NEXT FROM Ad_cursor 
    INTO @UserName,
        @AccountDisable,
        @FirstName,			 
        @LastName, 
        @Company, 
        @Office	, 
        @Province,
        @Town,	
        @Notes, 
        @Email, 
        @Cell, 
        @PersonnelCode, 
        @Phone, 
        @NationalID, 
        @Adress, 
        @PostalCode  

    WHILE @@FETCH_STATUS = 0
    BEGIN	
        Declare @UserIDT	int
        Declare @AccountDisableT	tinyInt				
        Declare @FirstNameT nvarchar(200)		
        Declare @LastNameT nvarchar(200)		
        Declare @CompanyT	 nvarchar(200)		
        Declare @OfficeT	 nvarchar(200)		
        Declare @ProvinceT nvarchar(200)		
        Declare @TownT	nvarchar(200)			
        Declare @NotesT	 nvarchar(max)			
        Declare @EmailT	 nvarchar(200)			
        Declare @CellT	 nvarchar(50)			
        Declare @PersonnelCodeT	 nvarchar(10)			
        Declare @PhoneT	 nvarchar(200)			
        Declare @NationalIDT	     nvarchar(10)		
        Declare @AdressT	 nvarchar(max)		
        Declare @PostalCodeT	nvarchar(200)	
        Declare @OwnerT		int

    ---------------------------------------------------------------------		
    ---------------------------------------------------------------------		
    SELECT 	
            @UserIDT = UserID,
            @AccountDisableT = AccountDisable,
            @FirstNameT = FirstName   ,
            @LastNameT = LastName	 ,
            @OfficeT = Office		 ,
            @CompanyT = Company	 ,
            @ProvinceT = Province	,
            @TownT = Town,
            @NotesT = Notes		 ,
            @EmailT = Email		 ,
            @CellT = Cell		 ,
            @PersonnelCodeT = PersonnelCode		 ,
            @PhoneT = Phone		 ,
            @NationalIDT= NationalID		 ,
            @AdressT= Adress		 ,
            @PostalCodeT = PostalCode, 
            @OwnerT=[Owner]
            FROM TUser
        
            WHERE UserName=@UserName 
    -----------------------------------------------------------------------		
    -----------------------------------------------------------------------						
        IF(@Owner=@OwnerT)
    BEGIN
    
        Declare @description nvarchar(max)
        SET @description = ''

        Declare  @AccountStatus  nvarchar(10)
        SET @AccountStatus= 'False'	
        IF(@AccountDisable != @AccountDisableT)
        BEGIN
            IF (CAST(@AccountDisable AS nvarchar(10))=1)
                SET @AccountStatus = 255
            SET @description = @description+';AccountDisable='+ @AccountStatus
        END
    
    
        IF(isnull(@FirstName,'NULL')!=isnull(@FirstNameT,'NULL'))
            SET @description = @description+';FirstName='+ isnull(@FirstName,'NULL')
        IF(isnull(@LastName,'NULL')!=isnull(@LastNameT,'NULL'))
            SET @description = @description+';LastName='+ isnull(@LastName,'NULL')
        IF(isnull(@Office,'NULL')!=isnull(@OfficeT,'NULL'))
            SET @description = @description+';Office='+ isnull(@Office,'NULL')
        IF(isnull(@Company,'NULL')!=isnull(@CompanyT,'NULL'))
            SET @description = @description+';Company='+ isnull(@Company,'NULL')
        IF(isnull(@Province,'NULL')!=isnull(@ProvinceT,'NULL'))
            SET @description = @description+';Province='+ isnull(@Province,'NULL')
        IF(isnull(@Town,'NULL')!=isnull(@TownT,'NULL'))
            SET @description = @description+';Town='+ isnull(@Town,'NULL')
        IF(isnull(@Notes,'NULL')!=isnull(@NotesT,'NULL'))
            SET @description = @description+';Notes='+ isnull(@Notes,'NULL')
        IF(isnull(@Email,'NULL')!=isnull(@EmailT,'NULL'))
            SET @description = @description+';Email='+ isnull(@Email,'NULL')
        IF(isnull(@Cell,'NULL')!=isnull(@CellT,'NULL'))
            SET @description = @description+';Cell='+ isnull(@Cell,'NULL')
        IF(isnull(@PersonnelCode,'NULL')!=isnull(@PersonnelCodeT,'NULL'))
            SET @description = @description+';PersonnelCode='+ isnull(@PersonnelCode,'NULL')
        IF(isnull(@Phone,'NULL')!=isnull(@PhoneT,'NULL'))
            SET @description = @description+';Phone='+ isnull(@Phone,'NULL')
        IF(isnull(@NationalID,'NULL')!=isnull(@NationalIDT,'NULL'))
            SET @description = @description+';NationalID='+ isnull(@NationalID,'NULL')
        IF(isnull(@Adress,'NULL')!=isnull(@AdressT,'NULL'))
            SET @description = @description+';Adress='+ isnull(@Adress,'NULL')
        IF(isnull(@PostalCode,'NULL')!= isnull(@PostalCodeT,'NULL'))
            SET @description = @description+';PostalCode='+ isnull(@PostalCode,'NULL')

    
    ---------------------------------------------------------------------		
    ---------------------------------------------------------------------						
        
        IF (@description!= '')
        BEGIN

                UPDATE  TUser 
            SET
        
            AccountDisable = @AccountDisable	 ,
            FirstName = @FirstName   ,
            LastName = @LastName	 ,
            Office = @Office		 ,
            Company = @Company	 ,
            Province=@Province	,
            Town=@Town			,
            Notes = @Notes		 ,
            Email = @Email		 ,
            Cell = @Cell		 ,
            PersonnelCode = @PersonnelCode		 ,
            Phone = @Phone		 ,
            NationalID = @NationalID		 ,
            Adress = @Adress		 ,
            PostalCode = @PostalCode , 
            [Owner] = @Owner		 		 	
        
            WHERE UserName=@UserName AND [Owner] = @Owner
    ---------------------------------------------------------------------		
    ---------------------------------------------------------------------						
    
            Declare	 @User	int
            Declare  @RowID		nvarchar (1000)
            Declare  @operationDate	nvarchar(10)
            Declare  @operationTime	 nvarchar(8)
            Declare  @Month nvarchar(2)
            Declare	 @Day nvarchar(2)
            Declare  @Hours nvarchar(2)
            Declare  @Minute nvarchar(2)
            Declare	 @Second nvarchar(2)

            
            SET @Month = CAST(DATEPART(month,GETDATE()) AS nvarchar(2)) 
            IF (@Month<10)
                SET @Month = '0'+@Month 
        
            SET @Day =CAST(DATEPART(day,GETDATE())AS nvarchar(2))
            IF(@Day <10)
                SET @Day= '0'+@Day

            SET @Hours =CAST(DATEPART(hour,GETDATE()) AS nvarchar(2))
            IF(@Hours <10)
                SET @Hours= '0'+@Hours

            SET @Minute =CAST(DATEPART(minute,GETDATE()) AS nvarchar(2))
            IF(@Minute <10)
                SET @Minute= '0'+@Minute

            SET @Second =CAST(DATEPART(second,GETDATE()) AS nvarchar(2))
            IF(@Second <10)
                SET @Second= '0'+@Second



            SET @description = substring(@description , 2 , 999)

            SET @User = @Owner+1
            SET @RowID = 'UserID='+CAST(@UserIDT AS nvarchar(10) )+ ';UserName='+@UserName		
            SET @operationDate = CAST(DATEPART(year ,GETDATE())AS nvarchar(4))+'/'
                +@Month+'/'
                +@Day
                    
            SET @operationTime =@Hours+':'+@Minute+':'+@Second
        

            EXEC UPS_Insert_logs_Manger @User ,'Table','UPDATE','User',@RowID ,@description,@operationDate,@operationTime
    
        END
    END
    ---------------------------------------------------------------------		
    ---------------------------------------------------------------------						

        FETCH NEXT FROM Ad_cursor 
    INTO @UserName,
        @AccountDisable,
        @FirstName,			 
        @LastName, 
        @Company, 
        @Office	, 
        @Province,
        @Town,	
        @Notes, 
        @Email, 
        @Cell, 
        @PersonnelCode, 
        @Phone, 
        @NationalID, 
        @Adress, 
        @PostalCode  
    
    END

    CLOSE Ad_cursor;
    DEALLOCATE Ad_cursor;


    END

     go

