
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesServices_Select] 
   AS
   BEGIN
	SELECT [ID]
      ,[ProtocolName]
      ,[ProtocolType]
      ,[SourcePort]
      ,[DestinationPort]
	  ,[IconIndex]
	FROM [dbo].[TNewPoliciesServices]
   END

   go

