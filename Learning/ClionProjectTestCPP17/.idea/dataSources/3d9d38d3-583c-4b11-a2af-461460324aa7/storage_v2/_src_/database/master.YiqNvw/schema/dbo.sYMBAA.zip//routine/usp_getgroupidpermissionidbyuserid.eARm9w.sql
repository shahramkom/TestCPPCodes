CREATE PROCEDURE [dbo].[USP_GetGroupIDPermissionIDByUserID] 
	@UserID bigint
AS
BEGIN
	select TUserGroups.GroupID,TUser.Permission_ID from TUserGroups inner join TUser on TUserGroups.UserID=TUser.UserID where TUser.UserID = @UserID  order by GPriority 
END
go

