
	CREATE PROCEDURE [dbo].[USP_CopyUser_PolicyAssignments] 
    @OldUserID  bigint,
	@NewUserID  bigint
   AS
   BEGIN
		INSERT INTO TUserPolicySet (UserID	 , PSID,PolPriority)
		SELECT 	@NewUserID	 ,PSID	,PolPriority 
		FROM TUserPolicySet WHERE UserID = @OldUserID
   END

  go

