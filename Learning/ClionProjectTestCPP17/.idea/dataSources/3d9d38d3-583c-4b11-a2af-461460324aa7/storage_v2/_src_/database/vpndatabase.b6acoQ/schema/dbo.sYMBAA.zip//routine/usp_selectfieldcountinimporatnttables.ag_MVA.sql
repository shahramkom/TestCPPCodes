
		CREATE PROCEDURE usp_selectFieldCountInImporatntTables
		AS
		BEGIN
			SELECT COUNT( USR.userid) userCount FROM TUser USR 
			SELECT COUNT(GRP.GroupID) grpCount FROM TGroup GRP 
			SELECT COUNT(pSet.PSID) PolicySetCount FROM  TPolicySet pSet
			SELECT COUNT(GrpPolSet.PSID) GroupPolicyCount FROM TGroupPolicySet GrpPolSet
			SELECT COUNT(UsrPolSet.PSID) UserPolicyCount FROM TUserPolicySet UsrPolSet
			SELECT COUNT(SAP.PolicyID) SAPCount FROM TServerAccessPolicy SAP
			SELECT COUNT(UFP.UFPID) UFPCount FROM TUserFirewallPolicy UFP
		END

    go

