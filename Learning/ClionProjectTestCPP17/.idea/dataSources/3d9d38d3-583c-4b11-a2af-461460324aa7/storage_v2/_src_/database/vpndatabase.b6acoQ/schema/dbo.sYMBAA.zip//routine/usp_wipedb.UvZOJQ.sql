CREATE PROCEDURE [dbo].[USP_WipeDB]
    with recompile
AS
BEGIN
    EXEC USP_DisableAllTriggers
    EXEC dbo.USP_ChangeReplicationState 1
    
    DELETE FROM		managerLog
    DELETE FROM		sAuthLog
    DELETE FROM		settingServerLog
    DELETE FROM		TSettingLog
    DELETE FROM		TAllLogs    
    
    EXEC            USP_WipeReplicationLog
    DELETE FROM     RepServersState
    DELETE FROM     RepServersGroups
    DELETE FROM     RepConfig
	EXEC            USP_DropReplogTable

    DELETE FROM		TNewPolicyMainTable
	DELETE FROM		TNewPoliciesDetails
	DELETE FROM		TNewPolicyGroupAssign
	DELETE FROM		TNewPolicyUserAssign

	DELETE  FROM	HealthCheckUserAssign
	DELETE  FROM	HealthCheckGroupAssign
	DELETE  FROM	HealthCheckRules
	DELETE  FROM	HealthCheckProfiles
    
    DELETE FROM		TUserKeya
    DELETE FROM     TUserGroups
	DELETE FROM     TUserPolicySet
	DELETE FROM     TUserDNS
	DELETE FROM     TUserTimeSet 
    DELETE FROM		TUserInterface

    DELETE FROM     TGroupScript
	DELETE FROM     TGroupTimeSet
	DELETE FROM     TGroupDNS
    DELETE FROM		TGroupPolicySet where (GroupID in (select GroupID from TGroupPolicySet))
    DELETE FROM		TGroupInterface

    DELETE FROM		TSAPTempTable where (PolicyID in (select PolicyID from TSAPTempTable))
    DELETE FROM		TADTempUser where (UserName in (select UserName from TADTempUser))
    DELETE FROM		TTempUserFirewallPolicy where (UFPID in (select UFPID from TTempUserFirewallPolicy))
    DELETE FROM		TTempPolicySet where (PSID in (select PSID from TTempPolicySet))
    DELETE FROM		TTempDNS where (DNSID in (select DNSID from TTempDNS))
    DELETE FROM		TempUser where (UserID in (select UserID from TempUser))
    DELETE FROM		TTempGroup where (GroupID in (select GroupID from TTempGroup))
    
    DELETE FROM		TUserFirewallPolicy where (UFPID in (select UFPID from TUserFirewallPolicy))
    DELETE FROM		TServerAccessPolicy where (Policyid in (select Policyid from TServerAccessPolicy))
    DELETE FROM		TPolicySet where (PSID in (select PSID from TPolicySet))
    DELETE FROM		SpecialPermission
    DELETE FROM		TScript
    DELETE FROM		TDNS 
    DELETE FROM		TInterface
    DELETE FROM		TTimeRole where (TRID in (select TRID from TTimeRole))
    DELETE FROM     TUser where (userid in (select userid from TUser))
    DELETE FROM		Tgroup
END
/*************************************************************************************************************************************/
go

