
    create PROCEDURE  [dbo].[USP_PolicySet_Select] 
    
        @GroupID int =null
    with recompile
    AS

    BEGIN
            select ps.* from  TPolicySet as ps right join TGroupPolicySet as gps on ps.PSID = gps.PSID  where (GroupID = @GroupID OR   @GroupID IS NULL OR  @GroupID=0) 
            order by PriorityOrder asc
            --SELECT  * from  TPolicySet where  PSID IN
            --( SELECT PSID FROM  TGroupPolicySet   WHERE GroupID = @GroupID OR   @GroupID IS NULL OR  @GroupID=0 order by PriorityOrder asc)
    END
    go

