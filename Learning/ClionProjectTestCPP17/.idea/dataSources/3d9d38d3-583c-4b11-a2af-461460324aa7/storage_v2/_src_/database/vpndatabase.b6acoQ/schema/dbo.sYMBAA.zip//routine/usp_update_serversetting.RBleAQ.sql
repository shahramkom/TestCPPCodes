    CREATE PROCEDURE [dbo].[USP_Update_ServerSetting]
         @nTotalUser int,
		 @nOnlineUser int
        ,@sVirtualIP nvarchar(50)
        ,@sVirtualIPMask nvarchar(50)
        ,@serverName nvarchar(50)
        ,@DefaultMasterPIN nvarchar(200)
        ,@DefaultUnBlockPIN nvarchar(200)
        ,@DefaultUserPIN nvarchar(200)
		,@KIPSUdpPort int
		,@UsfUserCount int
		,@AllowH2HPolicies int
		,@LastTunnelID int
		,@isSlaveServer int = 0
		,@LicenseCreationDate varchar(50)
		/* Keyhan 5 License Features */
		,@NewLicenseVersion int = 0
		,@ProductType int
		,@licenseID nvarchar(13) = "0"
		,@licenseServerSerial nvarchar(13) = 'none'
		,@androidSupport int = -1
		,@isDemo int = -1
		,@healthCheck int = -1
		,@standardToken int = -1
		,@ExpireDate nvarchar(50) = ''
		
    AS
    BEGIN
        if exists(select * from TSetting where [Property] = N'TotalUser')	
            update TSetting set [value] = @nTotalUser where [Property] = N'TotalUser'
        else
            insert into TSetting (Property,value) values('TotalUser' , @nTotalUser)

		if exists(select * from TSetting where [Property] = N'TotalOnlineUser')	
            update TSetting set [value] = @nOnlineUser where [Property] = N'TotalOnlineUser'
        else
            insert into TSetting (Property,value) values('TotalOnlineUser' , @nOnlineUser)
    
        if exists(select * from TSetting where [Property] = N'VirtualIP')	
            update TSetting set [value] = @sVirtualIP where [Property] = N'VirtualIP'
        else
            insert into TSetting (Property,value) values('VirtualIP' , @sVirtualIP)

        if exists(select * from TSetting where [Property] = N'VirtualIPMask')	
            update TSetting set [value] = @sVirtualIPMask where [Property] = N'VirtualIPMask'
        else
            insert into TSetting (Property,value) values('VirtualIPMask' , @sVirtualIPMask)
    
        if exists(select * from TSetting where [Property] = N'ServerName')	
            update TSetting set [value] = @serverName where [Property] = N'ServerName'
        else
            insert into TSetting (Property,value) values('ServerName' , @serverName)

        if exists(select * from TSetting where [Property] = N'DefaultUserPIN' and   @DefaultUserPIN != NULL)	
            update TSetting set [value] = @DefaultUserPIN where [Property] = N'DefaultUserPIN'
        else if(not(exists(select * from TSetting where [Property] = N'DefaultUserPIN')))
            insert into TSetting (Property,value) values('DefaultUserPIN' , @DefaultUserPIN)

		if exists(select * from TSetting where [Property] = N'KIPSUdpPort')	
            update TSetting set [value] = @KIPSUdpPort where [Property] = N'KIPSUdpPort'
        else
            insert into TSetting (Property,value) values('KIPSUdpPort' , @KIPSUdpPort)

        if exists(select * from TSetting where [Property] = N'DefaultMasterPIN' and @DefaultMasterPIN != NULL)	
            update TSetting set [value] = @DefaultMasterPIN where [Property] = N'DefaultMasterPIN'
        else if(not(exists(select * from TSetting where [Property] = N'DefaultMasterPIN')))
            insert into TSetting (Property,value) values('DefaultMasterPIN', @DefaultMasterPIN)

        if exists(select * from TSetting where [Property] = N'DefaultUnBlockPIN' and @DefaultUnBlockPIN != NULL)	
            update TSetting set [value] = @DefaultUnBlockPIN where [Property] = N'DefaultUnBlockPIN'
        else if(not(exists(select * from TSetting where [Property] = N'DefaultUnBlockPIN')))
            insert into TSetting (Property,value) values('DefaultUnBlockPIN' , @DefaultUnBlockPIN)

        if exists(select * from TSetting where [Property] = N'UsfUserCount')	
            update TSetting set [value] = @UsfUserCount where [Property] = N'UsfUserCount'
        else
            insert into TSetting (Property,value) values('UsfUserCount' , @UsfUserCount)

		if exists(select * from TSetting where [Property] = N'AllowH2HPolicies')	
            update TSetting set [value] = @AllowH2HPolicies where [Property] = N'AllowH2HPolicies'
        else
            insert into TSetting (Property,value) values('AllowH2HPolicies' , @AllowH2HPolicies)

		if not exists(select * from TSetting where [Property] = N'LastTunnelID')	
            insert into TSetting (Property,value) values('LastTunnelID' , @LastTunnelID)

		if exists(select * from TSetting where [Property] = N'isSlaveServer')	
            update TSetting set [value] = @isSlaveServer where [Property] = N'isSlaveServer'
        else
            insert into TSetting (Property,value) values('isSlaveServer' , @isSlaveServer)

		if exists(select * from TSetting where [Property] = N'LicenseCreationDate')
            update TSetting set [value] = @LicenseCreationDate where [Property] = N'LicenseCreationDate'
        else
            insert into TSetting (Property,value) values('LicenseCreationDate' , @LicenseCreationDate)

		if exists(select * from TSetting where [Property] = N'NewLicenseVersion')
            update TSetting set [value] = @NewLicenseVersion where [Property] = N'NewLicenseVersion'
        else
            insert into TSetting (Property,value) values('NewLicenseVersion' , @NewLicenseVersion)

			if exists(select * from TSetting where [Property] = N'ProductType')
            update TSetting set [value] = @ProductType where [Property] = N'ProductType'
        else
            insert into TSetting (Property,value) values('ProductType' , @ProductType)

		if exists(select * from TSetting where [Property] = N'LicenseServerSerial')	
            update TSetting set [value] = @licenseServerSerial where [Property] = N'LicenseServerSerial'
        else
            insert into TSetting (Property,value) values('LicenseServerSerial' , @licenseServerSerial)

		if exists(select * from TSetting where [Property] = N'LicenseID')
            update TSetting set [value] = @licenseID where [Property] = N'LicenseID'
        else
            insert into TSetting (Property,value) values('LicenseID' , @licenseID)

		if exists(select * from TSetting where [Property] = N'AndroidSupport')
            update TSetting set [value] = @androidSupport where [Property] = N'AndroidSupport'
        else
            insert into TSetting (Property,value) values('AndroidSupport' , @androidSupport)

		if exists(select * from TSetting where [Property] = N'isDemo')
            update TSetting set [value] = @isDemo where [Property] = N'isDemo'
        else
            insert into TSetting (Property,value) values('isDemo' , @isDemo)
		if exists(select * from TSetting where [Property] = N'HealthCheck')
            update TSetting set [value] = @healthCheck where [Property] = N'HealthCheck'
        else
            insert into TSetting (Property,value) values('HealthCheck' , @healthCheck)
		if exists(select * from TSetting where [Property] = N'StandardToken')
            update TSetting set [value] = @standardToken where [Property] = N'StandardToken'
        else
            insert into TSetting (Property,value) values('StandardToken' , @standardToken)			
		
		if exists(select * from TSetting where [Property] = N'ExpireDate')
            update TSetting set [value] = @ExpireDate where [Property] = N'ExpireDate'
        else
            insert into TSetting (Property,value) values('ExpireDate' , @ExpireDate)			
    END
    go

