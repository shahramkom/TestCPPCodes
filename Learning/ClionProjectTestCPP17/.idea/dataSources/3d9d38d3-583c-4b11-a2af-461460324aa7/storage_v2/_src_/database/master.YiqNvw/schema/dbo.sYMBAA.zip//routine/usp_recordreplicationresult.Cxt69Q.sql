CREATE PROCEDURE [dbo].[USP_RecordReplicationResult]
    @serversID TINYINT,
    @lastSuccessfulRun VARCHAR(20) = NULL,
	@runningState TINYINT = 255 -- Unknow
AS
BEGIN
    IF EXISTS(SELECT * FROM dbo.RepConfig WHERE @serversID = ServerID)
    BEGIN
        IF EXISTS(SELECT * FROM dbo.RepServersState WHERE ServerID = @serversID)
        BEGIN
            IF (@lastSuccessfulRun IS NULL)
                SELECT @lastSuccessfulRun = LastSuccessfulRun FROM dbo.RepServersState
            UPDATE dbo.RepServersState SET LastSuccessfulRun = @lastSuccessfulRun, RunningState = @runningState WHERE ServerID = @serversID
            IF(@serversID = 1 AND (@runningState = 1 OR @runningState = 2 OR @runningState = 4 OR @runningState = 255))
                UPDATE dbo.RepServersState SET RunningState = 1 WHERE ServerID <> @serversID
        END
        ELSE
        BEGIN
            IF (@lastSuccessfulRun IS NULL)
                SET @lastSuccessfulRun = CONVERT([nvarchar](20),getdate(),(20))

            INSERT INTO dbo.RepServersState(ServerID, LastSuccessfulRun, RunningState )
            VALUES  ( @serversID, @lastSuccessfulRun, @runningState )
        END
    END
END
go

