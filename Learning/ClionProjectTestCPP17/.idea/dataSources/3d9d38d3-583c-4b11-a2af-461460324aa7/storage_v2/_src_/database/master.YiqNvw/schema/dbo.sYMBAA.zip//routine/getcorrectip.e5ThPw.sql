/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetCorrectIP](@OperateType VARCHAR(20),@VIP VARCHAR(20))
RETURNS VARCHAR(20)
AS
BEGIN
	DECLARE @RetVIP VARCHAR(20)
	
	DECLARE @ICurrentVIP BIGINT
	DECLARE @ICurrentVIPMaskB BIGINT
	DECLARE @ICurrentVIPMaskL BIGINT
	DECLARE @MinIP AS BIGINT 
	DECLARE @MaxIP AS BIGINT 

	SELECT @ICurrentVIP      = dbo.[GetCurrentVIPHead]()
	SELECT @ICurrentVIPMaskB = dbo.[GetCurrentVIPMaskBig]()
	SELECT @ICurrentVIPMaskL = dbo.[GetCurrentVIPMaskLittle]()
	SELECT @MinIP            = dbo.[GetVIPMinIP](@ICurrentVIP,@ICurrentVIPMaskB)
	SELECT @MaxIP            = dbo.[GetVIPMaxIP](@ICurrentVIP,@ICurrentVIPMaskL)

	SELECT @RetVIP = dbo.[IPCorrector](@OperateType, @VIP ,@ICurrentVIP , @MinIP,@MaxIP)

	RETURN @RetVIP
END
go

