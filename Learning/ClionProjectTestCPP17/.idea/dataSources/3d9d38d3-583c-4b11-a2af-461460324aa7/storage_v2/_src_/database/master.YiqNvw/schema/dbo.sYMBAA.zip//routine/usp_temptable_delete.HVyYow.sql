


    Create PROCEDURE [dbo].[USP_TempTable_Delete]

        
    AS
    BEGIN	
        DELETE FROM [VPNDataBase].[dbo].[TTempDNS]
        DELETE FROM [VPNDataBase].[dbo].[TTempGroup]
        DELETE FROM [VPNDataBase].[dbo].[TTempPolicySet]
        DELETE FROM [VPNDataBase].[dbo].[TTempUserFirewallPolicy]       
    END

    go

