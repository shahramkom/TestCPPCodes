

    CREATE PROCEDURE [dbo].[USP_TNewPolicyMain_ChangeDetailID]
        @MainID  bigint,
        @DetailID int
    AS
    BEGIN

        UPDATE TNewPolicyMainTable 	
        SET
        AdvancedDetailID=@DetailID
        where 
        ID=@MainID
    END

    go

