
CREATE PROCEDURE [dbo].[Sync_GetReplicationGroups] 
    -- Add the parameters for the stored procedure here
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    -- Insert statements for procedure here
    Select GroupName from VPNDataBase..TGroup
END
go

