
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesDetails_Insert] 
		@MainID bigint ,
		@AllowNat  bit,
		@NatIP nvarchar(20),
        @VirtualIPType tinyint,
        @VirtualIPValue nvarchar(20),
        @SourceTunnelType  tinyint,
        @SourceTunnelValue  nvarchar(50),
        @DestinationTunnelType tinyint,
        @DestinationTunnelValue nvarchar(50)
   AS
   BEGIN
   DECLARE @lastID as bigint
   select @lastID = MainID from TNewPoliciesDetails WHERE MainID = @MainID
   if(@lastID > 0)
   BEGIN
	UPDATE [dbo].[TNewPoliciesDetails]
	   SET [AllowNat] = @AllowNat,
		   [NatIP] = @NatIP,
		   [VirtualIPType] = @VirtualIPType,
		   [VirtualIPValue] = @VirtualIPValue,
		   [SourceTunnelType] = @SourceTunnelType,
		   [SourceTunnelValue] = @SourceTunnelValue,
		   [DestinationTunnelType] = @DestinationTunnelType,
		   [DestinationTunnelValue] = @DestinationTunnelValue
	 WHERE MainID = @MainID
	 SELECT ID FROM TNewPoliciesDetails WHERE MainID = @MainID
   END
   ELSE
   BEGIN
	INSERT INTO [dbo].[TNewPoliciesDetails]
           ([MainID]
		   ,[AllowNat]
		   ,[NatIP]
           ,[VirtualIPType]
           ,[VirtualIPValue]
           ,[SourceTunnelType]
           ,[SourceTunnelValue]
           ,[DestinationTunnelType]
           ,[DestinationTunnelValue])
     VALUES
           ( @MainID ,
			 @AllowNat  ,
			 @NatIP,
			 @VirtualIPType ,
			 @VirtualIPValue ,
			 @SourceTunnelType  ,
			 @SourceTunnelValue ,
			 @DestinationTunnelType ,
			 @DestinationTunnelValue )
	SELECT @@IDENTITY
   END
   END

   go

