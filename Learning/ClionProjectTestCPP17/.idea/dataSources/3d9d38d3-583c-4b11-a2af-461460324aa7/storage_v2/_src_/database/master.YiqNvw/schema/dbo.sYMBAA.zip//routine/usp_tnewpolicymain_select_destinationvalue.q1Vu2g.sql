
    CREATE PROCEDURE [dbo].[USP_TNewPolicyMain_Select_DestinationValue] 
    @MainID  bigint
   AS
   BEGIN
		DECLARE @DestinationType as tinyint
		DECLARE @DestinationValue as nvarchar(50)
		SELECT @DestinationType = DestinationTunnelType , @DestinationValue = DestinationTunnelValue FROM TNewPolicyMainTable  WHERE ID = @MainID
		IF(@DestinationType = 4) --ANY TYPE
		BEGIN
			SELECT 'Any'
		END
		ELSE IF(@DestinationType = 0) --USER TYPE
		BEGIN
			if(@DestinationValue != 'UseRs:AnY')
				select USERNAME,SubNetIP from TUSER WHERE USERID = cast(@DestinationValue as int)
			else
				Select 'UseRs:AnY'
		END
		ELSE IF(@DestinationType = 1) --GROUP TYPE
		BEGIN
			select GROUPNAME from TGROUP WHERE GROUPID = cast(@DestinationValue as int)
		END
		ELSE
		BEGIN
			SELECT @DestinationValue
		END
   END

    go

