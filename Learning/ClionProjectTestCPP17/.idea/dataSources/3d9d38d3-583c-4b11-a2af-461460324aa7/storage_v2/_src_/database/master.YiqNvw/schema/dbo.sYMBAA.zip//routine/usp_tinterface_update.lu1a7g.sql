
	create PROCEDURE [dbo].[USP_TInterface_Update]
		-- Add the parameters for the stored procedure here
		@InterfaceID as int,
		@InterfaceName as nvarchar(50),
		@InterfaceIPAddress as nvarchar(20),
		@ID as int
	
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		declare @Statement as nvarchar(1000)
	
		set @Statement = 'update TInterface set '
		if(@InterfaceID is not null)
			set @Statement = isnull(@Statement ,'') + ' InterfaceID = ''' + convert(nvarchar(20),@InterfaceID) + ''','
		if(@InterfaceName is not null)
			set @Statement = isnull(@Statement ,'') + ' InterfaceName = ''' + @InterfaceName	+''','
		if(@InterfaceIPAddress is not null)
			set @Statement = isnull(@Statement ,'') + ' InterfaceIPAddress = ''' + @InterfaceIPAddress +''','
		set @Statement = SUBSTRING(@Statement ,1,len(@Statement) -1)
		set @Statement = @Statement + ' where (ID = ' + convert(nvarchar(20),@ID) + ')' 
		exec sp_executesql @Statement
	END

  go

