CREATE PROCEDURE [dbo].[USP_GetAllSAPByPSID] 
	@PSID int
AS
BEGIN
	select * from TServerAccessPolicy where PSID = @PSID and Status = 1 order by POrder
END
go

