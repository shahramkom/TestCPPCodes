CREATE PROCEDURE [dbo].[sp_AlternateModuleInsert] 
	@ProfileID int,
    @ModuleSerial nvarchar(16),
	@ModuleType	tinyint,
	@PIN	nvarchar(16),
	@UserName nvarchar(150)
AS
	BEGIN
	declare @ProgramDate as nvarchar(20)
	select @ProgramDate = CONVERT(nvarchar(20),GETDATE(),20)
	INSERT INTO [dbo].[AlternateModules]
           ([ProfileID]
           ,[ProgramDate]
           ,[ModuleSerial]
           ,[ModuleType]
           ,[PIN]
		   ,[UserName])
     VALUES
           (@ProfileID,
            @ProgramDate, 
            @ModuleSerial, 
            @ModuleType,
            @PIN,
			@UserName) 
	END
go

