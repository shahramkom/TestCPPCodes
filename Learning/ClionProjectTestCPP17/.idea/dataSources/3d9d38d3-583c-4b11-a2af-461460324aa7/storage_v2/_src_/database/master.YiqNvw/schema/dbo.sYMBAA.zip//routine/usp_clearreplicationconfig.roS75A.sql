CREATE PROCEDURE [dbo].[USP_ClearReplicationConfig]
AS
BEGIN
	DELETE FROM RepServersGroups
	DELETE FROM RepConfig
END
go

