/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_InsertUserChangesToRelatedReplog] 
	@RecordID AS INT ,
	@sActionType AS VARCHAR(50),
	@ReplogTableName as VARCHAR(30),
	@Query AS NVARCHAR(MAX),
	@NewGID as VARCHAR(25) = NULL,
	@AssignGrpIDs as VARCHAR(MAX) = NULL, 
	@AssignUsrIDs as VARCHAR(MAX) = NULL
AS
BEGIN
	IF(@sActionType = 'Delete-TUserGroups' OR @sActionType = 'Update-TUser' OR @sActionType = 'Update-TUserGroups' OR @sActionType = 'Update-TUserGroupsKeyA')
	 SET @AssignGrpIDs = NULL
	DECLARE @statement NVARCHAR(MAX)
	SET @Query = 'SELECT '+CAST(@RecordID AS VARCHAR(20)) +' as RecordID, ''' 
	+ CAST(@sActionType AS VARCHAR(50)) +''' AS ActionType, N'''+ @Query +''' as Command, '''+ ISNULL(@NewGID, '') +''' as GID, '''+ ISNULL(@AssignGrpIDs, '') + ''' As AssignedGrpIDs, ''' + ISNULL(@AssignUsrIDs, '') + ''' As AssignedUsrIDs'
	CREATE TABLE #tmpTable (RecordID INT, ActionType VARCHAR(50), Command NVARCHAR(MAX), GID varchar(25),AssignedGrpIDs varchar(MAX),AssignedUsrIDs varchar(MAX))
	INSERT INTO #tmpTable (RecordID, ActionType, Command, GID, AssignedGrpIDs, AssignedUsrIDs) EXEC sp_executesql @Query
	SET @statement = 'insert  '+@ReplogTableName+'(RecordID,ActionType,Command,GID,AssignedGrpIDs, AssignedUsrIDs) select * from #tmpTable'
	exec sp_executesql @statement
	DROP TABLE #tmpTable
END

go

