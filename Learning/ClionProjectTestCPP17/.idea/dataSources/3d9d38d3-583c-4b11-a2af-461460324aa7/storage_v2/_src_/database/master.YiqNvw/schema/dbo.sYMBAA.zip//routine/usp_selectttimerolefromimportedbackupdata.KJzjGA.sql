
        CREATE PROCEDURE [dbo].[USP_SelectTTimeRoleFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	

    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

    declare @TimeSetName nvarchar(200) , @InsertScript nvarchar(4000)
    declare @TRID int 
     Declare TTimeRole_cursor Cursor FAST_FORWARD
        For
        Select 
                  TimeSetName,[output],TRID 
            FROM tbl_InsertGroupScript   
            where tableName = 'TTimeRole'
            OPEN TTimeRole_cursor

    FETCH NEXT FROM TTimeRole_cursor
    INTO @TimeSetName,@InsertScript,@TRID

    WHILE @@FETCH_STATUS = 0
    begin 
                 
            
        if(exists (select * from TTimeRole where TimeSetName = @TimeSetName  or TRID = @TRID ))
            Begin
            
                if(@Replace = 1)
                    begin
                
                    Delete from TTimeRole   where TRID = @TRID	or TimeSetName = @TimeSetName
                    
                    end
            End	
        
            BEGIN TRY
            
                SET IDENTITY_INSERT TTimeRole ON
                exec sp_executesql @InsertScript	
                SET IDENTITY_INSERT TTimeRole OFF		
            END TRY
            BEGIN CATCH
				 INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,getdate()
			   ,@InsertScript
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectTTimeRoleFromImportedBackupData')
            END CATCH  	
            FETCH NEXT FROM TTimeRole_cursor 
            INTO @TimeSetName,@InsertScript,@TRID
    
        end
        CLOSE TTimeRole_cursor;
        DEALLOCATE TTimeRole_cursor;
    
    
                
    END

        go

