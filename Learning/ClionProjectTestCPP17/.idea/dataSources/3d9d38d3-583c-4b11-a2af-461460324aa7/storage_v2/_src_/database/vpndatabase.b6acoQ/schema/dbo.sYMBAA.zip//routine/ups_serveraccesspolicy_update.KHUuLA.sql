
    CREATE PROCEDURE [dbo].[UPS_ServerAccessPolicy_Update] 

		@PolicyID int,
		@PSID int,
		@NetworkIP nvarchar(15),
		@NetworkMask nvarchar(15),
		@Protocol nvarchar(10),
		@Port nvarchar(50),   
        @PAction nvarchar(50),
		@Authentication char(200) =NULL,
		@Encryption nchar(200) =NULL,
		@Compression	bit = 0,
		@IP_RangeType	nvarchar(20)='Network IP',
		@status			bit =1,
		@ExpirationDate	nvarchar(20),
		@POrder  int,
		@PolicyName      varchar(15) = NULL,
	    @PolicyDescription nvarchar(100)= NULL
    AS

    BEGIN
    SET NOCOUNT ON;
        declare @LastModifyDateTime as nvarchar(20)
		select @LastModifyDateTime = CONVERT(nvarchar(20),GETDATE(),20)
        UPDATE [VPNDataBase].[dbo].[TServerAccessPolicy]           
            SET           
               NetworkIP = @NetworkIP, 
               NetworkMask = @NetworkMask, 
               Protocol = @Protocol,
               Port = @Port, 
               PAction = @PAction, 
               Authentication = @Authentication, 
               Encryption = @Encryption,
               Compression = @Compression,
			   IP_RangeType = @IP_RangeType,				
			   LastModifiedTime = @LastModifyDateTime,
			   status = @status,
			   ExpireDate = @ExpirationDate,
			   POrder=@POrder,
			   PolicyName = @PolicyName,
			   PolicyDescription= @PolicyDescription    
                WHERE (PSID = @PSID AND PolicyID = @PolicyID)           
    END

    go

