
CREATE PROCEDURE [dbo].[USP_CH_Rule_CheckAssignment] 
    @RuleID int = 0
AS
	BEGIN
		SELECT COUNT(RuleIDs) FROM HealthCheckProfiles WHERE 
		RuleIDs like cast(@RuleID as nvarchar(10))+',%' OR 
		RuleIDs like '%,'+cast(@RuleID as nvarchar(10)) OR 
		RuleIDs like '%,'+cast(@RuleID as nvarchar(10))+',%' OR 
		RuleIDs like cast(@RuleID as nvarchar(10))
	END
go

