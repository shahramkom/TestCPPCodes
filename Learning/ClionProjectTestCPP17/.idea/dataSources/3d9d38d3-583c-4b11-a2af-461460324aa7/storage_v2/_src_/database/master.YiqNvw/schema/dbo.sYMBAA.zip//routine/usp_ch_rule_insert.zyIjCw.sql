CREATE PROCEDURE [dbo].[USP_CH_Rule_Insert]
    @CHR_Name		     nvarchar(50),
    @CHR_Category		 tinyint,
    @CHR_Action			 tinyint,
    @CHR_ActionParameter nvarchar(MAX) = Null,
	@CHR_RuleType		 tinyint = 0
AS
BEGIN
INSERT INTO [dbo].[HealthCheckRules]
           ([Name]
           ,[Category]
           ,[Action]
           ,[ActionParameter]
		   ,[RuleType])
     VALUES
           (@CHR_Name,
            @CHR_Category,
            @CHR_Action,
			@CHR_ActionParameter,
			@CHR_RuleType)
	SELECT @@IDENTITY		
END
go

