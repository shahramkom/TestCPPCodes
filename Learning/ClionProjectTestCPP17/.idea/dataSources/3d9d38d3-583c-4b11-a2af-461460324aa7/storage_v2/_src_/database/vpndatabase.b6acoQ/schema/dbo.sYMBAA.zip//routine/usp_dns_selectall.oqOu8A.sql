
    CREATE PROCEDURE  [dbo].[USP_DNS_SelectAll]
    
    with recompile	
    AS
    BEGIN
    --	SET NOCOUNT ON;

        select * from TDNS
    END

    go

