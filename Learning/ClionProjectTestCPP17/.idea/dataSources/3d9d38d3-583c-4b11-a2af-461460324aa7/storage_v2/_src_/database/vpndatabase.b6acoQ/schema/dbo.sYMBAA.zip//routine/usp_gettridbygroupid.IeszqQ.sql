CREATE PROCEDURE [dbo].[USP_GetTRIDByGroupID] 
	@GroupID int
AS
BEGIN
	select TRID from TGroupTimeset where GroupID = @GroupID order by priorityOrder asc
END
go

