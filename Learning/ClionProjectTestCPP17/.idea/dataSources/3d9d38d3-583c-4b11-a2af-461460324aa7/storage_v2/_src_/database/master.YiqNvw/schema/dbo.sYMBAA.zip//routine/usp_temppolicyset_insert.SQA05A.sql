

    CREATE PROCEDURE [dbo].[USP_TempPolicySet_Insert] 
        -- Add the parameters for the stored procedure here
        --@PSID int , 
            @oldPSID int ,
        @PSName nvarchar(100) = NULL ,
        @Replace int = 0
    
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        declare @exist int,@PSID int 
        select  @exist = count(PSID) from TPolicySet where PSName = @PSName
        if(@exist>0)
        begin
            if(@Replace!=0) 
			begin
				delete from  TServerAccessPolicy where PSID = (select PSID from TPolicySet where PSName = @PSName )
				delete from  TUserFirewallPolicy where PSID = (select PSID from TPolicySet where PSName = @PSName )
                delete from TPolicySet where PSName = @PSName
			end
            else
            begin
				select  @PSID = PSID from TPolicySet where PSName = @PSName
				update tpolicyset set oldPSID = @oldPSID where PSID = @PSID
				return
             end
        end 
        -- Insert statements for procedure here
        INSERT INTO 
            TPolicySet (/*PSID,*/PSName,oldPSID) values (/*@PSID,*/ @PSName,@oldPSID) 
        select @@IDENTITY		
    END


    go

