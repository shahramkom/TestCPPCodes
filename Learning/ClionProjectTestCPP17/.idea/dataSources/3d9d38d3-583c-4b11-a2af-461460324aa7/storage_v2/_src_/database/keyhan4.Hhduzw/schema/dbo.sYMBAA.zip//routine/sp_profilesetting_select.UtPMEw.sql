CREATE PROCEDURE [dbo].[sp_ProfileSetting_Select]  
	@CustomerName nvarchar(100)
AS
	SELECT ServerName,ProductTypeName,nTotalUsers,nOnlineUsers FROM ProfileSetting
	WHERE (CustomerName = @CustomerName)
go

