
   CREATE PROCEDURE [dbo].[USP_TNewPolicyMain_Copy] 
    @ID  bigint,
	@newPolicyName nvarchar(50)
   AS
   BEGIN
		
		DECLARE @currentApplyTime as int
		SELECT @currentApplyTime = ApplyTime FROM [TNewPolicyMainTable] WHERE ID =  @ID
		
		DECLARE @lastOrder as int
		SELECT @lastOrder = MAX (PolicyOrder) FROM [TNewPolicyMainTable] WHERE [ApplyTime] = @currentApplyTime
		SET @lastOrder = @lastOrder  + 1 

		DECLARE @CreatedDateTimeNow AS NVARCHAR(20)
		SELECT @CreatedDateTimeNow = CONVERT(nvarchar(20),GETDATE(),20)	

		DECLARE @CurrentPolicyType as int
		SELECT @CurrentPolicyType = PolicyType FROM [TNewPolicyMainTable] WHERE ID =  @ID

		DECLARE @CorrectTunnelID as int
		SET @CorrectTunnelID  = 0 
		if(@CurrentPolicyType = 1 OR @CurrentPolicyType = 2 )
		BEGIN
			SELECT  @CorrectTunnelID = [value] from TSetting where Property = 'LastTunnelID'
			if(@CorrectTunnelID  = 0)
			BEGIN
				select @CorrectTunnelID = max(TunnelID) from TNewPolicyMainTable
				if(@CorrectTunnelID  = 0)
					SET @CorrectTunnelID  = 200
			END
			if( @CorrectTunnelID < 200 OR @CorrectTunnelID > 944)
			BEGIN
				Raiserror('Tunnel ID value is not correct', 16 , 10 )
				return;
			END
		END
	
		INSERT INTO TNewPolicyMainTable ([PolicyType],[Name],[Enablity],[ServicesID]
					,[EncryptionID],[AdvancedDetailID],[Compression],[PolicyOrder],[CreateTime]
					,[LastModifyTime],[Discription],[ApplyTime],[sourceTunnelType],[sourceTunnelValue]
					,[DestinationTunnelType],[DestinationTunnelValue],[DirectionType],[EncryptionKey]
					,[IntegrityKey],[TunnelID])
		SELECT [PolicyType],@newPolicyName,[Enablity],[ServicesID]
					,[EncryptionID],[AdvancedDetailID],[Compression],@lastOrder,@CreatedDateTimeNow
					,NULL, [Discription],[ApplyTime],[sourceTunnelType],[sourceTunnelValue]
					,[DestinationTunnelType],[DestinationTunnelValue],[DirectionType],[EncryptionKey]
					,[IntegrityKey],@CorrectTunnelID from TNewPolicyMainTable where ID =  @ID
		
		if(@CurrentPolicyType = 1)
			SET @CorrectTunnelID = @CorrectTunnelID  + 2
		else if(@CurrentPolicyType = 2)
			SET @CorrectTunnelID = @CorrectTunnelID  + 4	
		if(@CurrentPolicyType = 1 OR @CurrentPolicyType = 2)
			UPDATE TSetting SET [value] = cast (@CorrectTunnelID as nvarchar(20))  where [Property] = 'LastTunnelID'

		DECLARE @LastInsertedID as int
		SET @LastInsertedID = @@identity
		Exec USP_TNewPoliciesDetails_Copy @ID,@LastInsertedID
		Exec USP_TNewPoliciesCopyAssignments @ID,@LastInsertedID
		SELECT @newPolicyName
   END

   go

