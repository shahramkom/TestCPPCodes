
    create PROCEDURE [dbo].[USP_TGroupDNS_Insert] 
        -- Add the parameters for the stored procedure here
        @groupID int,
        @DNSNameList nvarchar(max)
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
        declare @DNSName as nvarchar(50)
        declare @DNSID as int
        
        declare DNS_Cursor1 cursor for 
        SELECT * FROM dbo.Splitfn(@DNSNameList,',')
        
        open DNS_Cursor1
        fetch next from DNS_Cursor1 into @DNSName
        
        while @@FETCH_STATUS = 0
        begin
        select @DNSID = DNSID from TDNS where HostName = @DNSName
        
        insert into  TGroupDNS 
        (DNSID,GroupID) 
        values (@DNSID,@groupID)
        
        fetch next from DNS_Cursor1 into @DNSName
        end
        close DNS_Cursor1
        DEALLOCATE DNS_Cursor1
    END

    go

