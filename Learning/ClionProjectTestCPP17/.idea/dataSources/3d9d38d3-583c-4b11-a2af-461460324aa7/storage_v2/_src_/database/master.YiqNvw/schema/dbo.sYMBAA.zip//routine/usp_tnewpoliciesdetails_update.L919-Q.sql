
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesDetails_Update] 
		@ID  bigint,
		@MainID bigint ,
		@AllowNat  bit,
		@NatIP nvarchar(20),
        @VirtualIPType tinyint,
        @VirtualIPValue nvarchar(20),
        @SourceTunnelType  tinyint,
        @SourceTunnelValue  nvarchar(50),
        @DestinationTunnelType tinyint,
        @DestinationTunnelValue nvarchar(50)
   AS
   BEGIN

	UPDATE [dbo].[TNewPoliciesDetails]
	   SET [AllowNat] = @AllowNat,
		   [NatIP] = @NatIP,
		   [VirtualIPType] = @VirtualIPType,
		   [VirtualIPValue] = @VirtualIPValue,
		   [SourceTunnelType] = @SourceTunnelType,
		   [SourceTunnelValue] = @SourceTunnelValue,
		   [DestinationTunnelType] = @DestinationTunnelType,
		   [DestinationTunnelValue] = @DestinationTunnelValue
	 WHERE ID = @ID
   END

   go

