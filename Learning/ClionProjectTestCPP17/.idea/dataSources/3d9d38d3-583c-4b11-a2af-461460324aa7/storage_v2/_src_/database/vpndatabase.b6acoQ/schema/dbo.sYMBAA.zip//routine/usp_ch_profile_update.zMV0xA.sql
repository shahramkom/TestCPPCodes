CREATE PROCEDURE [dbo].[USP_CH_Profile_Update]
    @CHP_ProfileID			int,
    @CHP_Name				nvarchar(50)  = NULL,
    @CHP_Description		nvarchar(100) = NULL,
    @CHP_RuleIDs			nvarchar(500) = NULL,
	@activity               bit           = true 
AS
BEGIN
    SET NOCOUNT ON;
    declare @nTotalProfiles int
    select @nTotalProfiles=Count(*) from HealthCheckProfiles where (([Name]		= @CHP_Name) and (ProfileID<>@CHP_ProfileID))
    if (@nTotalProfiles>0)
    begin
        Raiserror ('check Health Profile name already exist', 16 , 10)
        return
    end
    UPDATE [dbo].[HealthCheckProfiles]
		 SET [Name] = @CHP_Name
		,[Description] = @CHP_Description
		,[RuleIDs] = @CHP_RuleIDs
		,[activity] = @activity
		WHERE ProfileID = @CHP_ProfileID
	SELECT @CHP_ProfileID
End
go

