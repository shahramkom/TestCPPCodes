
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesServices_Delete] 
   @ID  bigint
   AS
   BEGIN
	DECLARE @SelectedIconIndex as int
	SELECT @SelectedIconIndex = IconIndex FROM TNewPoliciesServices WHERE ID = @ID
	if(@SelectedIconIndex != 0)
	BEGIN
			raiserror('You can not delete this item',16,10);
			return
	END
	ELSE
		BEGIN
			IF NOT EXISTS (SELECT ServicesID FROM TNewPolicyMainTable WHERE ServicesID = @ID)
        		DELETE FROM [dbo].[TNewPoliciesServices]  WHERE ID = @ID
			ELSE
				RAISERROR('The selected service was assigned before. Please deassign it first.', 16 , 10 )
		END
  END

   go

