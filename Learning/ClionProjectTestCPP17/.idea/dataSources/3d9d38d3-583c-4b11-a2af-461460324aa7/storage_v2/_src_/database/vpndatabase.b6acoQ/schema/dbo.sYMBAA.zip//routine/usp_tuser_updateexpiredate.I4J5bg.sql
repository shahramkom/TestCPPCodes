
CREATE PROCEDURE [dbo].[USP_TUser_UpdateExpireDate] 
   @ExpDate as nvarchar(20),
   @UserID as bigint
AS
BEGIN
   UPdate TUser Set ExpireDate = @ExpDate WHere UserID = @UserID
END
go

