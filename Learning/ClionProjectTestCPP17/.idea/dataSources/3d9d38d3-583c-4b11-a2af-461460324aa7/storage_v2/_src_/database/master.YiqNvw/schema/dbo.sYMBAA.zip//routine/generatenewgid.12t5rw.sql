/*************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GenerateNewGID]
(
	@userID INT  
)
RETURNS VARCHAR(25)
AS
BEGIN
	DECLARE @gid AS VARCHAR(25)
	DECLARE @version AS INT
	SET @gid = NULL
	SET @version = 0
	SELECT @gid = gid FROM dbo.TUser WHERE UserID = @userID
	
	IF (@gid IS NOT NULL )
	BEGIN
		DECLARE @first AS INT
		DECLARE @second AS INT

		SET @first = CHARINDEX(',',@gid)
		SET @second = CHARINDEX(',', @gid, @first + 1)
		SET @version = SUBSTRING(@gid, @first + 1, @second - @first -1) + 1
	END
	RETURN dbo.GenerateGID(-1, @version, NULL)
END
go

