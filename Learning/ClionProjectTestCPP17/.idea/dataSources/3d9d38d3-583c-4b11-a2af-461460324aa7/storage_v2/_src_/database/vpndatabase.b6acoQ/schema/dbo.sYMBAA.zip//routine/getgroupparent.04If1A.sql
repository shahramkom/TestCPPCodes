
         CREATE FUNCTION [dbo].[GetGroupParent]
        (
            @PARENT_GROUP_ID NVARCHAR(100)
        )
        RETURNS NVARCHAR(100)
        AS
        BEGIN
            DECLARE @PARENT_PARENT_GROUP_ID NVARCHAR(100)
            SELECT @PARENT_PARENT_GROUP_ID = ParentID FROM TGROUP WHERE GroupID = @PARENT_GROUP_ID
        
            RETURN @PARENT_PARENT_GROUP_ID
     
        END

         go

