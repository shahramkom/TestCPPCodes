
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesDetails_DeleteByMainID] 
   @MainID  bigint
   AS
   BEGIN
		DELETE FROM [dbo].[TNewPoliciesDetails]  WHERE MainID = @MainID
   END

   go

