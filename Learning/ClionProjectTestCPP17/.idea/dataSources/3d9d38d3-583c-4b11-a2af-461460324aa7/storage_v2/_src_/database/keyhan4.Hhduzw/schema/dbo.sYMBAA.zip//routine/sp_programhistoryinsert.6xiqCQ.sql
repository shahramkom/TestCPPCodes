CREATE PROCEDURE [dbo].[sp_ProgramHistoryInsert] 
	@ProfileID int,
    @ModuleSerial nvarchar(20),
    @OnlineUsers  int,
    @TotalUsers int ,
    @Comment nvarchar(max),
	@UsfPercent int,
	@UserName nvarchar(150),
    @Reserve1 varchar(1000),
    @Reserve2 nvarchar(1000)
AS
	BEGIN
	update [Keyhan4].[dbo].[ProgramHistory] set valid = 0 where ID = (select max(ID) from [Keyhan4].[dbo].[ProgramHistory] where [ModuleSerial] = @ModuleSerial)
	declare @ProgramDate as nvarchar(20)
	select @ProgramDate = CONVERT(nvarchar(20),GETDATE(),20)
	INSERT INTO [dbo].[ProgramHistory]
           ([ProfileID]
           ,[ProgramDate]
           ,[ModuleSerial]
           ,[OnlineUsers]
           ,[TotalUsers]
           ,[Comment]
		   ,[UsfPercent]
		   ,[UserName]
           ,[Reserve1]
           ,[Reserve2]
		   ,[valid])
     VALUES
           (@ProfileID ,
			@ProgramDate ,
			@ModuleSerial ,
			@OnlineUsers  ,
			@TotalUsers  ,
			@Comment ,
			@UsfPercent,
			@UserName,
			@Reserve1 ,
			@Reserve2,
			1)
	END
go

