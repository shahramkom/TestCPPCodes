
    CREATE PROCEDURE [dbo].[UPS_Insert_logs_Manger]
        -- Add the parameters for the stored procedure here
        @L_userID			int =Null,
        @L_logType			nvarchar(50)=Null,
        @L_operationType	nvarchar(50)=Null,
        @L_logEvent			nvarchar(50)=Null,
        @L_rowID			nvarchar(max)=Null,
        @L_decription	    nvarchar(max)=Null,
        @L_operationDate	nvarchar(10)=Null,
        @L_operationTime	 nvarchar(8)=Null,
		@L_ClientUserID  	 nvarchar(30)=Null

    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
		DECLARE @ClientUserID as varchar(30)
		SET @ClientUserID = '0' 
		IF( @L_ClientUserID IS NOT NULL)
		BEGIN
			SET @ClientUserID = @L_ClientUserID
		END
		ELSE
		BEGIN
			DECLARE @index1 AS TINYINT
			DECLARE @index2 AS TINYINT
			SET @index1 = CHARINDEX(';', @L_rowID)
			SET @index2 = CHARINDEX(';', @L_rowID,@index1+1)
			IF(@index1 > 0 AND @index2 > 0)
				SET @ClientUserID = substring (@L_rowID ,@index1 + 8 , (@index2-1)-@index1 - 7)
		END

        if not exists(SELECT * from managerLog where (rowID = @L_rowID and decription = @L_decription and @L_rowID like '%Disable by System'))
        INSERT INTO managerLog
               (userID,
                logType,
               operationType,
               logEvent,
               rowID,
               decription,
               operationDate,
               operationTime,
			   ClientID)
         VALUES
               (@L_userID,
                @L_logType,
                @L_operationType,
                @L_logEvent	,
                @L_rowID, 
                @L_decription, 
                @L_operationDate, 
                @L_operationTime,
				@ClientUserID)
    END

    go

