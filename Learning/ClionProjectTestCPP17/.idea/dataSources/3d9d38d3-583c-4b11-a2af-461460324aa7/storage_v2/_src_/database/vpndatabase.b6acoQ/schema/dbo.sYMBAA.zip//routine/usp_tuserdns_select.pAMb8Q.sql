

    CREATE PROCEDURE  [dbo].[USP_TUserDNS_Select]
        @UserID   int
    AS
    BEGIN
         SELECT  d.HostName FROM  TDNS d inner join TUserDNS ud on d.DNSID = ud.DNSID
 
             WHERE ud.UserID = @UserID
    END

    go

