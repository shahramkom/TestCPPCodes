CREATE PROCEDURE [dbo].[sp_Products_GetList]          
AS
	select 
		[Code]          as N'ßÏ',
		[ProductName]   as N'äÇã',
		[ProductVer]    as N'æäå',
		[LockName]     as N'äæÚ ÞÝá',	
		[Description]	as N'ÊæÖíÍÇÊ'
	from  Products, Locks
	where (ProductLock = LockCode)
go

