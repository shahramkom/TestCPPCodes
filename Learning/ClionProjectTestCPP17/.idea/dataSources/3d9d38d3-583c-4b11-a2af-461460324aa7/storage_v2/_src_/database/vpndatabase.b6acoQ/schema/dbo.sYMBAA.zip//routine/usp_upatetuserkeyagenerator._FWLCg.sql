
    
        CREATE PROCEDURE [dbo].[USP_UpateTUserkeyAGenerator]
         as
    
    
        begin try
                DROP TABLE #tbl_UpdateGroupScript
            end try
            begin catch
            --RAISERROR ('Error raised in TRY block.', 16, 1);
            end catch
            create table #tbl_UpdateGroupScript(
                [Output]	nvarchar(max)
            )
        --Declare a cursor to retrieve column specific information for the specified table
        DECLARE cursTUserKeya CURSOR FAST_FORWARD FOR 
        SELECT UserID,KeyaSerial,[Date] FROM TUserKeya  --where GroupID in(@GroupID)
        OPEN cursTUserKeya
        DECLARE @string nvarchar(3000) --for storing the first half of INSERT statement		
        DECLARE @dataType nvarchar(max) --data types returned for respective columns
        DECLARE @newString nvarchar(MAX)

        --SET @string='Update TUserKeya SET  '		
         SET @newString=N'IF EXISTS (SELECT * FROM TUser WHERE UserID = @UserId)  IF NOT EXISTS (SELECT * from [TUserKeya] where UserID = @UserId and KeyaSerial = @KeyaSerial) INSERT INTO [TUserKeya] ([UserID],[KeyaSerial],[Date]) VALUES (@UserId,@KeyaSerial,@Date) ELSE Update TUserKeya SET Date=@Date where UserID=@UserId and KeyaSerial=@KeyaSerial'


        declare @UserId int 
        declare @KeyaSerial nvarchar(50)
        declare @Date nvarchar(50)

        FETCH NEXT FROM cursTUserKeya INTO @UserId,@KeyaSerial,@Date

        IF @@fetch_status<>0
            begin
            print 'Table TUserKeya'+' not found, processing skipped.'
            close cursTUserKeya
            deallocate cursTUserKeya
            return
        END

        WHILE @@FETCH_STATUS=0
        BEGIN

        if @KeyaSerial is NULL
        BEGIN
            --set @string = @string + 'KeyaSerial=' + isnull(@KeyaSerial ,'NULL')+' , '	
            set @newString = REPLACE(@newString, '@KeyaSerial', 'NULL')
        END
        else 
        BEGIN
            --set @string = @string + 'KeyaSerial=''' + isnull(@KeyaSerial ,'NULL')+''' , '	
            set @newString = REPLACE(@newString, '@KeyaSerial', ''''+ @KeyaSerial+ '''')
        END
        if @Date is NULL		
        BEGIN
            --set @string = @string + 'Date=' + isnull(@Date ,'NULL')+'  '	
            set @newString = REPLACE(@newString, '@Date', 'NULL')		
        END
        else 		
        BEGIN
            --set @string = @string + 'Date=''' + isnull(@Date ,'NULL')+'''  '	
            set @newString = REPLACE(@newString, '@Date', ''''+ @Date + '''')
        END
            --set @string = @string + ' where UserID='        + isnull(cast(@UserId as nvarchar(100)),'NULL') 
            set @newString = REPLACE(@newString, '@UserID', cast(@UserId as nvarchar(100)))
            --insert #tbl_UpdateGroupScript([Output])values(@string)
            insert #tbl_UpdateGroupScript([Output])values(@newString)
            --set @string = 'Update TUserKeya SET  '
			 SET @newString=N'IF EXISTS (SELECT * FROM TUser WHERE UserID = @UserId) IF NOT EXISTS (SELECT * from [TUserKeya] where UserID = @UserId and KeyaSerial = @KeyaSerial) INSERT INTO [TUserKeya] ([UserID],[KeyaSerial],[Date]) VALUES (@UserId,@KeyaSerial,@Date) ELSE Update TUserKeya SET Date=@Date where UserID=@UserId and KeyaSerial=@KeyaSerial'

        FETCH NEXT FROM cursTUserKeya INTO  @UserId,@KeyaSerial,@Date
        END


        CLOSE cursTUserKeya
        DEALLOCATE cursTUserKeya
        insert into TUser_Update_Script select * from #tbl_UpdateGroupScript

        go

