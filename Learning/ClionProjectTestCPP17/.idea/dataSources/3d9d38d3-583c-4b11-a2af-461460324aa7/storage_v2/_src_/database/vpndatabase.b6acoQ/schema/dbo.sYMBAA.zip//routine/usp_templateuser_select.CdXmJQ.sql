
    CREATE PROCEDURE  [dbo].[USP_TemplateUser_Select]
    
    
    AS
    BEGIN
    SELECT  [GroupID],
            [BindingStatus],
            [IPBindingStatus],
            [SubNetIP],
            [SubNetMask],
            [VirtualIPStatus],
            [UserPIN],
            [MasterPIN],
            [MustChangePIN],
            [LockModule],
            [RejOnKeepAliveFail],
			[ShowUserPrivilege] ,
            [Gender],
            [UnBlockPIN],
            [InterfaceBindingStatus],
            [InterfaceNames],
			[LoginType],
			[SendDNS],
			[DisableModernPolicy]
            FROM TTemplateUser
    END


    go

