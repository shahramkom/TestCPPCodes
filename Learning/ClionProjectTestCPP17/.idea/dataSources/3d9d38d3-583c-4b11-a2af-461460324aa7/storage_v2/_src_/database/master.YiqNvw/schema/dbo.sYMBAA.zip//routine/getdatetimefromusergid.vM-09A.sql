/*************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetDateTimeFromUserGID]
(
	@userID INT  
)
RETURNS DATETIME
AS
BEGIN
	DECLARE @gid AS VARCHAR(25)
	SET @gid = NULL
	
	SELECT @gid = gid FROM dbo.TUser WHERE UserID = @userID
	
	IF (@gid IS NOT NULL )
	BEGIN
		DECLARE @dateTime AS VARCHAR(12)
		DECLARE @second AS INT
		SET @second = CHARINDEX(',', @gid, CHARINDEX(',',@gid) + 1)
		SET @dateTime = RIGHT(@gid, LEN(@gid) - @second)
		
		RETURN dbo.UNIXToDateTime(@dateTime)
	END

	RETURN NULL
END
go

