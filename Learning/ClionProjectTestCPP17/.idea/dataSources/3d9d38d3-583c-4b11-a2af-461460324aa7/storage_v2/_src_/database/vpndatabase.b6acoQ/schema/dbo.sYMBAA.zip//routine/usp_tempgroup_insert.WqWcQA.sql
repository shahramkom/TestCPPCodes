

    CREATE PROCEDURE [dbo].[USP_TempGroup_Insert]

        @oldGroupID		int,
        @GroupName		nvarchar(500),
        @DefaultAccess	nvarchar(100)= 'Access',
        @Description	nvarchar(max) = NULL ,
        @Replace int = 0


    AS
    BEGIN
        SET NOCOUNT ON;
        declare @exist int
        select  @exist = count(GroupID) from TGroup where GroupName = @GroupName
        if(@exist>0)
        begin
            if(@Replace!=0) 
                delete from TGroup where GroupName = @GroupName
            else
             return
        end 
        INSERT INTO [VPNDataBase].[dbo].[TGroup]
           
                (--GroupID,
                GroupName,
                DefaultAccess,
                GroupDescription,
                 oldGroupID)
         VALUES
                (--@GroupID,
                @GroupName,
                @DefaultAccess,
                @Description,
                @oldGroupID)
    
        declare @newGroupID as int 
        set @newGroupID = @@IDENTITY
        update TTempDNS set GroupID = @newGroupID
        insert into TDNS select HostName,IP from TTempDNS
        declare @DNSID as int
        select @DNSID = DNSID from TDNS where HostName in (select HostName from TTempDNS)
        insert into TGroupDNS(DNSID ,GroupID) values (@DNSID,@newGroupID) 
        update managerLog 
         set rowID = 'groupName='+@GroupName
         where rowID = cast(@oldGroupID as nvarchar(50))	and logEvent like 'GroupPolicySet'
    
    

    END

    go

