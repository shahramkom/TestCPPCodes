CREATE PROCEDURE [dbo].[sp_GetOperatorLog] 
	@username nvarchar(150),
	@fromDate  varchar(20),
	@ToDate  varchar(20)
AS
	BEGIN
		SELECT dbo.ProgramHistory.ID, dbo.ProfileSetting.CustomerName AS ProfileID, dbo.ProgramHistory.ProgramDate, dbo.ProgramHistory.ModuleSerial, dbo.ProgramHistory.OnlineUsers, dbo.ProgramHistory.TotalUsers, 
                  dbo.ProgramHistory.Comment, dbo.ProgramHistory.UsfPercent, dbo.ProgramHistory.UserName, dbo.ProgramHistory.Reserve1, dbo.ProgramHistory.Reserve2
		FROM     dbo.ProgramHistory INNER JOIN
                  dbo.ProfileSetting ON dbo.ProgramHistory.ProfileID = dbo.ProfileSetting.Code   where UserName = @username AND dbo.ProgramHistory.ProgramDate >= @fromDate and dbo.ProgramHistory.ProgramDate <= @ToDate
		
		
		SELECT dbo.ProgramLicense.ID, dbo.ProfileSetting.CustomerName AS ProfileID, dbo.ProgramLicense.CreateDate, dbo.ProgramLicense.ExpireDate, dbo.ProgramLicense.TotalUsers, dbo.ProgramLicense.OnlineUsers,
		 dbo.ProgramLicense.USFPercent, dbo.ProgramLicense.NewFeatures, dbo.ProgramLicense.ServerBinding, dbo.ProgramLicense.LicenseID, dbo.ProgramLicense.FileName,    dbo.ProgramLicense.UserName
		FROM     dbo.ProgramLicense INNER JOIN
                  dbo.ProfileSetting ON dbo.ProgramLicense.ProfileID = dbo.ProfileSetting.Code  where UserName = @username AND dbo.ProgramLicense.CreateDate >= @fromDate and dbo.ProgramLicense.CreateDate <= @ToDate
		
		
		SELECT dbo.AlternateModules.ID, dbo.ProfileSetting.CustomerName AS ProfileID, dbo.AlternateModules.ProgramDate, dbo.AlternateModules.ModuleSerial, dbo.AlternateModules.ModuleType, dbo.AlternateModules.PIN, 
                  dbo.AlternateModules.UserName
		FROM     dbo.AlternateModules INNER JOIN
                  dbo.ProfileSetting ON dbo.AlternateModules.ProfileID = dbo.ProfileSetting.Code where UserName = @username AND dbo.AlternateModules.ProgramDate >= @fromDate and dbo.AlternateModules.ProgramDate <= @ToDate
	END
go

