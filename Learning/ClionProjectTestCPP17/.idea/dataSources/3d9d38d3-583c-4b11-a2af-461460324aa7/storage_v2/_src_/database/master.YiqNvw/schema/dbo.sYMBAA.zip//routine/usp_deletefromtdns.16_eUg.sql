
    Create PROCEDURE [dbo].[USP_DeletefromTDNS]
    @DNSID int
    AS
    BEGIN	
        delete from TDNS where DNSID IN (@DNSID)
    END

    go

