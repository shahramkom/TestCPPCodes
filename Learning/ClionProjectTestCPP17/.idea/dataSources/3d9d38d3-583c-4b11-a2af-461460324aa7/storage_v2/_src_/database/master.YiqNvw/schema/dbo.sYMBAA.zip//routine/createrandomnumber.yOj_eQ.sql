CREATE FUNCTION CreateRandomNumber(@lower int, @upper int) RETURNS int
AS
BEGIN
	DECLARE @randomF FLOAT
	DECLARE @random INT
	SELECT @randomF = Random FROM Get_Rand
	SELECT @random = ROUND(((@upper - @lower - 1) * @randomF + @lower), 0)
	RETURN @random
END
go

