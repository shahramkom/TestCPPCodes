/******************************************************************************************************************************************************/--
CREATE FUNCTION dbo.GetNetworkHostCount(@NetMask varchar(15))
RETURNS int
BEGIN
	if(@NetMask = '255.0.0.0')	
	   return 16777214
	else if(@NetMask = '255.128.0.0')
		return 8388606
	else if(@NetMask = '255.192.0.0')
		return 4194302
	else if(@NetMask = '255.224.0.0')
		return 2097150
	else if(@NetMask = '255.240.0.0')
		return 1048574
	else if(@NetMask = '255.248.0.0')
		return 524286
	else if(@NetMask = '255.252.0.0')
		return 262142
	else if(@NetMask = '255.254.0.0')
		return 131070
	else if(@NetMask = '255.255.0.0')
		return 65534
	else if(@NetMask = '255.255.128.0')
		return 32766
	else if(@NetMask = '255.255.192.0')
		return 16382
	else if(@NetMask = '255.255.224.0')
		return 8190
	else if(@NetMask = '255.255.240.0')
		return 4094
	else if(@NetMask = '255.255.248.0')
		return 2046
	else if(@NetMask = '255.255.252.0')
		return 1022
	else if(@NetMask = '255.255.254.0')
		return 510
	else if(@NetMask = '255.255.255.0')
		return 254
	else if(@NetMask = '255.255.255.128')
		return 126
	else if(@NetMask = '255.255.255.192')
		return 62
	else if(@NetMask = '255.255.255.224')
		return 30
	else if(@NetMask = '255.255.255.240')
		return 14
	else if(@NetMask = '255.255.255.248')
		return 6
	else if(@NetMask = '255.255.255.252')
		return 2
	return 0
END
go

