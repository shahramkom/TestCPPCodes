
    CREATE PROCEDURE  [dbo].[USP_USER_FILTER_SERIAL]
    
	    @UserID		bigint			= NULL ,	
        @UserName nvarchar(200)		= NULL , 
        @LastName nvarchar(200)		= NULL ,
        @AccountDisable tinyInt		= NULL ,
        @GroupID	int				= NULL ,	
        @BindingStatus nvarchar(50)	= NULL , 
        @BindingPCID nvarchar(100)	= NULL ,
        @VirtualIPStatus nvarchar(50)=NULL ,	
        @VirtualIP	   nvarchar(15)	= NULL ,
        @Owner		int				= NULL
    
        AS
    BEGIN
    
        select s1.* , s3.KeyASerial 
		from		
         (SELECT   TUser.UserID,UserName,BindingStatus,BindingPCID ,IPBindingStatus = 
        case  IPBindingStatus
            when '0' Then 'Disable'
            when '1' Then 'Enable'
        End,SubNetIP,SubNetMask,VirtualIPStatus,VirtualIP,UserPIN,MasterPIN,AuthenticationKey,MustChangePIN,AccountDisable --= 
--        case  AccountDisable
--            when '0' Then 'Enable'
--            when '1' Then 'Disable'
        
--        End
	,RejOnKeepAliveFail,ShowUserPrivilege,FirstName,LastName,Gender,Company,Office,Province,Town,Notes,Email,Cell,PersonnelCode,Phone,NationalID,Adress,PostalCode,Owner, Permission_ID , UnBlockPIN ,AuthType,CertType,CertValue--, GroupName
      FROM TUser --, TUserGroups , Tgroup
			Where	  
            --  TUserGroups.userid = TUser.userId 
			--		and TUserGroups.GroupID = TGroup.groupID and 

            (  @UserID  is NULL      or			  TUser.UserID = @UserID ) AND 				
            (  @UserName is  NULL      or         UserName LIKE '%'+@UserName+'%' )AND
            --(  @GroupID  is NULL      or          TGroup.GroupID = @GroupID ) AND 		
            (  @BindingStatus  is NULL   or       BindingStatus    LIKE '%'+@BindingStatus+'%' )AND
            (  @BindingPCID  is NULL   or	      BindingPCID     LIKE '%'+@BindingPCID+'%' )AND
            (  @VirtualIPStatus  is NULL   or     VirtualIPStatus     =  @VirtualIPStatus )AND
            (  @VirtualIP	   is NULL   or       VirtualIP	     =  @VirtualIP )AND
            (  @AccountDisable	   is NULL   or   AccountDisable	     =  @AccountDisable )AND

            (  @LastName is NULL      or          LastName LIKE '%'+@LastName+'%' )AND
            (  @Owner is NULL		or			  [Owner]=@Owner)
         --desc
        ) s1
		left outer join 
        (
            select uk.* from TUserKeyA uk , 
                (select userid , max(cast (replace(isnull(replace(isnull([date],0) ,'/',''),0),'-','') as bigint ) ) as date from tuserkeya group by userid) s2
            where s2.userid = uk.userid and s2.date = cast (replace(isnull(replace(isnull(uk.date , 0) ,'/',''),0),'-','') as bigint )
        
        ) s3
        on s1.UserID = s3.userID
    order by UserName asc
    END

    go

