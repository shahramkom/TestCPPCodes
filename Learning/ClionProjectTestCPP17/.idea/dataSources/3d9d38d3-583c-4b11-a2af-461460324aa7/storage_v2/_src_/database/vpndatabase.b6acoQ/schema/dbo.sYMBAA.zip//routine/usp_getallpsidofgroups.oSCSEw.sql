CREATE PROCEDURE [dbo].[USP_GetAllPSIDOfGroups]
	@AllGroups NVARCHAR(2000),
	@Outputval NVARCHAR(1000) OUTPUT
AS
BEGIN
	DECLARE @PSIDs NVARCHAR(1000)	
	DECLARE @execSql  as NVARCHAR(4000)
	SET @execSql = 'SELECT @PSIDs = STUFF ((SELECT    '',''+ CAST( dbo.TGroupPolicySet.PSID AS NVARCHAR(10))
  					FROM dbo.TGroupPolicySet WHERE  (dbo.TGroupPolicySet.GroupID in ('+@AllGroups+')) for xml path('''')) , 1 ,1 , '''') '
	EXEC SP_EXECUTESQL @execSql, N'@PSIDs NVARCHAR(1000) OUTPUT', @PSIDs OUTPUT
	SELECT @Outputval = @PSIDs
END
go

