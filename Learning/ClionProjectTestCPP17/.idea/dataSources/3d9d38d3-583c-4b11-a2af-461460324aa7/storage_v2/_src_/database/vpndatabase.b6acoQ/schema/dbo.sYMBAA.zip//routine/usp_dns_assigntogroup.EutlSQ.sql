

    CREATE PROCEDURE  [dbo].[USP_DNS_AssignToGroup]
    
        @DNSID int,
        @GroupID int


    AS
    BEGIN
        --SET NOCOUNT ON;
        INSERT INTO TGroupDNS
        (
        DNSID,
        GroupID
        )
        VALUES
        (	
        @DNSID,	
        @GroupID
        )


    END

    go

