CREATE PROCEDURE [dbo].[USP_SetLicenseInfo]
		 @nTotalUser int
		,@nOnlineUser int
		,@UsfUserCount int
		,@AllowH2HPolicies int
		,@isSlaveServer int = 0
		,@LicenseActivationDate varchar(50)
		/* Keyhan 5 License Features */
		,@NewLicenseVersion int = 0
		,@licenseID nvarchar(9) = "0"
		,@licenseServerSerial nvarchar(13) = 'none'
		,@androidSupport int = -1
		,@isDemo int = -1
		,@HealthCheck int = -1
		,@StandardToken int = -1
		,@ExpireDate nvarchar(50) = ''
		,@LicenseCreationDate nvarchar(50) = ''
		,@remainingDays varchar(10) = '0'
		,@LicenseStatus int = 1
AS
BEGIN
	
        if exists(select * from TSetting where [Property] = N'TotalUser')	
            update TSetting set [value] = @nTotalUser where [Property] = N'TotalUser'
        else
            insert into TSetting (Property,value) values('TotalUser' , @nTotalUser)

		if exists(select * from TSetting where [Property] = N'TotalOnlineUser')	
            update TSetting set [value] = @nOnlineUser where [Property] = N'TotalOnlineUser'
        else
            insert into TSetting (Property,value) values('TotalOnlineUser' , @nOnlineUser)
    
        if exists(select * from TSetting where [Property] = N'UsfUserCount')	
            update TSetting set [value] = @UsfUserCount where [Property] = N'UsfUserCount'
        else
            insert into TSetting (Property,value) values('UsfUserCount' , @UsfUserCount)

		if exists(select * from TSetting where [Property] = N'AllowH2HPolicies')	
            update TSetting set [value] = @AllowH2HPolicies where [Property] = N'AllowH2HPolicies'
        else
            insert into TSetting (Property,value) values('AllowH2HPolicies' , @AllowH2HPolicies)

		if exists(select * from TSetting where [Property] = N'isSlaveServer')	
            update TSetting set [value] = @isSlaveServer where [Property] = N'isSlaveServer'
        else
            insert into TSetting (Property,value) values('isSlaveServer' , @isSlaveServer)

		if exists(select * from TSetting where [Property] = N'LicenseActivationDate')
            update TSetting set [value] = @LicenseActivationDate where [Property] = N'LicenseActivationDate'
        else
            insert into TSetting (Property,value) values('LicenseActivationDate' , @LicenseActivationDate)

		if exists(select * from TSetting where [Property] = N'NewLicenseVersion')
            update TSetting set [value] = @NewLicenseVersion where [Property] = N'NewLicenseVersion'
        else
            insert into TSetting (Property,value) values('NewLicenseVersion' , @NewLicenseVersion)

		if exists(select * from TSetting where [Property] = N'LicenseServerSerial')	
            update TSetting set [value] = @licenseServerSerial where [Property] = N'LicenseServerSerial'
        else
            insert into TSetting (Property,value) values('LicenseServerSerial' , @licenseServerSerial)

		if exists(select * from TSetting where [Property] = N'LicenseID')
            update TSetting set [value] = @licenseID where [Property] = N'LicenseID'
        else
            insert into TSetting (Property,value) values('LicenseID' , @licenseID)

		if exists(select * from TSetting where [Property] = N'AndroidSupport')
            update TSetting set [value] = @androidSupport where [Property] = N'AndroidSupport'
        else
            insert into TSetting (Property,value) values('AndroidSupport' , @androidSupport)

		if exists(select * from TSetting where [Property] = N'isDemo')
            update TSetting set [value] = @isDemo where [Property] = N'isDemo'
        else
            insert into TSetting (Property,value) values('isDemo' , @isDemo)
		if exists(select * from TSetting where [Property] = N'HealthCheck')
            update TSetting set [value] = @HealthCheck where [Property] = N'HealthCheck'
        else
            insert into TSetting (Property,value) values('HealthCheck' , @HealthCheck)
		if exists(select * from TSetting where [Property] = N'StandardToken')
            update TSetting set [value] = @StandardToken where [Property] = N'StandardToken'
        else
            insert into TSetting (Property,value) values('StandardToken' , @StandardToken)

		if exists(select * from TSetting where [Property] = N'ExpireDate')
            update TSetting set [value] = @ExpireDate where [Property] = N'ExpireDate'
        else
            insert into TSetting (Property,value) values('ExpireDate' , @ExpireDate)
		
		if exists(select * from TSetting where [Property] = N'LicenseCreationDate')
            update TSetting set [value] = @LicenseCreationDate where [Property] = N'LicenseCreationDate'
        else
            insert into TSetting (Property,value) values('LicenseCreationDate' , @LicenseCreationDate)
		
		if exists(select * from TSetting where [Property] = N'RemainingExpireDays')
            update TSetting set [value] = @remainingDays where [Property] = N'RemainingExpireDays'
        else
            insert into TSetting (Property,value) values('RemainingExpireDays' , @remainingDays)	
		
		if exists(select * from TSetting where [Property] = N'LicenseStatus')
            update TSetting set [value] = @LicenseStatus where [Property] = N'LicenseStatus'
        else
            insert into TSetting (Property,value) values('LicenseStatus' , @LicenseStatus)	
			
END
/******************************************************************************************************************************************************/
----------------------------------------------------------------------------
go

