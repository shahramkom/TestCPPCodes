
CREATE PROCEDURE [dbo].[USP_Select_GroupIDNameFromWhere]
       @WhereCondition as nvarchar(MAX)
        AS
BEGIN
    	begin try
	 DROP TABLE #ResultTable
	end try
	begin catch
	end catch;
	
	 SELECT * INTO #ResultTable FROM(
	 SELECT  TGroup.* ,dbo.fnGroupInterfaceNames(TGroup.GroupID) as InterfaceBinding
			FROM    TGroup)as t
	 DECLARE @Query AS NVARCHAR(MAX)
	 SET @Query = '	 SELECT GroupID ,GroupName From #ResultTable '

	IF(@WhereCondition IS NOT NULL)
		SET @Query = @Query + ' WHERE '+ @WhereCondition
	 EXEC dbo.sp_executesql @Query
END
go

