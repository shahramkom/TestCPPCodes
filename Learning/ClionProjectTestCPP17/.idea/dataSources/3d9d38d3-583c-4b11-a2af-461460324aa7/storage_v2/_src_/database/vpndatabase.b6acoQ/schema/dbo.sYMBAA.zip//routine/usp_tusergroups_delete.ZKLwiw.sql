/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_TUserGroups_Delete] 
        -- Add the parameters for the stored procedure here
    @UserID INT,
    @GroupID INT
AS
BEGIN
    SET NOCOUNT ON;
   IF ( @GroupID = -1 )
    BEGIN
        DECLARE @CreateDateTime AS NVARCHAR(20)
        SELECT  @CreateDateTime = CONVERT(NVARCHAR(20), GETDATE(), 20)
		SELECT  @CreateDateTime
        DECLARE @GID AS VARCHAR(25)
	    SET @GID = dbo.GenerateNewGID(@UserID)
        
        UPDATE  Tuser SET  LastModifiedTime = @CreateDateTime, GID = @GID WHERE   UserID = @UserID
        UPDATE  TUserGroups SET  GID = @GID WHERE  UserID = @UserID     
		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Temp_ChangeAssignedUserType]') AND type in (N'U'))
        BEGIN
            UPDATE Temp_ChangeAssignedUserType SET AssignedType = 1 --Change Assigned
        END
        ELSE
        BEGIN
            CREATE TABLE [dbo].[Temp_ChangeAssignedUserType]( [AssignedType] [INT] )
            INSERT INTO Temp_ChangeAssignedUserType(AssignedType) VALUES(1)
        END
        DELETE  FROM TUserGroups WHERE   UserID = @UserID
    END
    ELSE IF ( @UserID = -1 )
	BEGIN
         DELETE  FROM TUserGroups WHERE   GroupID = @GroupID
	END
END

go

