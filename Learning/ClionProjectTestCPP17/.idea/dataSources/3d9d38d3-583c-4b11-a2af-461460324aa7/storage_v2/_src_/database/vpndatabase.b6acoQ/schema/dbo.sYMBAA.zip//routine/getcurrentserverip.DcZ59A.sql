/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.GetCurrentServerIP()
	RETURNS varchar(MAX)
AS
BEGIN
		DECLARE @MyServerIP as char(15)
		SELECT  @MyServerIP = [value] from TSetting Where [Property] = 'ServerIP'
		RETURN @MyServerIP
END
go

