

    CREATE PROCEDURE [dbo].[USP_TScript_FilterAssigned]
    @ScriptID int
    AS
    BEGIN	
        select g.GroupID,g.GroupName from TGroup g inner join TGroupScript gs
            on g.GroupID = gs.GroupID
            where ScriptID = @ScriptID 
    END


    go

