
    CREATE PROCEDURE  [dbo].[USP_TUserPolicySet_Select]
        @UserID   int
    AS
    BEGIN
         SELECT  ps.PSName FROM  TPolicySet ps inner join TUserPolicySet ups on ps.PSID = ups.PSID
 
             WHERE ups.UserID = @UserID order by ups.PolPriority
    END

    go

