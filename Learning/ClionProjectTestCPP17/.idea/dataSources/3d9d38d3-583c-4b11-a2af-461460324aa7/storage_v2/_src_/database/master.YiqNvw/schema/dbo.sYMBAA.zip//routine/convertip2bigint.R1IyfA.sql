
	CREATE FUNCTION [dbo].[ConvertIP2BigInt]
	(
		@ip varchar(15)
	)
	RETURNS varchar(15)
	AS
	BEGIN
		RETURN	(
			 ( Convert(bigint, PARSENAME( @ip, 1 )) ) + 
			 ( Convert(bigint, PARSENAME( @ip, 2 )) * 256 ) +
			 ( Convert(bigint, PARSENAME( @ip, 3 )) * 65536 ) + 
			 ( Convert(bigint, PARSENAME( @ip, 4 )) * 16777216 ) 
		)
	END
  go

