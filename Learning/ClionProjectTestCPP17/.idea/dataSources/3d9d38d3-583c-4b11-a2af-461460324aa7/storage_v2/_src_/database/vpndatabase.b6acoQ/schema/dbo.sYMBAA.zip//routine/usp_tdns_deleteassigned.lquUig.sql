



    CREATE PROCEDURE [dbo].[USP_TDNS_DeleteAssigned]
    @DNSID int,
    @GroupID int
    AS
    BEGIN	
        DELETE TGroupDNS
            WHERE DNSID = @DNSID and GroupID = @GroupID
    END

    go

