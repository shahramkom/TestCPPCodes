/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE USP_ProcessUserChanges
	@sActionType VARCHAR(50), 
	@Command nvarchar(MAX),
	@RecordIDValue int,
	@UserGID VARCHAR(25) = NULL,
	@MyServerID TINYINT,
	@UserAssignedGroups VARCHAR(MAX),
	@ServerIDFromGID TINYINT
AS
BEGIN
	IF(dbo.IsMyModification(@MyServerID, @ServerIDFromGID) = 1)
	BEGIN
		IF(dbo.IsPrimaryServer(@MyServerID) = 1)
			EXEC USP_InsertChangesToSecondaryReplog @sActionType,@Command,@RecordIDValue,@UserGID, @UserAssignedGroups
		ELSE
			EXEC USP_InsertUserChangesToRelatedReplog @RecordIDValue,@sActionType,'RepPrimaryLog', @Command, @UserGID , @UserAssignedGroups
	END
END
go

