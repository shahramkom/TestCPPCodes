
CREATE PROCEDURE [dbo].[USP_BackupLocalDatabase]
        @backupLocation nvarchar(1000),
		@BackupName nvarchar(1000)
    AS
    BEGIN
		SET NOCOUNT ON;
		DECLARE @sqlCommand NVARCHAR(1000)
		SET @sqlCommand = 'BACKUP DATABASE VPNDataBase TO DISK = '''+@backupLocation+ ''' WITH INIT, NAME= ''' +@BackupName+''', NOSKIP, NOFORMAT'
		EXEC(@sqlCommand)
	END
go

