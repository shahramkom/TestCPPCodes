--------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[CheckReplicationConnection]
  @SlaveServerIP NVARCHAR(20),
  @MasterServerIP NVARCHAR(20)
AS
BEGIN
	DECLARE @SlaveLinkServerObjectName NVARCHAR(100)
	SET @SlaveLinkServerObjectName = 'LNK'+ REPLACE(@SlaveServerIP,'.','_')

	DECLARE @SlaveExist AS INT
	EXEC CheckLinkServerExists @SlaveLinkServerObjectName,@SlaveExist OUTPUT
	
	if(@SlaveExist = 0)--slave link server object not found
		exec GenerateLinkServer @SlaveServerIP,@SlaveLinkServerObjectName
	
	DECLARE @TestLinkSlaveErrorCode as int
	EXEC TestLinkServerConnection @SlaveLinkServerObjectName,@TestLinkSlaveErrorCode OUTPUT
	if(@TestLinkSlaveErrorCode <> 0)
	BEGIN
		SELECT @TestLinkSlaveErrorCode AS ConnectToSlaveErrorCode
		RETURN
	END
	if(@TestLinkSlaveErrorCode = 0)
	BEGIN
		DECLARE @MasterExist AS INT
		DECLARE @MasterCommands AS NVARCHAR(MAX)
		SET @MasterCommands = '['+@SlaveLinkServerObjectName+'].[VPNDataBase].[dbo].[CheckLinkServerExists] N''LNKMASTER'',@MasterExist OUTPUT'
		EXEC sp_executeSQL @MasterCommands, @params = N'@MasterExist INT OUTPUT', @MasterExist = @MasterExist OUTPUT
		if(@MasterExist = 0)
		BEGIN
			SET @MasterCommands = '['+@SlaveLinkServerObjectName+'].[VPNDataBase].[dbo].[GenerateLinkServer] N'''+@MasterServerIP+''',N''LNKMASTER'''
			EXEC sp_executeSQL @MasterCommands
		END
		DECLARE @TestLinkMasterErrorCode AS INT
		SET @MasterCommands = '['+@SlaveLinkServerObjectName+'].[VPNDataBase].[dbo].[TestLinkServerConnection] N''LNKMASTER'',@TestLinkMasterErrorCode OUTPUT'
		EXEC sp_executeSQL @MasterCommands, @params = N'@TestLinkMasterErrorCode INT OUTPUT', @TestLinkMasterErrorCode = @TestLinkMasterErrorCode OUTPUT
		SELECT @TestLinkMasterErrorCode AS CreateLinkServerObject
	END
END
go

