CREATE PROCEDURE [dbo].[sp_AddEdit_ProfileSetting]
	@Code           	int,
	@CustomerName		nvarchar(100),
	@CustomerType		int, 
	@CustomerTypeName	nvarchar(100),
	@ProductType        int = 0,
	@ProductTypeName	nvarchar(100),
	@UserUserPin		nvarchar(32), 
	@UserMasterPin		nvarchar(32),
	@ManagerUserPIN		nvarchar(32),
	@ManagerMasterPIN	nvarchar(32),
	@ServerUserPIN		nvarchar(32),
	@ManagerAuthKey		nvarchar(64),
	@DataBaseKey        nvarchar(128),
	@ManagerPort		smallint,
	@ConnectionPort		smallint,
	@ServerAddresses  	nvarchar(2048),
	@ServerName         nvarchar(50),
	@nTotalUsers 		int,
	@nOnlineUsers 		int,
	@DefPolicies		varchar(8000),
	@ManagerSqlPass		nvarchar(64),
	@BackupKey			varchar(64),
	@LogServerSqlPass	nvarchar(64) = NULL,
	@LogAnalyzerSqlPass  nvarchar(64) = NULL,
	@LogServerModulePIN	nvarchar(64) = NULL,
	@LicenseKey     	nvarchar(64) = NULL,
	@isVisible			bit = 1 ,
	@isDisable			bit = 0 ,
	@ErrMsg 		    nvarchar(300) output
AS
	---- for Add
	declare @PrevCode int
	set @PrevCode = -1
	select @PrevCode = Code from ProfileSetting where CustomerName = @CustomerName or ServerName = @ServerName
	
	if(@BackupKey is NULL)
		set @BackupKey='00000000000000000000000000000000'
	if(@ManagerSqlPass is null)	
		set @ManagerSqlPass='0000000000000000'
	if(@LogServerSqlPass is null)	
		set @LogServerSqlPass='1111111111111111'
	if(@LogAnalyzerSqlPass is null)	
		set @LogAnalyzerSqlPass='1111111111111111'	
	if(@LogServerModulePIN is null)	
		set @LogServerModulePIN='0000000000000000'
	if(@LicenseKey is null)	
		set @LicenseKey='0000000000000000'
	if (isnull(@Code,0) = 0)
	begin

		if (@PrevCode != -1)
		begin
			set @ErrMsg = N'Profile with this Customer Name/Server Name is currently exists.'
			select @ErrMsg
			return 
		end
		declare @CreateDateTime as nvarchar(10)
		select @CreateDateTime = CONVERT(nvarchar(10),GETDATE(),10)
		set @CreateDateTime = [dbo].[Miladi2Shamsi](@CreateDateTime)
		     Insert into ProfileSetting
				(CustomerName, CustomerType, CustomerTypeName, ProductType, ProductTypeName, UserUserPin, UserMasterPin, ManagerUserPIN, ManagerMasterPIN, ServerUserPIN, ManagerAuthKey , DataBasekey, ManagerPort, ConnectionPort, ServerAddresses, ServerName, nTotalUsers, nOnlineUsers, DefPolicies , ManagerSqlPass ,BackupKey ,LogServerSqlPass,LogAnalyzerSqlPass,LogServerModulePIN,LicenseKey, CreateDateTime,isVisible,isDisable)
 		           values   
				(@CustomerName, @CustomerType, @CustomerTypeName, @ProductType, @ProductTypeName, @UserUserPin, @UserMasterPin, @ManagerUserPIN, @ManagerMasterPIN, @ServerUserPIN, @ManagerAuthKey , @DataBaseKey, @ManagerPort, @ConnectionPort, @ServerAddresses, @ServerName, @nTotalUsers, @nOnlineUsers,  @DefPolicies , @ManagerSqlPass ,@BackupKey , @LogServerSqlPass,@LogAnalyzerSqlPass,@LogServerModulePIN,@LicenseKey, @CreateDateTime,@isVisible,@isDisable)
			set @ErrMsg = N'Successfully insert the profile to database.'
			select @ErrMsg
		return ;
	end

	-- Exist before
	
	if (@PrevCode != -1 and @PrevCode != @Code)
	begin
		set @ErrMsg = N'Profile with this Customer Name/Server Name is currently exists.'
		select @ErrMsg;
		return ;
	end

	-- for Edit
	Update ProfileSetting  set
		CustomerName = @CustomerName,
		CustomerType	= @CustomerType,
		CustomerTypeName = @CustomerTypeName,
		ProductType		 = @ProductType,
		ProductTypeName   = @ProductTypeName,
		UserUserPin	= @UserUserPin	,
		UserMasterPin = @UserMasterPin,
		ManagerUserPIN	= @ManagerUserPIN	,
		ManagerMasterPIN = @ManagerMasterPIN ,
		ServerUserPIN	= @ServerUserPIN	,
		ManagerAuthKey = @ManagerAuthKey,
		DataBaseKey = @DataBaseKey,
		ManagerPort =	@ManagerPort	,
		ConnectionPort =	@ConnectionPort,	
		ServerAddresses = @ServerAddresses,
		ServerName = @ServerName,
		nTotalUsers   = @nTotalUsers, 
		nOnlineUsers = @nOnlineUsers,
		DefPolicies = 	@DefPolicies,	
		ManagerSqlPass = @ManagerSqlPass,
		BackupKey = @BackupKey ,
		LogServerSqlPass = @LogServerSqlPass ,
		LogAnalyzerSqlPass = @LogAnalyzerSqlPass,
		LogServerModulePIN = @LogServerModulePIN,
		LicenseKey = @LicenseKey,
		isVisible = @isVisible ,
		isDisable = @isDisable
	where 	(@Code = Code)

	set @ErrMsg = N'Successfully update the profile.'
	select @ErrMsg;
go

