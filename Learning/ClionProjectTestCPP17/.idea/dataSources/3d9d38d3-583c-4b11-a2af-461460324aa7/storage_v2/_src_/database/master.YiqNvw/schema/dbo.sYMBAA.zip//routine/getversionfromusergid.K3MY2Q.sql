/*************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetVersionFromUserGID]
(
	@userID INT  
)
RETURNS INT
AS
BEGIN
	DECLARE @gid AS VARCHAR(25)
	SET @gid = NULL
	
	SELECT @gid = gid FROM dbo.TUser WHERE UserID = @userID
	
	IF (@gid IS NOT NULL )
	BEGIN
		DECLARE @version AS VARCHAR(8)
		DECLARE @first AS INT
		DECLARE @second AS INT
		SET @first = CHARINDEX(',',@gid)
		SET @second = CHARINDEX(',', @gid, @first + 1)
		SET @version = SUBSTRING(@gid, @first + 1, @second - @first -1)
		
		RETURN CONVERT(INT, @version)
	END

	RETURN -1
END
go

