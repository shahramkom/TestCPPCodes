
	CREATE PROCEDURE [dbo].[USP_USER_Update_PCBinding_Status]
        -- Add the parameters for the stored procedure here
        @UserID bigint,	
        @boundedTo	nvarchar(100)=NULL
    AS
    BEGIN
		DECLARE @GID AS VARCHAR(25)
		SET @GID = dbo.GenerateNewGID(@UserID)

        UPDATE TUser set BindingPCID = @boundedTo, GID = @GID WHERE UserID = @UserID 
		UPDATE TUserGroups set GID = @GID WHERE UserID = @UserID 
    END

  go

