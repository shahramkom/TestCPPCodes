CREATE PROCEDURE [dbo].[USP_GetLicenseVersion]
AS
BEGIN
	
	SELECT [value] from TSetting where [Property] = N'NewLicenseVersion'

END
/******************************************************************************************************************************************************/
go

