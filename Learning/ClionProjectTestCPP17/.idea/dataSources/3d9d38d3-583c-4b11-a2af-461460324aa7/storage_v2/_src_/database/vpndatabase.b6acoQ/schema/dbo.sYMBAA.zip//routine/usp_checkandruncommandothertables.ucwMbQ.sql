/******************************************************************************************************************************************************/-------------------------------

CREATE PROCEDURE [dbo].[USP_CheckAndRunCommandOtherTables]
	@IDValue INT,
	@ActionType  VARCHAR(6),
	@tableName   VARCHAR(20),
	@idfieldName varchar(20),
	@assignedTo VARCHAR(8),
	@assigned NVARCHAR(MAX), 
    @returnCommand INT = 0 OUTPUT
	AS
	BEGIN
		DECLARE @RowServerID AS TINYINT
		DECLARE @Command NVARCHAR(MAX)
		DECLARE @sActionType as VARCHAR(50)
		SET @Command = ' '
		DECLARE @ServerIP VARCHAR(20)
	    SELECT @ServerIP = [value] FROM dbo.TSetting WHERE Property = 'ServerIP'

		SET @sActionType = @ActionType + '-' + @tableName

		DECLARE @grpAssigned VARCHAR(MAX)
		DECLARE @usrAssigned VARCHAR(MAX)
		IF (@assignedTo = 'Tuser')
		BEGIN
			SET @grpAssigned = dbo.GetUserAssignGroups(@assigned)
			SET @usrAssigned = @assigned
		END
		ELSE
		BEGIN
			SET @grpAssigned = @assigned
			SET @usrAssigned = ''
		END
		DECLARE @MyServerID TINYINT
		SELECT  @MyServerID = dbo.GetCurrentServerID()
			
		DECLARE CursAssigned CURSOR FAST_FORWARD FOR
		SELECT items FROM dbo.splitfn(@grpAssigned,',')
		OPEN CursAssigned
		
		DECLARE @items VARCHAR(20)
		
		FETCH NEXT FROM CursAssigned INTO @items
		WHILE @@FETCH_STATUS=0
		BEGIN
		IF(@tableName = 'TPermissionGroup')
			EXEC USP_PrepareTPermissionGroupRelatedQuery @ActionType, @IDValue, @grpAssigned, @Command OUTPUT
		ELSE
			EXEC USP_PrepareTableRelatedQuery @ActionType, @tableName, @idfieldName, @IDValue, @Command OUTPUT

		IF(dbo.HasSlaveServer(@MyServerID) = 1)
			EXEC USP_InsertUserChangesToRelatedReplog @IDValue, @sActionType, 'RepSlaveLog', @Command, NULL, @items, @usrAssigned

		IF(dbo.checkInterfaceOperate(@tableName) = 1)
		BEGIN
			FETCH NEXT FROM CursAssigned INTO @items
			CONTINUE
		END
		IF(dbo.IsRecordReplicatable(@items) = 1)
		BEGIN
			EXEC USP_ProcessTableChanges @sActionType, @Command, @IDValue, @MyServerID, @items , @usrAssigned
			IF (dbo.IsPrimaryServer(@MyServerID) = 0 AND dbo.isSlaveOFPrimary(@ServerIP) = 0)
			BEGIN
				EXEC USP_CheckDeleteAllItem @sActionType, @IDValue , 0
			END
            SET @returnCommand = 1
		END
		
		FETCH NEXT FROM CursAssigned INTO @items
		END
		CLOSE CursAssigned
		DEALLOCATE CursAssigned

		IF(@tableName = 'TServerAccessPolicy' OR @tableName = 'TUserFirewallPolicy' OR @tableName = 'TPolicySet')
			EXEC USP_PreparePolicyTableRelateQuery @IDValue, @items, @ActionType, @sActionType, @MyServerID, @returnCommand
        RETURN
END
go

