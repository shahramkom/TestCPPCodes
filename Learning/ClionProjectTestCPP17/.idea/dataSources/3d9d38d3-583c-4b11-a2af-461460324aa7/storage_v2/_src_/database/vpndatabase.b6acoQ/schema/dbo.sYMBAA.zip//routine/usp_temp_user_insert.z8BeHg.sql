CREATE PROCEDURE [dbo].[USP_temp_User_Insert]
    @UserID INT,
    @UserName NVARCHAR(200) = NULL,
    @nationalCode VARCHAR(200) = NULL,
    @personalCode VARCHAR(200) = NULL,
    @BindingStatus NVARCHAR(50) = NULL,
    @IPBindingStatus NVARCHAR(20) = NULL,
    @SubNetIP NVARCHAR(50) = NULL,
    @SubNetMask NVARCHAR(50) = NULL,
    @VirtualIPStatus NVARCHAR(50) = NULL,
    @VirtualIP NVARCHAR(15) = NULL,
    @UserPIN NVARCHAR(200) = NULL,
    @MasterPIN NVARCHAR(200) = NULL,
    @AuthenticationKey NVARCHAR(64) = NULL,
    @AccountDisable tinyInt = NULL,
    @FirstName NVARCHAR(200) = NULL,
    @LastName NVARCHAR(200) = NULL,
    @Company NVARCHAR(200) = NULL,
    @Office NVARCHAR(200) = NULL,
    @Province NVARCHAR(200) = NULL,
    @Town NVARCHAR(200) = NULL,
    @Notes NVARCHAR(MAX) = NULL,
    @Replace INT,
    @UnBlockPIN NVARCHAR(50)
AS
BEGIN
    DECLARE @EncAuthKey NVARCHAR(64) 
    DECLARE @nTotalCount INT,
        @nTotalUser INT,
        @nRepUsers INT,
        @nDuplicateUsers INT 
    
    BEGIN TRY
        DROP TABLE #Table
    END TRY
    BEGIN CATCH
        --RAISERROR ('Error raised in TRY block.', 16, 1);
    END CATCH

    CREATE TABLE #Table
    (
      CommandLine NVARCHAR(200),
      Param1 NVARCHAR(200),
      [Output] NVARCHAR(64)
    )
    
    SELECT  @nTotalCount = COUNT(*)
    FROM    TUser
    SELECT  @nTotalUser = [value]
    FROM    TSetting
    WHERE   Property = 'TotalUser'
    IF ( @nTotalUser < @nTotalCount + 1 )
        BEGIN
            RAISERROR ('Number of total user exceeded' , 16 , 10)
            RETURN
        END
        
    SET @nRepUsers = 0
    SELECT  @nRepUsers = COUNT(*)
    FROM    TUser
    WHERE   VirtualIP IS NOT NULL
            AND VirtualIP = @VirtualIP
            AND username != @UserName
    IF ( @nRepUsers > 0 )
        BEGIN
            RAISERROR ('The entered virtual ip assigned before. Please choose another ip .',16,10)
            RETURN
        END
    IF ( @VirtualIPStatus = N'Disable' )
        SET @VirtualIP = NULL
    SET @nDuplicateUsers = 0
    SELECT  @nDuplicateUsers = COUNT(*)
    FROM    TUser
    WHERE   UserName IS NOT NULL
            AND UserName = @UserName
    IF ( @nDuplicateUsers > 0 )
        BEGIN
            IF ( @Replace = 1 )
                BEGIN
                    DECLARE @existUserID INT
                    SET @existUserID = 0
                    SELECT  @existUserID = userid
                    FROM    tuser
                    WHERE   UserName = @UserName
                            OR userid = @userid
                    EXEC USP_User_Delete @existUserID
                END
            ELSE
                BEGIN
					 --Raiserror ('The entered username assigned before. Please choose another username.',16,10)
                    RETURN
                END		
        END
    
    INSERT  #Table
            EXEC Master..XYRunProc 'Encrypt', @AuthenticationKey
    SELECT  @EncAuthKey = [Output]
    FROM    #Table
    WHERE   CommandLine = 'Encrypt'
    DROP TABLE #Table
    IF ( @EncAuthKey IS NULL )
    BEGIN
		RAISERROR ('The Authentication key is null!  Please check server configs.',16,10)
        RETURN		
    END
    
    IF(LEN(@personalCode) > 10)
		SET @personalCode = SUBSTRING(@personalCode, 0, 10)

    IF(LEN(@nationalCode) > 10)
		SET @nationalCode = SUBSTRING(@nationalCode, 0, 10)

    IF ( @UserPIN IS NULL )
        SELECT  @UserPIN = [Value]
        FROM    TSetting
        WHERE   [property] = N'DefaultUserPIN'
    IF ( @MasterPIN IS NULL )
        SELECT  @MasterPIN = [Value]
        FROM    TSetting
        WHERE   [property] = N'DefaultMasterPIN'
		
	DECLARE @newGID VARCHAR(25) 
    SET @newGID = dbo.GenerateGID(-1, 0, NULL)			
		
    IF NOT EXISTS ( SELECT  *
                    FROM    TUser
                    WHERE   UserID = @UserID )
        BEGIN
      
            BEGIN TRY
               
                
                DECLARE @intErrorCode INT
                        --SET IDENTITY_INSERT  TUser ON
                INSERT  INTO TUser
                        ( UserID,
                          UserName,
                          NationalID,
                          PersonnelCode,
                          BindingStatus,
                          IPBindingStatus,
                          SubNetIP,
                          SubNetMask,
                          VirtualIPStatus,
                          VirtualIP,
                          UserPIN,
                          MasterPIN,
                          AuthenticationKey,
                          AccountDisable,
                          FirstName,
                          LastName,
                          Company,
                          Office,
                          Province,
                          Town,
                          Notes,
                          UnBlockPIN,
						  GID )
                VALUES  ( @UserID,
                          @UserName,
                          @nationalCode,
                          @personalCode,
                          @BindingStatus,
                          @IPBindingStatus,
                          @SubNetIP,
                          @SubNetMask,
                          @VirtualIPStatus,
                          @VirtualIP,
                          @UserPIN,
                          @MasterPIN,
                          @EncAuthKey,
                          @AccountDisable,
                          @FirstName,
                          @LastName,
                          @Company,
                          @Office,
                          @Province,
                          @Town,
                          @Notes,
                          @UnBlockPIN,
						  @newGID )
                        --SET IDENTITY_INSERT  TUser OFF	
                SELECT  @userID, @newGID 
                            
            END TRY
            BEGIN CATCH
                DECLARE @err NVARCHAR(MAX)
                SELECT  @err = ERROR_MESSAGE()
                RAISERROR ( @err , 16 , 10)
                        --raiserror ('Can not Insert User with plain UserID  !' ,16 , 10)
            END CATCH
                
        END
    ELSE
        BEGIN
         
            BEGIN TRY
			    DECLARE @newuserID INT 
                SET @newuserID = dbo.CreateIdentity()
                INSERT  INTO TUser
                        ( 
						  UserID,
						  UserName,
                          NationalID,
                          PersonnelCode,
                          BindingStatus,
                          IPBindingStatus,
                          SubNetIP,
                          SubNetMask,
                          VirtualIPStatus,
                          VirtualIP,
                          UserPIN,
                          MasterPIN,
                          AuthenticationKey,
                          AccountDisable,
                          FirstName,
                          LastName,
                          Office,
                          Province,
                          Town,
                          Company,
                          Notes,
                          UnBlockPIN,
						  GID )
                VALUES  ( 
						  @newuserID,	
						  @UserName,
                          @nationalCode,
                          @personalCode,
                          @BindingStatus,
                          @IPBindingStatus,
                          @SubNetIP,
                          @SubNetMask,
                          @VirtualIPStatus,
                          @VirtualIP,
                          @UserPIN,
                          @MasterPIN,
                          @EncAuthKey,
                          @AccountDisable,
                          @FirstName,
                          @LastName,
                          @Office,
                          @Province,
                          @Town,
                          @Company,
                          @Notes,
                          @UnBlockPIN,
						  @newGID )

                DECLARE @NewNotes NVARCHAR(200) 
                SET @NewNotes = ISNULL(@Notes, '') + 'OverWrite exception: UserID changed from '
                    + CAST(@UserID AS NVARCHAR(12)) + 'to ' + CAST(@newuserID AS NVARCHAR(10))
                UPDATE  TUser
                SET     Notes = @NewNotes
                WHERE   UserID = @newuserID
                SELECT  @newuserID, @newGID				 
            END TRY 
    
            BEGIN CATCH
                RAISERROR('can not insert User with AutoIncreament UserID!', 16,10)
                
            END CATCH
        
        END
END
go

