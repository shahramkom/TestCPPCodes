



    CREATE PROCEDURE [dbo].[USP_TDNS_FilterAssigned]
    @DNSID int

    AS
    BEGIN	
        select g.GroupID,g.GroupName from TGroup g inner join TGroupDNS gd 
            on g.GroupID=gd.GroupID
            where DNSID = @DNSID
    END

    go

