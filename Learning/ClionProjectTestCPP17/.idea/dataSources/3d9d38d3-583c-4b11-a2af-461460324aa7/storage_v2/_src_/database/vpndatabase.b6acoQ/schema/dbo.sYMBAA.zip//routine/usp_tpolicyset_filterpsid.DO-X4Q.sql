
    CREATE PROCEDURE  [dbo].[USP_TPolicySet_FilterPSID]
    @PSID int
        
    AS
    BEGIN
        --SET NOCOUNT ON;
        select PSName from TPolicySet
        where PSID = @PSID

    END

    go

