
	Create PROCEDURE [dbo].[USP_TNewPolicyMain_Filter] 
		@filterType tinyint,
		@filterData		   nvarchar(50)
	AS
	BEGIN

		if (@filterType = 0) EXEC USP_TNewPoliciesSearch_PolicyName        @filterData
		else if (@filterType = 1) EXEC USP_TNewPoliciesSearch_UserName     @filterData
		else if (@filterType = 2) EXEC USP_TNewPoliciesSearch_GroupName    @filterData
		else if (@filterType = 3) EXEC USP_TNewPoliciesSearch_IP           @filterData
		else if (@filterType = 4) EXEC USP_TNewPoliciesSearch_ServiceName  @filterData
		else if (@filterType = 5) EXEC USP_TNewPoliciesSearch_PolicyStatus @filterData
		else if (@filterType = 6) EXEC USP_TNewPoliciesSearch_PolicyType   @filterData
	END


  go

