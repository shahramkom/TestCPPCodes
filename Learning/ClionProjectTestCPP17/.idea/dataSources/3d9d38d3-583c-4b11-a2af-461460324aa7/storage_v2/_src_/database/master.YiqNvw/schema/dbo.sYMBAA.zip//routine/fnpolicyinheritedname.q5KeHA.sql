
	CREATE FUNCTION [dbo].[fnPolicyInheritedName]
	(@PSName Nvarchar(100),@InheritedGroup Nvarchar(200) , @GLevel int   )
	RETURNS nvarchar(max)
	AS
	BEGIN
		IF(@GLevel = 0)
			RETURN @PSName+'(Directly assigned to user)'
		IF(@GLevel = 1)
			RETURN @PSName+'(Directly assigned to group)'	
		IF(@GLevel != 1)
			RETURN @PSName+'(Inherited from '+@InheritedGroup+')'
		RETURN @PSName		
	END

  go

