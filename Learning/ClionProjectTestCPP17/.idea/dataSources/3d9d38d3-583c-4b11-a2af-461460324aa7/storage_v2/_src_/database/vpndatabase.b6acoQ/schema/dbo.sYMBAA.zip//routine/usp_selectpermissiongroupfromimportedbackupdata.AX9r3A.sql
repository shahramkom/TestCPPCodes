
        CREATE PROCEDURE [dbo].[USP_SelectPermissionGroupFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        declare @groupID nvarchar(200), @PermissionID nvarchar(200),@InsertScript nvarchar(4000)

     Declare TPermissionGroup_cursor Cursor FAST_FORWARD
        For
        Select 
                 PermissionID,GroupID,[output] 
            FROM tbl_InsertGroupScript   
            where tableName = 'TPermissionGroup'
            OPEN TPermissionGroup_cursor

    FETCH NEXT FROM TPermissionGroup_cursor
    INTO @PermissionID,@groupID,@InsertScript

    WHILE @@FETCH_STATUS = 0
    begin 

            if(exists (select Permission_ID from TPermissionGroup where Permission_ID = @PermissionID and Group_ID = @groupID ))
            Begin
                if(@Replace = '1')
                     Delete from TPermissionGroup    where Permission_ID = @PermissionID and Group_ID = @groupID 	
            End
            BEGIN TRY
             exec sp_executesql @InsertScript	
            END TRY
            BEGIN CATCH
				
						
	     INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectPermissionGroupFromImportedBackupData')
				
				   
            END CATCH
        
            
            
            FETCH NEXT FROM TPermissionGroup_cursor 
             INTO @PermissionID,@groupID,@InsertScript
    
        end
        CLOSE TPermissionGroup_cursor;
        DEALLOCATE TPermissionGroup_cursor;		
        
    END

        go

