/*************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetServerIDFromUserGID]
(
	@userID INT  
)
RETURNS INT
AS
BEGIN
	DECLARE @gid AS VARCHAR(25)
	DECLARE @serverID AS VARCHAR(3)
	SET @gid = NULL
	
	SELECT @gid = gid FROM dbo.TUser WHERE UserID = @userID
	
	IF (@gid IS NOT NULL )
	BEGIN
		SET @serverID = SUBSTRING(@gid, 0, CHARINDEX(',', @gid ))
		RETURN CONVERT(INT, @serverID)
	END

	RETURN -1
END
go

