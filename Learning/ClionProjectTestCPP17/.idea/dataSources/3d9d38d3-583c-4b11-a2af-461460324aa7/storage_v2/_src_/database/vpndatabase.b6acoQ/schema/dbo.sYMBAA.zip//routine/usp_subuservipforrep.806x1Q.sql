/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_SubUserVIPforRep]
	@ActionType varchar(50),
    @Command NVARCHAR(MAX),
	@ReturnedCommand NVARCHAR(MAX) OUTPUT
AS
BEGIN
	DECLARE @valuesLocation INT
	DECLARE @VIPStartLocation INT
	DECLARE @VIPEndLocation INT
	DECLARE @counter INT
	DECLARE @SVIP NVARCHAR(20)
	SET @SVIP = NULL
	DECLARE @tmpSVIP NVARCHAR(20)
	SET @counter = 1

	IF(@ActionType = 'Insert-TUser')
	BEGIN
		SELECT @valuesLocation = CHARINDEX('VALUES(',@Command,0)
		SET @VIPStartLocation = @valuesLocation
		WHILE @counter < 9
		BEGIN
			SELECT  @VIPStartLocation = CHARINDEX(',',@Command,@VIPStartLocation+1)
			SET @counter = @counter + 1
		END
		SELECT  @VIPEndLocation = CHARINDEX(',',@Command,@VIPStartLocation+1)
		SELECT @SVIP = SUBSTRING(@Command ,@VIPStartLocation+1, @VIPEndLocation- @VIPStartLocation-1)
	END
	ELSE IF(@ActionType = 'Update-TUser')
	BEGIN
		SELECT @VIPStartLocation = CHARINDEX('VirtualIP = ',@Command,0)
		SELECT  @VIPEndLocation = CHARINDEX(',',@Command,@VIPStartLocation+1)
		SELECT  @SVIP = SUBSTRING(@Command ,@VIPStartLocation+12, @VIPEndLocation- @VIPStartLocation-12)
	END
	IF(@SVIP IS NOT NULL AND @SVIP <> 'NULL')
	BEGIN
		BEGIN TRY
			SET @tmpSVIP = REPLACE(@SVIP , 'N','')
			SET @tmpSVIP = REPLACE(@tmpSVIP , '''','')
			SELECT @tmpSVIP = dbo.[GetCorrectIP]('InsertMode',@tmpSVIP)
			SET @ReturnedCommand = REPLACE(@Command , @SVIP, ''''''+@tmpSVIP+'''''')
		END TRY
		BEGIN CATCH
			SET @ReturnedCommand = @Command
		END CATCH
	END
	ELSE
		SET @ReturnedCommand = @Command
END
go

