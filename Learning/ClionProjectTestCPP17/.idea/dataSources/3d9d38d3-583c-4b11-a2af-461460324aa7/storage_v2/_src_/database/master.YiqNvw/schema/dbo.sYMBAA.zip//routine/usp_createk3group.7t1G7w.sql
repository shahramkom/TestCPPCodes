CREATE PROCEDURE [dbo].[USP_CreateK3Group]
    @GroupName NVARCHAR(500),
    @DefaultAccess NVARCHAR(100),
    @Description NVARCHAR(MAX),
    @Replace INT = 0
AS
BEGIN
    SET NOCOUNT ON;
    IF ( NOT EXISTS ( SELECT groupid FROM  tgroup WHERE groupname = @GroupName ) )
    BEGIN
        EXEC USP_Group_Insert @GroupName, @DefaultAccess, @Description	
    END
    SELECT  GroupID FROM TGroup WHERE GroupName = @GroupName   
END
/*************************************************************************************************************************************/
go

