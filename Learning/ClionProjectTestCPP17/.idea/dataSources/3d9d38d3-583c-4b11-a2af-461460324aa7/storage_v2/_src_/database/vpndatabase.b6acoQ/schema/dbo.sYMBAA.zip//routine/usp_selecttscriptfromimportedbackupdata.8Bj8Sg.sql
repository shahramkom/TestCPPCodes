
        CREATE PROCEDURE [dbo].[USP_SelectTScriptFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	

    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        
    declare @ScriptTitle nvarchar(200) , @InsertScript nvarchar(4000)
    declare @ScriptID int 
     Declare TScriptTitle_cursor Cursor FAST_FORWARD
        For
        Select 
                   ScriptTitle,[output],ScriptID 
            FROM tbl_InsertGroupScript   
            where tableName = 'TScript'
            OPEN TScriptTitle_cursor

    FETCH NEXT FROM TScriptTitle_cursor
    INTO @ScriptTitle,@InsertScript,@ScriptID

    WHILE @@FETCH_STATUS = 0
    begin 
                  
          
       if(exists (select * from TScript where ScriptTitle = @ScriptTitle or scriptID = @scriptID	  ))
            Begin
            
                if(@Replace = 1)
                    begin
                
                    Delete from TScript  where ScriptTitle = @ScriptTitle	or scriptID = @scriptID
                    
                    end
            End
        
            BEGIN TRY
            
                SET IDENTITY_INSERT TScript ON
                exec sp_executesql @InsertScript	
                SET IDENTITY_INSERT TScript OFF		
            END TRY
            BEGIN CATCH
				INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectTScriptFromImportedBackupData')
            END CATCH  	
            FETCH NEXT FROM TScriptTitle_cursor 
            INTO @scriptTitle,@InsertScript,@ScriptID
    
        end
        CLOSE TScriptTitle_cursor;
        DEALLOCATE TScriptTitle_cursor;
        
                
    END


        go

