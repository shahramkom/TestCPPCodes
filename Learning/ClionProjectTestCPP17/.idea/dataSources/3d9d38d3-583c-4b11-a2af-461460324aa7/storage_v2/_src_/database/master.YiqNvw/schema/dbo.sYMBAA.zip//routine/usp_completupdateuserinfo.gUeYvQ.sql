CREATE PROCEDURE [dbo].[USP_CompletUpdateUserinfo] 
	@UserID BIGINT,
	@UserIP varchar(20),
	@LoginTime varchar(20),
	@ChangeIP bit
AS
BEGIN
	if(@ChangeIP = 1)
		update TUSER SET LastConnectedIP = @UserIP , LastLoginTime = @LoginTime WHERE UserID = @UserID
	else
		update TUSER SET LastLoginTime = @LoginTime WHERE UserID = @UserID
END
go

