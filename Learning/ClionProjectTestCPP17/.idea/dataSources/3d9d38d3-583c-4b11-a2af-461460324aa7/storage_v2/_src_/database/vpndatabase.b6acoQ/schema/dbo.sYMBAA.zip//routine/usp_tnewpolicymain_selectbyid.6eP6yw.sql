
        CREATE PROCEDURE [dbo].[USP_TNewPolicyMain_SelectByID] 
	@ID  bigint
   AS
   BEGIN
	Declare @sourceTunnelType       AS INT
	Declare @DestinationTunnelType  AS INT
	Declare @sourceTunnelValue      AS NVARCHAR(100)
	Declare @DestinationTunnelValue AS NVARCHAR(100)
	Declare @Real_Source_Value		AS NVARCHAR(100)
	Declare @Real_Destination_Value AS NVARCHAR(100)

	Select 	@sourceTunnelType      =  [sourceTunnelType]     ,@sourceTunnelValue = [sourceTunnelValue] FROM [dbo].[TNewPolicyMainTable]   WHERE ID = @ID
	Select 	@DestinationTunnelType =  [DestinationTunnelType],@DestinationTunnelValue = [DestinationTunnelValue] FROM [dbo].[TNewPolicyMainTable]   WHERE ID = @ID

    if(@sourceTunnelType = 0 AND @sourceTunnelValue != 'UseRs:AnY')--Source User_Type
		select 	@Real_Source_Value = UserName from TUSER WHERE UserID = @sourceTunnelValue		
	else if(@sourceTunnelType = 1)--Source Group_Type
		select 	@Real_Source_Value = GroupName from TGroup WHERE GroupID = @sourceTunnelValue		
	else
		set 	@Real_Source_Value = @sourceTunnelValue
	
	if(@DestinationTunnelType = 0 AND @DestinationTunnelValue != 'UseRs:AnY')--Destination User_Type
		select 	@Real_Destination_Value = UserName from TUSER WHERE UserID = @DestinationTunnelValue		
	else if(@DestinationTunnelType = 1)--Destination Group_Type
		select 	@Real_Destination_Value = GroupName from TGroup WHERE GroupID = @DestinationTunnelValue		
	else
		set 	@Real_Destination_Value = @DestinationTunnelValue
	
	
	SELECT [ID]
      ,[PolicyType]
      ,[Name]
      ,[Enablity]
      ,[ServicesID]
      ,[EncryptionID]
      ,[AdvancedDetailID]
      ,[Compression]
      ,[PolicyOrder]
      ,[CreateTime]
      ,[LastModifyTime]
      ,[Discription]
	  ,[ApplyTime]
      ,[sourceTunnelType]
      ,@Real_Source_Value AS  [sourceTunnelValue]
      ,[DestinationTunnelType]
      ,@Real_Destination_Value AS [DestinationTunnelValue]
      ,[DirectionType]
	  ,[EncryptionKey]
	  ,[IntegrityKey]
	  ,[TunnelID]
	  ,dbo.SelModernPolGroupsUsers(MP.ID)AS Assignments
   FROM [dbo].[TNewPolicyMainTable] AS MP
   WHERE ID = @ID
   END

        go

