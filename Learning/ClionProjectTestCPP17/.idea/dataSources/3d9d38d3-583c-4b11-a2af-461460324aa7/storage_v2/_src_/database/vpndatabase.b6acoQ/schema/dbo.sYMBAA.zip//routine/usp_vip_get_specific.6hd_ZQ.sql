
    CREATE PROCEDURE [dbo].[USP_VIP_Get_Specific]
        @minvip  bigint, 
        @maxvip  bigint,
        @headIP  nvarchar(20)
        with recompile
        AS
    BEGIN
        SET NOCOUNT ON;	
    
    create table #Table(VIP nvarchar(20))

    declare @DEFVIP	nvarchar(20)

    Declare VIPC_cursor Cursor For
        Select VirtualIP From tuser
        
    OPEN VIPC_cursor

    FETCH NEXT FROM VIPC_cursor 
    INTO @DEFVIP

    WHILE @@FETCH_STATUS = 0
    BEGIN

    declare @Exist_Status		bit	  
    set @Exist_Status=0
    declare @octnum as int
    select @octnum = count(*) FROM dbo.Splitfn(@DEFVIP,'.')
    if (@octnum <= 3) 
        BEGIN
        if (@DEFVIP <> '')
            insert into #Table (VIP)values(@headIP+@DEFVIP)
        END
        FETCH NEXT FROM VIPC_cursor 
        INTO @DEFVIP
    END

    CLOSE VIPC_cursor;
    DEALLOCATE VIPC_cursor;
    
        select
              max((256*256*256)*CAST(PARSENAME(VIP,4)AS bigint)
                +((256*256)*CAST(PARSENAME(VIP,3)AS bigint))
                +(256 * CAST(PARSENAME(VIP,2)AS bigint))
                +CAST(PARSENAME(VIP,1)AS bigint))		 
               from  #Table
            where
            (((256*256*256)*CAST(PARSENAME(VIP,4)AS bigint)
            +((256*256)*CAST(PARSENAME(VIP,3)AS bigint))
            + (256 * CAST(PARSENAME(VIP,2)AS bigint))
            +  CAST(PARSENAME(VIP,1)AS bigint)) >= @minvip  ) 
             and 
            (((256*256*256)*CAST(PARSENAME(VIP,4)AS bigint)
            +((256*256)*CAST(PARSENAME(VIP,3)AS bigint))
            + (256 * CAST(PARSENAME(VIP,2)AS bigint))
            +  CAST(PARSENAME(VIP,1)AS bigint)	)<=@maxvip)

    DROP TABLE #Table
                
    END

    go

