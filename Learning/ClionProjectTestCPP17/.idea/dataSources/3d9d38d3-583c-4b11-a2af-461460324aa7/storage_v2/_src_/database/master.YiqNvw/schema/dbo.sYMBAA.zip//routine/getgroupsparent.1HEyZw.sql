
	CREATE FUNCTION [dbo].[GetGroupsParent]
	(
		@UserID NVARCHAR(10)
	)
	RETURNS NVARCHAR(100)
	AS
	BEGIN
	DECLARE @GID NVARCHAR(10)
		DECLARE @GroupIDS NVARCHAR(100)
	
		
		SET @GID = ''
		SELECT @GID = cast( GroupID as NVARCHAR(10) ) FROM TUserGroups WHERE UserID = @UserID
		SET @GroupIDS = @GID

		WHILE ( ( @GID != '' ) AND ( @GID IS NOT NULL ) )
		BEGIN
		   SELECT  @GID =  dbo.GetGroupParent( @GID )
		   IF ( ( @GID != '0' ) AND ( @GID != '' ) AND ( @GID IS NOT NULL ) )
			  SET @GroupIDS = @GroupIDS + ',' + @GID  
		END
		RETURN @GroupIDS
	END

  go

