
	CREATE FUNCTION [dbo].[fnIsInRangeIPDword]
	(
		@IPstr VARCHAR(50),
		@MaskIP VARCHAR(50)
	)
	RETURNS BIT
	AS
	BEGIN
		declare @ip nvarchar(50)
		declare @subNet nvarchar(50)
		declare @subNetBigint bigint
		declare @ipRange nvarchar(50)
		set @ip = @IPstr
		set @subNet = ''
		set @ipRange = ''	
		declare @end int
		set @end = 0;
		set @end = CHARINDEX('/', @IPstr)
		if (@end > 0)
		begin
			set @ip = SUBSTRING(@IPstr, 0, @end)
			set @subNet = SUBSTRING(@IPstr, @end + 1 , LEN(@IPstr))
			set @subNetBigint = dbo.ConvertIP2BigInt( dbo.ConvertCIDRToIPV4( CAST(@subNet AS bigint ) ) )
		end
		else 
		begin
			set @end = CHARINDEX('-', @IPstr)
			if (@end > 0)
			begin
				set @ip = SUBSTRING(@IPstr, 0, @end)
				set @ipRange = SUBSTRING(@IPstr, @end + 1 , LEN(@IPstr))
			end	
		end
		if (LEN(@ip) > 0)	
		begin
			if (@subNet <> '')
			begin
				RETURN	CASE
					WHEN	(CAST(@IP AS bigint) & @subNetBigint) = (CAST(@MaskIP AS bigint) & @subNetBigint )
					THEN	1
					ELSE	0
				END
			end
			else if (@ipRange <> '')
			begin
				RETURN	CASE
					WHEN	(CAST(@IP AS bigint) <= CAST(@MaskIP AS bigint)) and (CAST(@MaskIP AS bigint) <= CAST(@ipRange AS bigint))
					THEN	1
					ELSE	0
				END
			end
		end
		RETURN	CASE
			WHEN	(CAST(@IP AS bigint) = CAST(@MaskIP AS bigint))
			THEN	1
			ELSE	0
		END
	END

  go

