
CREATE PROCEDURE [dbo].[USP_CH_Profile_UserAssignment_Insert]
  @CHP_ProfileID			int,
  @CHP_Users 				nvarchar(max)
    AS
    BEGIN
        SET NOCOUNT ON;
        declare @UserName as nvarchar(50)
        declare @UserID as int
        declare CH_CursorUser cursor for 
        SELECT * FROM dbo.Splitfn(@CHP_Users,',')
        open CH_CursorUser
        fetch next from CH_CursorUser into @UserName
        while @@FETCH_STATUS = 0
        begin
        select @UserID = UserID from TUser where UserName = @UserName
        INSERT INTO [dbo].[HealthCheckUserAssign]([UserID],[ProfileID])VALUES(@UserID ,@CHP_ProfileID)
        fetch next from CH_CursorUser into @UserName
        end
        close CH_CursorUser
        DEALLOCATE CH_CursorUser
    END
go

