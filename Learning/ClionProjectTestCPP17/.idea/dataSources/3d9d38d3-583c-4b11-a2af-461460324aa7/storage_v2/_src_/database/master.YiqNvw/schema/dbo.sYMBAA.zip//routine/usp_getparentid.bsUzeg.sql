CREATE PROCEDURE [dbo].[USP_GetParentID] 
	@GroupID int
AS
BEGIN
	select ParentID ,DefaultAccess from TGroup where GroupID = @GroupID	
END
go

