CREATE PROCEDURE [dbo].[USP_User_Insert_FromSSB] 
        -- Add the parameters for the stored procedure here
    @UserID INT,
    @GroupID NVARCHAR(MAX),
    @UserName NVARCHAR(200) = NULL,
    @BindingStatus NVARCHAR(50) = NULL,
    @BindingPCID NVARCHAR(100) = NULL,
    @IPBindingStatus NVARCHAR(20) = NULL,
    @SubNetIP NVARCHAR(50) = NULL,
    @SubNetMask NVARCHAR(50) = NULL,
    @VirtualIPStatus NVARCHAR(50) = NULL,
    @VirtualIP NVARCHAR(15) = NULL,
    @UserPIN NVARCHAR(200) = NULL,
    @PUKPIN NVARCHAR(200) = NULL,
    @MasterPIN NVARCHAR(200) = NULL,
    @AuthenticationKey NVARCHAR(64),
    @MustChangePIN BIT = NULL,
    @AccountDisable tinyint = NULL,
    @RejOnKeepAliveFail BIT = NULL,
    @ShowUserPrivilege BIT = NULL,
    @FirstName NVARCHAR(200) = NULL,
    @LastName NVARCHAR(200) = NULL,
    @Gender NVARCHAR(10) = NULL,
    @Company NVARCHAR(200) = NULL,
    @Office NVARCHAR(200) = NULL,
    @Province NVARCHAR(200) = NULL,
    @Town NVARCHAR(200) = NULL,
    @Notes NVARCHAR(MAX) = NULL,
    @Email NVARCHAR(200) = NULL,
    @Cell NVARCHAR(50) = NULL,
    @PersonnelCode NVARCHAR(10) = NULL,
    @Phone NVARCHAR(200) = NULL,
    @NationalID NVARCHAR(10) = NULL,
    @Adress NVARCHAR(MAX) = NULL,
    @PostalCode NVARCHAR(200) = NULL,
    @Owner INT = NULL,
    @Replace INT,
    @AuthType TINYINT,
    @CertType NVARCHAR(50),
    @CertValue NVARCHAR(400),
    @permission_ID INT,
    @LoginType TINYINT = 2,
    @LockModule AS BIT = 0,
    @ExpireDate NVARCHAR(20) = NULL,
    @VersionBindingStatus NVARCHAR(50) = 'Unbound',
    @BindingVersion NVARCHAR(10) = NULL,
    @CreateDateTime NVARCHAR(20) = NULL,
    @LastModifyDateTime NVARCHAR(20) = NULL,
    @SendDNS BIT = 0,
    @DisableModernPolicy BIT = 1,
    @LastConnectedIP NVARCHAR(20) = NULL,
    @LastLoginTime NVARCHAR(20) = NULL,
	@Version varchar(11) = NULL, 
    @DriverType tinyint = NULL, 
	@DisableResult nvarchar(100) = NULL,
	@GID VARCHAR(25) = NULL
AS
BEGIN
    DECLARE @EncAuthKey NVARCHAR(64),
        @nTotalCount INT,
        @nTotalUser INT,
        @nRepUsers INT,
        @nDuplicateUsers INT 
    
    
    BEGIN TRY
        DROP TABLE #Table
    END TRY
    BEGIN CATCH
        --RAISERROR ('Error raised in TRY block.', 16, 1);
    END CATCH

    CREATE TABLE #Table
    (
      CommandLine NVARCHAR(200),
      Param1 NVARCHAR(200),
      [Output] NVARCHAR(64)
    )

    SELECT  @nTotalCount = COUNT(*)
    FROM    TUser
    SELECT  @nTotalUser = [value]
    FROM    TSetting
    WHERE   Property = 'TotalUser'
    IF ( @nTotalUser < @nTotalCount + 1 )
        BEGIN
            RAISERROR ('Number of total user exceeded' , 16 , 10)
            RETURN
        END
    IF ( @LoginType = 0 )
        BEGIN
            DECLARE @DefinedUsfCount INT,
                @PermittedUsfCount INT
            SET @DefinedUsfCount = 0
            SET @PermittedUsfCount = 0
            SELECT  @DefinedUsfCount = COUNT(*)
            FROM    TUser
            WHERE   LoginType = 0
            SELECT  @PermittedUsfCount = [value]
            FROM    TSetting
            WHERE   Property = 'UsfUserCount'
            IF ( @PermittedUsfCount < @DefinedUsfCount + 1 )
                BEGIN
                    RAISERROR ('Number of USF users exceeded.' , 16 , 10)
                    RETURN
                END
        END
		
    IF ( @VirtualIPStatus = N'Disable' )
        SET @VirtualIP = NULL	

	DECLARE @StartVirtualIpDWORD AS BIGINT
	DECLARE @StartVirtualIpMaskString AS varchar(20)
	DECLARE @HostCount AS int
	SELECT @StartVirtualIpMaskString  = value from TSetting WHERE Property = 'UserVipPoolMask' 
	Set @HostCount  = dbo.GetNetworkHostCount(@StartVirtualIpMaskString)
	SET @StartVirtualIpDWORD = dbo.GetStartVirtualIpPoolIpAddreessDWORD()
    SET @nRepUsers = 0
	SELECT  @nRepUsers = COUNT(*) FROM TUser WHERE VirtualIP IS NOT NULL AND VirtualIP = @VirtualIP AND UserName != @UserName
	if(@nRepUsers > 0)
	BEGIN
        SET @Notes = ISNULL(@Notes, '') + ' User static virtual IP changed during import operation preventing conflict.'
        SET @VirtualIPStatus = 'Dynamic' 
        SET @virtualIP = NULL   
    END
	SELECT  @nRepUsers = COUNT(*) FROM Tuser WHERE virtualIPstatus = 'Static' and @VirtualIP = CAST(CAST(VirtualIP as BIGINT)+ @StartVirtualIpDWORD AS NVARCHAR(15)) --or @VIP = CAST(CAST(VirtualIP as BIGINT)-@StartVirtualIpDWORD AS NVARCHAR(15))  
	if(@nRepUsers > 0)
	BEGIN
	  SET @Notes = ISNULL(@Notes, '') + ' User static virtual IP changed during import operation preventing conflict.'
      SET @VirtualIPStatus = 'Dynamic' 
      SET @virtualIP = NULL   
	END
	if(@virtualIP < 16777216 AND @virtualIP > @HostCount)
		SET @virtualIP = @StartVirtualIpDWORD + CAST(@virtualIP AS BIGINT)
	
    SET @nDuplicateUsers = 0
    SELECT  @nDuplicateUsers = COUNT(*)
    FROM    TUser
    WHERE   UserName IS NOT NULL
            AND ( UserName = @UserName
                  OR UserId = @userID )
    IF ( @nDuplicateUsers > 0 )
        BEGIN
            IF ( @Replace != 0 )
                DELETE  FROM TUser
                WHERE   UserName = @UserName
                        OR UserId = @userID
            ELSE
                BEGIN
                 --Raiserror ('The entered username assigned before. Please choose another username.',16,10)
                    RETURN
                END		
        END
    
    
    INSERT  #Table
            EXEC Master..XYRunProc 'Encrypt', @AuthenticationKey
    SELECT  @EncAuthKey = [Output]
    FROM    #Table
    WHERE   CommandLine = 'Encrypt'
    DROP TABLE #Table
    IF ( @EncAuthKey IS NULL )
        BEGIN
            RAISERROR ('The Authentication key is null!  Please check server configs.',16,10)
            RETURN		
        END
        --select @AuthenticationKey , @EncAuthKey

    IF ( @UserPIN IS NULL )
        SELECT  @UserPIN = [Value]
        FROM    TSetting
        WHERE   [property] = N'DefaultUserPIN'
    IF ( @MasterPIN IS NULL )
        SELECT  @MasterPIN = [Value]
        FROM    TSetting
        WHERE   [property] = N'DefaultMasterPIN'
        --declare @newGroupID int 
        --select  @newGroupID =  GroupID from TGroup where oldGroupID = @GroupID  				
		
    DECLARE @CRTDateTime AS NVARCHAR(20)				
    IF ( @CreateDateTime IS NOT NULL )
        SELECT  @CRTDateTime = @CreateDateTime 
    ELSE
        SELECT  @CRTDateTime = CONVERT(NVARCHAR(20), GETDATE(), 20)
		
    DECLARE @LSTDateTime AS NVARCHAR(20)
    IF ( @LastModifyDateTime IS NOT NULL )
        SET @LSTDateTime = @LastModifyDateTime
    ELSE
        SELECT  @LSTDateTime = CONVERT(NVARCHAR(20), GETDATE(), 20)

	IF (@GID IS NULL) 
		SET @GID = dbo.GenerateGID(-1, 0, NULL)

    IF NOT EXISTS ( SELECT  *
                    FROM    TUser
                    WHERE   UserID = @UserID )
        BEGIN
      
            --SET IDENTITY_INSERT dbo.TUser ON

            INSERT  INTO TUser
                    ( UserID,
                        --GroupID	 ,
                      UserName,
                      BindingStatus,
                      BindingPCID,
                      IPBindingStatus,
                      SubNetIP,
                      SubNetMask,
                      VirtualIPStatus,
                      VirtualIP,
                      UserPIN,
                      UnBlockPIN,
                      MasterPIN,
                      AuthenticationKey,
                      MustChangePIN,
                      AccountDisable,
                      RejOnKeepAliveFail,
                      ShowUserPrivilege,
                      FirstName,
                      LastName,
                      Gender,
                      Office,
                      Province,
                      Town,
                      Company,
                      Notes,
                      Email,
                      Cell,
                      PersonnelCode,
                      Phone,
                      NationalID,
                      Adress,
                      PostalCode,
                      [Owner],
                      AuthType,
                      CertType,
                      CertValue,
                      Permission_ID,
                      LoginType,
                      LockModule,
                      ExpireDate,
                      VersionBindingStatus,
                      BindingVersion,
                      CreateTime,
                      LastModifiedTime,
                      SendDNS,
                      DisableModernPolicy,
                      LastConnectedIP,
                      LastLoginTime,
					  Version ,
					  DriverType ,
					  DisableResult,
					  GID )
            VALUES  ( @UserID,
                        --@GroupID	 ,--@newGroupID
                      @UserName,
                      @BindingStatus,
                      @BindingPCID,
                      @IPBindingStatus,
                      @SubNetIP,
                      @SubNetMask,
                      @VirtualIPStatus,
                      @VirtualIP,
                      @UserPIN,
                      @PUKPIN,
                      @MasterPIN,
                      @EncAuthKey,
                      @MustChangePIN,
                      @AccountDisable,
                      @RejOnKeepAliveFail,
                      @ShowUserPrivilege,
                      @FirstName,
                      @LastName,
                      @Gender,
                      @Office,
                      @Province,
                      @Town,
                      @Company,
                      @Notes,
                      @Email,
                      @Cell,
                      @PersonnelCode,
                      @Phone,
                      @NationalID,
                      @Adress,
                      @PostalCode,
                      @Owner,
                      @AuthType,
                      @CertType,
                      @CertValue,
                      @permission_ID,
                      @LoginType,
                      @LockModule,
                      @ExpireDate,
                      @VersionBindingStatus,
                      @BindingVersion,
                      @CRTDateTime,
                      @LSTDateTime,
                      @SendDNS,
                      @DisableModernPolicy,
                      @LastConnectedIP,
                      @LastLoginTime,
					  @Version ,
					  @DriverType ,
					  @DisableResult,
					  @GID )
            --SET IDENTITY_INSERT dbo.TUser OFF
        END
    IF ( @UserID = NULL )
        SELECT  @UserID = UserID
        FROM    TUSer
        WHERE   UserName = @UserName
    
    BEGIN TRY
        DROP TABLE #tbl_TGroup
    END TRY
    BEGIN CATCH
        --RAISERROR ('Error raised in TRY block.', 16, 1);
    END CATCH

    CREATE TABLE #tbl_TGroup ( groupID INT )
        
    INSERT  INTO #tbl_TGroup
            SELECT  *
            FROM    dbo.Splitfn(@GroupID, ',') 
        
        
    DECLARE @groupidStr INT 
    DECLARE @gPriority INT 	
    DECLARE groupID_cursor CURSOR
    FOR
    SELECT  groupid
    FROM    #tbl_TGroup
    
    OPEN groupID_cursor;

    FETCH NEXT FROM groupID_cursor 
    INTO @groupidStr;

    WHILE @@FETCH_STATUS = 0
        BEGIN
    
            SELECT  @gPriority = MAX(GPriority)
            FROM    TUserGroups
            WHERE   UserID = CAST(@UserID AS NVARCHAR(50)) 
            SET @gPriority = @gPriority + 1
            IF ( @groupidStr IS NOT NULL )
                BEGIN
                    IF EXISTS ( SELECT  *
                                FROM    TGroup
                                WHERE   GroupID = @groupidStr )
                        EXEC USP_TUserGroup_Insert @UserID, @groupidStr, @gPriority, @GID
                END
                
            FETCH NEXT FROM groupID_cursor 
            INTO @groupidStr;
        END
    CLOSE groupID_cursor;
    DEALLOCATE groupID_cursor;


END
go

