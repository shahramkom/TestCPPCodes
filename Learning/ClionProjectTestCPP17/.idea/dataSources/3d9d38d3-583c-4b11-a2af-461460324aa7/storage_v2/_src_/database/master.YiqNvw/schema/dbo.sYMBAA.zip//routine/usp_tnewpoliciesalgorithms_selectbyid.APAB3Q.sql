
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesAlgorithms_SelectByID] 
   @ID  bigint
   AS
   BEGIN
	SELECT [ID]
		  ,[EncryptionAlgorithm]
		  ,[IntegrityAlgorithm]
	  FROM [dbo].[TNewPoliciesAlgorithms]
	  Where ID = @ID
   END

   go

