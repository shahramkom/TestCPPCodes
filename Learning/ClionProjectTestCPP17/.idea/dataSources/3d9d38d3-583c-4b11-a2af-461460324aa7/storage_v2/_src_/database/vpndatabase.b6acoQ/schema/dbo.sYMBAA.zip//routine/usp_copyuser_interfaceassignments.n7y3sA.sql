
	CREATE PROCEDURE [dbo].[USP_CopyUser_InterfaceAssignments] 
    @OldUserID  bigint,
	@NewUserID  bigint
   AS
   BEGIN
		INSERT INTO TUserInterface (UserID	 , InterfaceID)
		SELECT 	@NewUserID	 ,InterfaceID	 
		FROM TUserInterface WHERE UserID = @OldUserID
   END

  go

