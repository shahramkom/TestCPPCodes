
    Create PROCEDURE [dbo].[USP_SetLicenseStatus]
		@licenseStatus int
    AS
    BEGIN
		if exists(select * from TSetting where [Property] = N'LicenseStatus')	
            update TSetting set [value] = @licenseStatus where [Property] = N'LicenseStatus'
        else
            insert into TSetting (Property,value) values('LicenseStatus' , @licenseStatus)
    END

    go

