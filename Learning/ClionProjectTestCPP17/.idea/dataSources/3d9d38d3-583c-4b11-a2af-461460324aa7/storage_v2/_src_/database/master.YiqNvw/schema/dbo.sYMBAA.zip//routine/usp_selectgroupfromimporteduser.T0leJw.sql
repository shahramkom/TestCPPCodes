

    CREATE PROCEDURE [dbo].[USP_SelectGroupFromImportedUser] 
        -- Add the parameters for the stored procedure here
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
    
        begin try
            DROP TABLE #tmp1
        end try
        begin catch
        --RAISERROR ('Error raised in TRY block.', 16, 1);
        end catch
        create table #tmp1(GroupName nvarchar(max) )

        insert into #tmp1(GroupName)
            select groupId  from tempUser group by groupId having groupID !=' ' 

declare @groupCounter int
set @groupCounter = 0; 	
    declare @groupName nvarchar(500)

     Declare Group_cursor Cursor 
        For
        Select 
                  GroupName
            FROM #tmp1   
        
            OPEN Group_cursor

    FETCH NEXT FROM Group_cursor
    INTO @groupName

    WHILE @@FETCH_STATUS = 0
    begin 
        set @groupCounter = @groupCounter + 1
            if( not exists (select groupid from tgroup where groupname = @groupName))
                EXEC Usp_Group_Insert @groupName,'Access','keyhan3.x Group' 
        
            
            FETCH NEXT FROM Group_cursor 
              INTO @GroupName
    
        end
        CLOSE Group_cursor;
        DEALLOCATE Group_cursor;
    
        begin try
            DROP TABLE #tmp1
        end try
        begin catch
        --RAISERROR ('Error raised in TRY block.', 16, 1);
        end catch
    select @groupCounter			
    END

    go

