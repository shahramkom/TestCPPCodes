CREATE PROCEDURE [dbo].[USP_GetPSIDbyUserID] 
	@UserID BIGINT
AS
BEGIN
	select PSID from TuserPolicySet where userID = @UserID order by PolPriority 
END
go

