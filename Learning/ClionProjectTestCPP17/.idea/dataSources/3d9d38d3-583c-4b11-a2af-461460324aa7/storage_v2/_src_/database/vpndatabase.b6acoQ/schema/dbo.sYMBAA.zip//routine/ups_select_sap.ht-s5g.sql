
    CREATE PROCEDURE  [dbo].[UPS_Select_SAP] 
    @PSID int =null
    with recompile
    AS
    BEGIN
		 SELECT [PolicyID],[PSID],[PolicyName],[NetworkIP],[NetworkMask],[Protocol],[Port],[PAction]
      ,[Authentication],[Encryption],[Compression],[IP_RangeType],[CreateTime],[LastModifiedTime],[Status]
      ,[ExpireDate],[POrder],[PolicyDescription] FROM [VPNDataBase].[dbo].[TServerAccessPolicy] where (PSID = @PSID OR   @PSID IS NULL OR @PSID = 0) order by  POrder 
    END

    go

