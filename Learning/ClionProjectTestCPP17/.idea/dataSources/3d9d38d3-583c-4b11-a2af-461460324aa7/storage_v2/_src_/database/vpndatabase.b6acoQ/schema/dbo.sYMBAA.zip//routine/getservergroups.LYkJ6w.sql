/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.GetServerGroups(@ServerID int)
	RETURNS varchar(MAX)
AS
BEGIN
	DECLARE CursGroup CURSOR FAST_FORWARD FOR 
	SELECT RepGroupID FROM RepServersGroups WHERE ServerID = @ServerID
	OPEN CursGroup

	DECLARE @GroupIDsStr varchar(MAX)
	SET @GroupIDsStr = ''
	DECLARE @GrpID varchar(30)

	FETCH NEXT FROM CursGroup INTO @GrpID

	WHILE @@FETCH_STATUS=0
	BEGIN
		IF (dbo.GetGroupChildren( @GrpID ) IS NOT null)
			SET @GroupIDsStr = @GroupIDsStr + dbo.GetGroupChildren( @GrpID )+ ','
		FETCH NEXT FROM CursGroup INTO @GrpID
	END

	CLOSE CursGroup
	DEALLOCATE CursGroup
	IF(@GroupIDsStr <> '')
		SET @GroupIDsStr = LEFT(@GroupIDsStr , LEN(@GroupIDsStr)-1)
	RETURN @GroupIDsStr
END
go

