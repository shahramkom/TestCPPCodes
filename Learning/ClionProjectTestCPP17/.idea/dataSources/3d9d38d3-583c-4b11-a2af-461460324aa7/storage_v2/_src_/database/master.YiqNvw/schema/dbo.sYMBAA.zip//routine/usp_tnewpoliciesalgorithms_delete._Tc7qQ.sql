
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesAlgorithms_Delete] 
   @ID  bigint
   AS
   BEGIN
		IF NOT EXISTS (SELECT EncryptionID FROM TNewPolicyMainTable WHERE EncryptionID = @ID)
        	DELETE FROM [dbo].[TNewPoliciesAlgorithms]  WHERE ID = @ID
		ELSE
			RAISERROR('The selected security profile was assigned before. Please deassign it first.', 16 , 10 )
   END

   go

