
    CREATE PROCEDURE [dbo].[USP_TNewPolicyMain_Update] 
      @ID  bigint,
	  @PolicyType  tinyint,
	  @Name  nvarchar(50),
	  @Enablity  bit,
	  @ServicesID  int,
	  @EncryptionID  int,
	  @AdvancedDetailID  int,
	  @Compression  bit,
	  @PolicyOrder  tinyint,
	  @CreateTime  nvarchar(20),
	  @LastModifyTime  nvarchar(20),
	  @Discription  nvarchar(200),
	  @ApplyTime    tinyint, 
	  @sourceTunnelType  tinyint,
	  @sourceTunnelValue  nvarchar(150),
	  @DestinationTunnelType  tinyint,
	  @DestinationTunnelValue  nvarchar(150),
	  @DirectionType  tinyint,
	  @EncryptionKey  nvarchar(200),
	  @IntegrityKey  nvarchar(200),
	  @TunnelID      int
    AS
    BEGIN
		DECLARE @LastModifyDateTimeNow AS NVARCHAR(20)
		SELECT @LastModifyDateTimeNow = CONVERT(nvarchar(20),GETDATE(),20)	

		Declare @Real_Source_Value as nvarchar(100)
		Declare @Real_Destination_Value as nvarchar(100)

		SET @Real_Source_Value = @sourceTunnelValue
		SET @Real_Destination_Value = @DestinationTunnelValue

		if(@sourceTunnelType = 0)--Source User_Type
			select 	@Real_Source_Value = UserID from TUSER WHERE UserName = @sourceTunnelValue		
		if(@sourceTunnelType = 1)--Source Group_Type
			select 	@Real_Source_Value = GroupID from TGroup WHERE GroupName = @sourceTunnelValue		

		if(@DestinationTunnelType = 0)--Destination User_Type
			select 	@Real_Destination_Value = UserID from TUSER WHERE UserName = @DestinationTunnelValue		
		if(@DestinationTunnelType = 1)--Destination Group_Type
			select 	@Real_Destination_Value = GroupID from TGroup WHERE GroupName = @DestinationTunnelValue	

	Declare @currentApplyTime as int
	Declare @CurrentOrder as int
	Declare @lastOrder as int
	select  @currentApplyTime = ApplyTime ,@CurrentOrder = PolicyOrder from TNewPolicyMainTable WHERE ID = @ID
	if(@currentApplyTime != @ApplyTime)
	BEGIN
		select  @lastOrder = MAX(PolicyOrder) from TNewPolicyMainTable WHERE ApplyTime = @ApplyTime
		IF(@lastOrder IS NULL)
			SET @lastOrder = 1
		ELSE
			SET @lastOrder = @lastOrder + 1
	END
	ELSE
		SET @lastOrder = @CurrentOrder

	UPDATE [dbo].[TNewPolicyMainTable]
    SET [PolicyType] = PolicyType,
      [Name] = @Name,
      [Enablity] = @Enablity,
      [ServicesID] = @ServicesID,
      [EncryptionID] = @EncryptionID,
      [AdvancedDetailID] = @AdvancedDetailID,
      [Compression] = @Compression,
	  [PolicyOrder] = @lastOrder,
      [LastModifyTime] = @LastModifyDateTimeNow,
      [Discription] = @Discription,
	  [ApplyTime]	= @ApplyTime,
      [sourceTunnelType] = @sourceTunnelType,
      [sourceTunnelValue] = @Real_Source_Value,
      [DestinationTunnelType] = @DestinationTunnelType,
      [DestinationTunnelValue] = @Real_Destination_Value,
      [DirectionType] = @DirectionType,
	  [EncryptionKey] = @EncryptionKey ,
	  [IntegrityKey] = @IntegrityKey ,
	  [TunnelID] = @TunnelID
	WHERE ID = @ID

	SELECT @ID
    END

    go

