/******************************************************************************************************************************************************/---------------------------
CREATE PROCEDURE [dbo].[USP_CopyUser]
    @UserID BIGINT,
    @AuthenticationKey NVARCHAR(64) = NULL,
    @VirtualIPStatus NVARCHAR(50) = NULL,
    @VirtualIP NVARCHAR(15) = NULL
AS
BEGIN
		
    IF ( dbo.ISAllowAddUSerCount() = 0 )
        BEGIN
            RAISERROR ('Number of total user exceeded' , 16 , 10)
            RETURN 
        END

    DECLARE @CurrentLoginType AS INT
    SELECT  @CurrentLoginType = LoginType
    FROM    TUSER
    WHERE   UserID = @UserID
    IF ( @CurrentLoginType = 0 )
        IF ( dbo.ISAllowAddUSerUSF() = 0 )
            BEGIN
                RAISERROR ('Number of USF users exceeded.' , 16 , 10)
                RETURN 
            END

    BEGIN TRY
        DROP TABLE #Table
    END TRY
    BEGIN CATCH
    END CATCH

    CREATE TABLE #Table
    (
      CommandLine NVARCHAR(200),
      Param1 NVARCHAR(200),
      [Output] NVARCHAR(64)
    )
--Auth Key
    DECLARE @EncAuthKey NVARCHAR(64) 
    INSERT  #Table
            EXEC Master..XYRunProc 'Encrypt', @AuthenticationKey
    SELECT  @EncAuthKey = [Output]
    FROM    #Table
    WHERE   CommandLine = 'Encrypt'	
    DROP TABLE #Table
    IF ( @EncAuthKey IS NULL )
        BEGIN
            RAISERROR ('The Authentication key is null!  Please check server configs.',16,10)
            RETURN		
        END
		
    DECLARE @CurrentUserName NVARCHAR(50)
    SELECT  @CurrentUserName = UserName
    FROM    TUser
    WHERE   UserID = @UserID
    DECLARE @NewUserName AS NVARCHAR(50)
    SET @NewUserName = dbo.CopyUserName(@UserID, @CurrentUserName)

    IF ( @NewUserName IS NULL )
        BEGIN
            RAISERROR ('The User name is null and can not be continue.',16,10)
            RETURN		
        END		
	IF ( len(@NewUserName) > 50 )
        BEGIN
            RAISERROR ('The User name is too long and can not be continue.',16,10)
            RETURN		
        END				
    DECLARE @CreatedDateTimeNow AS NVARCHAR(20)
    SELECT  @CreatedDateTimeNow = CONVERT(NVARCHAR(20), GETDATE(), 20)	

    DECLARE @GID AS VARCHAR(25)
    SELECT  @GID = dbo.GenerateGID(-1, 0, NULL)	

    IF ( @VirtualIPStatus IS NULL
         OR @VirtualIPStatus = 'Disable' )
        BEGIN
            SET @VirtualIPStatus = 'Dynamic'
            SET @VirtualIP = NULL		
        END	
    
	DECLARE @AccountStatus as int
	select @AccountStatus = AccountDisable from tuser where userID = @UserID
	if(@AccountStatus != 2 AND @AccountStatus != 255)
		SET @AccountStatus = 2
	
    DECLARE @LastInsertedID AS INT
    SET @LastInsertedID = dbo.CreateIdentity()

    INSERT  INTO TUser
            ( 
			  UserId,	
			  UserName,
              BindingStatus,
              BindingPCID,
              IPBindingStatus,
              SubNetIP,
              SubNetMask,
              VirtualIPStatus,
              VirtualIP,
              UserPIN,
              MasterPIN,
              AuthenticationKey,
              MustChangePIN,
              AccountDisable,
              RejOnKeepAliveFail,
              ShowUserPrivilege,
              AuthType,
              CertType,
              CertValue,
              FirstName,
              LastName,
              Gender,
              Office,
              Province,
              Town,
              Company,
              Notes,
              Email,
              Cell,
              PersonnelCode,
              Phone,
              NationalID,
              Adress,
              PostalCode,
              [Owner],
              Permission_ID,
              UnBlockPIN,
              InterfaceBindingStatus,
              LoginType,
              LockModule,
              ExpireDate,
              VersionBindingStatus,
              BindingVersion,
              CreateTime,
              LastModifiedTime,
              SendDNS,
              DisableModernPolicy,
			  Version, 
              DriverType,
			  DisableResult,
              GID )
            SELECT 
					@LastInsertedID,	
					@NewUserName,
                    'Unbound',
                    NULL,
                    IPBindingStatus,
                    SubNetIP,
                    SubNetMask,
                    @VirtualIPStatus,
                    @VirtualIP,
                    UserPIN,
                    MasterPIN,
                    @EncAuthKey,
                    MustChangePIN,
                    @AccountStatus,
                    RejOnKeepAliveFail,
                    ShowUserPrivilege,
                    AuthType,
                    CertType,
                    CertValue,
                    NULL,
                    NULL,
                    Gender,
                    Office,
                    Province,
                    Town,
                    Company,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    [Owner],
                    Permission_ID,
                    UnBlockPIN,
                    InterfaceBindingStatus,
                    LoginType,
                    LockModule,
                    ExpireDate,
                    VersionBindingStatus,
                    BindingVersion,
                    @CreatedDateTimeNow,
                    @CreatedDateTimeNow,
                    SendDNS,
                    DisableModernPolicy,
					NULL, 
					DriverType,
					NULL,
                    @GID
            FROM    TUSER
            WHERE   UserID = @UserID

    IF ( @LastInsertedID > 0 )
        BEGIN
            EXEC USP_CopyUser_GroupAssignments @UserID, @LastInsertedID, @GID
            EXEC USP_CopyUser_PolicyAssignments @UserID, @LastInsertedID
            EXEC USP_CopyUser_TimeSetAssignments @UserID, @LastInsertedID
            EXEC USP_CopyUser_ScriptAssignments @UserID, @LastInsertedID
            EXEC USP_CopyUser_DNSAssignments @UserID, @LastInsertedID
            EXEC USP_CopyUser_InterfaceAssignments @UserID, @LastInsertedID
        END
	
END
/******************************************************************************************************************************************************/---------------------------------------------------
go

