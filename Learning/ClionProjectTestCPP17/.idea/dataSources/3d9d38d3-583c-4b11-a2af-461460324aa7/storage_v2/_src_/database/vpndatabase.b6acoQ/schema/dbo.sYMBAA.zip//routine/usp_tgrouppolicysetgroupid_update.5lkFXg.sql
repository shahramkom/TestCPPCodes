


    CREATE PROCEDURE [dbo].[USP_TGroupPolicySetGroupID_Update] 
        -- Add the parameters for the stored procedure here
      
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
            update e1
        set GroupID = e.GroupId
        from TGroupPolicySet e1
        join TGroup e
        on e.oldgroupID = e1.GroupID
            
    END

    go

