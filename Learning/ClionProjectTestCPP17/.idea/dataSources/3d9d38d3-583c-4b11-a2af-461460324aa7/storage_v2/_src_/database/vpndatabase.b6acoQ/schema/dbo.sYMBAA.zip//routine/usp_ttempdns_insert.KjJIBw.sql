
    CREATE PROCEDURE [dbo].[USP_TTempDNS_Insert] 
    
        @HostName nvarchar(50) = NULL ,
        @IP		  nvarchar(15) = NULL ,
        @Replace int = 0
        
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
    
        declare @exist int
        set @exist = 0 
        select  @exist = count(DNSID) from TDNS where  HostName = @HostName 
        
        if(@exist>0)
        begin
            if(@Replace!=0) 
              begin
                 delete from TUserDNS where DNSID in  (select DNSID from TDNS where HostName = @HostName)
                 delete from TGroupDNS where DNSID in  (select DNSID from TDNS where HostName = @HostName)
                 delete from TDNS  where  HostName = @HostName 
              end
            else
             return
        end 

    
        Insert Into TDNS(HostName,IP)Values (@HostName,@IP)
    END

    go

