
    CREATE PROCEDURE [dbo].[USP_Select_Multigroups_USerID]
        -- Add the parameters for the stored procedure here
    @groupIDList	nvarchar(4000)
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
        ----for editing in group nesting use this line
        select distinct UserID from TUserGroups where GroupID in ( SELECT * FROM dbo.Splitfn(@groupIDList,','))

        ----for editing in other versions use this line
        --select distinct UserID from TUser where GroupID in ( SELECT * FROM dbo.Splitfn(@groupIDList,','))
    END


    go

