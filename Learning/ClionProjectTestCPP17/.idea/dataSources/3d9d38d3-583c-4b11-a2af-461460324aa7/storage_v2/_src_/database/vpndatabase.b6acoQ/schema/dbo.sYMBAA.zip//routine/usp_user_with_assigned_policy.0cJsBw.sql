
CREATE PROCEDURE [dbo].[USP_User_With_Assigned_Policy] 
	@WhereStm As nvarchar(MAX),
	@ContainInherited As bit,
	@SetPaging as bit,
	@PageNumber as int,
	@RowNumInPage as int,
	@SortFiled as nvarchar(50),
	@SortType as nvarchar(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @BaseSTM as nvarchar(MAX)
	SET @BaseSTM  = ''
	
	
	DECLARE @CTEStm as nvarchar(MAX)
	SET @CTEStm =
		'WITH GroupIDTree (GroupID,ParentID) AS
		(
		/*Anchor member definition*/
		SELECT     TGroup.GroupID ,TGroup.ParentID 
		FROM       TGroup INNER JOIN
				   TGroupPolicySet ON TGroup.GroupID = TGroupPolicySet.GroupID INNER JOIN
				   TPolicySet ON TGroupPolicySet.PSID = TPolicySet.PSID

		UNION ALL
		/*Recursive member definition*/
			SELECT       TGroup.GroupID,TGroup.ParentID
			FROM         TGroup
						 INNER JOIN  GroupIDTree as GID
						 ON (TGroup.ParentID = GID.GroupID)
		)'
	/*Statement that executes the CTE*/
	DECLARE @InheritedGroupSelectStm as nvarchar(MAX)
	SET @InheritedGroupSelectStm =
	 '  SELECT     TUser.*,dbo.RetrieveInterfaceNames(TUser.UserID) as InterfaceBinding
		FROM       TUser INNER JOIN
		TUserGroups ON TUser.UserID = TUserGroups.UserID INNER JOIN
		TGroup ON TUserGroups.GroupID = TGroup.GroupID INNER JOIN
		GroupIDTree as GIT  ON GIT.GroupID = TGroup.GroupID'
		
	
	DECLARE @UserSelectStm as nvarchar(MAX)
	SET @UserSelectStm=
	 ' SELECT TUser.*,dbo.RetrieveInterfaceNames(TUser.UserID) as InterfaceBinding
	   FROM   TUser INNER JOIN
	   TUserPolicySet ON TUser.UserID = TUserPolicySet.UserID
	   
	   UNION
	   
	   SELECT     dbo.TUser.*,dbo.RetrieveInterfaceNames(TUser.UserID) as InterfaceBinding
	   FROM         dbo.TUser INNER JOIN
       dbo.TUserGroups ON dbo.TUser.UserID = dbo.TUserGroups.UserID INNER JOIN
       dbo.TGroupPolicySet ON dbo.TUserGroups.GroupID = dbo.TGroupPolicySet.GroupID '
	
	----------------------------------------------------------
	/*Create Paging stm*/
	 declare @lbound as int,
			 @ubound as int
	IF (@RowNumInPage < 1 OR @RowNumInPage is NULL )
		SET @RowNumInPage = 20 
	IF (@PageNumber < 1 OR @PageNumber is NULL) 
		SET @PageNumber = 1
	SET @lbound = ((@PageNumber-1) * @RowNumInPage)
	SET @ubound = ((@PageNumber) * @RowNumInPage)+1
	
	if(@ContainInherited = 1)
		SET @BaseSTM = @CTEStm 
		
	IF(@SortFiled is NULL)
		SET @SortFiled = 'UserID'
	IF(@SortType is NULL)
		SET @SortType = 'ASC'	
	SET @BaseSTM = @BaseSTM +'Select * INTO #PagingTable  from( select TUserWithRowNum.* ,ROW_NUMBER() OVER(ORDER BY TUserWithRowNum.'+@SortFiled+' '+@SortType+' ) as RowNumber  from('
	
	if(@ContainInherited = 1)
		SET @BaseSTM =@BaseSTM+@InheritedGroupSelectStm +' UNION '
	
	SET @BaseSTM = @BaseSTM+@UserSelectStm +') TUserWithRowNum '
	
	--------------------------------------------------------					
	--create where stm
	IF(@WhereStm is not NULL)
		SET @BaseSTM = @BaseSTM+' WHERE('+ @WhereStm +')'
	
	SET @BaseSTM = @BaseSTM + ') as AllRecordTable '

	--create paging
	SET @BaseSTM = @BaseSTM+'; SELECT * FROM #PagingTable '
	--Creat Paging table
	IF(@SetPaging = 1)
		SET @BaseSTM = @BaseSTM+' WHERE ( RowNumber > '+ cast(@lbound as nvarchar(10)) +' AND RowNumber < '+cast(@ubound as nvarchar(10))  +')'

	--------------------------------------------------------
	-- Select Table Count	
	SET @BaseSTM = 'begin try
			 DROP TABLE #PagingTable
			 end try
			 begin catch
			 end catch;' +@BaseSTM+'; SELECT COUNT(*) AS [RowCount] FROM #PagingTable'	
	--Excuting command
	--select @BaseSTM
	EXEC dbo.sp_executesql @BaseSTM  	

END
go

