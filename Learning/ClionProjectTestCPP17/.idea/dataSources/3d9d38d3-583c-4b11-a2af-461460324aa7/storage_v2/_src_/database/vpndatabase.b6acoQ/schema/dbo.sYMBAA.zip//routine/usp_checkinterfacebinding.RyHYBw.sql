
	CREATE PROCEDURE [dbo].[USP_CheckInterfaceBinding] 
		-- Add the parameters for the stored procedure here
		@UserID int = NULL,
		@InterFaceIP nvarchar(20) = NULL
	
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;
		DECLARE @IBStatus bit
		set @IBStatus = 0
		SELECT @IBStatus = InterfaceBindingStatus FROM TUser where userid=@UserID
		IF(@IBStatus = 1) -- user have interface binding
		BEGIN
			DECLARE @IPAddress nvarchar(20)
			DECLARE interface_cursor CURSOR FOR 
			SELECT ti.InterfaceIPAddress from TuserInterface tui inner join TInterface ti on 
			(tui.InterfaceID = ti.InterfaceID) where tui.UserID =@UserID order by ti.InterfaceID

			OPEN interface_cursor

			FETCH NEXT FROM interface_cursor 
			INTO @IPAddress
			WHILE @@FETCH_STATUS = 0
				BEGIN
					IF(@IPAddress = @InterFaceIP)
					Begin
						SELECT 1
						CLOSE interface_cursor
						DEALLOCATE interface_cursor
						return (1)
					End
				
					FETCH NEXT FROM interface_cursor 
					INTO @IPAddress
				END
			CLOSE interface_cursor
			DEALLOCATE interface_cursor
		
			SELECT 0
			return (0)

		END
		ELSE -- read user group
			BEGIN
				DECLARE @GroupID int
				DECLARE group_cursor CURSOR FOR 
				SELECT GroupID From TUserGroups where UserId = @UserID order by GPriority
				OPEN group_cursor

				FETCH NEXT FROM group_cursor 
				INTO @GroupID
				WHILE @@FETCH_STATUS = 0
					BEGIN
						WHILE (@GroupID <> 0)
							BEGIN
										--DEBUG
										--select @GROupID
								set @IBStatus = 0
								SELECT @IBStatus = InterfaceBindingStatus FROM TGroup WHERE GroupID=@GroupID
									IF(@IBStatus = 1) -- Gruop have interface binding
									BEGIN
										DECLARE @IPAddress2 nvarchar(20)
										DECLARE interface_cursor2 CURSOR FOR 
										SELECT ti.InterfaceIPAddress from TGroupInterface tgi inner join TInterface ti on
										 (tgi.InterfaceID = ti.InterfaceID) where tgi.GroupID = @GroupID order by ti.InterfaceID
										OPEN interface_cursor2

										FETCH NEXT FROM interface_cursor2 
										INTO @IPAddress2
										WHILE @@FETCH_STATUS = 0
											BEGIN
												--DEBUG
												--select @IPAddress2	
												IF(@IPAddress2 = @InterFaceIP)
												Begin
													---DEBUG
													--SELECT 'c2'
													SELECT 1
													CLOSE interface_cursor2
													DEALLOCATE interface_cursor2
													CLOSE group_cursor
													DEALLOCATE group_cursor
													return (1)
												End
												FETCH NEXT FROM interface_cursor2 
												INTO @IPAddress2
											END
										
										CLOSE interface_cursor2
										DEALLOCATE interface_cursor2
										CLOSE group_cursor
										dEALLOCATE group_cursor
										---DEBUG
										--SELECT 'c2-0'
										SELECT 0
										return (0)

									END
									select @GroupID = ParentID  from TGroup where GroupID = @GroupID
							END
					
					FETCH NEXT FROM group_cursor 
					INTO @GroupID
					----DEBUG
							--SELECT @GroupID
							--SELECT 'TEST'
					END
					CLOSE group_cursor
					DEALLOCATE group_cursor
					---DEBUG
						--SELECT 'c1'
					SELECT 1
					return (1)
				
			END
			---DEBUG
					--SELECT 'c0'
			return (1)
	END

  go

