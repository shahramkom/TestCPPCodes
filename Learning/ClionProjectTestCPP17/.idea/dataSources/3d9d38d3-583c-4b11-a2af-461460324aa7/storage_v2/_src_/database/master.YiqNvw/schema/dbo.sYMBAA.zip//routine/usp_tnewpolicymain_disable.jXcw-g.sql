
   CREATE PROCEDURE [dbo].[USP_TNewPolicyMain_Disable] 
    @ID  bigint
   AS
   BEGIN
		UPDATE TNewPolicyMainTable  SET Enablity = Enablity ^ 1 WHERE ID = @ID
   END

   go

