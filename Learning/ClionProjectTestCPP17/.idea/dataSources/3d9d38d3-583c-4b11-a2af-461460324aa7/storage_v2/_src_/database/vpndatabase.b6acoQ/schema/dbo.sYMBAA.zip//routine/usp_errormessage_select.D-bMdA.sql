
    create PROCEDURE [dbo].[USP_ErrorMessage_Select] 
    AS
    BEGIN
        select * from TEmessage
    END

    go

