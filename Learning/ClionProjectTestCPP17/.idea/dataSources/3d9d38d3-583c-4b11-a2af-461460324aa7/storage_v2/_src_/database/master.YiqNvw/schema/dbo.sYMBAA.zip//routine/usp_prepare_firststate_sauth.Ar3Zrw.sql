CREATE PROCEDURE [dbo].[USP_Prepare_FirstState_SAuth] 
	@UserID BIGINT
AS
BEGIN
	DECLARE @isUserIDFound TINYINT
	SELECT @isUserIDFound = COUNT(UserID) FROM TUser WHERE UserID = @UserID
	IF(@isUserIDFound = 0 )
	BEGIN
		SELECT 'User_Not_Found' As UserValidity
		return
	END
	DECLARE @PolicyAssign INT

	SELECT 'User_IS_Available' As UserValidity
	DECLARE @ALLGroupsOFUser NVARCHAR(2000)
	SET @ALLGroupsOFUser = dbo.GetAllRelatedGroupsOfUser(@UserID)
	--Primary User Value
		EXEC USP_User_Filter @UserID
	--User Authentication Key
		EXEC USP_Get_User_AuthKey @UserID
	--User assigned groups
		EXEC USP_getGroupsOfAUser @UserID
	--User send DNS Check
		EXEC UPS_Get_User_SendDNS_Status @UserID
	--User Time set Check
		EXEC UPS_CheckTimeSet_Status @UserID,@ALLGroupsOFUser
	EXEC USP_Get_UserAssignToAnyPolicySet @UserID,@ALLGroupsOFUser,@PolicyAssign OUTPUT
	IF(@PolicyAssign  =  0 )
	BEGIN
		SELECT 0 AS SimplePolicy--For Simple Policy
		SELECT 0 AS AdvancedPolicy --For Advanced Policy
	END
	ELSE
	BEGIN
		DECLARE @ALLPSID NVARCHAR(2000)
		EXEC USP_getAllRelatedPSIDofUser  @UserID,@ALLGroupsOFUser , @ALLPSID OUTPUT
		--User Have Any Simple Policy
			EXEC UPS_Check_UserHave_AnySimplePolicy @ALLPSID
		--User Have Any Advanced Policy
			EXEC UPS_Check_UserHave_AnyAdvancedPolicy @ALLPSID
	END
	--User Have Any Modern Policy
		EXEC UPS_Check_UserHave_AnyModernPolicy @UserID,@ALLGroupsOFUser
	--User Have Any Script
		EXEC UPS_Check_UserHave_AnyScript @UserID,@ALLGroupsOFUser
	--User Have Any DNS
		EXEC UPS_Check_UserHave_AnyDNS @UserID,@ALLGroupsOFUser		
	--User Have Any Interface
		EXEC UPS_Check_UserHave_AnyInterface @UserID,@ALLGroupsOFUser
END
go

