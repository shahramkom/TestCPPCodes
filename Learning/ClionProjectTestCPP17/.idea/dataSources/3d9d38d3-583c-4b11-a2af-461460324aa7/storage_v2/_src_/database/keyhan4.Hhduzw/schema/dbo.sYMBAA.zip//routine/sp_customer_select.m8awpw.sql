CREATE PROCEDURE [dbo].[sp_Customer_Select]  
	@ManagerSqlPass varchar(64)
AS
	SELECT CustomerName FROM ProfileSetting
	WHERE (ManagerSqlPass = @ManagerSqlPass)
go

