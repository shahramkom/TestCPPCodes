/******************************************************************************************************************************************************/--
CREATE FUNCTION dbo.GetAssignTableIDFieldName(@TableName VARCHAR(50))
RETURNS VARCHAR(50)
BEGIN
	DECLARE @TableIDFieldName AS VARCHAR(50)
	SET @TableIDFieldName = 
	(CASE 	
			WHEN @TableName = 'TgroupScript' OR @TableName = 'TUserScripts'
			THEN 'ScriptID'
			WHEN @TableName = 'TGroupPolicySet' OR @TableName = 'TUserPolicySet'
			THEN 'PSID'
			WHEN @TableName = 'TgroupDNS' OR @TableName = 'TUserDNS'
			THEN 'DNSID'
			WHEN @TableName = 'TGroupInterface' OR @TableName = 'TUserInterface'
			THEN 'InterfaceID'
			WHEN @TableName = 'TUserKeya' OR @TableName = 'TUserGroups'
			THEN 'UserID'
			WHEN @TableName = 'TgroupTimeset'
			THEN 'TRID'
			WHEN @TableName = 'TUserTimeSet'
			THEN 'TimeSetId'
			WHEN @TableName = 'TServerAccessPolicy' 
			THEN 'PSID'
			WHEN @TableName = 'TUserFirewallPolicy'
			THEN 'UFPID'
	END)	
	RETURN @TableIDFieldName
END
go

