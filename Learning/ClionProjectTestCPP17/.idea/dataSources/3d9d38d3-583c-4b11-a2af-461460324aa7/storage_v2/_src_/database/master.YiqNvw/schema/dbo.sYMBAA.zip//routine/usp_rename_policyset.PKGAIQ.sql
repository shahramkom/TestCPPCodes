
    create PROCEDURE  [dbo].[USP_Rename_PolicySet]

            @K3groupName  nvarchar(max)
        ,@oldPSName nvarchar(max)
        ,@Replace int 	 
    AS
    BEGIN
        SET NOCOUNT ON;
        declare @pIDN int
            declare @rowCount int   
        select @rowCount = count(*)  from TPolicySet where PSName = @K3groupName
        if(@rowCount>0) 
        begin
            if(@Replace = 1 ) 
                begin
                    select @pIDN= PSID from  TPolicySet where PSName= @K3groupName  
                    delete from TPolicySet where PSID  = @pIDN
                    delete from TServerAccessPolicy where PSID = @pIDN
                    delete from TGroupPolicySet where  PSID = @pIDN
                    delete from TUserFirewallPolicy where  PSID = @pIDN
                
                end 
            else
            begin
                select @pIDN= PSID from  TPolicySet where PSName= @oldPSName  
                delete from TPolicySet where PSID  = @pIDN
                delete from TServerAccessPolicy where PSID = @pIDN
                delete from TGroupPolicySet where  PSID = @pIDN
                delete from TUserFirewallPolicy where  PSID = @pIDN			 
                 return
            end		
        end
    
            select @pIDN= PSID from  TPolicySet where PSName= @oldPSName  
           UPDATE TPolicySet
            set PSName = @K3groupName 
            where  PSID = @pIDN  

        UPDATE TPolicySet
        set oldPSID = NULL
    END
    go

