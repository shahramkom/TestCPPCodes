


    CREATE PROCEDURE [dbo].[USP_TGroup_FilterGroupID] 
        -- Add the parameters for the stored procedure here
    @GroupID int
      
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        --SET NOCOUNT ON;
        SELECT GroupName from TGroup 
        where GroupID=@GroupID
            
    END

    go

