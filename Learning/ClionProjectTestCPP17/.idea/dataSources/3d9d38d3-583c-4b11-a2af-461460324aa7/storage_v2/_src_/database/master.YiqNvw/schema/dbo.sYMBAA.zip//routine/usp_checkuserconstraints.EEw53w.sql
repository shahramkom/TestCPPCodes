/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE USP_CheckUserConstraints
		@ActionType VARCHAR(50),
		@RecordID INT,
		@UserName NVARCHAR(100),
		@VirtualIP NVARCHAR(20),
		@LoginType TINYINT,			
		@ResultMsg VARCHAR(500) OUTPUT
AS
BEGIN
			SET @ResultMsg = NULL
		IF(@ActionType = 'Insert-Tuser')
		BEGIN
			DECLARE @nTotalCount int , @nTotalUser int , @nRepUsers int , @nDuplicateUsers int 
			select @nTotalCount = count(*) from  TUser
			select @nTotalUser  = [value] from TSetting where Property = 'TotalUser'
			if (@nTotalUser < @nTotalCount + 1 )
			BEGIN
        		 SELECT @ResultMsg = '|User_Exceed'
				 RETURN
			END
			
			if(@LoginType = 0)
			begin
				declare @DefinedUsfCount int, @PermittedUsfCount int
				set @DefinedUsfCount = 0
				set @PermittedUsfCount = 0
				select @DefinedUsfCount = count(*) from  TUser where LoginType = 0
				select @PermittedUsfCount  = [value] from TSetting where Property = 'UsfUserCount'
				if (@PermittedUsfCount < @DefinedUsfCount + 1 )
				BEGIN
        		    SELECT @ResultMsg = '|USF_Exceed'
					RETURN
				END
			end
		END

        set @nRepUsers = 0
		IF(@ActionType = 'Insert-Tuser')
		BEGIN
			select @nRepUsers = count(*) from TUser where VirtualIPStatus='static' AND VirtualIP IS NOT NULL AND VirtualIP  = @VirtualIP 
		END
		ELSE IF (@ActionType = 'Update-Tuser')
		BEGIN
			select @nRepUsers = count(*) from TUser where UserID <> @RecordID AND VirtualIPStatus='static' AND VirtualIP IS NOT NULL AND VirtualIP  = @VirtualIP 
		END
       
        IF((@ActionType = 'Insert-Tuser' AND @nRepUsers > 0) OR (@ActionType = 'Update-Tuser' AND @nRepUsers > 0))
        BEGIN
            SELECT @ResultMsg = '|VIP_Conflict'
			RETURN
        END    
        set @nDuplicateUsers = 0
        select @nDuplicateUsers = count(*) from TUser where UserName IS NOT NULL AND UserName  = @UserName AND UserID <> @RecordID
        if(@nDuplicateUsers > 0)
        BEGIN
            SELECT @ResultMsg = '|Name_Conflict'
			RETURN
        END
		SELECT @ResultMsg
END

go

