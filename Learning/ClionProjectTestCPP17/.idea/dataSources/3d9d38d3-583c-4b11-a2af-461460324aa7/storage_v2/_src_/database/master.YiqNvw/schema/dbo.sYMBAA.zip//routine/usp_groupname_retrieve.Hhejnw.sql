
    CREATE PROCEDURE [dbo].[USP_GroupName_Retrieve]
        @GroupID int
     AS
    BEGIN	
			declare @Statement as nvarchar(max)
			set @Statement = ' Select GroupName from Tgroup Where GroupID = '+ convert(nvarchar(50),@GroupID)			
			exec sp_executesql @Statement
    END

    go

