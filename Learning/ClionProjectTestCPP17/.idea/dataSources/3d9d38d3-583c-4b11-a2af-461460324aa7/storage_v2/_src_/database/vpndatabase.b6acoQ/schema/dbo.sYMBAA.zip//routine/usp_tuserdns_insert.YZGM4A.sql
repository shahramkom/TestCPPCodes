CREATE PROCEDURE [dbo].[USP_TUserDNS_Insert]
@UserID   int,
@DNSID	  int

AS
BEGIN
    IF NOT EXISTS(SELECT * FROM TUserDNS WHERE UserID = @UserID AND DNSID = @DNSID)
		INSERT INTO TUserDNS VALUES(@UserID,@DNSID)

	declare @CreateDateTime as nvarchar(20)
	select @CreateDateTime = CONVERT(nvarchar(20),GETDATE(),20)
	select @CreateDateTime
	Update Tuser set LastModifiedTime = @CreateDateTime where UserID = @UserID
END
go

