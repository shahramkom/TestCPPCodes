
    create PROCEDURE [dbo].[USP_ErrorMessage_Update] 
        @UseDefault bit,
        @ErrorMessage nvarchar(100), 
        @mes_type int
    
    AS
    BEGIN
        update TEMessage set
        UseDefault = @UseDefault,
        ErrorMessage = @ErrorMessage

        WHERE 
        MessageType = @mes_type
    END

    go

