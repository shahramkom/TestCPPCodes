--------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[RestoreDatabase]
	@BackupAddress AS varchar(1000)
AS
BEGIN	
	DECLARE @result NVARCHAR(MAX)   
	BEGIN TRY
		IF EXISTS (SELECT 1 FROM sys.databases WHERE name = 'VPNDataBase_Restore')
			DROP DATABASE VPNDataBase_Restore

		RESTORE DATABASE VPNDataBase_Restore FROM DISK = @BackupAddress
		WITH MOVE 'VPNDataBase' TO 'C:\starsecfiles4\OrganizationDB\VPNDataBase_Restore.mdf',
		MOVE 'VPNDataBase_log' TO 'C:\starsecfiles4\OrganizationDB\VPNDataBase_Restore.ldf'

		EXEC [VPNDataBase].[dbo].[SyncDatabases] 1

		SELECT @Result = 'Restore completed successfully.'
	END TRY  
	BEGIN CATCH
		SELECT @Result = 'Error occurred in restore: '+ ERROR_MESSAGE()
	END CATCH

	SELECT @result
	DROP DATABASE VPNDataBase_Restore
END
go

