
CREATE PROCEDURE [dbo].[USP_Select_Groups_FromPSID]
        @PSID as bigint
        AS
BEGIN
     SELECT        dbo.TGroup.GroupID, dbo.TGroup.GroupName
FROM            dbo.TPolicySet INNER JOIN
                         dbo.TGroupPolicySet ON dbo.TPolicySet.PSID = dbo.TGroupPolicySet.PSID INNER JOIN
                         dbo.TGroup ON dbo.TGroupPolicySet.GroupID = dbo.TGroup.GroupID
WHERE        (dbo.TPolicySet.PSID = @PSID)
END
go

