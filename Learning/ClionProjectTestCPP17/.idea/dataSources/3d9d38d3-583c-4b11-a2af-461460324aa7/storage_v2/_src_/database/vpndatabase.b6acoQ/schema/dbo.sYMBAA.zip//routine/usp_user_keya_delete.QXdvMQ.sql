CREATE  PROCEDURE  [dbo].[USP_USER_KEYA_Delete]
    @KeyaSerial nvarchar(50),
    @UserID	int
AS 
BEGIN

    DECLARE @gid AS VARCHAR(25)
	DECLARE @version AS INT
	SET @gid = NULL
	SET @version = 0
	SELECT @gid = GID FROM dbo.TUserkeya WHERE UserID = @UserID	AND KeyaSerial = @KeyaSerial
	
	IF (@gid IS NOT NULL )
	BEGIN
		DECLARE @first AS INT
		DECLARE @second AS INT

		SET @first = CHARINDEX(',',@gid)
		SET @second = CHARINDEX(',', @gid, @first + 1)
		SET @version = SUBSTRING(@gid, @first + 1, @second - @first -1) + 1
	END
    UPDATE dbo.TUserKeya SET GID = dbo.GenerateGID(-1, @version, NULL) WHERE UserID = @UserID AND KeyaSerial = @KeyaSerial
	    
    DELETE FROM TUserKeya WHERE UserID = @UserID AND KeyaSerial = @KeyaSerial
END
go

