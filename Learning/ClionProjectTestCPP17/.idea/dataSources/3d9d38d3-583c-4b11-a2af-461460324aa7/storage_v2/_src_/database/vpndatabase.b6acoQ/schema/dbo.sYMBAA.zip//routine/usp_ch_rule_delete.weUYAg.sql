
CREATE PROCEDURE [dbo].[USP_CH_Rule_Delete] 
    @RuleID int = 0
AS
	BEGIN
		DELETE FROM HealthCheckRules    WHERE RuleID =  @RuleID
END
go

