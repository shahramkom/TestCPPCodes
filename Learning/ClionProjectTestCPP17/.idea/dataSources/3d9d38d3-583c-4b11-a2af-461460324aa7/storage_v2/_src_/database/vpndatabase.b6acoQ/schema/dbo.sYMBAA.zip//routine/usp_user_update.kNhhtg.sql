/******************************************************************************************************************************************************/------------------------------------------------------        
CREATE PROCEDURE [dbo].[USP_User_Update]
    @UserID INT, 
        --@GroupID			int				= NULL	,	
    @UserName NVARCHAR(200) = NULL,
    @BindingStatus NVARCHAR(50) = NULL,
    @BindingPCID NVARCHAR(100) = NULL,
    @IPBindingStatus NVARCHAR(20) = NULL,
    @SubNetIP NVARCHAR(50) = NULL,
    @SubNetMask NVARCHAR(50) = NULL,
    @VirtualIPStatus NVARCHAR(50) = NULL,
    @VirtualIP NVARCHAR(15) = NULL,
    @UserPIN NVARCHAR(200) = NULL,
    @MasterPIN NVARCHAR(200) = NULL,
    @AuthenticationKey NVARCHAR(64) = NULL,
    @MustChangePIN BIT = NULL,
    @AccountDisable tinyInt = NULL,
    @RejOnKeepAliveFail BIT = NULL,
    @ShowUserPrivilege BIT = NULL,
    @AuthType TINYINT = NULL,
    @CertType NVARCHAR(50) = NULL,
    @CertValue NVARCHAR(64) = NULL,
    @FirstName NVARCHAR(200) = NULL,
    @LastName NVARCHAR(200) = NULL,
    @Gender NVARCHAR(10) = NULL,
    @Company NVARCHAR(200) = NULL,
    @Office NVARCHAR(200) = NULL,
    @Province NVARCHAR(200) = NULL,
    @Town NVARCHAR(200) = NULL,
    @Notes NVARCHAR(MAX) = NULL,
    @Email NVARCHAR(200) = NULL,
    @Cell NVARCHAR(50) = NULL,
    @PersonnelCode NVARCHAR(10) = NULL,
    @Phone NVARCHAR(200) = NULL,
    @NationalID NVARCHAR(10) = NULL,
    @Adress NVARCHAR(MAX) = NULL,
    @PostalCode NVARCHAR(200) = NULL,
    @Owner INT = NULL,
    @Permission_ID BIGINT = NULL,
    @UnBlockPIN NVARCHAR(200) = NULL,
    @changes NVARCHAR(50) = NULL,
    @interfaceBindingStatus AS BIT = 0,
    @LoginType AS TINYINT = 2,
    @LockModule AS BIT = 0,
    @ExpireDate NVARCHAR(20) = NULL,
    @VersionBindingStatus NVARCHAR(50) = 'Unbound',
    @BindingVersion NVARCHAR(10) = NULL,
    @SendDNS BIT = NULL,
    @DisableModernPolicy AS BIT = 1,
	@DriverType AS tinyInt = 0xFA,
	@DisableResult AS nvarchar(100) = NULL
    WITH RECOMPILE
AS
BEGIN
    DECLARE @GeneralUserInfo AS BIT
    DECLARE @UserInfo AS BIT
    DECLARE @OrganizationInfo AS BIT
    DECLARE @CommentsInfo AS BIT
    DECLARE @StatusInfo AS BIT
    DECLARE @LoginInfo AS BIT
    DECLARE @ModuleInfo AS BIT
    DECLARE @CertInfo AS BIT
    DECLARE @AccountInfo AS BIT        
    DECLARE @NetConfigInfo AS BIT
    DECLARE @SpecialPermInfo AS BIT
    DECLARE @IPBindingInfo AS BIT
    DECLARE @BindingInfo AS BIT
    DECLARE @InterfacBindingInfo AS BIT
    DECLARE @VIPInfo AS BIT
    DECLARE @VersionInfo AS BIT       
    DECLARE @MailInfo AS BIT
    DECLARE @LocationInfo AS BIT
    DECLARE @PostalInfo AS BIT	
	DECLARE @DriverTypeInfo AS BIT
		
    SET @GeneralUserInfo = 0
    SET @UserInfo = 0
    SET @OrganizationInfo = 0
    SET @CommentsInfo = 0
    SET @StatusInfo = 0 
    SET @LoginInfo = 0
    SET @ModuleInfo = 0
    SET @CertInfo = 0
    SET @AccountInfo = 0
    SET @NetConfigInfo = 0
    SET @SpecialPermInfo = 0
    SET @IPBindingInfo = 0
    SET @BindingInfo = 0       
    SET @InterfacBindingInfo = 0       
    SET @VIPInfo = 0
    SET @VersionInfo = 0
    SET @MailInfo = 0
    SET @LocationInfo = 0
    SET @PostalInfo = 0
	set @DriverTypeInfo = 0
        
    DECLARE @LastModifyDateTime AS NVARCHAR(20)
	SELECT  @LastModifyDateTime = CONVERT(NVARCHAR(20), GETDATE(), 20)

	DECLARE @GID AS VARCHAR(25)
	SET @GID = dbo.GenerateNewGID(@UserID)
		
    IF ( @changes IS NOT NULL )
        BEGIN
            IF ( SUBSTRING(@changes, 1, 1) = '1' )
                SET @GeneralUserInfo = 1
            ELSE
                SET @GeneralUserInfo = 0
            IF ( SUBSTRING(@changes, 2, 1) = '1' )
                SET @UserInfo = 1
            ELSE
                SET @UserInfo = 0
            IF ( SUBSTRING(@changes, 3, 1) = '1' )
                SET @OrganizationInfo = 1
            ELSE
                SET @OrganizationInfo = 0
            IF ( SUBSTRING(@changes, 4, 1) = '1' )
                SET @CommentsInfo = 1
            ELSE
                SET @CommentsInfo = 0
            IF ( SUBSTRING(@changes, 5, 1) = '1' )
                SET @StatusInfo = 1
            ELSE
                SET @StatusInfo = 0
            IF ( SUBSTRING(@changes, 6, 1) = '1' )
                SET @LoginInfo = 1
            ELSE
                SET @LoginInfo = 0
            IF ( SUBSTRING(@changes, 7, 1) = '1' )
                SET @ModuleInfo = 1
            ELSE
                SET @ModuleInfo = 0
            IF ( SUBSTRING(@changes, 8, 1) = '1' )
                SET @CertInfo = 1
            ELSE
                SET @CertInfo = 0
            IF ( SUBSTRING(@changes, 9, 1) = '1' )
                SET @AccountInfo = 1
            ELSE
                SET @AccountInfo = 0
			
            IF ( SUBSTRING(@changes, 10, 1) = '1' )
                SET @NetConfigInfo = 1
            ELSE
                SET @NetConfigInfo = 0

            IF ( SUBSTRING(@changes, 11, 1) = '1' )
                SET @SpecialPermInfo = 1
            ELSE
                SET @SpecialPermInfo = 0
            IF ( SUBSTRING(@changes, 12, 1) = '1' )
                SET @IPBindingInfo = 1
            ELSE
                SET @IPBindingInfo = 0
            IF ( SUBSTRING(@changes, 13, 1) = '1' )
                SET @BindingInfo = 1
            ELSE
                SET @BindingInfo = 0
            IF ( SUBSTRING(@changes, 14, 1) = '1' )
                SET @InterfacBindingInfo = 1
            ELSE
                SET @InterfacBindingInfo = 0
            IF ( SUBSTRING(@changes, 15, 1) = '1' )
                SET @VIPInfo = 1
            ELSE
                SET @VIPInfo = 0
            IF ( SUBSTRING(@changes, 16, 1) = '1' )
                SET @VersionInfo = 1
            ELSE
                SET @VersionInfo = 0
            IF ( SUBSTRING(@changes, 17, 1) = '1' )
                SET @MailInfo = 1
            ELSE
                SET @MailInfo = 0            
            IF ( SUBSTRING(@changes, 18, 1) = '1' )
                SET @LocationInfo = 1
            ELSE
                SET @LocationInfo = 0
            IF ( SUBSTRING(@changes, 19, 1) = '1' )
                SET @PostalInfo = 1
            ELSE
                SET @PostalInfo = 0
			IF ( SUBSTRING(@changes, 20, 1) = '1' )
                SET @DriverTypeInfo = 1
            ELSE
                SET @DriverTypeInfo  = 0

        END
    DECLARE @DefinedUsfCount INT,  @PermittedUsfCount INT
    SET @DefinedUsfCount = 0
    SET @PermittedUsfCount = 0
	
	DECLARE @StartVirtualIpDWORD AS BIGINT
	DECLARE @StartVirtualIpString AS varchar(20)
	SELECT @StartVirtualIpString  = value from TSetting WHERE Property = 'UserVipPoolIp' 
	SET @StartVirtualIpDWORD = CAST( dbo.[ConvertIP2BigInt](@StartVirtualIpString) AS BIGINT)
	
	DECLARE @nRepUsers AS INT
	SET @nRepUsers = 0
	SELECT  @nRepUsers = COUNT(*) FROM TUser  WHERE VirtualIPStatus = 'static' AND VirtualIP IS NOT NULL AND (UserID != @UserID) AND  (VirtualIP = @VirtualIP OR @VirtualIP = CAST(CAST(VirtualIP as BIGINT)+@StartVirtualIpDWORD AS NVARCHAR(15)) OR @VirtualIP = CAST(CAST(VirtualIP as BIGINT)-@StartVirtualIpDWORD AS NVARCHAR(15))  )
    IF ( @nRepUsers > 0 )
    BEGIN
         RAISERROR('The entered virtual ip assigned before. Please choose another ip.', 16 , 10 )
         RETURN
    END
	
    IF NOT ( ISNULL(@AuthenticationKey, '''') = '''' )
        BEGIN
            DECLARE @EncAuthKey NVARCHAR(64)
            BEGIN TRY
                DROP TABLE #Table
            END TRY
            BEGIN CATCH
            --RAISERROR ('Error raised in TRY block.', 16, 1);
            END CATCH
            CREATE TABLE #Table
            (
              CommandLine NVARCHAR(200),
              Param1 NVARCHAR(200),
              [Output] NVARCHAR(64)
            )
            INSERT  #Table
                    EXEC Master..XYRunProc 'Encrypt', @AuthenticationKey
            SELECT  @EncAuthKey = [Output]
            FROM    #Table
            WHERE   CommandLine = 'Encrypt'	
            DROP TABLE #Table
            --select @AuthenticationKey , @EncAuthKey
            DECLARE @userupdate AS NVARCHAR(MAX)
            SET @userupdate = N'UPDATE TUser SET '
            IF ( @GeneralUserInfo = 1 )
                BEGIN
                    IF ( @UserName IS NOT NULL )
                        SET @userupdate = @userupdate + 'UserName = N''' + @UserName + ''','
                END
            IF ( @UserInfo = 1 )
                BEGIN	
                    IF ( @FirstName IS NOT NULL )
                        SET @userupdate = @userupdate + 'FirstName = N''' + @FirstName + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'FirstName = NULL,'
                    IF ( @LastName IS NOT NULL )
                        SET @userupdate = @userupdate + 'LastName = N''' + @LastName + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'LastName = NULL,'
                    IF ( @Gender IS NOT NULL )
                        SET @userupdate = @userupdate + 'Gender = N''' + @Gender + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'Gender = NULL,'
                    IF ( @PersonnelCode IS NOT NULL )
                        SET @userupdate = @userupdate + 'PersonnelCode = N''' + @PersonnelCode + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'PersonnelCode = NULL,'
                    IF ( @NationalID IS NOT NULL )
                        SET @userupdate = @userupdate + 'NationalID = N''' + @NationalID + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'NationalID = NULL,'
                END
            IF ( @OrganizationInfo = 1 )
                BEGIN	
                    IF ( @Office IS NOT NULL )
                        SET @userupdate = @userupdate + 'Office = N''' + @Office + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'Office = NULL,'
                    IF ( @Company IS NOT NULL )
                        SET @userupdate = @userupdate + 'Company = N''' + @Company + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'Company = NULL,'
                END
            IF ( @CommentsInfo = 1 )
                BEGIN	
                    IF ( @Notes IS NOT NULL )
                        SET @userupdate = @userupdate + 'Notes = N''' + @Notes + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'Notes = NULL,'
                END
            IF ( @StatusInfo = 1 )
                BEGIN	
                    IF ( @AccountDisable IS NOT NULL )
						SET @userupdate = @userupdate + 'AccountDisable = N''' + CAST(@AccountDisable AS NVARCHAR(5)) + ''',DisableResult = N'''+ @DisableResult + ''','	
                    ELSE
					    SET @userupdate = @userupdate + 'AccountDisable = NULL, DisableResult = NULL'					 
						
						
                    IF ( @ExpireDate IS NOT NULL )
                        SET @userupdate = @userupdate + 'ExpireDate = N''' + @ExpireDate + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'ExpireDate = NULL,'
                END
            IF ( @LoginInfo = 1 )
                BEGIN	
                    IF ( @LoginType IS NOT NULL )
                        BEGIN
                            IF ( @LoginType = 0 )
                                BEGIN
                                    SELECT  @DefinedUsfCount = COUNT(*) FROM TUser WHERE LoginType = 0 AND UserID <> @UserID
                                    SELECT  @PermittedUsfCount = [value] FROM TSetting WHERE   Property = 'UsfUserCount'
                                    IF ( @PermittedUsfCount < @DefinedUsfCount + 1 )
                                        BEGIN
                                            RAISERROR ('Number of USF users exceeded.' , 16 , 10)
                                            RETURN
                                        END
                                END
                            SET @userupdate = @userupdate + 'LoginType = ' + CAST(@LoginType AS NVARCHAR(3)) + ','
                        END
                END
            IF ( @ModuleInfo = 1 )
                BEGIN	
                    IF ( @UserPIN IS NOT NULL )
                        SET @userupdate = @userupdate + 'UserPIN = N''' + @UserPIN + ''','
                    IF ( @MasterPIN IS NOT NULL )
                        SET @userupdate = @userupdate + 'MasterPIN = N''' + @MasterPIN + ''','
                    IF ( @UnBlockPIN IS NOT NULL )
                        SET @userupdate = @userupdate + 'UnBlockPIN = N''' + @UnBlockPIN + ''','
                END
            IF ( @CertInfo = 1 )
                BEGIN				
                    IF ( @AuthType IS NOT NULL )
                        SET @userupdate = @userupdate + 'AuthType = N''' + CAST(@AuthType AS NVARCHAR(5)) + ''','
                
                    IF ( @CertType IS NOT NULL )
                        SET @userupdate = @userupdate + 'CertType = N''' + @CertType + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'CertType = NULL,'
                
                    IF ( @CertValue IS NOT NULL )
                        SET @userupdate = @userupdate + 'CertValue = N''' + @CertValue + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'CertValue = NULL,'
                END
            IF ( @AccountInfo = 1 )
                BEGIN	
                    IF ( @MustChangePIN IS NOT NULL )
                        SET @userupdate = @userupdate + 'MustChangePIN = N''' + CAST(@MustChangePIN AS NVARCHAR(5))
                            + ''','
                    IF ( @LockModule IS NOT NULL )
                        SET @userupdate = @userupdate + 'LockModule = N''' + CAST(@LockModule AS NVARCHAR(5)) + ''','
                    IF ( @ShowUserPrivilege IS NOT NULL )
                        SET @userupdate = @userupdate + 'ShowUserPrivilege = N'''
                            + CAST(@ShowUserPrivilege AS NVARCHAR(5)) + ''','
                END
            IF ( @NetConfigInfo = 1 )
                BEGIN
                    IF ( @RejOnKeepAliveFail IS NOT NULL )
                        SET @userupdate = @userupdate + 'RejOnKeepAliveFail = N'''
                            + CAST(@RejOnKeepAliveFail AS NVARCHAR(5)) + ''','
                    IF ( @SendDNS IS NOT NULL )
                        SET @userupdate = @userupdate + 'SendDNS = N''' + CAST(@SendDNS AS NVARCHAR(5)) + ''','
                    SET @userupdate = @userupdate + 'DisableModernPolicy = N'''
                        + CAST(@DisableModernPolicy AS NVARCHAR(5)) + ''','
                END
            IF ( @SpecialPermInfo = 1 )
                BEGIN	
                    IF ( @Owner IS NOT NULL )
                        SET @userupdate = @userupdate + '[Owner] = ' + CAST(@Owner AS NVARCHAR(20)) + ','
                    IF ( @Permission_ID IS NOT NULL )
                        SET @userupdate = @userupdate + 'Permission_ID = ' + CAST(@Permission_ID AS NVARCHAR(50)) + ','	
                    ELSE
                        SET @userupdate = @userupdate + 'Permission_ID = NULL,'	
                END
            IF ( @IPBindingInfo = 1 )
                BEGIN	
                    IF ( @IPBindingStatus IS NOT NULL )
                        SET @userupdate = @userupdate + 'IPBindingStatus = N''' + @IPBindingStatus + ''','
                    IF ( @SubNetIP IS NOT NULL )
                        SET @userupdate = @userupdate + 'SubNetIP		= N''' + @SubNetIP + ''','
                    IF ( @SubNetMask IS NOT NULL )
                        SET @userupdate = @userupdate + 'SubNetMask	= N''' + @SubNetMask + ''','
                END
            IF ( @BindingInfo = 1 )
                BEGIN	 
                    IF ( @BindingStatus IS NOT NULL )
                        SET @userupdate = @userupdate + 'BindingStatus = N''' + @BindingStatus + ''','
                    IF ( @BindingPCID IS NOT NULL )
                        SET @userupdate = @userupdate + 'BindingPCID   = N''' + @BindingPCID + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'BindingPCID   = NULL,'
                END
            IF ( @InterfacBindingInfo = 1 )
                BEGIN	
                    IF ( @interfaceBindingStatus IS NOT NULL )
                        SET @userupdate = @userupdate + '[InterfaceBindingStatus] = '
                            + CAST(@interfaceBindingStatus AS NVARCHAR(3)) + ','
                END
            IF ( @VIPInfo = 1 )
                BEGIN
                    IF ( @VirtualIPStatus IS NOT NULL )
                        BEGIN
                            SET @userupdate = @userupdate + 'VirtualIPStatus = N''' + @VirtualIPStatus + ''','
                            IF ( @VirtualIPStatus != N'Static' )
                                SET @userupdate = @userupdate + 'VirtualIP = NULL,'
                            ELSE
                                IF ( @VirtualIP IS NOT NULL )
                                    SET @userupdate = @userupdate + 'VirtualIP = N''' + @VirtualIP + ''','
                        END

                END
            IF ( @VersionInfo = 1 )
                BEGIN	 
                    IF ( @VersionBindingStatus IS NOT NULL )
                        SET @userupdate = @userupdate + 'VersionBindingStatus = N''' + @VersionBindingStatus + ''','
                    IF ( @BindingVersion IS NOT NULL )
                        SET @userupdate = @userupdate + 'BindingVersion   = N''' + @BindingVersion + ''','					
                    ELSE
                        SET @userupdate = @userupdate + 'BindingVersion   = NULL,'	 
                END
                
            IF ( @MailInfo = 1 )
                BEGIN	
                    IF ( @Email IS NOT NULL )
                        SET @userupdate = @userupdate + 'Email = N''' + @Email + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'Email = NULL,'
                    IF ( @cell IS NOT NULL )
                        SET @userupdate = @userupdate + 'Cell = N''' + @Cell + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'Cell = NULL,'
                    IF ( @Phone IS NOT NULL )
                        SET @userupdate = @userupdate + 'Phone = N''' + @Phone + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'Phone = NULL,'
                END

            IF ( @LocationInfo = 1 )
                BEGIN	
                    IF ( @Province IS NOT NULL )
                        SET @userupdate = @userupdate + 'Province=N''' + @Province + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'Province = NULL,'
                    IF ( @Town IS NOT NULL )
                        SET @userupdate = @userupdate + 'Town=N''' + @Town + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'Town = NULL,'
                END             
                
            IF ( @PostalInfo = 1 )
                BEGIN	
                    IF ( @Adress IS NOT NULL )
                        SET @userupdate = @userupdate + 'Adress = N''' + @Adress + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'Adress = NULL,'
                    IF ( @PostalCode IS NOT NULL )
                        SET @userupdate = @userupdate + 'PostalCode = N''' + @PostalCode + ''','
                    ELSE
                        SET @userupdate = @userupdate + 'PostalCode = NULL,'
                END
			IF(@DriverTypeInfo = 1)
			BEGIN
			        SET @userupdate = @userupdate + 'DriverType = ' + CAST(@DriverType AS NVARCHAR(20)) + ','
			END

            SET @userupdate = @userupdate + 'LastModifiedTime = N''' + @LastModifyDateTime + ''','	+ 'GID = ''' + @GID + ''','										
            IF ( @GeneralUserInfo = 1
                 OR @UserInfo = 1
                 OR @OrganizationInfo = 1
                 OR @CommentsInfo = 1
                 OR @StatusInfo = 1
                 OR @LoginInfo = 1
                 OR @ModuleInfo = 1
                 OR @CertInfo = 1
                 OR @AccountInfo = 1
                 OR @NetConfigInfo = 1
                 OR @SpecialPermInfo = 1
                 OR @IPBindingInfo = 1
                 OR @BindingInfo = 1
                 OR @InterfacBindingInfo = 1
                 OR @VIPInfo = 1
                 OR @VersionInfo = 1
                 OR @MailInfo = 1
                 OR @LocationInfo = 1
                 OR @PostalInfo = 1
				 OR @DriverTypeInfo = 1 )
                BEGIN
                    DECLARE @FinalSt AS NVARCHAR(MAX)	
                    SET @userupdate = @userupdate + ' where UserID=' + CAST(@UserID AS NVARCHAR(50))                	
                    SELECT  @FinalSt = REPLACE(@userupdate, ', where', ' where')
                    BEGIN TRY
                        BEGIN TRAN t1
                
                        EXEC(@FinalSt)
                        IF ( @@ERROR = 0 )
                            BEGIN
                                SELECT  @LastModifyDateTime
								Update TUserGroups SET GID = @GID WHERE UserID = @UserID
                            END
                        IF ( @ModuleInfo = 1 )
                            BEGIN	
                                IF ( @AuthenticationKey IS NOT NULL )
                                    BEGIN
                                        DECLARE @HashVal AS NVARCHAR(MAX)
                                        DECLARE @CurrentKey AS NVARCHAR(64)
                                        DECLARE @EncryptedAuthKey NVARCHAR(64)	
                                        DECLARE @TempTBLName AS NVARCHAR(100)
                                        SELECT  @TempTBLName = [name]
                                        FROM    tempdb.sys.tables
                                        WHERE   ( [name] LIKE N'%#AKTable%' )
                                        IF ( @TempTBLName IS NOT NULL )
                                            DROP TABLE #AKTable
                                        CREATE TABLE #AKTable
                                        (
                                          CommandLine NVARCHAR(200),
                                          Param1 NVARCHAR(200),
                                          [Output] NVARCHAR(64)
                                        )
                                        SELECT  @EncryptedAuthKey = AuthenticationKey
                                        FROM    TUser
                                        WHERE   UserID = @UserID
                                        INSERT  #AKTable
                                                EXEC Master..XYRunProc 'Decrypt', @EncryptedAuthKey
                                        SELECT  @CurrentKey = [Output]
                                        FROM    #AKTable
                                        WHERE   CommandLine = 'Decrypt'
                                        DROP TABLE #AKTable
                                        DECLARE @HashKEY AS NVARCHAR(500)
                                        SELECT  @HashKEY = CONVERT(NVARCHAR(500), @CurrentKey)
                                        SELECT  @HashVal = SUBSTRING(master.dbo.fn_varbintohexstr(HASHBYTES('MD5',
                                                                                                        @HashKEY)), 3,
                                                                     32)
										SET @GID = dbo.GenerateNewGID(@UserID)
                                        UPDATE tuser SET AuthenticationKey = @EncAuthKey, GID = @GID WHERE UserID = @UserID
										UPDATE TUserGroups SET GID = @GID WHERE UserID = @UserID
                                        IF ( @@ERROR = 0 )
                                            BEGIN	
                                                DECLARE @KeyChangeStr AS NVARCHAR(200)
                                                DECLARE @CurrentNote AS NVARCHAR(MAX)
                                                DECLARE @CurrentDate AS NVARCHAR(50)
                                                SELECT  @CurrentDate = CONVERT (NVARCHAR(30), GETDATE(), 21)
                                                SELECT  @CurrentNote = Notes
                                                FROM    Tuser
                                                WHERE   UserID = @UserID
                                                SET @KeyChangeStr = 'AuthKey changed in :' + @CurrentDate
                                                    + '. Hash value of old key is:(' + @HashVal + ')'

												SET @GID = dbo.GenerateNewGID(@UserID)
                                                IF ( @CurrentNote IS NOT NULL )
                                                    UPDATE tuser SET Notes = Notes + CHAR(13) + CHAR(10) + @KeyChangeStr, GID = @GID WHERE   UserID = @UserID
                                                ELSE
                                                    UPDATE tuser SET Notes = @KeyChangeStr, GID = @GID WHERE UserID = @UserID
												UPDATE TUserGroups SET GID = @GID WHERE UserID = @UserID
                                            END	
                                    END
                            END
					--exec USP_TUserInterface_Update @UserID , @interfaceBindingStatus,@interfaceNames
                        COMMIT TRAN t1
                    END TRY
                    BEGIN CATCH
                        ROLLBACK TRAN t1
                        RAISERROR ('Error in updating user ',16,10)
                    END CATCH
                END
            ELSE
                BEGIN
                    RAISERROR ('ERROR!no field select for update',16,10)
                END
        
        END
    ELSE -- If Authentication wad not changed		
        BEGIN
            SET @nRepUsers = 0
            SELECT  @nRepUsers = COUNT(*) FROM    TUser WHERE   ( UserID != @UserID AND UserName = @UserName )
            IF ( @nRepUsers > 0 )
                BEGIN
                    RAISERROR('The entered username assigned before. Please choose another username.', 16 , 10 )
                    RETURN
                END
            DECLARE @userupdater AS NVARCHAR(MAX)
            SET @userupdater = N'UPDATE TUser set '
                
            IF ( @GeneralUserInfo = 1 )
                BEGIN
                    IF ( @UserName IS NOT NULL )
                        SET @userupdater = @userupdater + 'UserName = N''' + @UserName + ''','
                END
            IF ( @UserInfo = 1 )
                BEGIN	
                    IF ( @FirstName IS NOT NULL )
                        SET @userupdater = @userupdater + 'FirstName = N''' + @FirstName + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'FirstName = NULL,'
                    IF ( @LastName IS NOT NULL )
                        SET @userupdater = @userupdater + 'LastName = N''' + @LastName + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'LastName = NULL,'
                    IF ( @Gender IS NOT NULL )
                        SET @userupdater = @userupdater + 'Gender = N''' + @Gender + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'Gender = NULL,'
                    IF ( @PersonnelCode IS NOT NULL )
                        SET @userupdater = @userupdater + 'PersonnelCode = N''' + @PersonnelCode + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'PersonnelCode = NULL,'
                    IF ( @NationalID IS NOT NULL )
                        SET @userupdater = @userupdater + 'NationalID = N''' + @NationalID + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'NationalID = NULL,'
                END
            IF ( @OrganizationInfo = 1 )
                BEGIN	
                    IF ( @Office IS NOT NULL )
                        SET @userupdater = @userupdater + 'Office = N''' + @Office + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'Office = NULL,'
                    IF ( @Company IS NOT NULL )
                        SET @userupdater = @userupdater + 'Company = N''' + @Company + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'Company = NULL,'
                END
            IF ( @CommentsInfo = 1 )
                BEGIN	
                    IF ( @Notes IS NOT NULL )
                        SET @userupdater = @userupdater + 'Notes = N''' + @Notes + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'Notes = NULL,'
                END
            IF ( @StatusInfo = 1 )
                 BEGIN	
                    IF ( @AccountDisable IS NOT NULL )
						SET @userupdater = @userupdater + 'AccountDisable = N''' + CAST(@AccountDisable AS NVARCHAR(10)) + ''',DisableResult = N'''+ @DisableResult + ''','	
                    ELSE
					    SET @userupdater = @userupdater + 'AccountDisable = NULL, DisableResult = NULL'					 
						
                    IF ( @ExpireDate IS NOT NULL )
                        SET @userupdater = @userupdater + 'ExpireDate = N''' + @ExpireDate + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'ExpireDate = NULL,'
                END
            IF ( @LoginInfo = 1 )
                BEGIN	
                    IF ( @LoginType IS NOT NULL )
                        BEGIN
                            IF ( @LoginType = 0 )
                                BEGIN
                                    SELECT  @DefinedUsfCount = COUNT(*) FROM TUser WHERE LoginType = 0 AND UserID <> @UserID
                                    SELECT  @PermittedUsfCount = [value] FROM TSetting WHERE Property = 'UsfUserCount'
                                    IF ( @PermittedUsfCount < @DefinedUsfCount + 1 )
                                        BEGIN
                                            RAISERROR ('Number of USF users exceeded.' , 16 , 10)
                                            RETURN
                                        END
                                END
                            SET @userupdater = @userupdater + 'LoginType = ' + CAST(@LoginType AS NVARCHAR(3)) + ','
                        END
                END
            IF ( @ModuleInfo = 1 )
                BEGIN	
                    IF ( @UserPIN IS NOT NULL )
                        SET @userupdater = @userupdater + 'UserPIN = N''' + @UserPIN + ''','
                    IF ( @MasterPIN IS NOT NULL )
                        SET @userupdater = @userupdater + 'MasterPIN = N''' + @MasterPIN + ''','
                    IF ( @UnBlockPIN IS NOT NULL )
                        SET @userupdater = @userupdater + 'UnBlockPIN = N''' + @UnBlockPIN + ''','
                END
            IF ( @CertInfo = 1 )
                BEGIN				
                    IF ( @AuthType IS NOT NULL )
                        SET @userupdater = @userupdater + 'AuthType = N''' + CAST(@AuthType AS NVARCHAR(5)) + ''','
                
                    IF ( @CertType IS NOT NULL )
                        SET @userupdater = @userupdater + 'CertType = N''' + @CertType + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'CertType = NULL,'
                
                    IF ( @CertValue IS NOT NULL )
                        SET @userupdater = @userupdater + 'CertValue = N''' + @CertValue + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'CertValue = NULL,'
                END
            IF ( @AccountInfo = 1 )
                BEGIN	
                    IF ( @MustChangePIN IS NOT NULL )
                        SET @userupdater = @userupdater + 'MustChangePIN = N''' + CAST(@MustChangePIN AS NVARCHAR(5))
                            + ''','
                    IF ( @LockModule IS NOT NULL )
                        SET @userupdater = @userupdater + 'LockModule = N''' + CAST(@LockModule AS NVARCHAR(5)) + ''','
                    IF ( @ShowUserPrivilege IS NOT NULL )
                        SET @userupdater = @userupdater + 'ShowUserPrivilege = N'''
                            + CAST(@ShowUserPrivilege AS NVARCHAR(5)) + ''','
                END

            IF ( @NetConfigInfo = 1 )
                BEGIN
                    IF ( @RejOnKeepAliveFail IS NOT NULL )
                        SET @userupdater = @userupdater + 'RejOnKeepAliveFail = N'''
                            + CAST(@RejOnKeepAliveFail AS NVARCHAR(5)) + ''','
                    IF ( @SendDNS IS NOT NULL )
                        SET @userupdater = @userupdater + 'SendDNS = N''' + CAST(@SendDNS AS NVARCHAR(5)) + ''','
                    SET @userupdater = @userupdater + 'DisableModernPolicy = N'''
                        + CAST(@DisableModernPolicy AS NVARCHAR(5)) + ''','
                END

            IF ( @SpecialPermInfo = 1 )
                BEGIN	
                    IF ( @Owner IS NOT NULL )
                        SET @userupdater = @userupdater + '[Owner] = ' + CAST(@Owner AS NVARCHAR(20)) + ','
                    IF ( @Permission_ID IS NOT NULL )
                        SET @userupdater = @userupdater + 'Permission_ID = ' + CAST(@Permission_ID AS NVARCHAR(50))
                            + ','	
                    ELSE
                        SET @userupdater = @userupdater + 'Permission_ID = NULL,'	
                END
            IF ( @IPBindingInfo = 1 )
                BEGIN	
                    IF ( @IPBindingStatus IS NOT NULL )
                        SET @userupdater = @userupdater + 'IPBindingStatus = N''' + @IPBindingStatus + ''','
                    IF ( @SubNetIP IS NOT NULL )
                        SET @userupdater = @userupdater + 'SubNetIP		= N''' + @SubNetIP + ''','
                    IF ( @SubNetMask IS NOT NULL )
                        SET @userupdater = @userupdater + 'SubNetMask	= N''' + @SubNetMask + ''','
                END
            IF ( @BindingInfo = 1 )
                BEGIN	 
                    IF ( @BindingStatus IS NOT NULL )
                        SET @userupdater = @userupdater + 'BindingStatus = N''' + @BindingStatus + ''','
                    IF ( @BindingPCID IS NOT NULL )
                        SET @userupdater = @userupdater + 'BindingPCID   = N''' + @BindingPCID + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'BindingPCID   = NULL,'
                END
            IF ( @InterfacBindingInfo = 1 )
                BEGIN	
                    IF ( @interfaceBindingStatus IS NOT NULL )
                        SET @userupdater = @userupdater + '[InterfaceBindingStatus] = '
                            + CAST(@interfaceBindingStatus AS NVARCHAR(3)) + ','
                END
            IF ( @VIPInfo = 1 )
                BEGIN
                    IF ( @VirtualIPStatus IS NOT NULL )
                        BEGIN
                            SET @userupdater = @userupdater + 'VirtualIPStatus = N''' + @VirtualIPStatus + ''','
                            IF ( @VirtualIPStatus != N'Static' )
                                SET @userupdater = @userupdater + 'VirtualIP = NULL,'
                            ELSE
                                IF ( @VirtualIP IS NOT NULL )
                                    SET @userupdater = @userupdater + 'VirtualIP = N''' + @VirtualIP + ''','
                        END

                END
            IF ( @VersionInfo = 1 )
                BEGIN	 
                    IF ( @VersionBindingStatus IS NOT NULL )
                        SET @userupdater = @userupdater + 'VersionBindingStatus = N''' + @VersionBindingStatus + ''','
                    IF ( @BindingVersion IS NOT NULL )
                        SET @userupdater = @userupdater + 'BindingVersion   = N''' + @BindingVersion + ''','					
                    ELSE
                        SET @userupdater = @userupdater + 'BindingVersion   = NULL,'	 
                END
                
            IF ( @MailInfo = 1 )
                BEGIN	
                    IF ( @Email IS NOT NULL )
                        SET @userupdater = @userupdater + 'Email = N''' + @Email + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'Email = NULL,'
                    IF ( @cell IS NOT NULL )
                        SET @userupdater = @userupdater + 'Cell = N''' + @Cell + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'Cell = NULL,'
                    IF ( @Phone IS NOT NULL )
                        SET @userupdater = @userupdater + 'Phone = N''' + @Phone + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'Phone = NULL,'
                END

            IF ( @LocationInfo = 1 )
                BEGIN	
                    IF ( @Province IS NOT NULL )
                        SET @userupdater = @userupdater + 'Province=N''' + @Province + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'Province = NULL,'
                    IF ( @Town IS NOT NULL )
                        SET @userupdater = @userupdater + 'Town=N''' + @Town + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'Town = NULL,'
                END             
                
            IF ( @PostalInfo = 1 )
                BEGIN	
                    IF ( @Adress IS NOT NULL )
                        SET @userupdater = @userupdater + 'Adress = N''' + @Adress + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'Adress = NULL,'
                    IF ( @PostalCode IS NOT NULL )
                        SET @userupdater = @userupdater + 'PostalCode = N''' + @PostalCode + ''','
                    ELSE
                        SET @userupdater = @userupdater + 'PostalCode = NULL,'
                END

			IF(@DriverTypeInfo = 1)
			BEGIN
			        SET @userupdater = @userupdater + 'DriverType = ' + CAST(@DriverType AS NVARCHAR(20)) + ','
			END

            SET @userupdater = @userupdater + 'LastModifiedTime = N''' + @LastModifyDateTime + ''',' + 'GID = ''' + @GID + ''','						
                
            IF ( @GeneralUserInfo = 1
                 OR @UserInfo = 1
                 OR @OrganizationInfo = 1
                 OR @CommentsInfo = 1
                 OR @StatusInfo = 1
                 OR @LoginInfo = 1
                 OR @ModuleInfo = 1
                 OR @CertInfo = 1
                 OR @AccountInfo = 1
                 OR @NetConfigInfo = 1
                 OR @SpecialPermInfo = 1
                 OR @IPBindingInfo = 1
                 OR @BindingInfo = 1
                 OR @InterfacBindingInfo = 1
                 OR @VIPInfo = 1
                 OR @VersionInfo = 1
                 OR @MailInfo = 1
                 OR @LocationInfo = 1
                 OR @PostalInfo = 1 
				 OR @DriverTypeInfo = 1 )
                BEGIN
                    DECLARE @FinalStr AS NVARCHAR(MAX)	
                    SET @userupdater = @userupdater + ' where UserID=' + CAST(@UserID AS NVARCHAR(50))
                    SELECT  @FinalStr = REPLACE(@userupdater, ', where', ' where')                
                    EXEC(@FinalStr)
                    IF ( @@ERROR = 0 )
                        BEGIN
							Update TUserGroups SET GID = @GID WHERE UserID = @UserID
                            SELECT  @LastModifyDateTime
                        END
                END
            ELSE
                BEGIN
                    RAISERROR ('ERROR!no field select for update',16,10)
                END
        END
END


go

