
CREATE PROCEDURE [dbo].[USP_Select_Group_AllChilds]
        @GroupID as BIGINT
        AS
BEGIN
     DECLARE @GroupQuery AS NVARCHAR(MAX)
     DECLARE @UserQuery  AS NVARCHAR(MAX)
     DECLARE @TotalQuery AS NVARCHAR(MAX)
	 
	 SET @GroupQuery = ' SELECT GroupID,GroupName FROM TGroup WHERE ParentID = '
	 SET @GroupQuery = @GroupQuery + cast (@GroupID AS NVARCHAR(50))

	 SET @UserQuery = ' SELECT dbo.TUserGroups.UserID, dbo.TUser.UserName FROM dbo.TUserGroups INNER JOIN
                         dbo.TUser ON dbo.TUserGroups.UserID = dbo.TUser.UserID WHERE dbo.TUserGroups.GroupID = '
	 SET @UserQuery = @UserQuery + cast (@GroupID AS NVARCHAR(50)) 
	 
	 SET @TotalQuery = @GroupQuery +' ; '+ @UserQuery
	 EXEC dbo.sp_executesql @TotalQuery
END
go

