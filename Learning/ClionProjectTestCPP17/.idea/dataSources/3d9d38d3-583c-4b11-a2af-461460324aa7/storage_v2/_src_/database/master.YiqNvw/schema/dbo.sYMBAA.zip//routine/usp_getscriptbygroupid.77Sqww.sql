CREATE PROCEDURE [dbo].[USP_GetScriptByGroupID] 
	@GroupID int
AS
BEGIN
	select ScriptTitle,ScriptText from TScript inner join TGroupScript on TScript.ScriptID =  TGroupScript.ScriptID where TGroupScript.GroupID = @GroupID and ScriptActivity=1
END
go

