CREATE PROCEDURE [dbo].[sp_AddEdit_Orgs]  
	@Code                int,
	@CustomerName nvarchar(200),  
	@President nvarchar(200), 
	@Address nvarchar(200), 
	@Delegate nvarchar(200), 
	@Tel nvarchar(200), 
	@Fax nvarchar(200), 
	@Email nvarchar(200), 
	@WebAddress nvarchar(200), 
	@Description nvarchar(200), 
	@WorkArea nvarchar(200)
AS
	-- for Add
	declare @PrevCode int
	set @PrevCode = -1
	select @PrevCode = CustomerCode from Customers where CustomerName = @CustomerName

	if (@Code = 0)
	begin
		if (@PrevCode != -1)
		begin
			select N'ÎÑíÏÇÑ ÈÇ Çíä äÇã ÞÈáÇ Èå ËÈÊ ÑÓíÏå ÇÓÊ' as ErrMsg, 1 as RetCode
			return 
		end
		Insert Customers (CustomerName, PresidentName, Address, Delegates, Phone, Fax, EmailAddress, WebAddress, [Description], WorkArea)
		          values      (@CustomerName, @President, @Address, @Delegate, @Tel, @Fax, @Email, @WebAddress, @Description, @WorkArea)		
		select N'ÎÑíÏÇÑ ãæÑÏ äÙÑ ÈÇ ãæÝÞíÊ Èå ÇíÇå ÏÇÏå ÇÖÇÝå ÔÏ.' as ErrMsg, 0 as RetCode
		return ;
	end

	-- Exist befor
	if (@PrevCode != -1 and @PrevCode != @Code)
	begin
		select N'ÎÑíÏÇÑ ÈÇ Çíä äÇã ÞÈáÇ Èå ËÈÊ ÑÓíÏå ÇÓÊ' as ErrMsg, 11 as RetCode
		return ;
	end

	-- for Edit
	Update Customers 
		set CustomerName  =@CustomerName, 
		      PresidentName  =@President, 
		      Address              =@Address, 
		      Delegates          =@Delegate, 
		      Phone                =@Tel, 
		      Fax                     =@Fax, 
		      EmailAddress      =  @Email, 
		      WebAddress      =@WebAddress, 
		      [Description]       =  @Description, 
		       WorkArea          =   @WorkArea	
	where 	(@Code = CustomerCode)

	select N'Ñ˜æÑÏ ãæÑÏ äÙÑ ÈÇ ãæÝÞíÊ æíÑÇíÔ ÔÏ.' as ErrMsg, 10 as RetCode
go

