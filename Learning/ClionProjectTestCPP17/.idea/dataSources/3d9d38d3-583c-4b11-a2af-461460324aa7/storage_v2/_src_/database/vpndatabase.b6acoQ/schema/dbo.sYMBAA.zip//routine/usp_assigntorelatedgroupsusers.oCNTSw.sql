/******************************************************************************************************************************************************/---------------------------------
CREATE PROCEDURE USP_AssignToRelatedGroupsUsers
@TableName varchar(50),
@RecordID INT,
@RecordAssignedIDS VARCHAR(MAX),
@RecordGID varchar(25),
@TableIDFieldName varchar(50),
@GroupIDFieldName varchar(50)
AS
BEGIN
	DECLARE @CheckDuplicatedRecordID AS BIT
	SET @CheckDuplicatedRecordID = 0

	DECLARE @ValuesStr AS NVARCHAR(MAX)

	DECLARE @Priority AS INT
	SET @Priority = 1
	
	DECLARE CursIDs CURSOR FAST_FORWARD FOR SELECT * FROM dbo.Splitfn(@RecordAssignedIDS,',')
	OPEN CursIDs
	DECLARE @CurrentID AS INT
	FETCH NEXT FROM CursIDs INTO @CurrentID
	WHILE @@FETCH_STATUS=0
	BEGIN
		IF(@CurrentID IS NOT NULL)
		BEGIN
			EXEC USP_CheckDuplicateRecord @TableName,@TableIDFieldName,@RecordID,@GroupIDFieldName,@CurrentID,@CheckDuplicatedRecordID OUTPUT
			IF(@CheckDuplicatedRecordID = 0)
			BEGIN
				
				IF(dbo.IsPostfixIDTable(@TableName) = 1 )
					SET @ValuesStr = CAST(@CurrentID AS VARCHAR(20)) +','+ CAST(@RecordID AS VARCHAR(20))
				ELSE
					SET @ValuesStr = CAST(@RecordID AS VARCHAR(20)) +','+ CAST(@CurrentID AS VARCHAR(20))
				
				IF( @TableName = 'TGroupPolicySet' OR @TableName = 'TUserPolicySet' OR @TableName ='TGroupTimeSet'  OR @TableName = 'TUserTimeSet')
				BEGIN
					SELECT @Priority = dbo.GetLatestPriorityByRecordID(@TableName,@CurrentID)
					SET @ValuesStr = @ValuesStr + ','+CAST (@Priority AS VARCHAR (10))
				END
				ELSE IF( @TableName = 'TUserGroups')
				BEGIN
					SELECT @Priority = dbo.GetLatestPriorityByRecordID(@TableName,@RecordID)
					SET @ValuesStr = @ValuesStr + ','+CAST (@Priority AS VARCHAR (10)) + ','''+@RecordGID+''''
				END				
				EXEC USP_InsertGroupUsersAssingToRelatedTable @tableName, @ValuesStr
				
			END
		END
		FETCH NEXT FROM CursIDs INTO @CurrentID
	END
	CLOSE CursIDs
	DEALLOCATE CursIDs	
END
go

