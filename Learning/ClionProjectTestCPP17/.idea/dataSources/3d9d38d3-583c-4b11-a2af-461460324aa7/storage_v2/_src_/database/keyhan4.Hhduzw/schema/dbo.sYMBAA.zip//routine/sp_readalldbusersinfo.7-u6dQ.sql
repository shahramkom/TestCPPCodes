CREATE PROCEDURE [dbo].[sp_ReadAllDBUsersInfo] 
AS
	BEGIN
		SELECT * from Users
	END
go

