/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_PrepareTableRelatedQuery]
	@ActionType varchar(20),
	@TableName varchar(20),
	@IDFieldName varchar(25),
	@IDFieldValue int,
	@ReturnCommand nvarchar(MAX) OUTPUT
	AS
	BEGIN
		DECLARE @Query nvarchar(MAX)
		IF(@ActionType = 'Insert')
			SET @Query = dbo.GetTableInsertQuery( @TableName, @IDFieldName, @IDFieldValue )
		ELSE IF(@ActionType = 'Update')
			SET @Query = dbo.GetTableUpdateQuery( @TableName, @IDFieldName, @IDFieldValue )
		ELSE IF(@ActionType = 'Delete')
		BEGIN
			SET @Query = dbo.GetTableDeleteQuery( @TableName, @IDFieldName, @IDFieldValue )
			SELECT @ReturnCommand=@Query
			RETURN
		END

		CREATE TABLE #tmpTbl([Command] nvarchar(MAX))
		INSERT INTO #tmpTbl ([Command]) exec sp_executesql @Query 
		DECLARE @TmpQuery NVARCHAR(MAX)
		SELECT @TmpQuery = Command from #tmpTbl
		SET @Query = REPLACE(@TmpQuery , '''' , '''''')
		
		IF(@ActionType = 'Update')
		BEGIN
			DECLARE @WhereStatement AS VARCHAR(100)
			SET @WhereStatement = ' WHERE ' + @IDFieldName + '=' + CAST(@IDFieldValue AS VARCHAR(20))
			SET @Query = @Query + @WhereStatement
		END
		SELECT @ReturnCommand=@Query
		DROP TABLE #tmpTbl
END
go

