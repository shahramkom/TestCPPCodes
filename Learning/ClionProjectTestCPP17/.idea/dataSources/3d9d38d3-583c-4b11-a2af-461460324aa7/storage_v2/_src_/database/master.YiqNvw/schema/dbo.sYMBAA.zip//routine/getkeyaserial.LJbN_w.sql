/******************************************************************************************************************************************************/--
CREATE FUNCTION dbo.GetKeyASerial(@Command NVARCHAR(MAX))
RETURNS VARCHAR(30)
BEGIN
	DECLARE @RetValSerial AS VARCHAR(30)
	SET @RetValSerial = SUBSTRING(@Command,CHARINDEX(',N''',@Command , 0)+3,12)
	RETURN @RetValSerial
END
go

