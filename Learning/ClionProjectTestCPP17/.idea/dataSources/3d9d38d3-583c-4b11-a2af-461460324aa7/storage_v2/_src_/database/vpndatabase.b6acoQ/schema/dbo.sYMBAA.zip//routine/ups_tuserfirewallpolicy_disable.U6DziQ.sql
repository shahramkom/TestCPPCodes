

    CREATE PROCEDURE   [dbo].[UPS_TUserFirewallPolicy_Disable]

        @UFPID	int  
        AS

    BEGIN
        
	declare @lastModifyDateTime as nvarchar(20)
	select @lastModifyDateTime = CONVERT(nvarchar(20),GETDATE(),20)	
        
    declare @status bit 
    select @status = status from TUserFirewallPolicy where UFPID= @UFPID
    if (@status is not null AND @status = 0)
		Update TUserFirewallPolicy set status = 1 , LastModifiedTime = @lastModifyDateTime where UFPID= @UFPID 
	else
		Update TUserFirewallPolicy set status = 0 , LastModifiedTime = @lastModifyDateTime where UFPID= @UFPID 

    END

    go

