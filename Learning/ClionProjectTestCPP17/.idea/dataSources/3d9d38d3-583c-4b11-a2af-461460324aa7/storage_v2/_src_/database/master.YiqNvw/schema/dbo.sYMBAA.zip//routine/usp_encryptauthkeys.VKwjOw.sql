CREATE PROCEDURE [dbo].[USP_EncryptAuthKeys]
        @NewDBKey nvarchar(128),
        @ServerMasterPIN nvarchar(32)
    AS
    BEGIN
        
        BEGIN TRY
            --CLOSE users
            DEALLOCATE users		
        END TRY
        BEGIN CATCH
            --RAISERROR ('ERROR RAISED IN TRY BLOCK.', 16, 1);
        END CATCH
    
        BEGIN TRY
            DROP TABLE #Table		
        END TRY
        BEGIN CATCH
            --RAISERROR ('ERROR RAISED IN TRY BLOCK 2.', 16, 1);
        END CATCH
    
        DECLARE users CURSOR STATIC  --SCROLL_LOCKS 
        FOR SELECT UserID, AuthenticationKey from TUser --where userid = 1  --for update
        DECLARE @userID int , @AuthKey nvarchar(64) , @NewAuthKey nvarchar(64),@temp nvarchar(50)
    

        OPEN users
        --select @@CURSOR_ROWS
    
        
        CREATE TABLE #Table(
            CommandLine nvarchar(200),
            Param1		nvarchar(200),
            Param2		nvarchar(200),
            [Output]	nvarchar(64)
        )
    
        BEGIN TRAN t1		
        BEGIN TRY	
            INSERT into #Table (CommandLine , [Output]) EXEC MASTER..XYRunProc 'NewKeyReq' ,NULL, NULL
			IF NOT EXISTS (SELECT  * FROM #Table)
                RETURN;
        
            DELETE FROM #Table
            
            WHILE (1=1)
            BEGIN
                FETCH NEXT FROM users INTO @UserID , @AuthKey			
                IF (@@FETCH_STATUS != 0)							
                begin               
                    break
                end
              
                        
                DELETE FROM #Table
                        
                INSERT into #Table EXEC MASTER..XYRunProc 'NewKey' ,@AuthKey , @NewDBKey
            
                SELECT @NewAuthKey = [Output] from #Table where CommandLine = 'NewKey'
          		
                UPDATE TUser set AuthenticationKey = @NewAuthKey from Tuser where UserID = @UserID
            END
            CLOSE users
        
            delete from #Table 
        
            INSERT INTO #table EXEC MASTER..XYRunProc 'SetDBKey' ,@ServerMasterPIN, @NewDBKey			
        
            select @temp = [Output] from #Table where CommandLine = 'SetDBKey'
                
            if (@temp <> '' and not @temp is null )
            begin
                select @temp
                ROLLBACK TRAN t1;
                RAISERROR ('rollbacked' , 16,1 );			
            end
            else
            begin
                select @temp
                COMMIT TRANSACTION t1				
            end
            return;
        END TRY
        BEGIN CATCH
            ROLLBACK TRANSACTION t1
            RAISERROR('Unhandeld exception occurred' , 16 , 1)
        RETURN
        END CATCH
    
        --ROLLBACK TRANSACTION t1
            
    END

go

