
    
        CREATE PROCEDURE [dbo].[USP_SelectTDNSFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	

    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        
    declare @HostName nvarchar(200) , @InsertScript nvarchar(4000)
    declare @dnsID int 
     Declare TDNS_cursor Cursor FAST_FORWARD
        For
        Select 
                HostName,[output],DNSID 
            FROM tbl_InsertGroupScript   
            where tableName = 'TDNS'
            OPEN TDNS_cursor

    FETCH NEXT FROM TDNS_cursor
    INTO @HostName,@InsertScript,@dnsID

    WHILE @@FETCH_STATUS = 0
    begin 
          
        
            
       if(exists (select * from TDNS where HostName = @HostName or DNSID = @dnsID  ))
            Begin
            
                if(@Replace = 1)
                    begin
                
                   Delete from TDNS   where DNSID = @dnsID	or HostName = @HostName
                    
                    end
            End	
        
            BEGIN TRY
            
                SET IDENTITY_INSERT TDNS ON
                exec sp_executesql @InsertScript	
                SET IDENTITY_INSERT TDNS OFF		
            END TRY
            BEGIN CATCH
				
				INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript 
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectTDNSFromImportedBackupData')   


            END CATCH  	
            FETCH NEXT FROM TDNS_cursor 
            INTO @HostName,@InsertScript,@dnsID
    
        end
        CLOSE TDNS_cursor;
        DEALLOCATE TDNS_cursor;
    
    
                
    END


        go

