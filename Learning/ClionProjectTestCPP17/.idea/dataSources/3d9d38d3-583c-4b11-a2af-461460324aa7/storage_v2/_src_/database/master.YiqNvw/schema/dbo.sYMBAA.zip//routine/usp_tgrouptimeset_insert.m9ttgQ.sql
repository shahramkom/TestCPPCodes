
    create PROCEDURE [dbo].[USP_TGroupTimeSet_Insert] 
        -- Add the parameters for the stored procedure here
        @groupID int,
        @TimeSetNameList nvarchar(max)
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
        declare @TimeSetName as nvarchar(50)
        declare @TimeSetID as int
        declare @priority as int
        set @priority = 1
        
        declare TimeSet_Cursor1 cursor for 
        SELECT * FROM dbo.Splitfn(@TimeSetNameList,',')
        
        open TimeSet_Cursor1
        fetch next from TimeSet_Cursor1 into @TimeSetName
        
        while @@FETCH_STATUS = 0
        begin
        select @TimeSetID = TRID from TTimeRole where TimeSetName = @TimeSetName
        
        insert into  TGroupTimeSet 
        (TRID,GroupID,PriorityOrder) 
        values (@TimeSetID,@groupID,@priority)
        
        set @priority = @priority + 1
        
        fetch next from TimeSet_Cursor1 into @TimeSetName
        end
        close TimeSet_Cursor1
        DEALLOCATE TimeSet_Cursor1
    END

    go

