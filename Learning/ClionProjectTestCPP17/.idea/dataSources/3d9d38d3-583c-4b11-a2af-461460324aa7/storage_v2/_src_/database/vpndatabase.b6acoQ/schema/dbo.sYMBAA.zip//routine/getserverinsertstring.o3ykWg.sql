/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetServerInsertString]
(
  @TableName varchar(100),
  @isSetIdentity bit,
  @isRestore bit
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE @RetVal AS NVARCHAR(MAX)
	SET @RetVal = ' '

	if(@isSetIdentity = 1)
	BEGIN
		SET @RetVal += 'SET IDENTITY_INSERT [VPNDataBase].[dbo].' + @TableName +' ON '
	SET @RetVal +='
	'
	END
	if(@isRestore = 1)
		SET @RetVal += ' INSERT INTO [VPNDataBase].[dbo].'+@TableName + '(' + STUFF ((SELECT ','+ COLUMN_NAME FROM VPNDataBase.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @TableName FOR XML PATH('')) , 1 ,1 , '') + ')'+' SELECT * FROM [VPNDataBase_Restore].[dbo].['+@TableName+']'
	else
		SET @RetVal += ' INSERT INTO '+@TableName + '(' + STUFF ((SELECT ','+ COLUMN_NAME FROM VPNDataBase.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @TableName FOR XML PATH('')) , 1 ,1 , '') + ')'+' SELECT * FROM [LNKMASTER].[VPNDataBase].[dbo].['+@TableName+']'
	if(@isSetIdentity = 1)
	BEGIN
	SET @RetVal +='
	'
		SET @RetVal += ' SET IDENTITY_INSERT [VPNDataBase].[dbo].' + @TableName +' OFF '
	SET @RetVal +='
	'
	END

if(@isSetIdentity = 0)
	SET @RetVal +='
	'
	RETURN @RetVal
END
go

