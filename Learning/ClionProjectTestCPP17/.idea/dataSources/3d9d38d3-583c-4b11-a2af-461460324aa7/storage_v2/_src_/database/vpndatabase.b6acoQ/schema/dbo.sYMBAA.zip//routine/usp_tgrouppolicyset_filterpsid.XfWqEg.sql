
    CREATE PROCEDURE [dbo].[USP_TGroupPolicySet_FilterPSID] 
        -- Add the parameters for the stored procedure here
        @PSID int =null
    AS

    BEGIN

         SELECT GroupID FROM  TGroupPolicySet   WHERE PSID = @PSID
    END


    go

