CREATE PROCEDURE [dbo].[sp_ProgramLicenseSELECT] 
		@ProfileID int,
	@UserName nvarchar(150)
AS
BEGIN
	if(@UserName is not null)
	begin
		SELECT  [ID],[ProfileID],[CreateDate],[ExpireDate],[TotalUsers],[OnlineUsers],[USFPercent],[NewFeatures],[ServerBinding],[LicenseID],[FileName],[UserName]	FROM [Keyhan4].[dbo].[ProgramLicense]
		Where ProfileID = @ProfileID and UserName = @UserName
	end
	ELSE
	BEGIN
	SELECT  [ID],[ProfileID],[CreateDate],[ExpireDate],[TotalUsers],[OnlineUsers],[USFPercent],[NewFeatures],[ServerBinding],[LicenseID],[FileName],[UserName]	FROM [Keyhan4].[dbo].[ProgramLicense]
		Where ProfileID = @ProfileID 
	END
END
go

