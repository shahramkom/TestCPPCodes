
    CREATE PROCEDURE [dbo].[USP_SelectTuserKeyaFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
            @Replace bit	
    AS
    BEGIN
      SET NOCOUNT ON

        
    declare @UserID int ,@groupID nvarchar(200), @InsertScript nvarchar(4000)
    declare @keyaSerial nvarchar(50) ,@nCount int 
     Declare TUserKeya_cursor Cursor FAST_FORWARD
        For
        Select 
                  UserID,GroupID,[output] ,KeyaSerial
            FROM tbl_InsertGroupScript   
            where tableName = 'TUserKeya'
            OPEN TUserKeya_cursor

    FETCH NEXT FROM TUserKeya_cursor
    INTO @UserID,@groupID,@InsertScript,@keyaSerial

    WHILE @@FETCH_STATUS = 0
    begin 
            set @keyaSerial = substring( @keyaSerial, 2,len(@keyaSerial) )
        
        
        if(exists (select * from TUserKeya where UserID = @UserID AND KeyaSerial = @keyaSerial	  ))
            Begin
            
                if(@Replace = 1)
                    begin
                
                    Delete from TUserKeya   where UserID = @UserID AND KeyaSerial = @keyaSerial	  	
                    
                    end
            End	
        
            BEGIN TRY
            
                
                set @InsertScript = replace( @InsertScript, '''N','N''' )			
                exec sp_executesql @InsertScript	
            
            END TRY
            BEGIN CATCH
				INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectTuserKeyaFromImportedBackupData')		     
            END CATCH  	
            FETCH NEXT FROM TUserKeya_cursor 
            INTO @UserID,@groupID,@InsertScript,@keyaSerial
    
        end
        CLOSE TUserKeya_cursor;
        DEALLOCATE TUserKeya_cursor;
    
      END

    go

