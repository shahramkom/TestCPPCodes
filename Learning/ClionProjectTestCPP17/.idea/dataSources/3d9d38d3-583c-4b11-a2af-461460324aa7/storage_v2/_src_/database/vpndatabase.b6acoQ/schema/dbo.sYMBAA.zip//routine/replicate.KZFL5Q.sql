--------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Replicate]
AS
BEGIN	
	DECLARE @Result NVARCHAR(MAX)  
	BEGIN TRY	
		EXEC [VPNDataBase].[dbo].[SyncDatabases] 0
		SELECT @Result = 'Replication completed successfully.'
	END TRY  
	BEGIN CATCH
		SELECT @Result = 'Error occurred in replication: '+ ERROR_MESSAGE()
	END CATCH

	SELECT @Result
END
go

