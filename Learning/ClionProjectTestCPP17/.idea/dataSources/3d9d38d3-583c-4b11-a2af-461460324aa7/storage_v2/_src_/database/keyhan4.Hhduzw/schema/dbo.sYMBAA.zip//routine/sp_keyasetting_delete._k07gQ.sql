CREATE PROCEDURE [dbo].[sp_KeyASetting_Delete]  
	@RecCode int
AS
	delete from KeyASettings where @RecCode = SettingCode
go

