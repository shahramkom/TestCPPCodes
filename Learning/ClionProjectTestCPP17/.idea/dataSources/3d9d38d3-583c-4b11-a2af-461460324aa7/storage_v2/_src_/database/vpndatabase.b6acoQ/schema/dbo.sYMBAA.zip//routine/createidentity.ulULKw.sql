CREATE FUNCTION [dbo].[CreateIdentity]() RETURNS int
BEGIN
	DECLARE @intServerID AS INT
	DECLARE @serverBinaryID AS BINARY(4)
	DECLARE @stringServerBinaryID AS CHAR(10)
	DECLARE @stringFirst AS CHAR(2)
	SET @intServerID = 0
	SET @serverBinaryID = CAST(1 AS BINARY(4))
	SET @stringServerBinaryID = master.dbo.fn_varbintohexstr(@serverBinaryID)
	SET @stringFirst = RIGHT(@stringServerBinaryID, 2)
	SET @stringServerBinaryID = REPLACE(@stringServerBinaryID, @stringFirst,'00')
	SET @stringServerBinaryID = REPLACE(@stringServerBinaryID, '0x00','0x'+@stringFirst)

	select @serverBinaryID = cast('' as xml).value('xs:hexBinary(substring(sql:variable(''@stringServerBinaryID''),
	sql:column(''t.pos'')))','varbinary(max)')
	from(select case substring(@stringServerBinaryID,1,2) when '0x' then 3 else 0 end) as t(pos)

	SET @intServerID = CAST(@serverBinaryID AS INT)

	DECLARE @maxID AS INT
	DECLARE @maxStringID as VARCHAR(12)
	SELECT @maxID = MAX(UserID & 0x00FFFFFF) FROM TUser
	if (@maxID IS NULL)
		SET @maxID = dbo.CreateRandomNumber(1000, 2000)

	SET @maxID = (@maxID | @intServerID) + 1
	RETURN @maxID
END

go

