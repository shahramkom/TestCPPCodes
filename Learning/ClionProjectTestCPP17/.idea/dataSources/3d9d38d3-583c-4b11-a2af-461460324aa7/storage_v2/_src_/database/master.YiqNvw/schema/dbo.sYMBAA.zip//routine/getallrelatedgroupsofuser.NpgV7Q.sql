/*************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetAllRelatedGroupsOfUser](@UserID BIGINT)
RETURNS VARCHAR(2000)
AS
BEGIN
	DECLARE @RetVal NVARCHAR(2000)
	SET @RetVal = ' '
	DECLARE @DirectGroups NVARCHAR(1000)
	SELECT @DirectGroups = dbo.GetUserAssignGroups(@UserID)
	if( CHARINDEX(',' , @DirectGroups ) = 0 )
	BEGIN
		SELECT @RetVal = dbo.[GetGroupParents](@DirectGroups)
		RETURN @RetVal
	END
	ELSE
	BEGIN
		declare @GID as nvarchar(10)
		declare Groups_Cursor cursor for select * from dbo.Splitfn(@DirectGroups,',')
		open Groups_Cursor
		fetch next from Groups_Cursor into @GID
		while @@FETCH_STATUS = 0
		begin
		if(@GID is not null)
		begin
			SET @RetVal = @RetVal + dbo.[GetGroupParents](@GID) + ','
		end
		fetch next from Groups_Cursor into @GID
		end
		CLOSE Groups_Cursor;	
		DEALLOCATE Groups_Cursor;
		IF(LEN(@RetVal) > 1)
			SET @RetVal = SUBSTRING(@RetVal , 1 , LEN(@RetVal) -1 )
		RETURN @RetVal
	END
	RETURN @RetVal
END
go

