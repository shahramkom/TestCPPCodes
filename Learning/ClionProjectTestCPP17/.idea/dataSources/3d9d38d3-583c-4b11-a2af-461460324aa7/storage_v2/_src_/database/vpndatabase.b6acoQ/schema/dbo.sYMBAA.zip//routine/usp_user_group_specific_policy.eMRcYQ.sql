
CREATE PROCEDURE [dbo].[USP_User_Group_Specific_Policy] 

	@PSID AS INT
AS
BEGIN

	SELECT  TUser.*
	FROM    TUser INNER JOIN
			TUserPolicySet ON TUser.UserID = TUserPolicySet.UserID INNER JOIN
		    TPolicySet ON TUserPolicySet.PSID = TPolicySet.PSID
	WHERE	TPolicySet.PSID = @PSID   
	
	SELECT  TGroup.*
	FROM    TGroup INNER JOIN
            TGroupPolicySet ON TGroup.GroupID = TGroupPolicySet.GroupID INNER JOIN
            TPolicySet ON TGroupPolicySet.PSID = TPolicySet.PSID 
    WHERE	TPolicySet.PSID = @PSID         


END

go

