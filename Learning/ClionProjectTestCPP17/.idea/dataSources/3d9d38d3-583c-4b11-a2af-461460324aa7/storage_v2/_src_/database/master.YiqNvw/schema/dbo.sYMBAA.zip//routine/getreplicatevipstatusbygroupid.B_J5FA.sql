/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetReplicateVIPStatusByGroupID](@GroupID int)
RETURNS BIT
AS
BEGIN
	DECLARE @iRetVal int
	DECLARE @RetVal BIT
	SELECT @iRetVal = ServerID FROM dbo.RepServersGroups WHERE RepGroupID = @GroupID
	SELECT @RetVal = dbo.GetReplicateVIPStatus(@iRetVal)
	RETURN @RetVal
END
go

