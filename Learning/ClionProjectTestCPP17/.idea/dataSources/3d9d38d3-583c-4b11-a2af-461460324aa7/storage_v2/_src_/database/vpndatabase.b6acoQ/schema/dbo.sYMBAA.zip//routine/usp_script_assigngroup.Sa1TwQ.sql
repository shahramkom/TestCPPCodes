



    CREATE PROCEDURE  [dbo].[USP_Script_AssignGroup]
        @ScriptID	int,
        @GroupID	int
    AS
    BEGIN
        SET NOCOUNT ON;
        INSERT INTO TGroupScript
        (
            ScriptID,
            GroupID
        )
        VALUES
        (	
            @ScriptID,
            @GroupID	
        )
    END


    go

