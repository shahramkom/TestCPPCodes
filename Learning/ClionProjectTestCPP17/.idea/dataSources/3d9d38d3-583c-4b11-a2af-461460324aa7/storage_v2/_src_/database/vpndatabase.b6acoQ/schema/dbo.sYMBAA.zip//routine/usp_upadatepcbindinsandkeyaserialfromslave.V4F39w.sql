
    
    CREATE PROCEDURE [dbo].[USP_UpadatePCBindinsAndKeyASerialFromSlave] 
    
      
    AS
    BEGIN
            begin try
                DROP TABLE #tbl_UpdateUserScript
            end try
            begin catch
            --RAISERROR ('Error raised in TRY block.', 16, 1);
            end catch
            create table #tbl_UpdateUserScript(
                [Output]	nvarchar(max)
            )
            declare @UpdateCmd nvarchar(max)
        --Declare a cursor to retrieve column specific information for the specified table
        DECLARE cursCol CURSOR FAST_FORWARD FOR 
        SELECT Output FROM VPNDataBase.dbo.TUser_Update_Script --where GroupID in(@GroupID)
        OPEN cursCol

        FETCH NEXT FROM cursCol INTO @UpdateCmd

        IF @@fetch_status<>0
            begin
            print 'Table TUser_Update_Script is empty .'
            close curscol
            deallocate curscol
            return 
        END

        WHILE @@FETCH_STATUS=0
        BEGIN

           exec sp_executesql @UpdateCmd

        FETCH NEXT FROM cursCol INTO @UpdateCmd
        END


        CLOSE cursCol
        DEALLOCATE cursCol

        END


    go

