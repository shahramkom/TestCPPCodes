/******************************************************************************************************************************************************/
CREATE  FUNCTION [dbo].[GetTableInsertQuery]( @TableName nvarchar(100), @IDFieldName nvarchar(100), @IDFieldValue varchar(20))
		RETURNS nvarchar(MAX)
	AS
	BEGIN
		DECLARE CursCol CURSOR FAST_FORWARD FOR 
		SELECT column_name,data_type FROM information_schema.columns WHERE table_name = @TableName 
		OPEN CursCol
		DECLARE @String nvarchar(MAX) --for storing the first half of INSERT statement
		DECLARE @StringData nvarchar(MAX) --for storing the data (VALUES) related statement
		DECLARE @DataType nvarchar(100) --data types returned for respective columns
		
		SET @String='INSERT '+@TableName+'('
		SET @StringData=' '

		DECLARE @ColName nvarchar(50)

		FETCH NEXT FROM CursCol INTO @ColName, @DataType

		WHILE @@FETCH_STATUS=0
		BEGIN
			IF(@TableName = 'TUser')
			BEGIN
				IF(@ColName = 'AuthenticationKey')
					SET @ColName = 'ENCRYPTEDUSERAUTHKEY'
			END	

			SET @StringData = @StringData + [dbo].getDataTypeString(@DataType,@ColName)
			SET @String = @String + @ColName + ','
			FETCH NEXT FROM CursCol INTO @ColName,@DataType
		END
		 
		DECLARE @Query nvarchar(MAX)
		
		SET @Query ='SELECT '''+substring(@String,0,len(@String))+  ') VALUES(''+ ' + substring(@StringData,0,len(@StringData)-2)+'''+'')'' FROM '+ @TableName 
		+ ' WHERE ' + @IDFieldName +' = ' + @IDFieldValue
		
		if(@TableName = 'TUser')
		BEGIN
			SET @Query = REPLACE(@Query , ',ENCRYPTEDUSERAUTHKEY,',',AuthenticationKey,')
		END
		CLOSE CursCol
		DEALLOCATE CursCol
		return @Query
END
go

