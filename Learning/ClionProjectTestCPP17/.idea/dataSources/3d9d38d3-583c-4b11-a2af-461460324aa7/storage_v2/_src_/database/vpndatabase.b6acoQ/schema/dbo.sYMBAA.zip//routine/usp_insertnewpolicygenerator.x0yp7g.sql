
	Create PROCEDURE [dbo].[USP_InsertNewPolicyGenerator] 
		@GroupIDsStr as nvarchar(MAX)
	AS
	BEGIN
		DECLARE @tableName varchar(100)
		DECLARE @IDField varchar(100)
		DECLARE @NameField varchar(100)
		DECLARE @SecondNameField varchar(100)
		DECLARE @Query nvarchar(4000)
    
		SET @tableName = 'TNewPolicyMainTable'
		SET @IDField = 'ID'
		SET @NameField = 'Name'
   		SET @query = dbo.GetTableColumns( @tableName, @IDField, @NameField )
		insert  tbl_InsertGroupScript( [output], ModernPolicyID, ModernPolicyName, tableName ) exec sp_executesql @query

		SET @tableName = 'TNewPoliciesServices'
		SET @IDField = 'ID'
		SET @NameField = 'ProtocolName'
   		SET @query = dbo.GetTableColumns( @tableName, @IDField, @NameField )
		insert  tbl_InsertGroupScript( [output], ModernPolicyID, ModernPolicyName, tableName ) exec sp_executesql @query

		SET @tableName = 'TNewPoliciesDetails'
		SET @IDField = 'ID'
		SET @NameField = 'MainID'
   		SET @query = dbo.GetTableColumns( @tableName, @IDField, @NameField )
		insert  tbl_InsertGroupScript( [output], ModernPolicyID, ModernPolicyName, tableName ) exec sp_executesql @query

		SET @tableName = 'TNewPoliciesAlgorithms'
		SET @IDField = 'ID'
		SET @NameField = 'EncryptionAlgorithm' + ' + ''*'' + ' + 'IntegrityAlgorithm'
   		SET @query = dbo.GetTableColumns( @tableName, @IDField, @NameField )
		insert  tbl_InsertGroupScript( [output], ModernPolicyID, ModernPolicyName, tableName ) exec sp_executesql @query

		SET @tableName = 'TNewPolicyGroupAssign'
		SET @IDField = 'ModernPID'
		SET @NameField = 'GroupID'
   		SET @query = dbo.GetTableColumns( @tableName, @IDField, @NameField )+' WHERE GroupID in( '+@GroupIDsStr +')'
		insert  tbl_InsertGroupScript( [output], ModernPolicyID, ModernPolicyName, tableName ) exec sp_executesql @query

		SET @tableName = 'TNewPolicyUserAssign'
		SET @IDField = 'ModernPID'
		SET @NameField = 'UserID'
   		SET @query = dbo.GetTableColumns( @tableName, @IDField, @NameField )+' WHERE UserID in( SELECT UserID FROM TUserGroups WHERE GroupID IN ('+@GroupIDsStr +'))'
		insert  tbl_InsertGroupScript( [output], ModernPolicyID, ModernPolicyName, tableName ) exec sp_executesql @query
	
	END

  go

