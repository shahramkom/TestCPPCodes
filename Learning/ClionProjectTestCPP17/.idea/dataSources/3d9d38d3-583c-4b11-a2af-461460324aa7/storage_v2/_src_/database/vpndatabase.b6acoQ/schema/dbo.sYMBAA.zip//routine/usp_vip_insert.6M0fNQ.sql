
    CREATE PROCEDURE  [dbo].[USP_VIP_Insert]
        @VIP   nvarchar(15) = null,
        @Mask  nvarchar(15) = null
        with recompile
    AS
    BEGIN
        SET NOCOUNT ON;
    
        delete from TVIP
        INSERT INTO TVIP
        (VIP,Mask)
        VALUES
        (@VIP,@Mask)
    END

    go

