CREATE PROCEDURE [dbo].[GetPermissionIDOfUser] 
	@UserID bigint
AS
BEGIN
	select Permission_ID from TUser where UserID = @UserID
END
go

