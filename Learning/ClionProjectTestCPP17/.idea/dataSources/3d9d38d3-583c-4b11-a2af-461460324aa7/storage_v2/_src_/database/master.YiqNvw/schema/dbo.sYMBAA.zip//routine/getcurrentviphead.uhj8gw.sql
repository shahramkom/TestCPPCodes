/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetCurrentVIPHead]()
RETURNS BIGINT
AS
BEGIN
	DECLARE @RetVIP BIGINT
	DECLARE @CurrentVIP VARCHAR(20)
	SELECT @CurrentVIP = VIP FROM dbo.TVIP
	IF(@CurrentVIP IS NOT NULL)
		SELECT @RetVIP = dbo.ConvertIP2BigInt(@CurrentVIP)
	ELSE
		SET @RetVIP = 0
	RETURN @RetVIP
END
go

