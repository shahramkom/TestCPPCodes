CREATE PROCEDURE [dbo].[sp_UpdateUserPassword] 
	@username nvarchar(150),
	@password nvarchar(150)
AS
	BEGIN
		update Users set U_Password = @password where U_Name = @username
		select 'Success'
	END
go

