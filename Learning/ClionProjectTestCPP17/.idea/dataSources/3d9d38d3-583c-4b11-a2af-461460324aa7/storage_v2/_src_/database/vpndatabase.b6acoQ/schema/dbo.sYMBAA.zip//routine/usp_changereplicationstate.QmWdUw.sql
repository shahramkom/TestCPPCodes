/*************************************************************************************************************************************/   
CREATE PROCEDURE [dbo].[USP_ChangeReplicationState]
	@state		int,
    @serverID   INT = NULL
AS
BEGIN
	DECLARE @currentState AS INT
	SET @currentState = -1

	IF @serverID IS NULL
	BEGIN
		IF(@state = 0)
			EXEC USP_EnableAllTriggers
		ELSE IF(@state = 1)
			EXEC USP_DisableAllTriggers
		DECLARE CursRows CURSOR FAST_FORWARD FOR SELECT serverID, RunningState FROM RepServersState
		OPEN CursRows
		FETCH NEXT FROM CursRows INTO @serverID, @currentState
		WHILE @@FETCH_STATUS=0
		BEGIN
			UPDATE RepServersState SET [RunningState] = @state WHERE serverID = @serverID
			IF (@state = 0 AND @currentState <> 0)
				EXEC USP_WipeReplicationLog @serverID
            FETCH NEXT FROM CursRows INTO @serverID, @currentState
		END
		CLOSE CursRows
		DEALLOCATE CursRows
		IF @state = 1
			SELECT 0
		ELSE
			SELECT 1
		return	
	END

    SELECT @currentState = [RunningState] FROM dbo.RepServersState WHERE ServerID = @serverID 

    IF @currentState  <> -1
    BEGIN
	    UPDATE RepServersState SET [RunningState] = @state WHERE ServerID = @serverID 
		IF (@state = 0 AND @currentState <> 0)
		BEGIN
			EXEC USP_WipeReplicationLog @serverID
			EXEC USP_EnableAllTriggers
		END
    END
    ELSE
    BEGIN
		INSERT INTO RepServersState(ServerID, LastSuccessfulRun, RunningState) VALUES (@serverID, GETDATE(), @state)
		IF (@state = 0 AND @currentState <> 0)
		BEGIN
			EXEC USP_WipeReplicationLog @serverID
			EXEC USP_EnableAllTriggers
		END
    END

	IF @serverID = 1 and @state <> 0
	BEGIN
		UPDATE RepServersState SET [RunningState] = 1
		EXEC USP_DisableAllTriggers
	END
    SELECT @currentState

END

go

