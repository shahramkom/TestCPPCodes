CREATE PROCEDURE [dbo].[sp_ProgramLicenseInsert] 
	@ProfileID int ,
	@ExpireDate	nvarchar(20),	
	@TotalUsers int,
	@OnlineUsers int,
	@USFPercent int,
	@NewFeatures nvarchar(500),
	@ServerBinding varchar(13),
	@LicenseID	varchar(64)	,
	@FileName nvarchar(500),
	@UserName nvarchar(150)
AS
	BEGIN
	declare @CreateDate as nvarchar(20)
	select @CreateDate = CONVERT(nvarchar(20),GETDATE(),20)
	INSERT INTO [Keyhan4].[dbo].[ProgramLicense]
			([ProfileID]	,
			[CreateDate],	
			[ExpireDate],	
			[TotalUsers],
			[OnlineUsers],
			[USFPercent],
			[NewFeatures],
			[ServerBinding],
			[LicenseID],
			[FileName],
			[UserName])			
     VALUES
           (@ProfileID ,
			@CreateDate	,
			@ExpireDate	,
			@TotalUsers,
			@OnlineUsers,
			@USFPercent,
			@NewFeatures,
			@ServerBinding,
			@LicenseID	,
			@FileName,
			@UserName)
	END
go

