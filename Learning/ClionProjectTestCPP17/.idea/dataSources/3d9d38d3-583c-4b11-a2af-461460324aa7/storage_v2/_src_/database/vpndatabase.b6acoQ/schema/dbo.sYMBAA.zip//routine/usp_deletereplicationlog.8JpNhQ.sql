/*************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[USP_DeleteReplicationLog] 
	@tableName NVARCHAR(50),
	@replogID  int
AS
BEGIN	
	SET NOCOUNT ON;
	DECLARE @command NVARCHAR(100)
	SET @command = 'DELETE FROM ' + @tableName + ' where ID = ' + CONVERT(NVARCHAR(8), @replogID)
	EXEC dbo.sp_executesql @statement = @command
END
go

