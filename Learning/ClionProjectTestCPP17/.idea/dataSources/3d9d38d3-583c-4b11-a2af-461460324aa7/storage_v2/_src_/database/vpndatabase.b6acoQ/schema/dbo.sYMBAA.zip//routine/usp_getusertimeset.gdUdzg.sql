CREATE PROCEDURE [dbo].[USP_GetUserTimeSet] 
	@UserID bigint
AS
BEGIN
	select TimeSetId from TUserTimeset where UserID = @UserID order by Tpriority asc
END
go

