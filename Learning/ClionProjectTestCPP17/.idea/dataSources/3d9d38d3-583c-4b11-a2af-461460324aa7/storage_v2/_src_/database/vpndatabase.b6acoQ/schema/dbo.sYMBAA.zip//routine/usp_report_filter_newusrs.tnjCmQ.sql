
    CREATE PROCEDURE [dbo].[USP_REPORT_FILTER_NEWUSRS] 
        @startDate		nvarchar(10)=Null,
        @endDate		nvarchar(10)=Null,
        @pageSize int = NULL,
        @pageNum int = 1
        --@startTime		nvarchar(8)=Null,	
        --@endTime		nvarchar(8)=Null
    AS
    BEGIN

        SET NOCOUNT ON;
        declare 
                @STMT		as nvarchar(max),
                @row			nvarchar(max),
                @descript		nvarchar(max),
                @opDate			nvarchar(10),
                @opTime			nvarchar(10),
                @tempUserID		nvarchar(max),
                @tempUserName	nvarchar(max),
                @tempFirstName	nvarchar(max),
                @tempLastName	nvarchar(max)

        create table #tempTable(
            rowID			nvarchar(max),
            description		nvarchar(max),
            operationDate	nvarchar(10),
            operationTime	nvarchar(10)
        )
        set	 @STMT = 'select rowID,decription,operationDate,operationTime FROM managerLog where (operationDate >= '''+ @startDate + 
                     ''') AND (operationDate <= ''' + @endDate + 
                     ''') AND (operationType = ''INSERT'') AND (logEvent = ''User'')
					 ORDER BY operationDate DESC, operationTime DESC'

        delete #tempTable
        delete  [VPNDataBase].[dbo].[TTempUserRep]

        insert #tempTable exec sp_executesql @STMT 

        declare @index1 as int

    DECLARE tableRow CURSOR FAST_FORWARD FOR
      select rowID ,description,operationDate,operationTime from #tempTable
    
    OPEN tableRow
        FETCH NEXT FROM tableRow INTO @row ,@descript,@opDate ,@opTime
        WHILE @@FETCH_STATUS=0
        BEGIN

        set @tempUserID = @row
        set @tempUserName = @row 
    -------------finding userID in rowID---------------------
        set @tempUserID = substring (@tempUserID, (patindex('%userID%', @tempUserID)+7) 
    ,(len(@tempUserID)- patindex('%userID=%', @tempUserID)+7))
        set @index1 = (CHARINDEX(';', @tempUserID))
        if @index1 <= 0
            set @index1 = 1
        declare @userIdStr nvarchar(200)
        set @userIdStr = @tempUserID
        set @userIdStr = substring (@userIdStr ,1,@index1-1)

    -------------finding UserName in rowID---------------------
        set @tempUserName = substring (@tempUserName, (patindex('%UserName%', @tempUserName)+9) 
    ,(len(@tempUserName)- patindex('%UserName=%', @tempUserName)+9))
        declare @userNameStr nvarchar(200)
        set @userNameStr = @tempUserName
        set @userNameStr = substring (@userNameStr ,1,200)

    -------------finding firstName in description---------------------
        set @tempFirstName = @descript
        set @tempFirstName = substring (@tempFirstName, (patindex('%FirstName%', @tempFirstName)+10) 
    ,(len(@tempFirstName)- patindex('%FirstName=%', @tempFirstName)+10))
        set @index1 = (CHARINDEX(';', @tempFirstName))
        if @index1 <= 0
            set @index1 = 1
        declare @userFNameStr nvarchar(200)
        set @userFNameStr = @tempFirstName
        set @userFNameStr = substring (@userFNameStr ,1,@index1-1)

    -------------finding lastName in description---------------------
        set @tempLastName = @descript
        set @tempLastName = substring (@tempLastName, (patindex('%LastName%', @tempLastName)+9) 
    ,(len(@tempLastName)- patindex('%LastName=%', @tempLastName)+9))
        set @index1 = (CHARINDEX(';', @tempLastName))
        if @index1 <= 0
            set @index1 = 1
        declare @userLNameStr nvarchar(200)
        set @userLNameStr = @tempLastName
        set @userLNameStr = substring (@userLNameStr ,1,@index1-1)

        INSERT into [VPNDataBase].[dbo].[TTempUserRep]
            (
            userID,		   
            userName,	 
            firstName,	  
            lastName,	  
            operationDate, 
            operationTime 
            )
            values
            (
                @userIdStr,
                @userNameStr,
                @userFNameStr,
                @userLNameStr,
                @opDate,
                @opTime
            )
    
        FETCH NEXT FROM tableRow INTO @row,@descript,@opDate ,@opTime
        END

    ----------------------------Select from pageNumber with the size of pagesize------------

        DECLARE
         @pagNum int,
         @pagSize int,
         @lbound int,
         @ubound int,
         @recct  int

        SET @pagNum = ABS(@pageNum)
        SET @pagSize = ABS(@pageSize)
        IF @pageNum < 1 SET @pageNum = 1
        IF @pageSize < 1 SET @pageSize = 1
        SET @lbound = ((@pageNum - 1) * @pageSize)
        SET @ubound = @lbound + @pageSize + 1
    
        /*select @recct = COUNT(*) from TTempUserRep
        IF @lbound >= @recct BEGIN
          SET @ubound = @recct + 1
          SET @lbound = @ubound - (@pageSize + 1) -- return the last page of records if                                               -- no records would be on the
                                                  -- specified page
        END*/
        select  *  
                      FROM    (
                                SELECT  ROW_NUMBER() OVER(ORDER BY operationDate DESC, operationTime DESC) AS row, *
                                FROM    TTempUserRep
                              ) as tb1
                      WHERE
                              row > CONVERT(varchar(9), @lbound) AND
                              row <  CONVERT(varchar(9), @ubound)
        --EXEC (@STMT)                 -- return requested records 

    ----------------------------/Select from pageNumber with the size of pagesize------------
    END
    drop table #tempTable

    go

