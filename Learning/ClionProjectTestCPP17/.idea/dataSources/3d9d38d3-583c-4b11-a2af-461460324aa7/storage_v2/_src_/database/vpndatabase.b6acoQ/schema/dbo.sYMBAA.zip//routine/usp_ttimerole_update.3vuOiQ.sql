
    
    CREATE PROCEDURE [dbo].[USP_TTimeRole_Update] 

        @TimeSetName nvarchar(300),
        @trid int,
        @timeStr nvarchar(50),
        @timedescription nvarchar(max)
      
    AS
    BEGIN
            -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.

        update [TTimeRole] set
            [TimeSetName] = @TimeSetName,	
            [timeStr] = @timeStr,
            [TimeDescription] = @timedescription
        where TRID =@trid;
    
    
    END

    go

