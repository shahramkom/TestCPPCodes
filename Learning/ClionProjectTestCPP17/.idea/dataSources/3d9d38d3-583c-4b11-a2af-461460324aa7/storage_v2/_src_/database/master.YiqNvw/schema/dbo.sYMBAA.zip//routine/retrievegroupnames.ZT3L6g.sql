
    create function RetrieveGroupNames(@UserID int)
    returns nvarchar(max)
    AS
    begin
    declare @Groupname as nvarchar(max)

    select @Groupname = coalesce(@GroupName+',','')+ GroupName from TUserGroups as Grp, TGroup as UserGrp 
    where UserID = @UserID and Grp.groupID = UserGrp.groupID

    return @Groupname
    end
    go

