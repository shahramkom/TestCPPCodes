/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.IsPrimaryServer(@CurrentServerID tinyint)
	RETURNS BIT
AS
BEGIN
	DECLARE @CurrentServerType AS TINYINT
	SET @CurrentServerType = 0
	SELECT @CurrentServerType = ServerType  FROM RepConfig WHERE ServerID = @CurrentServerID  
	
	DECLARE @isPrimary AS BIT
	if( @CurrentServerType = 0 )
		set @isPrimary = 1
	else
		set @isPrimary = 0
	RETURN @isPrimary
END
go

