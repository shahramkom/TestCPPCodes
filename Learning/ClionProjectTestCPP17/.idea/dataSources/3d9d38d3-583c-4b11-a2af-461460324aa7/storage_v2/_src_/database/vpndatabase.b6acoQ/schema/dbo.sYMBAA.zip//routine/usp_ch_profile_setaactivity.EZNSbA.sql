CREATE PROCEDURE [dbo].[USP_CH_Profile_SetAactivity]
    @CHP_ProfileID			int
AS
BEGIN
	declare @act bit
	Select @act = Activity from HealthCheckProfiles where ProfileID = @CHP_ProfileID
	Set @act = ~@act
    UPDATE [dbo].[HealthCheckProfiles]
		 SET [activity] = @act
		WHERE ProfileID = @CHP_ProfileID
End
go

