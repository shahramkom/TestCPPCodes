
CREATE PROCEDURE [dbo].[USP_Select_UserIDNameFromWhere]
        @WhereCondition as nvarchar(MAX)
        AS
BEGIN
  	begin try
	 DROP TABLE #ResultTable
	end try
	begin catch
	end catch;
	
	 SELECT * INTO #ResultTable FROM(
	 SELECT  TUser.* , dbo.RetrieveInterfaceNames(TUser.UserID)  as InterfaceBinding
	 FROM    TUser )as t
	 DECLARE @Query AS NVARCHAR(MAX)
	 SET @Query = 'SELECT UserId , UserName From #ResultTable '

	IF(@WhereCondition IS NOT NULL)
		SET @Query = @Query + ' WHERE '+ @WhereCondition

	 EXEC dbo.sp_executesql @Query
END
go

