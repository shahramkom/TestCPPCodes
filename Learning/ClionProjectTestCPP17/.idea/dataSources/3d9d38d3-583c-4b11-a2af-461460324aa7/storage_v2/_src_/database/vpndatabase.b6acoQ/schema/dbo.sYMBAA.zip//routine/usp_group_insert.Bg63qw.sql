
    CREATE PROCEDURE [dbo].[USP_Group_Insert]


        --@GroupID		int,
        @GroupName		nvarchar(500),
        @DefaultAccess	nvarchar(100),
        @Description	nvarchar(max) = NULL,
        @ParentID    	int = 0 ,
        @InterfaceBindingStatus as bit = 0,
		@SendDNS			as bit = 0


    AS
    BEGIN
        declare @GroupID int; 
        SET NOCOUNT ON;

        INSERT INTO [VPNDataBase].[dbo].[TGroup]
           
                (--GroupID,
                GroupName,
                DefaultAccess,
                GroupDescription,
                ParentID,
                InterfaceBindingStatus,
				SendDNS) 
            
         VALUES
                (--@GroupID,
                @GroupName,
                @DefaultAccess,
                @Description,
                @ParentID,
                @InterfaceBindingStatus,
				@SendDNS) 

        select @@IDENTITY

    END

    go

