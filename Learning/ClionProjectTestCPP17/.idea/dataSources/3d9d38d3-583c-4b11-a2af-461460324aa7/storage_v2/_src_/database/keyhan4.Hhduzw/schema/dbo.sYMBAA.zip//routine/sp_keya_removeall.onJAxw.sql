CREATE PROCEDURE [dbo].[sp_KeyA_RemoveAll]  
AS
delete from PurchasedKeyA
go

