/******************************************************************************************************************************************************/--
CREATE FUNCTION dbo.IsTableAssignable(@TableName VARCHAR(50))
RETURNS BIT
BEGIN
	IF(@TableName <> 'TServerAccessPolicy' AND @TableName <> 'TUserFirewallPolicy' AND 
	   @TableName <> 'TUserKeya' AND @TableName <> 'SpecialPermission' AND 
	   @TableName <> 'TPermissionGroup' AND @TableName <> 'TGroup')
		RETURN 0
	RETURN 1
END
go

