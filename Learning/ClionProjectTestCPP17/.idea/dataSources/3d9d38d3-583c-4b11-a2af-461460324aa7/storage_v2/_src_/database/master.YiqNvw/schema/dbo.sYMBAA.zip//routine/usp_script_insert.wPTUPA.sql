
    CREATE PROCEDURE  [dbo].[USP_Script_Insert]
        @ScriptTitle	nvarchar(50),
        @ScriptText	nvarchar(300),
        @ScriptActivity	bit
    AS
    BEGIN
    
        SET NOCOUNT ON;
        INSERT INTO TScript
        (
            ScriptTitle,
            ScriptText,	
            ScriptActivity	
        )
        VALUES
        (		
            @ScriptTitle,
            @ScriptText,	
            @ScriptActivity	
        )
    END

    go

