
	CREATE FUNCTION [dbo].[SelModernPolGroupsUsers]
	(
		@MODERN_ID int
	)
	RETURNS NVARCHAR(MAX)
	AS
	BEGIN
		DECLARE @RETENVALUE NVARCHAR(MAX)  SET @RETENVALUE = ' '
		DECLARE @GROUPNAMES NVARCHAR(MAX)
		DECLARE @USERNAMES  NVARCHAR(MAX)
		select @GROUPNAMES = 'Groups:'+ stuff ((SELECT    ', '+ dbo.TGroup.GroupName
		FROM         dbo.TNewPolicyGroupAssign INNER JOIN
						  dbo.TGroup ON dbo.TNewPolicyGroupAssign.GroupID = dbo.TGroup.GroupID
		WHERE     (dbo.TNewPolicyGroupAssign.ModernPID = @MODERN_ID) for xml path('')) , 1 ,1 , '') 
		select @USERNAMES = ' Users:'+ stuff ((SELECT    ', '+ dbo.TUser.UserName
		FROM         dbo.TNewPolicyUserAssign INNER JOIN
				  dbo.TUser ON dbo.TNewPolicyUserAssign.UserID = dbo.TUser.UserID
		WHERE     (dbo.TNewPolicyUserAssign.ModernPID = @MODERN_ID) for xml path('')) , 1 ,1 , '')
		if(@GROUPNAMES is not null)
			SET @RETENVALUE =  @RETENVALUE + @GROUPNAMES  
		if(@USERNAMES is not null)
			SET @RETENVALUE =  @RETENVALUE + @USERNAMES
		RETURN @RETENVALUE
	END
  go

