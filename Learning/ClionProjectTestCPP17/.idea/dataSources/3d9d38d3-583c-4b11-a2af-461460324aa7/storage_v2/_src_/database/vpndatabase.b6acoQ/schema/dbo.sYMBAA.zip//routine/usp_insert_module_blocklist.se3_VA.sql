
CREATE PROCEDURE [dbo].[USP_Insert_Module_BlockList]
	-- Add the parameters for the stored procedure here
	@keyaSerial	nvarchar(13)
AS
BEGIN
    -- Insert statements for procedure here
	INSERT INTO TModuleBlockList (KeyaSerial, [Date]) VALUES (@keyaSerial, GETDATE())
	
END
/******************************************************************************************************************************************************/
go

