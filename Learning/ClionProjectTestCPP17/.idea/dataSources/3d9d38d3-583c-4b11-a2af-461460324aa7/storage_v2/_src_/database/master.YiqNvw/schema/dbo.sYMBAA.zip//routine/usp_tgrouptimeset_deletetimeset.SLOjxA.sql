
    create PROCEDURE [dbo].[USP_TgroupTimeSet_DeleteTimeSet] 
        -- Add the parameters for the stored procedure here
        @GroupID int
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
        DELETE FROM TGroupTimeSet WHERE GroupID = @GroupID
    END

    go

