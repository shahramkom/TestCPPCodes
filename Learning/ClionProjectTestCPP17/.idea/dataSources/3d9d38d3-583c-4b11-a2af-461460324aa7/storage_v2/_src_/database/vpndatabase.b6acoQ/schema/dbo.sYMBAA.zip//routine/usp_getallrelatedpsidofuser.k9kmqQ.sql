CREATE PROCEDURE [dbo].[USP_getAllRelatedPSIDofUser]
	@UserID BIGINT,
	@AllGroups NVARCHAR(2000),
	@Outputval NVARCHAR(2000) OUTPUT
AS
BEGIN
	DECLARE @USERPSID NVARCHAR(1000) 
	SET @USERPSID = ''
	DECLARE @GROUPPSID NVARCHAR(2000)
	SET @GROUPPSID = ''
	DECLARE @RetVal NVARCHAR(2000)
	SET @RetVal = ''
	SELECT @USERPSID = [dbo].[GetAllPSIDDirectUser](@UserID)
	EXEC USP_GetAllPSIDOfGroups @AllGroups,@GROUPPSID OUTPUT
	if(@USERPSID is not null)
		SET @RetVal = @USERPSID + ','
	if(@GROUPPSID  is not null)
		SET @RetVal = @RetVal + @GROUPPSID
	else
	BEGIN
		IF(LEN(@RetVal) > 0)
			SET @RetVal = SUBSTRING(@RetVal , 1 , LEN(@RetVal) -1 )
	END	
	SELECT @Outputval = @RetVal
END
go

