

    create PROCEDURE [dbo].[USP_REPORT_FILTER_INACtvUSRS_EXP] 
        @startDate		nvarchar(10)=Null,
        @endDate		nvarchar(10)=Null
    AS
    BEGIN

        SET NOCOUNT ON;
        declare @selItems as nvarchar(max),
                @STMT as nvarchar(max),
                @datasrc as nvarchar(max),
                @selItems1 as nvarchar(max),
                @STMT1 as nvarchar(max),
                @query as nvarchar(max),

                @row			nvarchar(max),
                @descript		nvarchar(max),
                --@opDate			nvarchar(10),
                --@opTime			nvarchar(10),
                @tempUserID		nvarchar(max),
                @tempUserName	nvarchar(max),
                @tempFirstName	nvarchar(max),
                @tempLastName	nvarchar(max)

        declare @i as int
        set @i =0
        --delete [TTempUserRepInactive]
    
    ----insert filtered data to table
        set	 @STMT = 'select distinct UserID FROM sAuthLog where (eventDate <= '''+ @startDate + 
                     ''') AND (eventDate >= ''' + @endDate + ''')'

        set	 @selItems1 = 'distinct userID ,userName , BindingStatus ,BindingPCID,SubnetIP,SubnetMask,VirtualIPStatus, '
		set  @selItems1  = @selItems1  + 'VirtualIP,FirstName,LastName,Company,Office,Province,Town,Email , '
		set  @selItems1  = @selItems1  + 'Cell , PersonnelCode,Phone ,NationalID , Adress , PostalCode'
        set  @datasrc = 'TUser '
        SET	 @STMT1 =  '
                                SELECT  '+ @selItems1 +' 
                                FROM  ' + @datasrc +
                                ' WHERE  UserID  NOT IN('+ @STMT +')
                            '
    -------------------------------------------------------------------------	 
    exec sp_executesql @STMT1
    END


    go

