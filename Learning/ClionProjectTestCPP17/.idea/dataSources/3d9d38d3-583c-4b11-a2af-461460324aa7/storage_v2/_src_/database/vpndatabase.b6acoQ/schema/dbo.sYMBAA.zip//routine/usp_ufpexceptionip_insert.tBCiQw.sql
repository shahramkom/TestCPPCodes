CREATE PROCEDURE [dbo].[USP_UFPExceptionIP_INSERT]
    
        @UFPExID INT=NULL OUTPUT,	
        @UFPID   INT,
        @IP      NVARCHAR(15)

    AS
    BEGIN
        
        Insert into TUFPExceptionIP
        (IP,UFPID )
        VALUES
        (@IP,@UFPID)

        SET
        @UFPExID =@@IDENTITY
        
    
    END

go

