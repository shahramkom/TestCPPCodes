CREATE PROCEDURE [dbo].[USP_CH_Profile_Delete] 
    @ProfileID int = 0
AS
	BEGIN
		DELETE FROM HealthCheckProfiles    WHERE ProfileID =  @ProfileID
		DELETE FROM HealthCheckGroupAssign WHERE ProfileID =  @ProfileID
		DELETE FROM HealthCheckUserAssign  WHERE ProfileID =  @ProfileID
END


go

