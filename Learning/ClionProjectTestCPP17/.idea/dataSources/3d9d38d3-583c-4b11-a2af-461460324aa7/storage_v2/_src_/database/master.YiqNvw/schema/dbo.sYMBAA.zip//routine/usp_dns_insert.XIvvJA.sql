
    CREATE PROCEDURE  [dbo].[USP_DNS_Insert]
    
        @HostName	nvarchar(300),
        @IP			nvarchar(15)


    AS
    BEGIN
        --SET NOCOUNT ON;
        INSERT INTO TDNS
        (	
        HostName,	
        IP	
        )
        VALUES
        (		
        @HostName,	
        @IP	
        )


    END


    go

