CREATE PROCEDURE [dbo].[USP_ReadReplicationConfig] 
AS
BEGIN	
	SET NOCOUNT ON;
	Select RepConfig.ServerID, ServerIP, ServerType, SlaveIP, ChangedVirtualIP, 
	(SELECT STUFF ((SELECT ','+ CAST( GroupName AS NVARCHAR(25))
	FROM RepServersGroups INNER JOIN TGroup ON (RepGroupID = GroupID) Where ServerID = RepConfig.ServerID FOR XML PATH('')) , 1 ,1 , '')) as Groups, RepServersState.RunningState FROM RepConfig 
    LEFT JOIN RepServersState ON (RepConfig.ServerID = RepServersState.ServerID)
END
go

