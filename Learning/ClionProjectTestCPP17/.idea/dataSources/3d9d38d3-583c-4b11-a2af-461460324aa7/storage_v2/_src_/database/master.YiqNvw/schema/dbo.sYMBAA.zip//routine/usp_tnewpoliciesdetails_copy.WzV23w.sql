
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesDetails_Copy] 
    @MainID  bigint,
	@CopiedID bigint
   AS
   BEGIN
		INSERT INTO TNewPoliciesDetails ([MainID],[AllowNat],[NatIP],[VirtualIPType],[VirtualIPValue]
					,[SourceTunnelType],[SourceTunnelValue],[DestinationTunnelType],[DestinationTunnelValue])
		SELECT @CopiedID,[AllowNat],[NatIP],[VirtualIPType],[VirtualIPValue]
					,[SourceTunnelType],[SourceTunnelValue],[DestinationTunnelType],[DestinationTunnelValue]
		FROM TNewPoliciesDetails where MainID =  @MainID
   END

   go

