CREATE PROCEDURE [dbo].[sp_AlternateModulesDELETE] 
	@AlterID int
AS
BEGIN
	DELETE FROM [Keyhan4].[dbo].[AlternateModules]
	WHERE ID = @AlterID
END
go

