CREATE FUNCTION [dbo].[GenerateGID]
(
  @serverID INT,
  @version INT,
  @date DATETIME = NULL
)
RETURNS VARCHAR(25)
AS
BEGIN
	IF( @serverID <= 0 )
	BEGIN
		DECLARE @ret VARCHAR(3)
		SET @ret = 0
		SELECT @ret = [value] FROM dbo.TSetting WHERE Property = 'ServerID'
		SET @serverID = CONVERT(INT, @ret)
	END

	IF @date IS NULL
		SET @date = GETDATE()

	RETURN (CONVERT(VARCHAR(3), @serverID) + ','
			+ CONVERT(VARCHAR(8), @version) + ','
			+ CONVERT(VARCHAR(12), dbo.DateTimeToUNIX(@date))
	)
END
go

