/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_SelectTUserGroupsFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
    @Replace BIT
AS
BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
    SET NOCOUNT ON;
        
    DECLARE @groupID NVARCHAR(200),
        @UserID NVARCHAR(200),
        @InsertScript NVARCHAR(4000)

    DECLARE TUserGroups_cursor CURSOR FAST_FORWARD
    FOR
    SELECT  UserID,
            GroupID,
            [output]
    FROM    tbl_InsertGroupScript
    WHERE   tableName = 'TUserGroups'
    OPEN TUserGroups_cursor

    FETCH NEXT FROM TUserGroups_cursor
    INTO @UserID, @groupID, @InsertScript

    WHILE @@FETCH_STATUS = 0
        BEGIN 

    --		if(exists (select UserID from TPolicySet where PSName = @PSName ))
    --		Begin
    --			if(@Replace = '1')
    --				 Delete from TPolicySet   where PSName = @PSName	
    --		End
            BEGIN TRY
                EXEC sp_executesql @InsertScript
                DECLARE @gid AS VARCHAR(25)
				DECLARE @uid AS INT
				SET @uid = CONVERT(INT, @UserID)
                SET @gid = dbo.GetUserGID(@uid)
				EXEC USP_TUserGroups_Update @uid, @gid	
            END TRY
            BEGIN CATCH
                INSERT  INTO [VPNDataBase].[dbo].[TSqlError]
                        ( [userid],
                          [moment],
                          [operate],
                          [errorcode],
                          [errortext],
                          [comment] )
                VALUES  ( 1,
                          GETDATE(),
                          @InsertScript,
                          @@Error,
                          ERROR_MESSAGE(),
                          N'USP_SelectTUserGroupsFromImportedBackupData' )
            END CATCH
        
            
            
            FETCH NEXT FROM TUserGroups_cursor 
             INTO @UserID, @groupID, @InsertScript
    
        END
    CLOSE TUserGroups_cursor;
    DEALLOCATE TUserGroups_cursor;		
END
go

