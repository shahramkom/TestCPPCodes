CREATE PROCEDURE [dbo].[USP_Update_TUser]
-- Add the parameters for the stored procedure here
	@fields			nvarchar(4000),
	@ChangedValues	nvarchar(max),
	@UserID			nvarchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	select * from TUser where UserID = @UserID
	-- Insert statements for procedure here
	if(@fields <> '')
	BEGIN
	DECLARE @RESULT AS nvarchar(max)
	set @RESULT = 'UPDATE TUSER SET '
	
	DECLARE @DEFVAL	nvarchar(50)
	DECLARE @DEFFLD	nvarchar(50)

	DECLARE FIELDS_cursor Cursor For
			SELECT * FROM dbo.Splitfn(@fields,'$')
	DECLARE VALUES_cursor Cursor For
			SELECT * FROM dbo.Splitfn(@ChangedValues,'$')
		
	OPEN FIELDS_cursor
	OPEN VALUES_cursor


	FETCH NEXT FROM FIELDS_cursor 
	INTO @DEFFLD
	FETCH NEXT FROM VALUES_cursor 
	INTO @DEFVAL

	WHILE @@FETCH_STATUS = 0
	BEGIN
	if(@DEFFLD <> '')
	BEGIN
		if(@DEFVAL = 'NULL')
			set @RESULT = @RESULT + @DEFFLD  + '='+@DEFVAL  + ','
		ELSE
			set @RESULT = @RESULT + @DEFFLD  + '='+ +'N'''+@DEFVAL +''''+ + ','
	END
	FETCH NEXT FROM FIELDS_cursor 
		INTO @DEFFLD
	FETCH NEXT FROM VALUES_cursor 
		INTO @DEFVAL
	END

	CLOSE FIELDS_cursor;
	DEALLOCATE FIELDS_cursor;
	CLOSE VALUES_cursor;
	DEALLOCATE VALUES_cursor;

	declare @LastModifyDateTime as nvarchar(20)
	select @LastModifyDateTime = CONVERT(nvarchar(20),GETDATE(),20)
	select @LastModifyDateTime
	DECLARE @GID AS VARCHAR(25)
	SET @GID = dbo.GenerateNewGID(@UserID)
	set @RESULT=@RESULT+'LastModifiedTime = N'''+@LastModifyDateTime +''',GID = '''+@GID +''','

	set @RESULT = @RESULT + 'WHERE UserID = ' + @UserID
	set @RESULT = Replace(@RESULT,',WHERE',' WHERE')
	set @RESULT = replace(@RESULT,'''NULL''','NULL')

	EXEC (@RESULT)
	Update TUserGroups SET GID = @GID WHERE UserID = @UserID     
END
END

go

