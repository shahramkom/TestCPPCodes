
    
        CREATE PROCEDURE [dbo].[USP_SelectSpecialPermissionFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	

    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        
    declare @PermissionName nvarchar(200) ,@groupID nvarchar(200), @InsertScript nvarchar(4000)
    declare @ID int 
     Declare SpecialPermission_cursor Cursor FAST_FORWARD
        For
        Select 
                  PermissionName,GroupID,[output] 
            FROM tbl_InsertGroupScript   
            where tableName = 'SpecialPermission'
            OPEN SpecialPermission_cursor

    FETCH NEXT FROM SpecialPermission_cursor
    INTO @PermissionName,@groupID,@InsertScript

    WHILE @@FETCH_STATUS = 0
    begin 
            
        
            select @ID = ID from SpecialPermission where PermissionName = @PermissionName
        if(exists (select ID from SpecialPermission where PermissionName = @PermissionName	  ))
            Begin
            
                if(@Replace = 1)
                    begin
                
                    Delete from SpecialPermission   where ID = @ID	
                    
                    end
            End	
        
            BEGIN TRY
            
                SET IDENTITY_INSERT SpecialPermission ON
                exec sp_executesql @InsertScript	
                SET IDENTITY_INSERT SpecialPermission OFF		
            END TRY
            BEGIN CATCH
				INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectSpecialPermissionFromImportedBackupData')
            END CATCH  	
            FETCH NEXT FROM SpecialPermission_cursor 
            INTO @PermissionName,@groupID,@InsertScript
    
        end
        CLOSE SpecialPermission_cursor;
        DEALLOCATE SpecialPermission_cursor;
                
    END

        go

