

    CREATE PROCEDURE [dbo].[UPS_SetOrderUFPolicy]

        @UFPID int,
        @POrder int,
        @UFPID1 int,
        @POrder1 int
    AS
    BEGIN

        UPDATE TUserFirewallPolicy	
        SET
        POrder=@POrder
        where 
        UFPID=@UFPID

        UPDATE TUserFirewallPolicy
        SET
        POrder=@POrder1
        where 
        UFPID=@UFPID1
    END

    go

