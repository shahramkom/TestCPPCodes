
	CREATE PROCEDURE [dbo].[USP_TInterface_Select_All]
		-- Add the parameters for the stored procedure here	
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		declare @Statement as nvarchar(1000)
	
		set @Statement = 'select * from Tinterface'
		exec sp_executesql @Statement
	END


  go

