
  Create PROCEDURE [dbo].[USP_TNewPoliciesSearch_PolicyName] 
	@PolicyName nvarchar(200)
	AS
	BEGIN
		if (@PolicyName = '')
		begin
			exec USP_TNewPolicyMain_Select
			return
		end	
		SELECT *  ,dbo.SelModernPolGroupsUsers(MP.ID)AS Assignments
				 FROM [dbo].[TNewPolicyMainTable] AS MP
				 WHERE Name like @PolicyName
				 ORDER BY ApplyTime DESC ,PolicyOrder ASC
	END

  go

