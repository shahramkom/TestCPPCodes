/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE USP_ProcessTableChanges
	@sActionType VARCHAR(50), 
	@Command nvarchar(MAX),
	@RecordIDValue int,
	@MyServerID TINYINT,
	@AssignedGroups VARCHAR(MAX) = NULL,
	@AssignedUsers VARCHAR(MAX) = NULL
AS
BEGIN
	IF(dbo.IsPrimaryServer(@MyServerID) = 1)
		EXEC USP_InsertChangesToSecondaryReplog @sActionType, @Command, @RecordIDValue, NULL, @AssignedGroups, @AssignedUsers
END
go

