/******************************************************************************************************************************************************/--
CREATE FUNCTION dbo.GetTableGroupIDFieldName(@TableName VARCHAR(50))
RETURNS VARCHAR(50)
BEGIN
	DECLARE @GroupIDFieldName AS VARCHAR(50)
	SET @GroupIDFieldName = 
	(CASE 	
			WHEN @TableName = 'TgroupDNS' OR @TableName = 'TGroupPolicySet' OR @TableName = 'TgroupScript' OR @TableName = 'TgroupTimeset' OR @TableName = 'TUserGroups' OR @TableName = 'TGroupInterface'
			THEN 'GroupID'
			WHEN @TableName = 'TUserDNS' OR @TableName = 'TUserScripts' OR @TableName = 'TUserPolicySet' OR @TableName = 'TUserTimeSet' OR @TableName = 'TUserInterface'
			THEN 'UserID'
			WHEN @TableName = 'TServerAccessPolicy' OR @TableName = 'TUserFirewallPolicy'  
			THEN 'PSID'
			WHEN @TableName = 'TPermissionGroup' 
			THEN 'Group_ID'
			WHEN @TableName = 'TUserKeyA' 
			THEN 'KeyaSerial'
	END)
	RETURN @GroupIDFieldName
END
go

