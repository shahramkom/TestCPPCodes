/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetPolicyTableDeleteQuery]( @TableName varchar(100), @PSIDFieldName varchar(100), @PSIDFieldValue int, @IDFieldName varchar(100), @IDFieldValue int)
		RETURNS varchar(MAX)
AS
BEGIN
		DECLARE @CommandStr nvarchar(MAX)
		SET @CommandStr ='DELETE FROM ' +@TableName+ ' WHERE '+ @PSIDFieldName +' = ' + CAST(@PSIDFieldValue AS VARCHAR(20))+' AND ' + @IDFieldName +' = ' + CAST(@IDFieldValue AS VARCHAR(20))+''
		return @CommandStr
END
go

