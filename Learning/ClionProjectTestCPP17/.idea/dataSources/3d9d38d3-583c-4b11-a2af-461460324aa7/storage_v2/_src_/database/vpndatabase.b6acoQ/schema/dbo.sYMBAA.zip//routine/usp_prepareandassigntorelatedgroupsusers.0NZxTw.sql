/******************************************************************************************************************************************************/---------------------------------
 CREATE PROCEDURE USP_PrepareAndAssignToRelatedGroupsUsers
@TableName varchar(50),
@RecordID INT,
@RecordAssignedGroups VARCHAR(MAX),
@RecordAssignedUsers  VARCHAR(MAX),
@RecordGID varchar(25)
AS
BEGIN
	DECLARE @AssignStr AS VARCHAR(MAX)
	DECLARE @AssignType AS VARCHAR(20)	
	SELECT @AssignType = dbo.GetAssignType(@RecordAssignedGroups,@RecordAssignedUsers)
	
	SELECT @TableName = dbo.GetCorrectTableName(@TableName,@AssignType)

	DECLARE @GroupIDFieldName AS VARCHAR(50)
	SELECT @GroupIDFieldName = dbo.GetTableGroupIDFieldName(@TableName)
	
	DECLARE @TableIDFieldName AS VARCHAR(50)
	SELECT @TableIDFieldName = dbo.GetAssignTableIDFieldName(@TableName)

	IF (@AssignType = 'Assign-Users')
		SET @AssignStr = @RecordAssignedUsers
	ELSE IF (@AssignType = 'Assign-Groups')
		SET @AssignStr = @RecordAssignedGroups

	IF (@AssignStr IS NOT NULL)
		EXEC USP_AssignToRelatedGroupsUsers @TableName,@RecordID,@AssignStr,@RecordGID,@TableIDFieldName,@GroupIDFieldName 
END
go

