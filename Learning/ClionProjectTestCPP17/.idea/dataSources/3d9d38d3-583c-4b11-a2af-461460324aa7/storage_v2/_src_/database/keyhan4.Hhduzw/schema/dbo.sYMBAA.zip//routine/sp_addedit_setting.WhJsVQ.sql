CREATE PROCEDURE [dbo].[sp_AddEdit_Setting]  
	@SettingCode			int,
	@SettingName			nvarchar(200),
	@VersionCode			int,
	@FreeMemSize			int,
	@SecureMemSize		int,
	@DeveloperMemSize		int, 
	@KVKeyNumber		int,
	@QueryKeyNumber		int, 
	@KAB 				nchar(32),
	@FreeEnable			varchar(10),
	@DeveloperEnable		varchar(10),
	@EncByCustomKey		varchar(10),
	@LoginFlag			varchar(10),
	@PinCode			varchar(20),
	@MasterPin			varchar(200),
	@DeviceType			bit
 AS
	-- Calculate the value of LoginFlag
	declare @LoginState 		bit
	declare 	@FreeEnableFlag 	bit
	declare 	@DeveloperEnableFlag 	bit
	declare 	@EncByCustomKeyFlag 	bit
	select @LoginState = 0
	if (@LoginFlag = 'true')
		set @LoginState = 1

	select @FreeEnableFlag = 0
	if (@FreeEnable = 'true')
		set @FreeEnableFlag = 1

	select @DeveloperEnableFlag = 0
	if (@DeveloperEnable = 'true')
		set @DeveloperEnableFlag = 1

	select @EncByCustomKeyFlag = 0
	if (@EncByCustomKey = 'true')
		set @EncByCustomKeyFlag = 1

	-- for Add
	if (@SettingCode = 0)
	begin
		declare @k1   binary(8) 
		declare @k2   binary(8) 
		declare @Kp   binary(16) 
		declare @Kr    binary(16) 
		declare @Kw   binary(16) 
		declare @Kw2 binary(16) 
		-- @Kp
		select @k1 = 9223372036854775807 * rand()
		select @k2 = 9223372036854775807 * rand()
		select @Kp = @k2 + @k1

		-- @Kr
		select @k1 = 9223372036854775807 * rand()
		select @k2 = 9223372036854775807 * rand()
		select @Kr = @k2 + @k1

		-- @Kw
		select @k1 = 9223372036854775807 * rand()
		select @k2 = 9223372036854775807 * rand()
		select @Kw = @k2 + @k1

		-- @Kw2
		select @k1 = 9223372036854775807 * rand()
		select @k2 = 9223372036854775807 * rand()
		select @Kw2 = @k2 + @k1

		Insert KeyASettings (SettingName, Version, KABKey, FreeMemSize, SecureMemSize, DeveloperMemSize, 
		                                      KVKeyNumber, QureyKeyNumber, FreeMemEnable, DeveloperMemEnable, EncByCustomKey,LoginFlag, PinCode, Kp, Kr, Kw, Kw2, MasterPin, DeviceType)
		values  		           (@SettingName, @VersionCode, @KAB, @FreeMemSize, @SecureMemSize, @DeveloperMemSize, 
				@KVKeyNumber, @QueryKeyNumber, @FreeEnableFlag, @DeveloperEnableFlag, @EncByCustomKeyFlag, @LoginState, @PinCode, @Kp, @Kr, @Kw, @Kw2, @MasterPin, @DeviceType)		
		select N'ÊäÙíãÇÊ ãæÑÏ äÙÑ ÈÇ ãæÝÞíÊ Èå ÇíÇå ÏÇÏå ÇÖÇÝå ÔÏ.' as ErrMsg, 0 as RetCode
		return ;
	end

	-- for Edit
	Update KeyASettings  
	set 
		Version			= @VersionCode,	
		SettingName		= @SettingName,
		KABKey		 	= @KAB,
		FreeMemSize	 	= @FreeMemSize,
		SecureMemSize	 	= @SecureMemSize,
		DeveloperMemSize 	= @DeveloperMemSize,
		KVKeyNumber		= @KVKeyNumber,
		QureyKeyNumber	= @QueryKeyNumber, 
		FreeMemEnable		= @FreeEnableFlag,
		DeveloperMemEnable     = @DeveloperEnableFlag ,
		EncByCustomKey	= @EncByCustomKeyFlag ,
		LoginFlag		= @LoginState,
		MasterPin		= @MasterPin,
		PinCode		= @PinCode,
		DeviceType		= @DeviceType
	where 	(@SettingCode = SettingCode)

	select N'Ñ˜æÑÏ ãæÑÏ äÙÑ ÈÇ ãæÝÞíÊ æíÑÇíÔ ÔÏ.' as ErrMsg, 10 as RetCode
go

