CREATE PROCEDURE [dbo].[USP_UFPExceptionIP_Update]
    
        @UFPExID INT,	
        @UFPID   INT,
        @IP      NVARCHAR(15)

    AS
    BEGIN
        
        update  TUFPExceptionIP
        set
        IP = @IP,UFPID = @UFPID 
        where	
        UFPExID = @UFPExID 
    
    END

go

