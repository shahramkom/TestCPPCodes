
	CREATE PROCEDURE [dbo].[USP_CopyUser_DNSAssignments] 
    @OldUserID  bigint,
	@NewUserID  bigint
   AS
   BEGIN
		INSERT INTO TUserDNS (UserID	 , DNSID)
		SELECT 	@NewUserID	 ,DNSID	 
		FROM TUserDNS WHERE UserID = @OldUserID
   END

  go

