


    CREATE  PROCEDURE [dbo].[UPS_Insert_ADTempUser]
    
    
            @UserName  nvarchar(200),
            @AccountDisable tinyInt,
            @FirstName nvarchar(200),
            @LastName nvarchar(200),
            @Company nvarchar(200),
            @Office nvarchar(200),
            @Province nvarchar(200),
            @Town nvarchar(200),
            @Notes nvarchar(max),
            @Email nvarchar(200),
            @Cell nvarchar(50),
            @PersonnelCode nvarchar(10),
            @Phone nvarchar(200),
            @NationalID nvarchar(10),
            @Adress nvarchar(max),
            @PostalCode nvarchar(200)
    
    AS
    BEGIN

        INSERT INTO [VPNDataBase].[dbo].[TADTempUser]
               ([UserName]
               ,[AccountDisable]
               ,[FirstName]
               ,[LastName]
               ,[Company]
               ,[Office]
               ,[Province]
               ,[Town]
               ,[Notes]
               ,[Email]
               ,[Cell]
               ,[PersonnelCode]
               ,[Phone]
               ,[NationalID]
               ,[Adress]
               ,[PostalCode])
         VALUES
              (@UserName,
               @AccountDisable,
               @FirstName,
               @LastName,
               @Company,
               @Office, 
               @Province,
               @Town,
               @Notes,
               @Email,
               @Cell, 
               @PersonnelCode,
               @Phone,
               @NationalID, 
               @Adress,
               @PostalCode) 
           
    END


    go

