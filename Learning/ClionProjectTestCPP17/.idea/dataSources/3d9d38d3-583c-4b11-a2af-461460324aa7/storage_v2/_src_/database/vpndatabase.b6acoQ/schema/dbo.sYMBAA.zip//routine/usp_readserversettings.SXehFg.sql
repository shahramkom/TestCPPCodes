CREATE PROCEDURE [dbo].[USP_ReadServerSettings] 
	@param VARCHAR(20)
AS
BEGIN	
	SET NOCOUNT ON;
	SELECT * FROM TSetting WHERE [property] = @param
END

go

