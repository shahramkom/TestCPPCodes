CREATE PROCEDURE [dbo].[CheckDatabaseConnection] 
AS
BEGIN
	SELECT COUNT(PSID) FROM TPolicySet
	
END
go

