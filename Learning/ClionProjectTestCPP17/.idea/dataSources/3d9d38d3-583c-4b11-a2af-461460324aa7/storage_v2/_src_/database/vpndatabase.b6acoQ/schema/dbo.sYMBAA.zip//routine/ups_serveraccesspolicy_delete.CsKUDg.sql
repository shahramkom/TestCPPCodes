
    CREATE PROCEDURE [dbo].[UPS_ServerAccessPolicy_Delete]

       @PolicyID int,
       @GSID   int ,
       @order  int  
   
    AS

    BEGIN
        
        DELETE FROM  [VPNDataBase].[dbo].[TServerAccessPolicy] WHERE  PolicyID =@PolicyID
        DECLARE SAPID_cursor CURSOR FAST_FORWARD READ_ONLY FOR 
            select  PolicyID from  TServerAccessPolicy where PSID = @GSID   order by POrder asc
        
        declare @RowNumber int 
        set @RowNumber = 1
        OPEN SAPID_cursor

        FETCH NEXT FROM SAPID_cursor
        into @PolicyID

        if @@FETCH_STATUS != 0
        begin
            close SAPID_cursor
            DEALLOCATE SAPID_cursor  
            return	
        end
        WHILE @@FETCH_STATUS = 0
        BEGIN
        
            update TServerAccessPolicy set POrder = @RowNumber where PolicyID = @PolicyID 
            set @RowNumber = @RowNumber + 1
        FETCH NEXT FROM SAPID_cursor
        into @PolicyID
        END
        close SAPID_cursor
        DEALLOCATE SAPID_cursor
    END

    go

