
    CREATE PROCEDURE [dbo].[USP_PolicyOfGroups_Select] 
        -- Add the parameters for the stored procedure here
        @PSID int =null
    AS

    BEGIN

        SELECT  GroupName from  TGroup where  GroupID IN
 
        ( SELECT GroupID FROM  TGroupPolicySet   WHERE PSID = @PSID)
    END


    go

