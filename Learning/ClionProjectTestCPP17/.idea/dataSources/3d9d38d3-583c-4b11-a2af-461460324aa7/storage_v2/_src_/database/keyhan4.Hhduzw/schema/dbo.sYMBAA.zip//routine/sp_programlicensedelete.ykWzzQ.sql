CREATE PROCEDURE [dbo].[sp_ProgramLicenseDELETE] 
	@LicenseID int
AS
	BEGIN
DELETE FROM [Keyhan4].[dbo].[ProgramLicense]
 WHERE ID = @LicenseID

	END
go

