CREATE PROCEDURE [dbo].[sp_SelledKeyA_delete]  
	@RecCode	int
AS
	declare @BFlag bit

	select @BFlag = LoanFlag from PurchasedKeyA where PurchaseCode = @RecCode
	
	if (@BFlag = 0) 
	begin
		delete from SerialRanges where PurchaseCode = @RecCode
		delete from PurchasedKeya where PurchaseCode = @RecCode
	end
	else
		update  PurchasedKeyA 
			set DeleteFlag = 1
		where PurchaseCode = @RecCode
go

