
	 CREATE PROCEDURE [dbo].[USP_convert44To45] 
        -- Add the parameters for the stored procedure here
        
      
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        --SET NOCOUNT ON;

       declare @row nvarchar(max) , @GID nvarchar(50) , @UID nvarchar(50),@insertScript nvarchar(Max)
    ,@username nvarchar(max)   , @hostname nvarchar(max),@DNSID nvarchar(50),@permissionName nvarchar(max)
    ,@permissionOutPut nvarchar(max),@miniAdminType nvarchar(max)
    
    DECLARE TSpecialPermissionRow CURSOR FAST_FORWARD FOR
      select [output], [PermissionName],[GroupID] from tbl_InsertGroupScript460
       where tableName =  N'SpecialPermission'
        OPEN TSpecialPermissionRow
        FETCH NEXT FROM TSpecialPermissionRow INTO @row,@permissionName,@GID
        WHILE @@FETCH_STATUS=0
        BEGIN
    
    set @permissionOutPut = @row 
    set @permissionOutPut = REPLACE(@permissionOutPut,'ExportImportUserInfo)','ExportImportUserInfo ,MiniAdminType)')
    set  @miniAdminType = substring (@permissionOutPut,PATINDEX('% VALUES(%',@permissionOutPut),len(@permissionOutPut))
   set  @miniAdminType = left( @miniAdminType,len(@miniAdminType)-1)+',1)' 
    set @permissionOutPut =  left(@permissionOutPut,PATINDEX('% VALUES(%',@permissionOutPut))
    set @permissionOutPut = @permissionOutPut + @miniAdminType
       
        insert  tbl_InsertGroupScript([output],tableName,GroupID,PermissionName)values(@permissionOutPut,'SpecialPermission',@GID,@permissionName) 	
            FETCH NEXT FROM TSpecialPermissionRow INTO @row,@permissionName,@GID 
        END
            
            
            CLOSE TSpecialPermissionRow
            DEALLOCATE TSpecialPermissionRow	
    
    DECLARE TScriptRow CURSOR FAST_FORWARD FOR
      select [output], GroupID , userID , username from tbl_InsertGroupScript460
       where tableName =  N'TUser'
        OPEN TScriptRow
        FETCH NEXT FROM TScriptRow INTO @row,@GID , @UID , @userName
        WHILE @@FETCH_STATUS=0
        BEGIN
          
		  begin try   
            set @insertScript  =  'INSERT INTO [VPNDataBase].[dbo].[TUserGroups]
           ([UserID]
           ,[GroupID])
     VALUES
           ('+ 'N'''+@UID +''','+
          'N'''+@GID+''')'



          insert  tbl_InsertGroupScript([output],tableName,GroupID,UserID)values(@insertScript,'TUserGroups',@GID,@UID) 		
           end try

		   begin catch

			INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@insertScript
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_convert44to45')
		   end catch

		   begin try
        set @row  = replace (@row ,'GroupID,','' )
    --	select @row
        
        declare @rowLocal nvarchar(max)
            set @rowLocal = @row
        --	set @rowLocal = substring (@rowLocal, (patindex('%VALUES(%', @rowLocal)+9) ,(len(@rowLocal)- patindex('%VALUES(%', @rowLocal)+8))
            --select @rowLocal
            
            declare @i int  , @j int 
            --set  @i = (CHARINDEX(',', @rowLocal)+1)
            set @i = patindex('%VALUES(%', @row) +LEN(@UID) +10  
            set  @rowLocal =  substring (@row, 0 , @i)
            set @rowLocal = @rowLocal + SUBSTRING(@row, @i + len(@gid)+ 3 ,(len(@row)-@i + len(@gid)+ 2))
        
            

            insert  tbl_InsertGroupScript([output],tableName,userName,UserID)values(@rowLocal,'TUser',@userName,@UID) 	 
			end try
			begin catch

				INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@rowLocal
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_convert44to45')
            end catch
		
            FETCH NEXT FROM TScriptRow INTO @row,@GID , @UID,@userName
        END
            
            
            CLOSE TScriptRow
            DEALLOCATE TScriptRow	
        
        
            
		 DECLARE TDNSRow CURSOR FAST_FORWARD FOR
      select [output], GroupID , hostname from tbl_InsertGroupScript460
       where tableName =  N'TDNS'
        OPEN TDNSRow
        FETCH NEXT FROM TDNSRow INTO @row,@GID , @hostname 
        WHILE @@FETCH_STATUS=0
        BEGIN
        
         
			declare @DNSIdStr nvarchar(200)
          
			 if(exists (select * from tbl_InsertGroupScript where hostname = @hostname)) 
			  begin
               begin try
					declare @outputStr nvarchar(max),@groupidStrD nvarchar(max)
					select @DNSIdStr = DNSID from tbl_InsertGroupScript where hostname = @hostname and tablename = 'tdns'
				    set @insertScript  =  'INSERT INTO [VPNDataBase].[dbo].[TGroupDNS]
						([DNSID]
						,[GroupID])
						VALUES
						('+ 'N'''+@DNSIdStr +''','+
						'N'''+@GID+''')'
			            insert  tbl_InsertGroupScript([output],tableName,GroupID,DNSID)values(@insertScript,'TGroupDNS',@GID,@DNSIdStr) 		
				end try 
				begin catch
					INSERT INTO [VPNDataBase].[dbo].[TSqlError]
					([userid]
					,[moment]
					,[operate]
					,[errorcode]
					,[errortext]
					,[comment])
					 VALUES
					 (1
					,GETDATE()
					,@insertScript
					,@@Error
					,Error_MESSAGE()
					,N'USP_convert44to45')

				end catch

			  end
			else
				begin 
							 begin try
								set @rowLocal = substring (@row, (patindex('%VALUES(%', @row)+8) ,(len(@row)- patindex('%VALUES(%', @row)+8))
								set  @i = (CHARINDEX(',', @rowLocal)+1)
								set @DNSIdStr = @rowLocal
								set @DNSIdStr = substring (@DNSIdStr ,0,@i-2 )
		            
  							  set @insertScript  =  'INSERT INTO [VPNDataBase].[dbo].[TGroupDNS]
  							 ([DNSID]
  							 ,[GroupID])
  					   VALUES
  							 ('+ 'N'''+@DNSIdStr +''','+
  							'N'''+@GID+''')'



						 insert  tbl_InsertGroupScript([output],tableName,GroupID,DNSID)values(@insertScript,'TGroupDNS',@GID,@DNSIdStr) 		
		           
						 end try
						 begin catch
								INSERT INTO [VPNDataBase].[dbo].[TSqlError]
							   ([userid]
							   ,[moment]
							   ,[operate]
							   ,[errorcode]
							   ,[errortext]
							   ,[comment])
						 VALUES
							   (1
							   ,GETDATE()
							   ,@insertScript
							   ,@@Error
							   ,Error_MESSAGE()
							   ,N'USP_convert44to45')

				   end catch

				   begin try
						  set @row  = replace (@row ,'GroupID,','' )
						  set @rowLocal = @row
						  set @i = patindex('%VALUES(%', @row) +LEN(@DNSIdStr) +10   
						  set  @rowLocal =  substring (@row, 0 , @i)
						  set @rowLocal = @rowLocal + SUBSTRING(@row, @i + len(@gid)+ 3 ,(len(@row)-@i + len(@gid)+ 2))
						  insert  tbl_InsertGroupScript([output],tableName,hostname,DNSID)values(@rowLocal,'TDNS',@hostname,@DNSIdStr) 	 
					
						end try
						begin catch
							INSERT INTO [VPNDataBase].[dbo].[TSqlError]
						   ([userid]
						   ,[moment]
						   ,[operate]
						   ,[errorcode]
						   ,[errortext]
						   ,[comment])
					 VALUES
						   (1
						   ,GETDATE()
						   ,@rowLocal
						   ,@@Error
						   ,Error_MESSAGE()
						   ,N'USP_convert44to45')
					end catch
		end 	
            FETCH NEXT FROM TDNSRow INTO @row,@GID , @hostname
        END
            
            
            CLOSE TDNSRow
            DEALLOCATE TDNSRow	
            
              
            
            
       declare @PSID nvarchar(50)		
        DECLARE TGroupPolicySetRow CURSOR FAST_FORWARD FOR
      select [output], GroupID , PSID from tbl_InsertGroupScript460
       where tableName =  N'TGroupPolicySet'
        OPEN TGroupPolicySetRow
        FETCH NEXT FROM TGroupPolicySetRow INTO @row,@GID , @PSID 
        WHILE @@FETCH_STATUS=0
        BEGIN
			 begin try

            set @row =  'INSERT INTO [VPNDataBase].[dbo].[TGroupPolicySet]
           ([GroupID]
           ,[PSID]
           ,[PriorityOrder])
     VALUES
           ('+ replace(@GID,'''','') +' , '+ replace(@PSID,'''','') + ','+ '1' +')'
            
              insert  tbl_InsertGroupScript([output],tableName,GroupID,DNSID)values(@row,'TGroupPolicySet',@GID,@PSID) 
			  
			 end try
			 begin catch
				INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@row
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_convert44to45')

			 end catch 		
              FETCH NEXT FROM TGroupPolicySetRow INTO @row,@GID , @PSID
        END
            
            
            CLOSE TGroupPolicySetRow
            DEALLOCATE TGroupPolicySetRow
            
            
                declare @PSname nvarchar(max)		
        DECLARE TGroupPolicySetRow CURSOR FAST_FORWARD FOR
      select [output], PSname , PSID from tbl_InsertGroupScript460
       where tableName =  N'TPolicySet'
        OPEN TGroupPolicySetRow
        FETCH NEXT FROM TGroupPolicySetRow INTO @row, @PSname,@PSID 
        WHILE @@FETCH_STATUS=0
        BEGIN
		begin try
            insert  tbl_InsertGroupScript([output],tableName,PSID,PSName)values(@row,'TPolicySet',@PSID,@PSName) 	
		end try
		begin catch
			INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@row
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_convert44to45')

		end catch
            FETCH NEXT FROM TGroupPolicySetRow INTO @row,@PSname , @PSID
        END
            
            CLOSE TGroupPolicySetRow
            DEALLOCATE TGroupPolicySetRow	
            
            
  
    
    declare @scriptTitle nvarchar(max), @scriptID nvarchar(50) 
    DECLARE TScriptRow CURSOR FAST_FORWARD FOR
      select [output],scriptTitle,GroupID from tbl_InsertGroupScript460
        where  tableName =  N'TScript'
        OPEN TScriptRow
        
        FETCH NEXT FROM TScriptRow INTO @row,@scriptTitle,@GID
        WHILE @@FETCH_STATUS=0
        BEGIN
            
			begin try
		          set @rowLocal = @row
		          set @rowLocal = substring (@rowLocal, (patindex('%VALUES%', @rowLocal)+8) ,(len(@rowLocal)- patindex('%VALUES(%', @rowLocal)+8))
		          set  @i = (CHARINDEX(',', @rowLocal)-1)
		          set @scriptID = SUBSTRING(@rowLocal ,0,@i) 
		          
		          set @insertScript  =  'INSERT INTO [VPNDataBase].[dbo].[TGroupScript]
		         ([ScriptID]
		         ,[GroupID])
		   VALUES
		         ('+ 'N'''+@scriptID +''','+
		        'N'''+@GID+''')'
		        
		          insert  tbl_InsertGroupScript([output],tableName,GroupID,ScriptID)values(@insertScript,'TGroupScript',@GID,@ScriptID) 	
			end try
			begin catch
				INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@row
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_convert44to45')
			end catch
            
            begin try

             set @row  = replace (@row ,'GroupID,','' )
            
                        set @i = patindex('%VALUES(%', @row) +LEN(@scriptID) +10   
            set  @rowLocal =  substring (@row, 0 , @i)
            set @rowLocal = @rowLocal + SUBSTRING(@row, @i + len(@gid)+ 3 ,(len(@row)-@i + len(@gid)+ 2))
            
            
            insert  tbl_InsertGroupScript([output],tableName,ScriptTitle)values(@rowLocal,'TScript',@scriptTitle) 	

			end try
			begin catch
					INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@rowLocal
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_convert44to45')
			end catch
            FETCH NEXT FROM TScriptRow INTO @row,@scriptTitle,@GID
        END

            CLOSE TScriptRow
            DEALLOCATE TScriptRow			
    
          
            INSERT INTO [VPNDataBase].[dbo].[tbl_InsertGroupScript]
           ([Output]
                 ,[GroupID]
                 ,[GroupName]
                 ,[PSID]
                 ,[PSName]
                 ,[UserID]
                 ,[userName]
                 ,[hostname]
                 ,[tableName]
                 ,[ScriptTitle]
                 ,[PermissionName]
                 ,[KeyaSerial]
           
           )
           SELECT [Output]
                 ,[GroupID]
                 ,[GroupName]
                 ,[PSID]
                 ,[PSName]
                 ,[UserID]
                 ,[userName]
                 ,[hostname]
                 ,[tableName]
                 ,[ScriptTitle]
                 ,[PermissionName]
                 ,[KeyaSerial]
                FROM [VPNDataBase].[dbo].[tbl_InsertGroupScript460] 
                where tableName not in ('SpecialPermission','TGroupScript','TScript','TTimeRole','TGroupTimeSet','TUser','TUserGroups','TGroupDNS','TGroupPolicySet','TPolicySet','TDNS')
			
            
    END


   go

