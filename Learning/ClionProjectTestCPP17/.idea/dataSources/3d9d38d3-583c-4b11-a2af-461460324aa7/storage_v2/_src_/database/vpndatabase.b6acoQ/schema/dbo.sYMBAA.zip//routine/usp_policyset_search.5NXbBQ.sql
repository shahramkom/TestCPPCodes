
Create PROCEDURE [dbo].[USP_PolicySet_Search] 

	@WherePSName As Nvarchar(100),
	@IP		As Varchar(15),
	@Mask	As Varchar(15),
	@Port   As Varchar(20),
	@Protocol As Varchar(10),
	@ContainAnyIPAdd As BIT,
	@LogicRelation As Nvarchar(Max)
AS
BEGIN

DECLARE @IPSelect As Nvarchar(MAX),
		@PortSelect As Nvarchar(Max),
		@ProtocolSelect As Nvarchar(Max),
		@PSNameStm As Nvarchar(MAX)
		
		SET @IPSelect = NULL
		SET @PortSelect = NULL
		SET @ProtocolSelect = NULL
		SET @PSNameStm = NULL
		
IF(@IP IS NOT NULL)
BEGIN
	SET @IPSelect = ' (SELECT * FROM TPolicySet WHERE PSID IN(
	  SELECT PSID FROM TUserFirewallPolicy WHERE
	  (dbo.fnIsInRangeIP('''+@IP+''' , Fil_Source_IPAdress ,'''+@Mask+''')=1 OR
	  dbo.fnIsInRangeIP('''+@IP+''' , Fil_Dest_IPAdress ,'''+@Mask+''')=1 OR
	  '''+@IP+''' = Ac_Tunnel_Source_IP OR
	  '''+@IP+''' = Ac_Tunnel_Dest_IP OR
	  '''+@IP+''' = Ac_VirtualIP )'
  IF(@ContainAnyIPAdd = 0)
	SET @IPSelect = @IPSelect + ' AND (Fil_Source_AdressType != ''Any'' AND  Fil_Dest_Type != ''Any'')' 
	 ELSE	
		SET @IPSelect = @IPSelect + ' OR (Fil_Source_AdressType = ''Any'' OR  Fil_Dest_Type = ''Any'')' 	
	SET @IPSelect = @IPSelect + ' UNION SELECT PSID FROM TServerAccessPolicy WHERE 
	dbo.fnIsInRangeIP('''+@IP+''' , NetworkIP ,'''+@Mask+''')=1))'
END 

IF(@Port IS NOT NULL)
BEGIN
	SET @PortSelect = ' (SELECT * FROM TPolicySet WHERE PSID IN(
	SELECT PSID FROM TUserFirewallPolicy WHERE
	dbo.fnIsInRangePort ('''+@Port+''',Fil_Protocol_SourcePort)=1 OR
	dbo.fnIsInRangePort ('''+@Port+''',Fil_Protocol_DestPort)=1 
	
	UNION 
	
	SELECT PSID FROM TServerAccessPolicy WHERE 
	dbo.fnIsInRangePort ('''+@Port+''',Port)=1 ))'
END 

IF(@Protocol IS NOT NULL)
BEGIN
   if(@Protocol = 'other')
   BEGIN
		SET @ProtocolSelect = ' (SELECT * FROM TPolicySet WHERE PSID IN(
		SELECT PSID FROM TUserFirewallPolicy WHERE 
		Fil_Protocol_Code =''' +@Protocol+'''
   
		UNION 
   
		SELECT PSID FROM TServerAccessPolicy WHERE
		Protocol not in (0,1,6,8,17,20,22,27,50,51,66,255)))'
   END
   else
   BEGIN
		SET @ProtocolSelect = ' (SELECT * FROM TPolicySet WHERE PSID IN(
		SELECT PSID FROM TUserFirewallPolicy WHERE 
		Fil_Protocol_Code =''' +@Protocol+'''
   
		UNION 
   
		SELECT PSID FROM TServerAccessPolicy WHERE
		Protocol = dbo.fnProtocolNumber('''+@Protocol+''' , Protocol)))'
   End
END

IF(@WherePSName IS NOT NULL)
   SET @PSNameStm = ' (SELECT * FROM TPolicySet WHERE '+@WherePSName+' )'
/******************************************************************************************************************************************************/------------

IF(@LogicRelation IS NULL)
	RaisError('LogicRelation is null!' , 16 ,1)
SET @LogicRelation  = REPLACE(@LogicRelation , '|',' UNION ')
SET @LogicRelation  = REPLACE(@LogicRelation , '&',' INTERSECT ')
IF(@IPSelect IS NOT NULL)
SET @LogicRelation  = REPLACE(@LogicRelation , '@#IP@#',@IPSelect)
IF(@PortSelect IS NOT NULL)
SET @LogicRelation  = REPLACE(@LogicRelation , '@#Port@#',@PortSelect)
IF(@ProtocolSelect IS NOT NULL)
SET @LogicRelation  = REPLACE(@LogicRelation , '@#Protocol@#',@ProtocolSelect)
IF(@PSNameStm IS NOT NULL)
SET @LogicRelation  = REPLACE(@LogicRelation , '@#PSName@#',@PSNameStm)

--select @LogicRelation
EXEC dbo.sp_executesql @LogicRelation   	
END
go

