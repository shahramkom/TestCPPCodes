--------------------------------------------------------------------------------
CREATE PROCEDURE  [dbo].[SyncBackupDatabase]
AS
BEGIN	
	BEGIN TRANSACTION BackupDbTrans

	BEGIN TRY
	
	DELETE FROM [VPNDataBase_Backup].[dbo].[TGroup]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TPolicySet]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TServerAccessPolicy]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TUserFirewallPolicy]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TGroupPolicySet]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TUserPolicySet]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TNewPoliciesAlgorithms]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TNewPoliciesDetails]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TNewPoliciesServices]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TNewPolicyMainTable]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TNewPolicyGroupAssign]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TNewPolicyUserAssign]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TUser]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TUserGroups]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TDNS]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TGroupDNS]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TUserDNS]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TScript]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TGroupScript]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TUserscripts]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TTimeRole]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TGroupTimeSet]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TUserTimeSet]
	DELETE FROM [VPNDataBase_Backup].[dbo].[HealthCheckProfiles]
	DELETE FROM [VPNDataBase_Backup].[dbo].[HealthCheckRules]
	DELETE FROM [VPNDataBase_Backup].[dbo].[HealthCheckGroupAssign]
	DELETE FROM [VPNDataBase_Backup].[dbo].[HealthCheckUserAssign]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TUserKeya]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TModuleBlockList]
	DELETE FROM [VPNDataBase_Backup].[dbo].[SpecialPermission]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TPermissionGroup]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TInterface]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TGroupInterface]
	DELETE FROM [VPNDataBase_Backup].[dbo].[TUserInterface]


	INSERT INTO [VPNDataBase_Backup].[dbo].[TGroup] SELECT * FROM [VPNDataBase].[dbo].[TGroup]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TPolicySet] SELECT * FROM [VPNDataBase].[dbo].[TPolicySet]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TServerAccessPolicy] SELECT * FROM [VPNDataBase].[dbo].[TServerAccessPolicy]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TUserFirewallPolicy] SELECT * FROM [VPNDataBase].[dbo].[TUserFirewallPolicy]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TGroupPolicySet] SELECT * FROM [VPNDataBase].[dbo].[TGroupPolicySet]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TUserPolicySet] SELECT * FROM [VPNDataBase].[dbo].[TUserPolicySet]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TNewPoliciesAlgorithms] SELECT * FROM [VPNDataBase].[dbo].[TNewPoliciesAlgorithms]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TNewPoliciesDetails] SELECT * FROM [VPNDataBase].[dbo].[TNewPoliciesDetails]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TNewPoliciesServices] SELECT * FROM [VPNDataBase].[dbo].[TNewPoliciesServices]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TNewPolicyMainTable] SELECT * FROM [VPNDataBase].[dbo].[TNewPolicyMainTable]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TNewPolicyGroupAssign] SELECT * FROM [VPNDataBase].[dbo].[TNewPolicyGroupAssign]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TNewPolicyUserAssign] SELECT * FROM [VPNDataBase].[dbo].[TNewPolicyUserAssign]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TUser] SELECT * FROM [VPNDataBase].[dbo].[TUser]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TUserGroups] SELECT * FROM [VPNDataBase].[dbo].[TUserGroups]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TDNS] SELECT * FROM [VPNDataBase].[dbo].[TDNS]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TGroupDNS] SELECT * FROM [VPNDataBase].[dbo].[TGroupDNS]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TUserDNS] SELECT * FROM [VPNDataBase].[dbo].[TUserDNS]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TScript] SELECT * FROM [VPNDataBase].[dbo].[TScript]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TGroupScript] SELECT * FROM [VPNDataBase].[dbo].[TGroupScript]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TUserscripts] SELECT * FROM [VPNDataBase].[dbo].[TUserscripts]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TTimeRole] SELECT * FROM [VPNDataBase].[dbo].[TTimeRole]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TGroupTimeSet] SELECT * FROM [VPNDataBase].[dbo].[TGroupTimeSet]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TUserTimeSet] SELECT * FROM [VPNDataBase].[dbo].[TUserTimeSet]
	INSERT INTO [VPNDataBase_Backup].[dbo].[HealthCheckProfiles] SELECT * FROM [VPNDataBase].[dbo].[HealthCheckProfiles]
	INSERT INTO [VPNDataBase_Backup].[dbo].[HealthCheckRules] SELECT * FROM [VPNDataBase].[dbo].[HealthCheckRules]
	INSERT INTO [VPNDataBase_Backup].[dbo].[HealthCheckGroupAssign] SELECT * FROM [VPNDataBase].[dbo].[HealthCheckGroupAssign]
	INSERT INTO [VPNDataBase_Backup].[dbo].[HealthCheckUserAssign] SELECT * FROM [VPNDataBase].[dbo].[HealthCheckUserAssign]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TUserKeya] SELECT * FROM [VPNDataBase].[dbo].[TUserKeya]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TModuleBlockList] SELECT * FROM [VPNDataBase].[dbo].[TModuleBlockList]
	INSERT INTO [VPNDataBase_Backup].[dbo].[SpecialPermission] SELECT * FROM [VPNDataBase].[dbo].[SpecialPermission]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TPermissionGroup] SELECT * FROM [VPNDataBase].[dbo].[TPermissionGroup]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TInterface] SELECT * FROM [VPNDataBase].[dbo].[TInterface]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TGroupInterface] SELECT * FROM [VPNDataBase].[dbo].[TGroupInterface]
	INSERT INTO [VPNDataBase_Backup].[dbo].[TUserInterface] SELECT * FROM [VPNDataBase].[dbo].[TUserInterface]

	
	COMMIT TRANSACTION BackupDbTrans
	END TRY
	  
	BEGIN CATCH 
		DECLARE @ErrorMessage nvarchar(max), @ErrorSeverity int, @ErrorState int
		select @ErrorMessage = ERROR_MESSAGE(),	@ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE()
		ROLLBACK TRANSACTION BackupDbTrans;
		RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);	
	END CATCH

END
go

