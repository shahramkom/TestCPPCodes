
	create PROCEDURE [dbo].[USP_TGroupInterface_Select]
		-- Add the parameters for the stored procedure here
		@GroupID as int
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

	    -- Insert statements for procedure here
		declare @Statement as nvarchar(1000)
	
		--set @Statement = 'select * from TGroupInterface '
		set @Statement = 'select ti.* from TGroupInterface tgi inner join TInterface ti on (tgi.InterfaceID = ti.InterfaceID) where tgi.GroupID = '
		set @Statement = isnull(@Statement ,'') + convert(nvarchar(50),@GroupID)+ 'order by ti.InterfaceID'
		exec sp_executesql @Statement
	END

  go

