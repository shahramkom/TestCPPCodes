--------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[checkDuplicateVirtualIP]
	@checkVIP		bigint,
	@StartVirtualIpDWORD bigint
AS
BEGIN
	SELECT COUNT(*) FROM TUser  WHERE VirtualIPStatus = 'static' AND VirtualIP IS NOT NULL AND  (VirtualIP = @checkVIP OR @checkVIP = CAST(CAST(VirtualIP as BIGINT)+@StartVirtualIpDWORD AS NVARCHAR(15)) OR @checkVIP = CAST(CAST(VirtualIP as BIGINT)-@StartVirtualIpDWORD AS NVARCHAR(15))  )
END
go

