
    create PROCEDURE [dbo].[USP_TUserGroup_Select]
        -- Add the parameters for the stored procedure here
        @UserID int,
        @GroupID int
    AS
    BEGIN
        SET NOCOUNT ON;

        -- Insert statements for procedure here
        if(@GroupID = -1)
            Select GroupID from TUserGroups where UserID = @UserID order by GPriority
        else if(@UserID = -1)
            select UserID from TUserGroups where GroupID = @GroupID	
    END

    go

