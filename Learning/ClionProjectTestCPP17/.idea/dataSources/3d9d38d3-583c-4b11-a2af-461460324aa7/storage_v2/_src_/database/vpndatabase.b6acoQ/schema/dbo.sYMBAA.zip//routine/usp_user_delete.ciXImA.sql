CREATE PROCEDURE [dbo].[USP_User_Delete]

	@UserID varchar(max),
	@DeleteTUserKeyA BIT = 1

AS
BEGIN	
	IF (EXISTS (SELECT UserID FROM TNewPolicyUserAssign WHERE UserID IN (SELECT CAST(items AS BIGINT) from dbo.Splitfn(@UserID , ','))))
		BEGIN
		RAISERROR('Policies have been assigned to this user. Please deassign it first.', 16 , 1 )	
			RETURN
		END
		ELSE
		BEGIN
			BEGIN TRAN
			
				DECLARE CursDeletedUsers CURSOR FAST_FORWARD FOR 
				SELECT items FROM dbo.splitfn(@UserID,',')
				OPEN CursDeletedUsers

				DECLARE @DeletedUserID varchar(30)
				SET @DeletedUserID = ''

				FETCH NEXT FROM CursDeletedUsers INTO @DeletedUserID

				WHILE @@FETCH_STATUS=0
				BEGIN
					DECLARE @GID AS VARCHAR(25)
					SET @GID = dbo.GenerateNewGID(@DeletedUserID) 
					Update TUserGroups SET GID = @GID WHERE UserID = @DeletedUserID
					FETCH NEXT FROM CursDeletedUsers INTO @DeletedUserID
				END

				CLOSE CursDeletedUsers
				DEALLOCATE CursDeletedUsers

				declare @Statement as nvarchar(max)
				IF(@DeleteTUserKeyA = 1)
				BEGIN
					set @Statement = 'DELETE FROM TUserKeya  WHERE UserID IN( ' + @UserID + ')'
					exec sp_executesql @Statement
					set @Statement = 'DELETE from TUserDNS where UserID IN( ' + @UserID + ')'
					exec sp_executesql @Statement
					set @Statement = 'DELETE from TUserPolicySet where UserID IN( ' + @UserID + ')'
					exec sp_executesql @Statement	
					set @Statement = 'DELETE from TUserscripts where UserID IN( ' + @UserID + ')'
					exec sp_executesql @Statement
					set @Statement = 'DELETE from TUserTimeSet where UserID IN( ' + @UserID + ')'
					exec sp_executesql @Statement
					set @Statement = 'DELETE from TUserInterface where UserID IN( ' + @UserID + ')'
					exec sp_executesql @Statement
				END
				set @Statement = 'DELETE from TUserGroups where UserID IN( ' + @UserID + ')'
				exec sp_executesql @Statement
				set @Statement = ' Delete from Tuser Where UserID in ( '+ @UserID+')'

				exec sp_executesql @Statement
			COMMIT TRAN
		END
END
/******************************************************************************************************************************************************/-----------------------------
go

