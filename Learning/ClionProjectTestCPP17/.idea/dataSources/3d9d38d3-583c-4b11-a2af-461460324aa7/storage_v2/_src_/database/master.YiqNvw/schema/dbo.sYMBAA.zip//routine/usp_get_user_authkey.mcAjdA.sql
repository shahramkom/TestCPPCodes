
    CREATE PROCEDURE  [dbo].[USP_Get_User_AuthKey]
        @UserID	 int
    
    AS
    BEGIN
        declare @EncAuthKey nvarchar(64)	
    
        begin try
            DROP TABLE #Table
        end try
        begin catch	
        end catch

        create table #Table(
            CommandLine nvarchar(200),
            Param1		nvarchar(200),
            [Output]	nvarchar(64)
        )

        select @EncAuthKey = AuthenticationKey from TUser where UserID =@UserID
        insert #Table EXEC Master..XYRunProc 'Decrypt' ,@EncAuthKey
        select [Output] AS UserAuthKey from #Table where CommandLine='Decrypt' 
        drop table #Table
    END

    go

