/******************************************************************************************************************************************************/

CREATE FUNCTION dbo.IsGroupRecordReplicatable(@GroupID INT, @ParentID INT)
	RETURNS @OutputValues TABLE( IsGroupExecutable BIT NOT NULL, ReplicateParentID VARCHAR(30) NULL)
AS
BEGIN
	DECLARE @IsGroupExecutable BIT
	DECLARE @ReplicateParentID VARCHAR(30)
	DECLARE @GroupIDs VARCHAR(MAX)
	SET @IsGroupExecutable = 0
	SET @GroupIDs = @GroupID
	SELECT @GroupIDs = @GroupIDs + ',' + ISNULL(dbo.GetGroupParents(@ParentID), '0')
	SELECT @ReplicateParentID = RepGroupID from RepServersGroups WHERE RepGroupID IN (SELECT items FROM dbo.Splitfn(@GroupIDs,','))
	IF(@ReplicateParentID > 0)
		SET @IsGroupExecutable = 1
	INSERT INTO @OutputValues VALUES(@IsGroupExecutable, @ReplicateParentID)
	RETURN
END
go

