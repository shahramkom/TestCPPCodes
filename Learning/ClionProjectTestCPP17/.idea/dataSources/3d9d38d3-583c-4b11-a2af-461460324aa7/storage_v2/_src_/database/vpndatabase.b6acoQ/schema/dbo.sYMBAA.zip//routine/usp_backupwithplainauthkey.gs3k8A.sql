
    --				<Then backup Database and after perform Database Encrypt DataBase>
    CREATE PROCEDURE  [dbo].[USP_BackupwithPlainAuthKey] 
        -- Add the parameters for the stored procedure here
     
     
        AS
    BEGIN
            -- SET NOCOUNT ON added to prevent extra result sets from
            -- interfering with SELECT statements.
            SET NOCOUNT ON;
        declare @tempAuthkey nvarchar(64)
        declare @UserID int 
        begin try
            DROP TABLE [dbo].[BackupPlainAuthTUser]
        end try
        begin catch	
        end catch
        CREATE TABLE [dbo].[BackupPlainAuthTUser](
        [UserID] [int] ,
        [AuthenticationKey] [nvarchar](64) NULL
        )
        INSERT INTO [dbo].[BackupPlainAuthTUser]  ([UserID], [AuthenticationKey])
           SELECT [UserID], [AuthenticationKey]
           FROM TUser
            -- Insert statements for procedure here
        
            DECLARE UserID_cursor CURSOR FAST_FORWARD READ_ONLY FOR 
            select  UserID from  TUser 		

        OPEN UserID_cursor

        FETCH NEXT FROM UserID_cursor
        into @UserID

        if @@FETCH_STATUS != 0
        begin
            close UserID_cursor
            DEALLOCATE UserID_cursor  
            return	
        end
        WHILE @@FETCH_STATUS = 0
        BEGIN
        
            exec Set_DecryptAuthKey_tempUser @UserID 
        
            FETCH NEXT FROM UserID_cursor
            into @UserID
        END
        close UserID_cursor
        DEALLOCATE UserID_cursor

    END


    go

