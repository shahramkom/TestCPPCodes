
CREATE PROCEDURE [dbo].[USP_Select_Users_FromPSID]
        @PSID as bigint
        AS
BEGIN
 SELECT        dbo.TUser.UserID, dbo.TUser.UserName
FROM            dbo.TPolicySet INNER JOIN
                         dbo.TUserPolicySet ON dbo.TPolicySet.PSID = dbo.TUserPolicySet.PSID INNER JOIN
                         dbo.TUser ON dbo.TUserPolicySet.UserID = dbo.TUser.UserID
WHERE        (dbo.TPolicySet.PSID = @PSID)
END
go

