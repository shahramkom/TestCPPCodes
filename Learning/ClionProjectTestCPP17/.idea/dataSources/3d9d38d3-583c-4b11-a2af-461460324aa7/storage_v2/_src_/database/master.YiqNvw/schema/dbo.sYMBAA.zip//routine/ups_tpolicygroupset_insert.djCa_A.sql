


    CREATE PROCEDURE [dbo].[UPS_TPolicyGroupSet_Insert] 
        -- Add the parameters for the stored procedure here
        @groupID int , 
        @policySetID int
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        --SET NOCOUNT ON;

        -- Insert statements for procedure here
            
            declare @Prty as int
            select @Prty = max(PriorityOrder) from TGroupPolicySet where GroupID = @groupID
            if(@Prty is NULL)
                insert into TGroupPolicySet values(@groupID,@policySetID,1)
            else
            begin
                set @Prty = @Prty +1
                insert into TGroupPolicySet values(@groupID,@policySetID,@Prty)
            end
    END

    go

