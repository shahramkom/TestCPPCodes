
    
    CREATE PROCEDURE  [dbo].[USP_USER_FILTER]
    
        @UserID		bigint			= NULL ,	
        @UserName nvarchar(200)		= NULL , 
        @LastName nvarchar(200)		= NULL ,
        @AccountDisable tinyInt		= NULL ,
        @GroupID	int				= NULL ,	
        @BindingStatus nvarchar(50)	= NULL , 
        @BindingPCID nvarchar(100)	= NULL ,
        @VirtualIPStatus nvarchar(50)=NULL ,	
        @VirtualIP	   nvarchar(15)	= NULL ,
        @Owner		int				= NULL ,
        @UserPerm   int				= NULL ,	
        @GroupIdList nvarchar(max)  = Null
    AS
    begin
        DECLARE @SpecialpermGID as int	
        declare @miniType		as int 
        DECLARE @PemId			as int
        declare @filter			as nvarchar(max)
        DECLARE @selectFields	as nvarchar(max)
        
        SELECT @SpecialPermGID = GroupID FROM TGroup WHERE GroupName = 'Special Users'
        if (@UserPerm is NULL OR  @UserPerm = 1 )
        BEGIN 
            set @SpecialPermGID = 0
        END	
        else
        begin
            select @PemId = Permission_ID from Tuser where UserID = @UserPerm
            select @miniType = MiniAdminType from SpecialPermission where ID = @PemId
        end
-----------------------fill conditions list up-----------------------------------------
        if(@UserID  is not NULL)
            set @filter = isnull(@filter ,'') +  '(TU.UserID = ' + isnull(cast(@UserID as nvarchar(100)) , '') +')AND' 
        if(@UserName is  not NULL)
            set @filter = isnull(@filter ,'') +  '(TU.UserName  LIKE N'''+'%' + isnull(cast(@UserName as nvarchar(100)) , '')+'%'')AND' 
        if(@GroupID is  not NULL)
        begin
            set @filter = isnull(@filter ,'') +  '(TU.UserID in (select UserID from TUserGroups where GroupID =' 
            + isnull(cast(@GroupID as nvarchar(100)) , '') +'))AND' 
        end
        if(@GroupID is null)
            if(@UserPerm = 1)
                set @filter = isnull(@filter ,'') +  '(TU.UserID in( select UserID from TUser ))AND' 
            else if(@miniType = 1)--powered mini admin
            begin
                set @filter = isnull(@filter ,'') +  
                '(TU.UserID in(select UserID from TUser where UserID not in (select UserId from TuserGroups where GroupID = ' 
                + isnull(cast(@SpecialPermGID as nvarchar(100)) , '') +')))AND' 
            end
            else if(@miniType = 2 and @GroupIdList is not NULL)--limited mini admin
                set @filter = isnull(@filter ,'') +  
                '(TU.UserID in(select UserID from TUser where UserID in (select UserId from TuserGroups where GroupID in( ' 
                + isnull(cast(@GroupIdList as nvarchar(max)) , '') +'))))AND' 
                    
        if(@BindingStatus is  not NULL)
            set @filter = isnull(@filter ,'') +  '(TU.BindingStatus LIKE N'''+'%' + isnull(cast(@BindingStatus as nvarchar(100)) , '') +'%'')AND' 
        if(@BindingPCID is  not NULL)
            set @filter = isnull(@filter ,'') +  '(TU.BindingPCID LIKE N'''+'%' + isnull(cast(@BindingPCID as nvarchar(100)) , '') +'%'')AND'  
        if(@VirtualIPStatus is  not NULL)
            set @filter = isnull(@filter ,'') +  '(TU.VirtualIPStatus = ''' + isnull(cast(@VirtualIPStatus as nvarchar(100)) , '') +''')AND' 
        if(@VirtualIP is  not NULL)
            set @filter = isnull(@filter ,'') +  '(TU.VirtualIP = ''' + isnull(cast(@VirtualIP as nvarchar(100)) , '') +''')AND' 
        if(@AccountDisable is  not NULL)
            set @filter = isnull(@filter ,'') +  '(TU.AccountDisable = ' + isnull(cast(@AccountDisable as nvarchar(100)) , '') +')AND' 
        if(@LastName is  not NULL)
            set @filter = isnull(@filter ,'') +  '(TU.LastName LIKE N'''+'%' + isnull(cast(@LastName as nvarchar(100)) , '') +'%'')AND' 
        if(@Owner is  not NULL)
            set @filter = isnull(@filter ,'') +  '(TU.[Owner] = ' + isnull(cast(@Owner as nvarchar(100)) , '') +')AND' 
        
        if(substring(@filter , LEN(@filter)-2 , LEN(@filter))= 'AND')
            set @filter = substring(@filter , 0 , LEN(@filter) - 2)
        if(@miniType = 2 and @GroupIdList is NULL)
            set @filter = NULL
    ------------------------fill selection List Up-------------------------------------------
        set @selectFields = isnull(@selectFields ,'') +  'distinct UserID,UserName,BindingStatus,BindingPCID ,IPBindingStatus, 
        SubNetIP,SubNetMask,VirtualIPStatus,VirtualIP,UserPIN,MasterPIN,AuthenticationKey,MustChangePIN,AccountDisable,
        RejOnKeepAliveFail,ShowUserPrivilege,FirstName,LastName,Gender,Company,Office,Province,Town,Notes,Email,Cell,PersonnelCode,Phone,
		NationalID,Adress,PostalCode,Owner,Permission_ID,UnBlockPIN ,AuthType,CertType,CertValue ,dbo.RetrieveGroupNames(UserID) as GroupNames,
		dbo.RetrievePSNames(UserID)as UserPolicies,dbo.RetrieveInterfaceNames(UserID) as InterfaceNames,InterfaceBindingStatus,
		LoginType,LockModule,ExpireDate,VersionBindingStatus,BindingVersion,CreateTime,LastModifiedTime,LastConnectedIP,DisableModernPolicy,Version, DriverType, DisableResult'
        DECLARE @LastStmnt as nvarchar(max)

		SET @LastStmnt = 'select '+ @selectFields+' FROM TUser as TU'
		--if @filter is null -> @LastStmnt+NULL = NULL
		if(@filter is Not NULL)
		BEGIN
            SET @LastStmnt = @LastStmnt +' where ' +@filter
										+'order by UserName asc' 
		END
        exec sp_executesql @LastStmnt
    END

    go

