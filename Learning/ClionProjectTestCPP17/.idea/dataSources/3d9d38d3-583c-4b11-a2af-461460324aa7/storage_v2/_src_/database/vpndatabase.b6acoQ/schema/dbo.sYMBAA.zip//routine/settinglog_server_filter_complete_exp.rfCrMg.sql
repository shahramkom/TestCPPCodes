
    CREATE PROCEDURE [dbo].[SETTINGLOG_SERVER_FILTER_COMPLETE_EXP] 
        -- Add the parameters for the stored procedure here
            @L_managerID int=NULL,
            @L_startDate nvarchar(10)=NULL,
            @L_startTime nvarchar(8)=NULL,	
            @L_endDate   nvarchar(10)=NULL,
            @L_endTime   nvarchar(8)=NULL,
            @L_LogType  nvarchar(50)=NULL,	
            @L_DateTime	 nvarchar(50)=NULL,
            @L_Interface nvarchar(50)=NULL,
            @L_Gateway   nvarchar(50)=NULL,
            @L_ServersNeighbor nvarchar(50)=NULL,
            @L_PATIP	nvarchar(50)=NULL,
            @L_Routing	nvarchar(50)=NULL,
            @L_Replication nvarchar(50)=NULL
    AS
      SET NOCOUNT ON
      declare @filter nvarchar(max)
      if (@L_managerID is not null)
        set @filter = isnull(@filter ,'') +  '(userID = ' + isnull(cast(@L_managerID as nvarchar(100)) , '') +')AND' 
    if (@L_logType is not null)	
        set @filter = isnull(@filter ,'') +  '(logType = '''+@L_logType+''')AND'	

    if (@L_startDate = @L_endDate)	
        set @filter = isnull(@filter ,'') +  '(operationDate = '''+@L_startDate+''' AND operationTime >= '''+ @L_startTime+''' AND operationTime <= '''+@L_endTime+''')AND'
    else
        set @filter = isnull(@filter ,'') +  '(((operationDate > '''+@L_startDate+''') AND (operationDate < '''+ @L_endDate  +''')) OR ((operationDate = '''+@L_startDate + ''' AND operationTime >= '''+ @L_startTime+''' )) OR '
            + ' ((operationDate = '''+@L_endDate + ''' AND operationTime <= '''+ @L_endTime+''' )))AND'

    if(@L_DateTime is not null OR @L_Interface is not null OR @L_Gateway is not null OR  @L_ServersNeighbor is not null  OR @L_PATIP is not null OR @L_Routing is not null )
    begin
        set @filter = isnull(@filter ,'')+ '('
        if (@L_DateTime is not null)
            set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_DateTime +''')OR'
        if (@L_Interface is not null)
            set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_Interface +''')OR'
        if (@L_Gateway is not null)
            set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_Gateway +''')OR'
        if (@L_ServersNeighbor is not null)
            set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_ServersNeighbor +''')OR'	
        if (@L_PATIP is not null)
            set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_PATIP +''')OR'
        if (@L_Routing is not null)
            set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_Routing +''')OR'
    if (@L_Replication is not null)
        set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_Replication +''')OR'
        set @filter = substring(@filter , 0 , LEN(@filter) - 1)			
        set @filter = isnull(@filter ,'')+ ')'
    end	
    else 
        set @filter = substring(@filter , 0 , LEN(@filter) - 2)	
      select @filter
       declare 	@datasrc nvarchar(200)
       set 	@datasrc = ' settingServerLog '	
       declare @orderBy nvarchar(200)
       set @orderBy = ' operationDate, operationTime DESC ' 
 
    declare  @fieldlist nvarchar(200) 
    set @fieldlist= ' operationDate as Date,operationTime as Time,userID as MangerID,logType,operationType,logEvent,rowID,decription '
     DECLARE
         @STMT nvarchar(max)         -- SQL to execute

     IF LTRIM(RTRIM(@filter)) = '' SET @filter = '1 = 1'
        SET @STMT =  'SELECT   ' + @fieldlist + 
                     'FROM     ' + @datasrc +
                     'WHERE    ' + @filter + 
                     'ORDER BY ' + @orderBy
              
         EXEC (@STMT)                 -- return requested records 


    go

