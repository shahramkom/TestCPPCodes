
    CREATE PROCEDURE [dbo].[UPS_ServerAccessPolicy_Disable]

       @PolicyID int      
   
    AS
    BEGIN
        
	declare @lastModifyDateTime as nvarchar(20)
	select @lastModifyDateTime = CONVERT(nvarchar(20),GETDATE(),20)	
        
    declare @status bit 
    select @status = status from TServerAccessPolicy where PolicyID= @PolicyID
    if (@status is not null AND @status = 0)
		Update TServerAccessPolicy set status = 1 , LastModifiedTime = @lastModifyDateTime where PolicyID= @PolicyID 
	else
		Update TServerAccessPolicy set status = 0 , LastModifiedTime = @lastModifyDateTime where PolicyID= @PolicyID 

    END

    go

