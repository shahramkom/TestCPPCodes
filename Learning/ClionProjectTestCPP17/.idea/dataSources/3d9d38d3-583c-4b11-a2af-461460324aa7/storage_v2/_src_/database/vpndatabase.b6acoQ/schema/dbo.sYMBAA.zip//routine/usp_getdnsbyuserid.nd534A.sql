CREATE PROCEDURE [dbo].[USP_GetDNSByUserID] 
	@UserID bigint
AS
BEGIN
	select HostName,IP from TDNS inner Join TUserDNS on TDNS.DNSID = TUserDNS.DNSID where TUserDNS.UserID = @UserID
END
go

