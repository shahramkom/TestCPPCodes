
  CREATE PROCEDURE [dbo].[USP_TNewPoliciesUsrModernPol_Insert] 
        -- Add the parameters for the stored procedure here
        @ModernPolicyID int,
        @UserNameList nvarchar(max)
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
        declare @UserName as nvarchar(50)
        declare @UserID as int
        declare @priority as int
        set @priority = 1
        
        declare policy_CursorUser cursor for 
        SELECT * FROM dbo.Splitfn(@UserNameList,',')
        
        open policy_CursorUser
        fetch next from policy_CursorUser into @UserName
        
        while @@FETCH_STATUS = 0
        begin
        if( NOT(@UserName = 'UseRs:AnY' OR @UserName = 'Any User'))
		BEGIN
			select @UserID = UserID from TUser where UserName = @UserName
        
			INSERT INTO [dbo].[TNewPolicyUserAssign]
			   ([UserID],[ModernPID],[PriorityOrder])
			VALUES
			   (@UserID ,@ModernPolicyID  , @priority )
        
			set @priority = @priority + 1
        END
        fetch next from policy_CursorUser into @UserName
        end
        close policy_CursorUser
        DEALLOCATE policy_CursorUser
    END

  go

