CREATE PROCEDURE [dbo].[USP_UpdateLastConnectedIPOfUser] 
	@LastLoginIP varchar(20),
	@UserID bigint
AS
BEGIN
	UPDATE TUser SET LastConnectedIP = @LastLoginIP WHERE UserID = @UserID
END
go

