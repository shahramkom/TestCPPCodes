CREATE PROCEDURE [dbo].[USP_UpdateChangePINStatusOfUser] 
	@changePIN bit,
	@UserID bigint
AS
BEGIN
	Update TUser set MustChangePIN = @changePIN where UserID = @UserID
END
go

