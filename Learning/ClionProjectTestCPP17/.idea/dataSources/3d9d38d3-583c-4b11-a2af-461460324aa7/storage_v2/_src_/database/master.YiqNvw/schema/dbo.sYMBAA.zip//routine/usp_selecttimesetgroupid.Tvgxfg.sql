
    Create PROCEDURE [dbo].[USP_SelectTimeSetGroupID]
    @GroupID int
    with recompile
    AS
    BEGIN	
        select tr.* from TTimeRole as tr right join  TGroupTimeSet as gtr on tr.TRID = gtr.TRID where GroupID =@GroupID
        order by PriorityOrder
    END

    go

