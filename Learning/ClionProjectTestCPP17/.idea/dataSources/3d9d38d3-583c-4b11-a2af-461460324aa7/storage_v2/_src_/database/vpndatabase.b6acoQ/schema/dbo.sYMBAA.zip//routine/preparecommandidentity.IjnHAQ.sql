/******************************************************************************************************************************************************/--
CREATE FUNCTION dbo.PrepareCommandIdentity(@Command NVARCHAR(MAX),@ActionType VARCHAR(50) ,@TableName VARCHAR(50))
RETURNS NVARCHAR(MAX)
BEGIN
	IF(@ActionType = 'Insert-TGroup' OR 
	   @ActionType = 'Insert-TPolicySet' OR
	   @ActionType = 'Insert-TScript' OR
	   @ActionType = 'Insert-TTimeRole' OR
	   @ActionType = 'Insert-TDNS' OR
	   @ActionType = 'Insert-TServerAccessPolicy' OR
	   @ActionType = 'Insert-TUserFirewallPolicy' OR
	   @ActionType = 'Insert-SpecialPermission'  OR
	   @ActionType = 'Insert-TInterface' ) 
		SET @Command = 'SET IDENTITY_INSERT ' + @TableName + ' ON ' + @Command + ' SET IDENTITY_INSERT ' + @TableName + ' OFF'
	RETURN @Command
END
go

