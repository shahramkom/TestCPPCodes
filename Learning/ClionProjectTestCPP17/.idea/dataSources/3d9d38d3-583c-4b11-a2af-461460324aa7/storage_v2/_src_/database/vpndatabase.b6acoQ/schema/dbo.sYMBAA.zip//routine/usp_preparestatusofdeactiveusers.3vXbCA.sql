
   CREATE PROCEDURE [dbo].[USP_PrepareStatusOfDeactiveUsers]
	@serverName as varchar(32)
AS
    BEGIN
	    DECLARE @CurrentDate AS NVARCHAR(10)
		SELECT  @CurrentDate = CONVERT(NVARCHAR(10),GETDATE(),20)
		DECLARE @CurrentTime AS NVARCHAR(10)
		SELECT  @CurrentTime = CONVERT(VARCHAR(8),GETDATE(),108) 
		
		Declare @MaxDeActiveUser as nvarchar(10)
		SELECT  @MaxDeActiveUser = [value] from tsetting where [property] = 'MaxDeActiveUserDays'
		if(@MaxDeActiveUser is null)
			SET @MaxDeActiveUser = '15'
			
		DECLARE @UserID   AS VARCHAR(10)
		DECLARE @UserName AS NVARCHAR(100)
		DECLARE @UserFN   AS NVARCHAR(100)
		DECLARE @UserLN   AS NVARCHAR(100)
		DECLARE User_Cursor CURSOR FOR SELECT UserID,UserName,FirstName,LastName  from tuser where(	datediff(day, convert(varchar(10), lastlogintime,120),convert(varchar(10), GETDATE(),120) ) >= cast(@MaxDeActiveUser as int) )
		open User_Cursor
		fetch next from User_Cursor into @UserID,@UserName,@UserFN,@UserLN
		while @@FETCH_STATUS = 0
		begin
		if(@UserID is not null)
		begin
			DECLARE @UserGroupsNames as nvarchar(max) 
			exec USP_GetUserAllGroupsName @UserID , @UserGroupsNames OUTPUT
			UPDATE tuser SET AccountDisable = 5, DisableResult= 'User has been diabled because inactive more time.'  where userid = @UserID
			DECLARE @LogEvent AS VARCHAR(300)
			SET     @LogEvent = 'serverModuleName='+@serverName+';userID='+CAST(@UserID AS VARCHAR(20))+';UserName='+@UserName+''
			DECLARE @RowID as nvarchar(500)
			SET @RowID = 'FirstName='+isnull( @UserFN , '') +';LastName='+isnull(@UserLN,'')+';groupName='+isnull(@UserGroupsNames,'')+';userStatus=Disable by system because inactive'
			EXEC UPS_Insert_logs_Manger 1,
					'Table',
					'UPDATE',
					'User',					
					@LogEvent,
					@RowID, 
					@CurrentDate,
					@CurrentTime
			
		end
		fetch next from User_Cursor into @UserID,@UserName,@UserFN,@UserLN
		end
		CLOSE User_Cursor;	
		DEALLOCATE User_Cursor;
END

   go

