CREATE PROCEDURE [dbo].[USP_GetDNSByGroupID] 
	@GroupID int
AS
BEGIN
	select HostName,IP from TDNS inner Join TGroupDNS on TDNS.DNSID = TGroupDNS.DNSID where TGroupDNS.GRoupID = @GroupID
END
go

