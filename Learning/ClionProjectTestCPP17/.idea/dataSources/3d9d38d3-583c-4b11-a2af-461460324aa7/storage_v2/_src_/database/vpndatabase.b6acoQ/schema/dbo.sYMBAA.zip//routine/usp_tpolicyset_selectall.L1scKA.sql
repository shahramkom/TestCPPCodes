
    CREATE PROCEDURE  [dbo].[USP_TPolicySet_SelectAll]
        
    AS
    BEGIN
        --SET NOCOUNT ON;
        select * from TPolicySet

    END

    go

