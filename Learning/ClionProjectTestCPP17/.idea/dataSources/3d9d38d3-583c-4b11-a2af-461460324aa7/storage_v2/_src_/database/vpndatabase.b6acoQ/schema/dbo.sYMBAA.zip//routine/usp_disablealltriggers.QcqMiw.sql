/******************************************************************************************************************************************************/-------------------------------
CREATE Procedure USP_DisableAllTriggers
AS
BEGIN
	DISABLE TRIGGER [dbo].[trgTUser]                  ON TUser;
	DISABLE TRIGGER [dbo].[trgTUserGroup]			  ON TUserGroups;
	DISABLE TRIGGER [dbo].[trgTGroup]				  ON TGroup;
	DISABLE TRIGGER [dbo].[trgTUserKeyA]			  ON TUserKeya;
	DISABLE TRIGGER [dbo].[trgSpecialPermission]	  ON SpecialPermission;
	DISABLE TRIGGER [dbo].[trgTPermissionGroup]		  ON TPermissionGroup;
	DISABLE TRIGGER [dbo].[trgTUserPolicySet]		  ON TUserPolicySet;
	DISABLE TRIGGER [dbo].[trgTGroupPolicySet]		  ON TGroupPolicySet;
	DISABLE TRIGGER [dbo].[trgTPolicySet]			  ON TPolicySet;
	DISABLE TRIGGER [dbo].[trgTServerAccessPolicy]    ON TServerAccessPolicy;
	DISABLE TRIGGER [dbo].[trgTUserFirewallPolicy]	  ON TUserFirewallPolicy;
	DISABLE TRIGGER [dbo].[trgTGroupScript]			  ON TgroupScript;
	DISABLE TRIGGER [dbo].[trgTScript]				  ON TScript;
	DISABLE TRIGGER [dbo].[trgTUserScript]			  ON TUserScripts;
	DISABLE TRIGGER [dbo].[trgTUserTimeSet]			  ON TUserTimeSet;
	DISABLE TRIGGER [dbo].[trgTGroupTimeSet]		  ON TgroupTimeset;
	DISABLE TRIGGER [dbo].[trgTTimeRole]			  ON TTimeRole;
	DISABLE TRIGGER [dbo].[trgTUserDNS]				  ON TUserDNS;
	DISABLE TRIGGER [dbo].[trgTGroupDNS]			  ON TgroupDNS;
	DISABLE TRIGGER [dbo].[trgTDNS]                   ON TDNS;
END
go

