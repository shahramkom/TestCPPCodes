CREATE PROCEDURE [dbo].[USP_GetReplicatedGroups] 
AS
BEGIN	
	SET NOCOUNT ON;
	SELECT dbo.GetAllReplicateGroups() AS GroupIDS
END
go

