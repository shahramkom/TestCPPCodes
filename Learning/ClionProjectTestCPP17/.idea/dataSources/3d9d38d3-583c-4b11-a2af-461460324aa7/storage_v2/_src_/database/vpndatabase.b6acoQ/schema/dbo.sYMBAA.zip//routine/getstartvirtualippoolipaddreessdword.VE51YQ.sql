CREATE FUNCTION dbo.GetStartVirtualIpPoolIpAddreessDWORD()
RETURNS bigint
BEGIN
	DECLARE @StartVirtualIpDWORD AS BIGINT
	DECLARE @StartVirtualIpString AS varchar(20)
	SELECT @StartVirtualIpString  = value from TSetting WHERE Property = 'UserVipPoolIp' 
	SET @StartVirtualIpDWORD = CAST( dbo.[ConvertIP2BigInt](@StartVirtualIpString) AS BIGINT)
	return @StartVirtualIpDWORD
END
go

