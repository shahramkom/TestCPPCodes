-- =============================================
CREATE PROCEDURE [dbo].[USP_Delete_Module_BlockList]
	@serialkeya	nvarchar(13)
AS
BEGIN
	DELETE FROM TModuleBlockList WHERE KeyaSerial = @serialkeya
END

/******************************************************************************************************************************************************/
go

