
    CREATE PROCEDURE [dbo].[USP_GROUP_FILTER]			
	@ManagerID bigint = null,
    @GroupName nvarchar(200) = ''
    AS	
    BEGIN
        if (@ManagerID =1)
               select * from TGroup where GroupName like + '%' + @GroupName + '%' order by GroupName 
        else
        begin
            declare @PermID as int 
            declare @MiniType as int
            select @PermID = Permission_ID from TUser where UserID = @ManagerID	
            select @MiniType = MiniAdminType from  SpecialPermission where ID = @PermID
            if(@MiniType = 1 OR @GroupName != '' )
                select * from TGroup where TGroup.GroupName != 'special users' AND GroupName like + '%' + @GroupName + '%' order by GroupName
            else if(@MiniType = 2 AND @GroupName = '')
            begin
                select * from TGroup where GroupID in( select Group_ID from TPermissionGroup where Permission_ID = @PermID) AND GroupName like + '%' + @GroupName + '%' order by GroupName
                
            end
        end	
    END

    go

