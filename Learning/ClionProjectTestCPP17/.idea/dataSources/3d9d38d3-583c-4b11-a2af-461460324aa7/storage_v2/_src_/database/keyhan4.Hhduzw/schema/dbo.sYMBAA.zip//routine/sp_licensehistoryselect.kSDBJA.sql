CREATE PROCEDURE [dbo].[sp_LicenseHistorySELECT] 
	@ProfileID int
AS
BEGIN
SELECT [ID]
      ,[ProfileID]
      ,[ProgramDate]
      ,[ModuleSerial]
      ,[OnlineUsers]
      ,[TotalUsers]
      ,[Comment]
      ,[Reserve1]
      ,[Reserve2]
  FROM [Keyhan4].[dbo].[ProgramHistory]
  Where ProfileID = @ProfileID
	END
go

