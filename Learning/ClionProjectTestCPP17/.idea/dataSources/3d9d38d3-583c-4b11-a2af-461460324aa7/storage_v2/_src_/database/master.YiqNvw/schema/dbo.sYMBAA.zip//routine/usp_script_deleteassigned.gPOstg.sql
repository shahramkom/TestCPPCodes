

    CREATE PROCEDURE  [dbo].[USP_Script_DeleteAssigned]
        @ScriptID int,
        @GroupID	int
    AS
    BEGIN
        SET NOCOUNT ON;

        DELETE TGroupScript
        WHERE ScriptID = @ScriptID and GroupID = @GroupID 
    END


    go

