
    create procedure [dbo].[USP_EncByKeyA]
        @AuthKey nvarchar(300)
        --returns nvarchar(300)
    as
    begin
        begin try
            DROP TABLE #Table
        end try
        begin catch
        --RAISERROR ('Error raised in TRY block.', 16, 1);
        end catch

        create table #Table(
            CommandLine nvarchar(50),
            Param1		nvarchar(50),
            [Output]	nvarchar(500)
        )
        insert #Table EXEC XYRunProc 'Encrypt' ,@AuthKey
        select [Output] from #Table where CommandLine='Encrypt'
        drop table #Table
    end

    go

