/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_Select_UserUpdateTime] 
    @userID INT
AS
BEGIN
    SELECT LastModifiedTime from TUser WHERE UserID = @userID
END

go

