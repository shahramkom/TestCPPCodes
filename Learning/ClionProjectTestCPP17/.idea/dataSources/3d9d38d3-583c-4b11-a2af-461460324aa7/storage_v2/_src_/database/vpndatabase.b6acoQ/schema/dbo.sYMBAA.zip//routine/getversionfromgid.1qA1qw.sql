/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetVersionFromGID](@GID VARCHAR(25))
RETURNS INT
AS
BEGIN
	DECLARE @version AS VARCHAR(8)
	DECLARE @first AS INT
	DECLARE @second AS INT
	SET @first = CHARINDEX(',', @GID)
	SET @second = CHARINDEX(',', @GID, @first + 1)
	SET @version = SUBSTRING(@GID, @first + 1, @second - @first -1)
	
	RETURN CONVERT(INT, @version)
END
go

