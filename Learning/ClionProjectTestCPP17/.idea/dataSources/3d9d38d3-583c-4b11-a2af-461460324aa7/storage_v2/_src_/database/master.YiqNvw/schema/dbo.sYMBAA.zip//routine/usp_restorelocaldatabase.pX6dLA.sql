
CREATE PROCEDURE [dbo].[USP_RestoreLocalDatabase]
        @backupLocationName nvarchar(1000)
    AS
    BEGIN
		SET NOCOUNT ON;
		DECLARE @sqlCommand NVARCHAR(1000)
		SET @sqlCommand = 'RESTORE DATABASE VPNDataBase FROM DISK = '''+@backupLocationName+ '''  WITH RECOVERY '
		EXEC(@sqlCommand)
	END
go

