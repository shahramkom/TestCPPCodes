/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetTableDeleteQuery]( @TableName varchar(100), @IDFieldName varchar(100), @IDFieldValue int)
		RETURNS varchar(MAX)
AS
BEGIN
		DECLARE @CommandStr nvarchar(MAX)
		SET @CommandStr ='DELETE FROM ' +@TableName+ ' WHERE '+ @IDFieldName +' = ' + CAST(@IDFieldValue AS VARCHAR(20))+''
		return @CommandStr
END
go

