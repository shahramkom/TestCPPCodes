



    CREATE PROCEDURE [dbo].[USP_TDNS_FilterDNSID]
    @HostName nvarchar(300)

    AS
    BEGIN	
        select DNSID from TDNS where HostName = @HostName
    END

    go

