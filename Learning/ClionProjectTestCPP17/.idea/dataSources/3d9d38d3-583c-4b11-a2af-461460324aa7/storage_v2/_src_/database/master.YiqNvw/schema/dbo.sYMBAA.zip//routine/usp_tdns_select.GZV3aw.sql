
    Create PROCEDURE [dbo].[USP_TDNS_Select]
    @GroupID int
    with recompile
    AS
    BEGIN	
        select * from TDNs where DNSID in
            (select DNSID from TGroupDNS where GroupID = @GroupID)
    END

    go

