CREATE PROCEDURE [dbo].[sp_ProgramLicenseSearch]
	@LicenseID varchar(13),
	@isAdmin bit = false
AS
BEGIN
	if(@isAdmin = 1)
		SELECT dbo.ProfileSetting.* FROM dbo.ProfileSetting INNER JOIN dbo.ProgramLicense ON dbo.ProfileSetting.Code = dbo.ProgramLicense.ProfileID
			WHERE dbo.ProgramLicense.LicenseID = @LicenseID
	else
		SELECT dbo.ProfileSetting.* FROM dbo.ProfileSetting INNER JOIN dbo.ProgramLicense ON dbo.ProfileSetting.Code = dbo.ProgramLicense.ProfileID
			WHERE (dbo.ProgramLicense.LicenseID = @LicenseID AND dbo.ProfileSetting.isVisible = 1)
END
go

