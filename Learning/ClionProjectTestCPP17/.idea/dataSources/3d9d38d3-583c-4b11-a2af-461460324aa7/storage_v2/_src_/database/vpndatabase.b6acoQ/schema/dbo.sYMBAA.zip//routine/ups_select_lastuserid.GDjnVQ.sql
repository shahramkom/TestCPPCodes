/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[UPS_Select_LastUserID] 
AS
BEGIN
    SELECT TOP 1 UserID, GID from TUser Order by UserID desc
END
go

