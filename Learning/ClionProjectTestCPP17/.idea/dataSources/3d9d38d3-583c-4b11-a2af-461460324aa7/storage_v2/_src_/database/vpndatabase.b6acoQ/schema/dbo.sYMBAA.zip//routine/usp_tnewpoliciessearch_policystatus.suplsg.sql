
	Create PROCEDURE [dbo].[USP_TNewPoliciesSearch_PolicyStatus] 
		@status nvarchar(10)
	AS
	BEGIN
		if (@status = 'Enable')
			SELECT * ,dbo.SelModernPolGroupsUsers(MP.ID)AS Assignments
   FROM [dbo].[TNewPolicyMainTable] AS MP   WHERE MP.Enablity = 1
			ORDER BY ApplyTime DESC ,PolicyOrder ASC
		else if (@status = 'Disable')
			SELECT * ,dbo.SelModernPolGroupsUsers(MP.ID)AS Assignments
   FROM [dbo].[TNewPolicyMainTable] AS MP  WHERE MP.Enablity = 0
			ORDER BY ApplyTime DESC ,PolicyOrder ASC
		else
			exec USP_TNewPolicyMain_Select
	END

  go

