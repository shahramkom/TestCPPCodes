
    CREATE  PROCEDURE  [dbo].[USP_USER_KEYA_FILTER]
    
        @UserID	int

    AS
    BEGIN
    SELECT  KeyASerial AS ModuleSerial,[Date] FROM  TUserKeya WHERE UserID= @UserID	
    END

    go

