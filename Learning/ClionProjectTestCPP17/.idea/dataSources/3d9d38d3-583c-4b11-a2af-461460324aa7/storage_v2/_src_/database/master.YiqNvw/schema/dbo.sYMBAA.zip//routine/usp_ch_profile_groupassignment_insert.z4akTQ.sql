CREATE PROCEDURE [dbo].[USP_CH_Profile_GroupAssignment_Insert]
 @CHP_ProfileID			int,
 @CHP_Groups 			nvarchar(max)
    AS
    BEGIN
        SET NOCOUNT ON;
        declare @GroupName as nvarchar(50)
        declare @GroupID as int
        declare CH_CursorGroup cursor for 
        SELECT * FROM dbo.Splitfn(@CHP_Groups,',')
        open CH_CursorGroup
        fetch next from CH_CursorGroup into @GroupName
        while @@FETCH_STATUS = 0
        begin
        select @GroupID = GroupID from TGroup where GroupName = @GroupName
        INSERT INTO [dbo].[HealthCheckGroupAssign]([GroupID],[ProfileID])VALUES(@GroupID ,@CHP_ProfileID)
        fetch next from CH_CursorGroup into @GroupName
        end
        close CH_CursorGroup
        DEALLOCATE CH_CursorGroup
    END
go

