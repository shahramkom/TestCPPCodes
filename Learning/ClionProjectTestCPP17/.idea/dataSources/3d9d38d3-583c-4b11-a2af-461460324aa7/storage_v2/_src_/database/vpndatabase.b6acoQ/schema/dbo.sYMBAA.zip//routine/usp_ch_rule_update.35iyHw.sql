CREATE PROCEDURE [dbo].[USP_CH_Rule_Update]
    @CHR_RuleID				int,
    @CHR_Name				nvarchar(50)   = NULL,
    @CHR_Category			tinyint		   = NULL,
    @CHR_Action				tinyint 	   = 0,
	@CHR_ActionParameter	nvarchar(500)  = NULL,
	@CHR_RuleType		 tinyint = 0
AS
BEGIN
    SET NOCOUNT ON;
    declare @nTotalRules int
    select @nTotalRules=Count(*) from HealthCheckRules where (([Name] = @CHR_Name) and (RuleID<>@CHR_RuleID))
    if (@nTotalRules>0)
    begin
        Raiserror ('Health check rule name already exists.', 16 , 10)
        return
    end
    UPDATE [VPNDataBase].[dbo].[HealthCheckRules]
	SET [Name] = @CHR_Name
      ,[Category] = @CHR_Category
      ,[Action] = @CHR_Action
      ,[ActionParameter] = @CHR_ActionParameter
	  ,[RuleType] =	@CHR_RuleType
	WHERE RuleID = @CHR_RuleID
End
go

