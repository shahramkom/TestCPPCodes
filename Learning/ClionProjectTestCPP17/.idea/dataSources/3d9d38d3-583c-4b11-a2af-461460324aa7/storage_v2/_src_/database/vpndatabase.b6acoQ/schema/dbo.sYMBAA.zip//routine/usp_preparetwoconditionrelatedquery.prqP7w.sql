/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_PrepareTwoConditionRelatedQuery]
	@ActionType varchar(20),
	@TableName varchar(20),
	@IDFieldName varchar(25),
	@IDFieldValue int,
	@SecondIdFieldName varchar(20) = NULL,
	@SecondIdFieldValue varchar(50) = NULL,
	@SecondIdFieldOldValue varchar(50) = NULL,
	@ReturnCommand nvarchar(MAX) OUTPUT
	AS
	BEGIN
		DECLARE @Query nvarchar(MAX)
		IF(@ActionType = 'Insert')
			SET @Query = dbo.GetTwoConditionInsertQuery( @TableName, @IDFieldName, @IDFieldValue, @SecondIdFieldName, @SecondIdFieldValue )
		ELSE IF(@ActionType = 'Update')
			SET @Query = dbo.GetTwoConditionUpdateQuery( @TableName, @IDFieldName, @IDFieldValue, @SecondIdFieldName, @SecondIdFieldValue )
		ELSE IF(@ActionType = 'Delete')
		BEGIN
			SET @Query = dbo.GetTwoConditionDeleteQuery( @TableName, @IDFieldName, @IDFieldValue,@SecondIdFieldName, @SecondIdFieldValue )
			SELECT @ReturnCommand=@Query
			RETURN
		END

		CREATE TABLE #tmpTbl([Command] nvarchar(MAX))
		INSERT INTO #tmpTbl ([Command]) exec sp_executesql @Query 
		DECLARE @TmpQuery NVARCHAR(MAX)
		SELECT @TmpQuery = Command from #tmpTbl
		SET @Query = REPLACE(@TmpQuery , '''' , '''''')
		
		IF(@ActionType = 'Update')
		BEGIN
			DECLARE @WhereStatement AS VARCHAR(100)
			SET @WhereStatement = ' WHERE ' + @IDFieldName + '=' + CAST(@IDFieldValue AS VARCHAR(20))
			+ ' AND ' + @SecondIdFieldName + '=N''''' + @SecondIdFieldOldValue + ''''''
			SET @Query = @Query + @WhereStatement
		END
		SELECT @ReturnCommand=@Query
		DROP TABLE #tmpTbl
END
go

