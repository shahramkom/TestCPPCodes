/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetGroupParents](@GroupID int)
	RETURNS varchar(MAX)
AS
BEGIN
	DECLARE @ParentIDs VARCHAR(MAX);
	
	with ParentsCTE as ( select GroupID, ParentID from TGroup where GroupID=@GroupID
	union all select TGroup.GroupID, TGroup.ParentID from TGroup join ParentsCTE on ParentsCTE.ParentID = TGroup.GroupID)

	SELECT @ParentIDs = STUFF ((SELECT ','+ CAST( ParentsCTE.GroupID AS VARCHAR(200))
	FROM ParentsCTE FOR XML PATH('')) , 1 ,1 , '')
	
	RETURN @ParentIDs
END
go

