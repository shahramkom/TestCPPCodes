
	CREATE FUNCTION [dbo].[CopyUserName]
	(
		@UserID NVARCHAR(10),
		@CurrentUserName NVARCHAR(50)
	)
	RETURNS NVARCHAR(50)
	AS
	BEGIN
			DECLARE @CreatedNewUserName NVARCHAR(200)
			DECLARE @NewCreateUserNameCount int 
			DECLARE @CurrentUserNameCount int
			DECLARE @counterLength int
			SELECT  @CurrentUserNameCount = COUNT(UserName) FROM TUser WHERE UserName like(@CurrentUserName+'%')
			SET @counterLength = len( cast(@CurrentUserNameCount as nvarchar(10)))
			SET @CurrentUserName = substring(@CurrentUserName , 1 , 50-(@counterLength+1))
			SET @CreatedNewUserName = @CurrentUserName + '_' + cast(@CurrentUserNameCount as nvarchar(10))
			select @NewCreateUserNameCount = COUNT(UserName) FROM TUser WHERE UserName = @CreatedNewUserName
			if(@NewCreateUserNameCount = 0)		
				return @CreatedNewUserName 
			else
				return dbo.CopyUserName (@UserID, substring(@CreatedNewUserName, 1, 50-(@counterLength+2)))
		return ''	
	END

  go

