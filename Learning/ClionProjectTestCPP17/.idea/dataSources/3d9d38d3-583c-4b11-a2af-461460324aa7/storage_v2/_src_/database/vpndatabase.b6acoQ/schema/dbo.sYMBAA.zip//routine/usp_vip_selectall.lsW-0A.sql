
    CREATE PROCEDURE  [dbo].[USP_VIP_SelectAll]
    AS
    BEGIN
       DECLARE @UserVipPoolIp varchar(25)
		DECLARE @UserVipPoolMask varchar(25)
		SELECT @UserVipPoolIp = [value] FROM TSetting where Property = 'UserVipPoolIp'
		SELECT @UserVipPoolMask = [value] FROM TSetting where Property = 'UserVipPoolMask'
		if(@UserVipPoolIp IS NOT NULL AND @UserVipPoolMask IS NOT NULL)
			SELECT '1' AS ID ,@UserVipPoolIp AS VIP , @UserVipPoolMask AS Mask
		else
			SELECT '1' AS ID ,'192.170.0.0' AS VIP , '255.255.0.0' AS Mask
    END

    go

