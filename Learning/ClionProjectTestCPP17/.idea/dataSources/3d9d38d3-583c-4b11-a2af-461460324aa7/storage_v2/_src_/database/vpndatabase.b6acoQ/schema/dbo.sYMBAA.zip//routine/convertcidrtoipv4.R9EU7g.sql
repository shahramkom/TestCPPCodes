
	CREATE FUNCTION [dbo].[ConvertCIDRToIPV4]
	(
		@cidr int
	)
	RETURNS varchar(15)
	AS
	BEGIN
		RETURN	CASE
				WHEN (@cidr = 0 ) Then  '0.0.0.0'
				WHEN (@cidr = 1 ) Then  '128.0.0.0'
				WHEN (@cidr = 2 ) Then  '192.0.0.0'
				WHEN (@cidr = 3 ) Then  '224.0.0.0'
				WHEN (@cidr = 4 ) Then  '240.0.0.0'
				WHEN (@cidr = 5 ) Then  '248.0.0.0'
				WHEN (@cidr = 6 ) Then  '252.0.0.0'
				WHEN (@cidr = 7 ) Then  '254.0.0.0'
				WHEN (@cidr = 8 ) Then  '255.0.0.0'
				WHEN (@cidr = 9 ) Then  '255.128.0.0'
				WHEN (@cidr = 10 ) Then '255.192.0.0'
				WHEN (@cidr = 11 ) Then '255.224.0.0'
				WHEN (@cidr = 12 ) Then '255.240.0.0'
				WHEN (@cidr = 13 ) Then '255.248.0.0'
				WHEN (@cidr = 14 ) Then '255.252.0.0'
				WHEN (@cidr = 15 ) Then '255.254.0.0'
				WHEN (@cidr = 16 ) Then '255.255.0.0'
				WHEN (@cidr = 17 ) Then '255.255.128.0'
				WHEN (@cidr = 18 ) Then '255.255.192.0'
				WHEN (@cidr = 19 ) Then '255.255.224.0'
				WHEN (@cidr = 20 ) Then '255.255.240.0'
				WHEN (@cidr = 21 ) Then '255.255.248.0'
				WHEN (@cidr = 22 ) Then '255.255.252.0'
				WHEN (@cidr = 23 ) Then '255.255.254.0'
				WHEN (@cidr = 24 ) Then '255.255.255.0'
				WHEN (@cidr = 25 ) Then '255.255.255.128'
				WHEN (@cidr = 26 ) Then '255.255.255.192'
				WHEN (@cidr = 27 ) Then '255.255.255.224'
				WHEN (@cidr = 28 ) Then '255.255.255.240'
				WHEN (@cidr = 29 ) Then '255.255.255.248'
				WHEN (@cidr = 30 ) Then '255.255.255.252'
				WHEN (@cidr = 31 ) Then '255.255.255.254'
				WHEN (@cidr = 32 ) Then '255.255.255.255'
				ELSE '255.255.255.255'
			END
	END
  go

