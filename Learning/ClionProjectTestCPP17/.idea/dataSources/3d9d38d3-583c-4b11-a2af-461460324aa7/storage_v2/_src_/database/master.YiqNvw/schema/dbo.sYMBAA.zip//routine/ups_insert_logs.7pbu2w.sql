
    create PROCEDURE [dbo].[UPS_Insert_logs]
    
        @Log nchar(1000),
        @IDLog int =NULL OUTPUT

    AS
    BEGIN

        insert into TAllLogs
        (Log)
        values
        (@Log)

        SET @IDLog = @@IDENTITY
    

    END
    go

