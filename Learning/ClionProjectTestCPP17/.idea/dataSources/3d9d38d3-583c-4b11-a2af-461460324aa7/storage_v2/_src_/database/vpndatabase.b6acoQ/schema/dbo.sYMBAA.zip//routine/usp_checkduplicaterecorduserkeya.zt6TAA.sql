/******************************************************************************************************************************************************/---------------------------------
CREATE PROCEDURE USP_CheckDuplicateRecordUserKeyA
@TableName VARCHAR(50),
@TableIDFieldValue INT,
@SerialValue VARCHAR(50),
@Outputval INT OUTPUT
AS
BEGIN
	DECLARE @RecCount AS INT 

	DECLARE @ExecCommand AS NVARCHAR(MAX)
	SET @ExecCommand = ' SELECT @RecCount = COUNT(*) FROM ' + @TableName +
				       ' where ((UserID = '+CAST(@TableIDFieldValue AS VARCHAR(20))+')AND(KeyaSerial ='''+@SerialValue +'''))'

	EXEC SP_EXECUTESQL  @ExecCommand
					  , N'@RecCount INT OUTPUT'
					  , @RecCount OUTPUT
	SELECT @Outputval = @RecCount
END
go

