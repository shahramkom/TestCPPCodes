
CREATE PROCEDURE [dbo].[USP_Top_N_Assigned_Policies] 

	@TopCount  int
AS
BEGIN

	   WITH GroupIDTree (UserID,GroupID,ParentID ) AS 
	   (    
		SELECT     TUser.UserID, TGroup.GroupID , TGroup.ParentID 
		FROM       TUser INNER JOIN
				   TUserGroups ON TUser.UserID = TUserGroups.UserID INNER JOIN
				   TGroup ON dbo.TUserGroups.GroupID = TGroup.GroupID

		 UNION ALL    
	   
	   /*Recursive member definition*/     
	   SELECT       GIT.UserID, TGroup.GroupID ,TGroup.ParentID
	   FROM         TGroup         INNER JOIN 
	   GroupIDTree AS GIT         
	   ON TGroup.GroupID = GIT.ParentID
	   )
	   
	   SELECT TOP(@TopCount) PIDTable.PSID , PIDTable.PSName+'('+Convert (varchar(20),COUNT(PSID))+')',PIDTable.PSDescription ,COUNT(PSID) AS PCount  From (
	   
	   SELECT TPolicySet.PSID , TPolicySet.PSName ,TPolicySet.PSDescription , USERID FROM TPolicySet 
	   INNER JOIN TGroupPolicySet ON TPolicySet.PSID = TGroupPolicySet.PSID
	   INNER JOIN (
	   SELECT  userid   , GroupID FROM GroupIDTree ) AS GIT
	   ON TGroupPolicySet.GroupID = GIT.GroupID
	   WHERE USERID NOT IN (SELECT  TUserPolicySet.UserID FROM TUserPolicySet )
	   Group by TPolicySet.PSID , TPolicySet.PSName  ,TPolicySet.PSDescription , USERID
	   
	   UNION all
	    
	   SELECT TPolicySet.PSID , TPolicySet.PSName,TPolicySet.PSDescription , UserID FROM TPolicySet
	   INNER JOIN TUserPolicySet ON TPolicySet.PSID = TUserPolicySet.PSID )AS PIDTable 
	   GROUP BY PIDTable.PSID , PIDTable.PSName , PIDTable.PSDescription
	   ORDER BY PCount DESC	    
	
END
go

