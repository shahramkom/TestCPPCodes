
	Create PROCEDURE [dbo].[USP_TGroupInterface_Insert]
		-- Add the parameters for the stored procedure here
		@InterfaceIDs as nvarchar(500),
		@GroupID as int
	
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		declare @Statement as nvarchar(1000)
		declare @intFID as nvarchar(10)
		declare interface_Cursor cursor for select * from dbo.Splitfn(@interfaceIDs,'#')
		open interface_Cursor
		fetch next from interface_Cursor into @intFID
		while @@FETCH_STATUS = 0
		begin
		set @Statement = 'insert into TGroupInterface (InterfaceID , GroupID) values ('
		set @Statement = isnull(@Statement ,'') + @intFID + ',' + CONVERT(nvarchar(20),@GroupID)+ ')'
		fetch next from interface_Cursor into @intFID
		end
		CLOSE interface_Cursor;	
		DEALLOCATE interface_Cursor;
		exec sp_executesql @Statement
	END

  go

