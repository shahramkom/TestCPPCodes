
    CREATE PROCEDURE   [dbo].[UPS_TUserFirewallPolicy_Update]

        @UFPID						int  ,
        @PSID						int	,
        @Ac_ActionType				nvarchar(50)	,
        @Ac_VirtualIP_Status		nvarchar(50)	,
        @Ac_VirtualIP				nvarchar(15)	,
        @Ac_Tunnel_Source_Type		nvarchar(50)	,
        @Ac_Tunnel_Source_IP		nvarchar(15)	,
        @Ac_Tunnel_Dest_Type		nvarchar(50)	,
        @Ac_Tunnel_Dest_IP			nvarchar(15)	,
        @Ac_Key_ID					nvarchar(100)	,

        @Ac_AthenticationType		nvarchar(150),
        @Ac_AthenticationKey		nvarchar(150),
        @Ac_EncryptionType			nvarchar(150),
        @Ac_EncryptionKey			nvarchar(150),	

        @Fil_Direction				nvarchar(50)	,
        @Fil_Source_AdressType		nvarchar(50)	,
        @Fil_Source_IPAdress		nvarchar(15)	,
        @Fil_Source_NetworkMask		nvarchar(15)	,
        @Fil_Dest_Type				nvarchar(50)	,
        @Fil_Dest_IPAdress			nvarchar(15)	,
        @Fil_Dest_NetworkMask		nvarchar(15)	,
        @Fil_Protocol_Code			nvarchar(50)	,
        @Fil_Protocol_SourcePort	nvarchar(50)	,
        @Fil_Protocol_DestPort		nvarchar(50)	,
        @Fil_AllowNAT				bit	,
		@Compression				bit = 0,
		@status						bit=1
    
    AS

    BEGIN

		declare @lastModifyDateTime as nvarchar(20)
		select @lastModifyDateTime = CONVERT(nvarchar(20),GETDATE(),20)
        
		UPDATE dbo.TUserFirewallPolicy
    
        SET  

        PSID = @PSID		,
        Ac_ActionType = @Ac_ActionType		,
        Ac_VirtualIP_Status = @Ac_VirtualIP_Status		,
        Ac_VirtualIP = @Ac_VirtualIP		,
        Ac_Tunnel_Source_Type = @Ac_Tunnel_Source_Type		,
        Ac_Tunnel_Source_IP = @Ac_Tunnel_Source_IP		,
        Ac_Tunnel_Dest_Type = @Ac_Tunnel_Dest_Type		,
        Ac_Tunnel_Dest_IP = @Ac_Tunnel_Dest_IP		,
        Ac_Key_ID = @Ac_Key_ID		,
        Ac_AthenticationType = @Ac_AthenticationType	,
        Ac_AthenticationKey = @Ac_AthenticationKey	,
        Ac_EncryptionType = @Ac_EncryptionType	,
        Ac_EncryptionKey = @Ac_EncryptionKey	,
    
        Fil_Direction = @Fil_Direction		,
        Fil_Source_AdressType = @Fil_Source_AdressType		,
        Fil_Source_IPAdress = @Fil_Source_IPAdress		,
        Fil_Source_NetworkMask = @Fil_Source_NetworkMask		,
        Fil_Dest_Type = @Fil_Dest_Type	,
        Fil_Dest_IPAdress = @Fil_Dest_IPAdress		,
        Fil_Dest_NetworkMask = @Fil_Dest_NetworkMask		,
        Fil_Protocol_Code = @Fil_Protocol_Code		,
        Fil_Protocol_SourcePort = @Fil_Protocol_SourcePort		,
        Fil_Protocol_DestPort = @Fil_Protocol_DestPort		,
        Fil_AllowNAT = @Fil_AllowNAT						,
		Compression	= @Compression						,
		LastModifiedTime = @lastModifyDateTime			,
		status = @status    
        WHERE	

        @UFPID = UFPID
    END

    go

