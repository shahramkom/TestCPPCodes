/*************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[USP_ReadReplicationLog] 
	@param VARCHAR(50) = NULL
AS
BEGIN	
	SET NOCOUNT ON;
	DECLARE @command NVARCHAR(50)
	SET @command = 'SELECT TOP(1) * FROM ' + @param 
	EXEC dbo.sp_executesql @statement = @command
END

go

