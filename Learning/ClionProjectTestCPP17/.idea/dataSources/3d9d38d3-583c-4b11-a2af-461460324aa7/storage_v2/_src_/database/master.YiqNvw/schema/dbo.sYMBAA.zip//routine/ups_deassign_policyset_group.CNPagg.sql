
    CREATE PROCEDURE [dbo].[UPS_Deassign_Policyset_Group] 
        -- Add the parameters for the stored procedure here
        @groupID int , 
        @policySetID int 
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
       declare @duplicateRelation int 
       set @duplicateRelation=0
       select @duplicateRelation=count(PSID)from TGroupPolicySet where PSID=@policySetID
       if(@duplicateRelation=0)
        begin
            Raiserror('Selected policy not assigned before. Please choose another policy set.', 16 , 10 )
            return
        end
        else
            delete from TGroupPolicySet where GroupID=@groupID and PSID=@policySetID

    END


    go

