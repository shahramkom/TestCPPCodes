
CREATE PROCEDURE  [dbo].[USP_TUserPolicySet_Insert]
    @UserID   int,
    @PSID	  int,
    @Priority int 
AS
BEGIN
	declare @CreateDateTime as nvarchar(20)
	select @CreateDateTime = CONVERT(nvarchar(20),GETDATE(),20)
	select @CreateDateTime
	Update Tuser set LastModifiedTime = @CreateDateTime where UserID = @UserID
    IF NOT EXISTS(SELECT * FROM TUserPolicySet WHERE UserID = @UserID AND PSID = @PSID AND PolPriority = @Priority)
	    INSERT INTO TUserPolicySet (UserID,PSID,PolPriority) VALUES(@UserID,@PSID,@Priority)
END
go

