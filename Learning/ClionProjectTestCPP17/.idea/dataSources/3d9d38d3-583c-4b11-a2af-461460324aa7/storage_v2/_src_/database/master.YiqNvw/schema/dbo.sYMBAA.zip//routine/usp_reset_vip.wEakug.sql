
Create PROCEDURE [dbo].[USP_Reset_VIP]
AS
BEGIN	
    UPDATE TUSER SET VirtualIPStatus = 'Dynamic' , VirtualIP = NULL
END
go

