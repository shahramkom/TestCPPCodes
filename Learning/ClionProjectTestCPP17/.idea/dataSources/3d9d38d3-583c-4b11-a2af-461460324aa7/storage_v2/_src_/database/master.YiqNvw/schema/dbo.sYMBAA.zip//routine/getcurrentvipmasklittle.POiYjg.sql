/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetCurrentVIPMaskLittle]()
RETURNS BIGINT
AS
BEGIN
	DECLARE @RetVIP BIGINT
	DECLARE @CurrentVIPMask VARCHAR(20)
	SELECT @CurrentVIPMask = Mask FROM dbo.TVIP
	IF(@CurrentVIPMask IS NOT NULL)
		SELECT @RetVIP = dbo.ConvertIP2LittleInt(@CurrentVIPMask)
	ELSE
		SET @RetVIP = 0
	RETURN @RetVIP
END
go

