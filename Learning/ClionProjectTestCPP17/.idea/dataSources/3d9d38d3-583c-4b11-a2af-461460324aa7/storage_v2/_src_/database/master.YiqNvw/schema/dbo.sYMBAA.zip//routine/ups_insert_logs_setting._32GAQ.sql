

    CREATE PROCEDURE  [dbo].[UPS_Insert_logs_setting]

        @L_Mode		nvarchar(50),
        @L_UserID	nvarchar(50),
        @L_IP		nvarchar(50),
        @L_Mask		nvarchar(50),
        @L_GateWay	nvarchar(50),
        @L_ifIndex	nvarchar(50),
        @L_Metric	nvarchar(50),
        @L_Time		nvarchar(50)
      AS
 
    BEGIN
        insert into TSettingLog 

        (L_Mode ,
         L_UserID,
         L_IP   ,
         L_Mask ,
         L_GateWay ,
         L_ifIndex ,
         L_Metric ,
         L_Time )
         VALUES
        (@L_Mode ,
         @L_UserID,
         @L_IP   ,
         @L_Mask ,
         @L_GateWay ,
         @L_ifIndex ,
         @L_Metric ,
         @L_Time )	

    END

    go

