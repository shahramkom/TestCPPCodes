
CREATE PROCEDURE [dbo].[USP_CH_Rule_Filter]			
	@RuleID int = null
AS	
BEGIN
	if(@RuleID is null)
		SELECT [RuleID],[Name],[Category],[Action],[ActionParameter],[RuleType] FROM [dbo].[HealthCheckRules]
	else
		SELECT [RuleID],[Name],[Category],[Action],[ActionParameter],[RuleType] FROM [dbo].[HealthCheckRules]	WHERE RuleID = @RuleID
END
go

