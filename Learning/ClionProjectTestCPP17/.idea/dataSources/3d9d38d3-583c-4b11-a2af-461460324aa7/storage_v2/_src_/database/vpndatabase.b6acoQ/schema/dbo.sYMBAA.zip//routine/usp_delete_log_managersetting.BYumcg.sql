
    CREATE PROCEDURE [dbo].[USP_Delete_Log_ManagerSetting] 

        @LogType	    int			,
        @condition			nvarchar(3)	,
        @strDateCondition		nvarchar(10),
        @strTimeCondition		nvarchar(10)	
    
    
    AS
    BEGIN
        DECLARE @dateCondition		DATETIME
        SET @dateCondition = CAST(@strDateCondition AS DATETIME)
    
        DECLARE @timeCondition		DATETIME
        SET @timeCondition = CAST(@strTimeCondition AS DATETIME)
    IF(@LogType=1)
    BEGIN
        IF(@condition='<')
            DELETE FROM managerLog  WHERE  (CAST(operationDate AS DATETIME) = @dateCondition AND   CAST(operationTime AS DATETIME) < @timeCondition)OR (CAST(operationDate AS DATETIME) < @strDateCondition )
        IF(@condition='>')
            DELETE FROM managerLog  WHERE  (CAST(operationDate AS DATETIME) = @dateCondition AND   CAST(operationTime AS DATETIME) > @timeCondition)OR (CAST(operationDate AS DATETIME) > @strDateCondition )
        IF(@condition='>=')
            DELETE FROM managerLog  WHERE (CAST(operationDate AS DATETIME) = @dateCondition AND   CAST(operationTime AS DATETIME) >= @timeCondition)OR (CAST(operationDate AS DATETIME) > @strDateCondition )
        IF(@condition='<=')
            DELETE FROM managerLog  WHERE (CAST(operationDate AS DATETIME) = @dateCondition AND   CAST(operationTime AS DATETIME) <= @timeCondition)OR (CAST(operationDate AS DATETIME) < @strDateCondition )
        IF(@condition='=')
            DELETE FROM managerLog  WHERE (CAST(operationDate AS DATETIME) = @dateCondition AND   CAST(operationTime AS DATETIME) = @timeCondition)
    END
    IF(@LogType=2)
    BEGIN
        IF(@condition='<')
            DELETE FROM settingServerLog  WHERE (CAST(operationDate AS DATETIME) = @dateCondition AND   CAST(operationTime AS DATETIME) < @timeCondition)OR (CAST(operationDate AS DATETIME) < @strDateCondition )
        IF(@condition='>')
            DELETE FROM settingServerLog  WHERE (CAST(operationDate AS DATETIME) = @dateCondition AND   CAST(operationTime AS DATETIME) > @timeCondition)OR (CAST(operationDate AS DATETIME) > @strDateCondition )
        IF(@condition='>=')
            DELETE FROM settingServerLog  WHERE (CAST(operationDate AS DATETIME) = @dateCondition AND   CAST(operationTime AS DATETIME) >= @timeCondition)OR (CAST(operationDate AS DATETIME) > @strDateCondition )
        IF(@condition='<=')
            DELETE FROM settingServerLog  WHERE (CAST(operationDate AS DATETIME) = @dateCondition AND   CAST(operationTime AS DATETIME) <= @timeCondition)OR (CAST(operationDate AS DATETIME) < @strDateCondition )
        IF(@condition='=')
            DELETE FROM settingServerLog  WHERE (CAST(operationDate AS DATETIME) = @dateCondition AND   CAST(operationTime AS DATETIME) = @timeCondition)
    END

    END


    go

