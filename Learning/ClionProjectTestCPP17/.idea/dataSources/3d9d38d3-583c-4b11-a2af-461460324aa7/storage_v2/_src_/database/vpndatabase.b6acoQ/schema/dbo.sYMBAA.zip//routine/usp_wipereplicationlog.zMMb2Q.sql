CREATE PROCEDURE [dbo].[USP_WipeReplicationLog]
	@serverID INT = -1
AS
BEGIN
	DECLARE @tableName AS NVARCHAR(100)
	DECLARE @tableScript AS NVARCHAR(100)
	
	IF (@serverID = 1 OR @serverID = -1)
	BEGIN
		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RepPrimaryLog]') AND type in (N'U'))
		BEGIN
			DELETE FROM RepPrimaryLog	
		END
		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RepSlaveLog]') AND type in (N'U'))
		BEGIN	
			DELETE FROM RepSlaveLog
		END
	    
		DECLARE @myServerID AS INT
		IF @serverID = -1
			SELECT @myServerID = convert(INT, [value]) FROM Tsetting Where [property] = 'ServerID'
		ELSE
			SET @myServerID = @serverID
		
		IF (dbo.IsPrimaryServer(@myServerID) = 1)
		BEGIN
			DECLARE @counter AS INT
			SET @counter = 1
			WHILE (@counter < 255 )
			BEGIN
				IF EXISTS(SELECT * FROM dbo.RepConfig WHERE ServerID = @counter)
				BEGIN
					SET @tableName = 'RepSecLog' + CONVERT(VARCHAR(3), @counter)
					IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].['+@tableName+']') AND type in (N'U'))
					BEGIN
						SET @tableScript = 'DELETE FROM [' + @tableName + ']'
						EXEC dbo.sp_executesql @statement = @tableScript
					END
				END
				SET @counter = @counter + 1
			END
		END
	END
	ELSE
	BEGIN
		SET @tableName = 'RepSecLog' + CONVERT(VARCHAR(3), @serverID)
		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RepSlaveLog]') AND type in (N'U'))
		BEGIN	
			SET @tableScript = 'DELETE FROM [' + @tableName + ']'
			EXEC dbo.sp_executesql @statement = @tableScript
		END
	END
END

go

