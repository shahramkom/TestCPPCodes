/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.IsMyModification(@CurrentServerID TINYINT, @RowServerID int)
	RETURNS BIT
AS
BEGIN
	DECLARE @isMyModify as BIT
	
	if(@CurrentServerID = @RowServerID)
		set @isMyModify = 1
	else
		set @isMyModify = 0
	RETURN @isMyModify
END
go

