
	CREATE PROCEDURE UPS_Get_User_SendDNS_Status
	
		@UserID as int 
	AS
	BEGIN
		-- SET NOCOUNTON added to prevent extra result sets from
		SET NOCOUNT ON;
		DECLARE @Count as int
		SELECT @Count=Count(SendDNS) From TUser Where UserID = @UserID And SendDNS = 1
		IF(@Count <> 0)
		BEGIN
			SELECT @Count as DNS_Status
			Return
		END;
		WITH GroupIDTree (GroupID, ParentID,SendDNS ,GPriority,  GLevel) AS 
	   (   /*Anchor member definition*/ 
		  SELECT    TGroup.GroupID,TGroup.ParentID,TGroup.SendDNS,TUserGroups.GPriority ,1 as GLevel    
		  FROM   TUser
				 INNER JOIN          TUserGroups ON TUser.UserID = TUserGroups.UserID
				 INNER JOIN          TGroup ON dbo.TUserGroups.GroupID = TGroup.GroupID       
				 WHERE (TUser.UserID = @UserID )
             
                 
		  UNION ALL
             
             
		 /*Recursive member definition*/    
		 SELECT  TGroup.GroupID,TGroup.ParentID,TGroup.SendDNS,GID.GPriority ,GLevel+1    
		 FROM    TGroup      
				  INNER JOIN  GroupIDTree as GID      ON (TGroup.GroupID = GID.ParentID)  
		 )    
		SELECT Count(SendDNS) as DNS_Status FROM GroupIDTree WHERE SendDNS = 1                
	END
  go

