
       create PROC [dbo].[USP_InsertTEMessageGenerator]
     as
        declare @tableName varchar(100)
        set @tableName = 'TEMessage'
        
    --Declare a cursor to retrieve column specific information for the specified table
    DECLARE cursCol CURSOR FAST_FORWARD FOR 
    SELECT column_name,data_type FROM information_schema.columns WHERE table_name = @tableName
    OPEN cursCol
    DECLARE @string nvarchar(3000) --for storing the first half of INSERT statement
    DECLARE @stringData nvarchar(3000) --for storing the data (VALUES) related statement
    DECLARE @dataType nvarchar(max) --data types returned for respective columns
    SET @string='Update '+@tableName+' set '' +'
    SET @stringData=''

    DECLARE @colName nvarchar(50)

    FETCH NEXT FROM cursCol INTO @colName,@dataType

    IF @@fetch_status<>0
    begin
        print 'Table '+@tableName+' not found, processing skipped.'
        close curscol
        deallocate curscol
        return
    END
	declare @index as int
	declare @CdtnStmt as nvarchar(500)
	set @index = 0
    WHILE @@FETCH_STATUS=0
    BEGIN
    IF @dataType in ('varchar','char','nchar','nvarchar')
    BEGIN
          SET @stringData='+isnull(''N'''+'''''+'+@colName+'+'''''+''''',''NULL'')+'',''+'
          set @string=@string+ ''''+@colName+' = ''' + @stringData
    END
    ELSE --presuming the data type is int,bit,numeric,decimal 
    BEGIN
		if(@index = 0)
		begin
			--select 7
			set @CdtnStmt = ''' where '+@colName + ' = ' +'''+isnull('''''+'+convert(varchar(200),'+@colName+')+'+''''',''NULL'')+'
			set @index  = @index + 1
		end
		else
		begin
			SET @stringData='+isnull('''''+'''''+convert(varchar(200),'+@colName+')+'''''+''''',''NULL'')+'',''+'
			set @string=@string+ ''''+ @colName+' = ''' + @stringData
		end
    END

   -- SET @string=@string+@colName+','
	
    FETCH NEXT FROM cursCol INTO @colName,@dataType
    END
    --select 5,@string
    set @string = SUBSTRING(@string,0,len(@string)-3)
    --select 4,@string
    SET @string=@string+@CdtnStmt --+','
	--select 1,@string
    DECLARE @query as nvarchar(4000)
	
    SET @query ='SELECT '''+substring(@string,0,len(@string)) + ' as [output],MessageType,UseDefault,ErrorMessage,'''+@tableName+'''as tablename FROM '+@tableName
	--select 2,@query		   
    insert  tbl_InsertGroupScript([output],MessageType,UseDefault,ErrorMessage,tableName) exec sp_executesql @query
    CLOSE cursCol
    DEALLOCATE cursCol

       go

