 CREATE PROCEDURE [dbo].[USP_ExecuteRestoreData]
    @command NVARCHAR(MAX),
    @moment  NVARCHAR(100)
 AS
 BEGIN
    SET NOCOUNT ON

    DECLARE @errorMSG NVARCHAR(MAX)
    DECLARE @dateTimeVar NVARCHAR(MAX)

    BEGIN TRY
        EXEC sp_executesql @command
    END TRY
    BEGIN CATCH
        SET @errorMSG = ERROR_MESSAGE()
        SET @dateTimeVar = GETDATE()
        INSERT  INTO [VPNDataBase].[dbo].[TSqlError]
                ( [userid],
                  [moment],
                  [operate],
                  [errorcode],
                  [errortext],
                  [comment] )
        VALUES  ( 1,
                  @dateTimeVar,
                  @moment,
                  @@Error,
                  ERROR_MESSAGE(),
                  @command )
    END CATCH
    
 END
 go

