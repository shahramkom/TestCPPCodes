
    Create PROCEDURE [dbo].[USP_SelectGroupIDfromTGroup]

    AS
    BEGIN	
        select * from TGroup
    END

    go

