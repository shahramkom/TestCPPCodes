/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetTwoConditionUpdateQuery]( @TableName nvarchar(100), @IDFieldName1 nvarchar(100), @IDFieldValue1 varchar(30), @IDFieldName2 nvarchar(100), @IDFieldValue2 varchar(30))
		RETURNS nvarchar(MAX)
	AS
	BEGIN
		DECLARE CursCol CURSOR FAST_FORWARD FOR 
		SELECT column_name,data_type FROM information_schema.columns WHERE table_name = @TableName AND ORDINAL_POSITION <> 1
		OPEN CursCol
		DECLARE @StringData nvarchar(MAX) --for storing the data (VALUES) related statement
		DECLARE @DataType nvarchar(100) --data types returned for respective columns
		
		SET @StringData=' '

		DECLARE @ColName nvarchar(50)

		DECLARE @Query nvarchar(MAX)
		SET @Query = ' '
		FETCH NEXT FROM CursCol INTO @ColName, @DataType
		WHILE @@FETCH_STATUS=0
		BEGIN
			SET @StringData = [dbo].getDataTypeString(@DataType,@ColName)
			SET @Query = @Query + @ColName+  ' = ''+ ' + substring(@StringData,0,len(@StringData)-2)+',''+'''
			FETCH NEXT FROM CursCol INTO @ColName,@DataType
		END
		SET @Query = LEFT(@Query, LEN(@Query)-6)

		SET @Query = 'SELECT ''UPDATE '+@TableName+' SET ' + @Query +' From '  + @TableName
		 + ' WHERE ' + @IDFieldName1 +' = ' + @IDFieldValue1 
		 +' AND '+ @IDFieldName2 +' = N''' + @IDFieldValue2 + ''''
		
		CLOSE CursCol
		DEALLOCATE CursCol
		return @Query
END
go

