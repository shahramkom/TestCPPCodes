
CREATE PROCEDURE [dbo].[Update_NULLGroupID_Users]
    @groupIDForUpdate NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @grpID INT 
        
     -- Insert statements for procedure here
    CREATE TABLE #TempTable ( UserID NVARCHAR(50), GID VARCHAR(25) )
    IF ( @groupIDForUpdate <> '0' )
        BEGIN
            
            SELECT  @grpID = groupid
            FROM    tgroup
            WHERE   groupname LIKE @groupIDForUpdate 
        END
    ELSE
        BEGIN
            IF NOT EXISTS ( SELECT  *
                            FROM    TGroup
                            WHERE   GroupName = N'DefaultGroup' )
                BEGIN					
                    INSERT  INTO TGroup
                            ( GroupName,
                              DefaultAccess,
                              GroupDescription )
                    VALUES  ( N'DefaultGroup',
                              N'Deny',
                              N'Users with no groups comes here' )
                END
            SELECT  @grpID = GroupID
            FROM    TGroup
            WHERE   GroupName = N'DefaultGroup' 
            
        END
    INSERT  INTO #TempTable
            SELECT  UserID,
                    GID
            FROM    Tuser
            WHERE   UserID NOT IN ( SELECT  userID
                                    FROM    tuserGroups )
    SELECT  @grpID
    DECLARE @userID NVARCHAR(50)
    DECLARE @gid VARCHAR(25)
    DECLARE UserID_cursor CURSOR
    FOR
    SELECT  *
    FROM    #TempTable
    OPEN UserID_cursor
    FETCH NEXT FROM UserID_cursor
    INTO @userID, @gid
    WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT  INTO TUserGroups
                    ( groupid, UserID, GID )
            VALUES  ( @grpID, @userID, @gid )
            FETCH NEXT FROM UserID_cursor 
        INTO @userID, @gid
        END
    DROP TABLE #TempTable
END 
/******************************************************************************************************************************************************/--------------------------------------------------------------------
go

