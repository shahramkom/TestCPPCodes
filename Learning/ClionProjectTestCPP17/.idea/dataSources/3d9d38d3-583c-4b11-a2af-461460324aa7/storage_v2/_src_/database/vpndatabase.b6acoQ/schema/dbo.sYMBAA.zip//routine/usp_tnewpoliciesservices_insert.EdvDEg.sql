
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesServices_Insert] 
	   @ProtocolName nvarchar(50),
	   @ProtocolType nvarchar(20),
	   @SourcePort nvarchar(50),
	   @DestinationPort nvarchar(50),
	   @IconIndex int
   AS
   BEGIN
	INSERT INTO [dbo].[TNewPoliciesServices]
           ([ProtocolName]
           ,[ProtocolType]
           ,[SourcePort]
           ,[DestinationPort]
		   ,[IconIndex])
     VALUES
           (@ProtocolName,
			@ProtocolType,
			@SourcePort,
			@DestinationPort,
			@IconIndex )
	SELECT @@IDENTITY
   END

   go

