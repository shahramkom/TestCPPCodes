
    
    CREATE PROCEDURE [dbo].[USP_SelectTPolicySetFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        
    declare @PSName nvarchar(200) ,@groupID nvarchar(200), @PSID nvarchar(200),@InsertScript nvarchar(4000)

     Declare PolicySet_cursor Cursor FAST_FORWARD
        For
        Select 
                  PSName,PSID,GroupID,[output] 
            FROM tbl_InsertGroupScript   
            where tableName = 'TPolicySet'
            OPEN PolicySet_cursor

    FETCH NEXT FROM PolicySet_cursor
    INTO @PSName,@PSID,@groupID,@InsertScript

    WHILE @@FETCH_STATUS = 0
    begin 
          	
            if(exists (select PSID from TPolicySet where PSName = @PSName or PSID = @PSID))
            Begin
                if(@Replace = '1')
                     Delete from TPolicySet   where PSName = @PSName or PSID = @PSID	
            End
        
            BEGIN TRY
                SET IDENTITY_INSERT TPolicySet ON
                exec sp_executesql @InsertScript	
                SET IDENTITY_INSERT TPolicySet OFF		
            END TRY
            BEGIN CATCH
					 INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectTPolicySetFromImportedBackupData')
					  
            END CATCH  	
            FETCH NEXT FROM PolicySet_cursor 
             INTO @PSName,@PSID,@groupID,@InsertScript
    
        end
        CLOSE PolicySet_cursor;
        DEALLOCATE PolicySet_cursor;	
    END


    go

