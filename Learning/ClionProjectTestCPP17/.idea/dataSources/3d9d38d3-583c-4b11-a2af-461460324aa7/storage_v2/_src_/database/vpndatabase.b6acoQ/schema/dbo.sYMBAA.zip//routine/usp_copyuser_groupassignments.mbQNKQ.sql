CREATE PROCEDURE [dbo].[USP_CopyUser_GroupAssignments]
    @OldUserID BIGINT,
    @NewUserID BIGINT,
	@GID VARCHAR(25) = NULL
AS
BEGIN
    INSERT  INTO TUserGroups
            ( UserID,
              GroupID,
              GPriority,
			  GID )
            SELECT  @NewUserID,
                    GroupID,
                    GPriority,
					@GID
            FROM    TUserGroups
            WHERE   UserID = @OldUserID
END
go

