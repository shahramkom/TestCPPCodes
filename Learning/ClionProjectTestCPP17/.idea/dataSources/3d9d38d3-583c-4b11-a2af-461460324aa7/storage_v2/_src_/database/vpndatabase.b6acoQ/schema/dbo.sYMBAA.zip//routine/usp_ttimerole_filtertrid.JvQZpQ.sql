
    Create PROCEDURE [dbo].[USP_TTimeRole_FilterTRID]
    @TimeSetName nvarchar(300)

    AS
    BEGIN	
        select TRID from TTimeRole where TimeSetName = @TimeSetName
    END

    go

