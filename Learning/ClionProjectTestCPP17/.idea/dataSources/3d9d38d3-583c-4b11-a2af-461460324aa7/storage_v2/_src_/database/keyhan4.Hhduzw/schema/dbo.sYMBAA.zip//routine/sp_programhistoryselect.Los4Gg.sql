CREATE PROCEDURE [dbo].[sp_ProgramHistorySELECT] 
	@ProfileID int,
	@UserName nvarchar(150)
AS
	BEGIN
	if(@UserName is not null)
	begin
		SELECT [ID],[ProfileID],[ProgramDate],[ModuleSerial],[OnlineUsers],[TotalUsers],[Comment],[UsfPercent],[UserName],[Reserve1],[Reserve2]
		FROM [Keyhan4].[dbo].[ProgramHistory]
		Where ProfileID = @ProfileID and UserName = @UserName
	end
	else
	begin
		SELECT [ID],[ProfileID],[ProgramDate],[ModuleSerial],[OnlineUsers],[TotalUsers],[Comment],[UsfPercent],[UserName],[Reserve1],[Reserve2]
		FROM [Keyhan4].[dbo].[ProgramHistory]
		Where ProfileID = @ProfileID 
	end
	END
go

