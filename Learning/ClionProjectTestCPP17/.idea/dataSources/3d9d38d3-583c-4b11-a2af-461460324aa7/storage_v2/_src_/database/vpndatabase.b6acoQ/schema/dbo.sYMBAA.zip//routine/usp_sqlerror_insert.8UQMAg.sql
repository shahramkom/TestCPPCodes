
    CREATE PROCEDURE  [dbo].[USP_SQlError_Insert]
                @userid		int
               ,@moment		nvarchar(20)
               ,@operate	nvarchar(200)
               ,@errorcode	int
               ,@errortext	nvarchar(300)
               ,@comment	nvarchar(300)
    AS
    BEGIN
        SET NOCOUNT ON;
    INSERT INTO [VPNDataBase].[dbo].[TSqlError]
               ([userid]
               ,[moment]
               ,[operate]
               ,[errorcode]
               ,[errortext]
               ,[comment])
         VALUES(
                @userid		
               ,@moment		
               ,@operate	
               ,@errorcode	
               ,@errortext	
               ,@comment	
        )
    END

    go

