
    CREATE PROCEDURE [dbo].[SETTINGLOG_SERVER_FILTER_COMPLETE] 
        -- Add the parameters for the stored procedure here
            @L_managerID int=NULL,
            @L_startDate nvarchar(10)=NULL,
            @L_startTime nvarchar(8)=NULL,	
            @L_endDate   nvarchar(10)=NULL,
            @L_endTime   nvarchar(8)=NULL,
            @L_LogType  nvarchar(50)=NULL,	
            @L_DateTime	 nvarchar(50)=NULL,
            @L_Interface nvarchar(50)=NULL,
            @L_Gateway   nvarchar(50)=NULL,
            @L_ServersNeighbor nvarchar(50)=NULL,
            @L_PATIP	nvarchar(50)=NULL,
            @L_Routing	nvarchar(50)=NULL,
            @L_Replication nvarchar(50)=NULL,
            @pageSize int = NULL,
            @pageNum int = 1
    AS
      SET NOCOUNT ON
      declare @filter nvarchar(max)
      if (@L_managerID is not null)
        set @filter = isnull(@filter ,'') +  '(userID = ' + isnull(cast(@L_managerID as nvarchar(100)) , '') +')AND' 
    if (@L_logType is not null)	
        set @filter = isnull(@filter ,'') +  '(logType = '''+@L_logType+''')AND'	

    if (@L_startDate = @L_endDate)	
        set @filter = isnull(@filter ,'') +  '(operationDate = '''+@L_startDate+''' AND operationTime >= '''+ @L_startTime+''' AND operationTime <= '''+@L_endTime+''')AND'
    else
        set @filter = isnull(@filter ,'') +  '(((operationDate > '''+@L_startDate+''') AND (operationDate < '''+ @L_endDate  +''')) OR ((operationDate = '''+@L_startDate + ''' AND operationTime >= '''+ @L_startTime+''' )) OR '
            + ' ((operationDate = '''+@L_endDate + ''' AND operationTime <= '''+ @L_endTime+''' )))AND'

    if(@L_DateTime is not null OR @L_Interface is not null OR @L_Gateway is not null OR  @L_ServersNeighbor is not null  OR @L_PATIP is not null OR @L_Routing is not null )
    begin
        set @filter = isnull(@filter ,'')+ '('
        if (@L_DateTime is not null)
            set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_DateTime +''')OR'
        if (@L_Interface is not null)
            set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_Interface +''')OR'
        if (@L_Gateway is not null)
            set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_Gateway +''')OR'
        if (@L_ServersNeighbor is not null)
            set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_ServersNeighbor +''')OR'	
        if (@L_PATIP is not null)
            set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_PATIP +''')OR'
        if (@L_Routing is not null)
            set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_Routing +''')OR'
		if (@L_Replication is not null)
			set @filter = isnull(@filter ,'') +  '(logEvent = '''+@L_Replication +''')OR'
        set @filter = substring(@filter , 0 , LEN(@filter) - 1)			
        set @filter = isnull(@filter ,'')+ ')'
    end	
    else
	begin 
        set @filter = substring(@filter , 0 , LEN(@filter) - 2)	
		set @filter = isnull(@filter ,'') + 'AND ' + '(logEvent = ''NULL'')'
	end
      select @filter
       declare 	@datasrc nvarchar(200)
       set 	@datasrc = ' settingServerLog '	
       declare @orderBy nvarchar(200)
       set @orderBy = ' operationDate, operationTime DESC ' 
 
    declare  @fieldlist nvarchar(200) 
    set @fieldlist= '[No],	
        operationDate as Date,operationTime as Time,userID as MangerID,logType,operationType,logEvent,rowID,
            decription'
     DECLARE
         @STMT nvarchar(max)         -- SQL to execute
        ,@recct int                  -- total # of records (for GridView paging interface)

     IF LTRIM(RTRIM(@filter)) = '' SET @filter = '1 = 1'
      IF @pageSize IS NULL BEGIN
        SET @STMT =  'SELECT   ' + @fieldlist + 
                     'FROM     ' + @datasrc +
                     'WHERE    ' + @filter + 
                     'ORDER BY ' + @orderBy
              
         EXEC (@STMT)                 -- return requested records 
      END ELSE BEGIN
        SET @STMT =  'SELECT  @recct = COUNT(*)
                     FROM     ' + @datasrc + '
                      WHERE    ' + @filter
        EXEC sp_executeSQL @STMT, @params = N'@recct INT OUTPUT', @recct = @recct OUTPUT
    
        --if (@recct between @pageSize * @pageNum and (@pageSize-1) * @pageNum)
        if (@pageSize * @pageNum > @recct and @pageSize * (@pageNum - 1 ) > @recct)
        begin
            select 'return'
            return;
        end
 
        SELECT @recct AS recct       -- return the total # of records

        DECLARE
         @lbound int,
         @ubound int

        SET @pageNum = ABS(@pageNum)
        SET @pageSize = ABS(@pageSize)
        IF @pageNum < 1 SET @pageNum = 1
        IF @pageSize < 1 SET @pageSize = 1
        SET @lbound = ((@pageNum - 1) * @pageSize)
        SET @ubound = @lbound + @pageSize + 1
        IF @lbound >= @recct BEGIN
          SET @ubound = @recct + 1
          SET @lbound = @ubound - (@pageSize + 1) -- return the last page of records if                                               -- no records would be on the
                                                  -- specified page
        END
        SET @STMT =  'SELECT  ' + @fieldlist + '
                      FROM    (
                                SELECT  ROW_NUMBER() OVER(ORDER BY ' + @orderBy + ') AS row, *
                                FROM    ' + @datasrc + '
                                WHERE   ' + @filter + '
                              ) AS tbl
                      WHERE
                              row > ' + CONVERT(varchar(9), @lbound) + ' AND
                              row < ' + CONVERT(varchar(9), @ubound)
        EXEC (@STMT)                 -- return requested records 
      END

    go

