/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.GetRelatedSecondaryID(@GroupID INT)
	RETURNS TINYINT
AS
BEGIN
	DECLARE CursSrvID CURSOR FAST_FORWARD FOR
		SELECT ServerID FROM dbo.RepConfig WHERE ServerID <> 1
	OPEN CursSrvID
	DECLARE @ServerID TINYINT

	FETCH NEXT FROM CursSrvID INTO @ServerID
	WHILE @@FETCH_STATUS=0
	BEGIN
	DECLARE @ServerGroupIDs VARCHAR(MAX)
	SET @ServerGroupIDs = dbo.GetServerGroups(@ServerID)
	IF EXISTS(SELECT @GroupID  WHERE @GroupID IN (SELECT items FROM dbo.Splitfn(@ServerGroupIDs,',')))
		RETURN @ServerID
	FETCH NEXT FROM CursSrvID INTO @ServerID
	END
	CLOSE CursSrvID
	DEALLOCATE CursSrvID	
	RETURN 0
END
go

