CREATE PROCEDURE [dbo].[USP_GetLicenseInfo]
AS
BEGIN
	select Property, value from TSetting 
END
/******************************************************************************************************************************************************/
go

