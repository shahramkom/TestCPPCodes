CREATE PROCEDURE [dbo].[USP_InsertReplicationConfig]
	@serversInfo NVARCHAR(MAX)
AS
BEGIN
    BEGIN TRAN
        DELETE FROM dbo.RepServersState
		DELETE FROM RepServersGroups
        DELETE FROM dbo.RepConfig

	    DECLARE @myServerID AS INT
        SELECT @myServerID = dbo.GetCurrentServerID()
        
		DECLARE serverList CURSOR FAST_FORWARD FOR SELECT * FROM dbo.Splitfn(@serversInfo,'#')
		OPEN serverList
		DECLARE @sList AS NVARCHAR(MAX)

		FETCH NEXT FROM serverList INTO @sList
		WHILE @@FETCH_STATUS=0
		BEGIN
            DECLARE @serverID		int
	        DECLARE @serverIP		varchar(15)	
	        DECLARE @serverType		int
	        DECLARE @slaveIP		varchar(15)
	        DECLARE @groupsName    	Nvarchar(MAX)
	        DECLARE @updatedVIP     BIT
            DECLARE @serverState	INT
            
            SELECT @serverID= X.value('x[1]','int'),
                @serverIP   = X.value('x[2]','varchar(15)'),
                @serverType = X.value('x[3]','int'),
                @slaveIP    = X.value('x[4]','varchar(15)'),
                @groupsName = X.value('x[5]','Nvarchar(MAX)'),
                @updatedVIP = X.value('x[6]','bit'),
				@serverState = X.value('x[7]','int')
            FROM (SELECT CAST('<x>'+REPLACE(@sList,'~','</x><x>') +'</x>' AS xml)) AS T(X)

		    INSERT INTO RepConfig(ServerID, ServerIP, ServerType, SlaveIP) VALUES(@serverID, @serverIP, @serverType, @slaveIP)     
			INSERT INTO RepServersState(ServerID, LastSuccessfulRun, RunningState) VALUES (@serverID, GETDATE(), @serverState)

            IF((@groupsName <> ',' OR @groupsName IS NOT NULL) AND (@serverID = @myServerID OR @myServerID = 1))
            BEGIN    
                DECLARE CursSecID CURSOR FAST_FORWARD FOR SELECT * FROM dbo.Splitfn(@groupsName,',')
		        OPEN CursSecID
		        DECLARE @GroupName AS NVARCHAR(100)

		        FETCH NEXT FROM CursSecID INTO @GroupName
		        WHILE @@FETCH_STATUS=0
		        BEGIN
		            DECLARE @groupID AS INT
					DECLARE @GRPID AS INT 
					DECLARE @ExecCommand AS NVARCHAR(MAX)
					SET @ExecCommand = ' SELECT @GRPID = GroupID FROM TGroup WHERE GroupName = N''' + @GroupName + ''''
					EXEC SP_EXECUTESQL  @ExecCommand , N'@GRPID INT OUTPUT' , @GRPID OUTPUT
					SELECT @groupID = @GRPID
					IF(NOT EXISTS (SELECT * FROM RepServersGroups WHERE ServerID = @serverID AND RepGroupID = @groupID) )
	  					INSERT INTO RepServersGroups(ServerID, RepGroupID) VALUES(@serverID, @groupID)
			        FETCH NEXT FROM CursSecID INTO @GroupName
		        END
		        CLOSE CursSecID
		        DEALLOCATE CursSecID
            END
            FETCH NEXT FROM serverList INTO @sList
        END
        CLOSE serverList
		DEALLOCATE serverList
		EXEC USP_CreateRepLogTable
    COMMIT TRAN
END
go

