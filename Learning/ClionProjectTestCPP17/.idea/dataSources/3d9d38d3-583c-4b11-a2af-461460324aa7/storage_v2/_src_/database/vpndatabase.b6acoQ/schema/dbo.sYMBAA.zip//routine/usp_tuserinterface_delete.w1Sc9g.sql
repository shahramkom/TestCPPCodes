
	create PROCEDURE [dbo].[USP_TUserInterface_Delete]
		-- Add the parameters for the stored procedure here
		@InterfaceID as int,
		@userID as int
	
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;	

		-- Insert statements for procedure here
		declare @Statement as nvarchar(1000)
		if(@InterfaceID is not null)
			set @Statement = 'delete from TUserInterface where ( InterfaceID = ' + convert(nvarchar(20),@InterfaceID )+ ')'
		if(@userID is not null)
		begin 
			set @Statement = 'delete from TUserInterface where ( UserID = ' + convert(nvarchar(20),@userID )+ ')'
		end
		exec sp_executesql @Statement

	END

  go

