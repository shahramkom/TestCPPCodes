
    CREATE PROCEDURE [dbo].[USP_Group_Update]

        @GroupID		int,
        @GroupName		nvarchar(500),
        @DefaultAccess	nvarchar(100),
        @Description	nvarchar(max) = NULL,
        @ParentID   	int = 0 ,
        @InterfaceBindingStatus as bit  = 0,
		@SendDNS as bit = 0


    AS
    BEGIN
        SET NOCOUNT ON;
        declare @nTotalGroup int
        select @nTotalGroup=Count(*) from TGroup where ((GroupName		= @GroupName) and (GroupID<>@GroupID))
        if (@nTotalGroup>0)
        begin
            Raiserror ('Group name already exist', 16 , 10)
            return
        end
        UPDATE [VPNDataBase].[dbo].[TGroup]
                   
                SET
                GroupName		= @GroupName,
                DefaultAccess	= @DefaultAccess,
                GroupDescription= @Description,
                ParentID        = @ParentID ,
				InterfaceBindingStatus = @InterfaceBindingStatus,
				SendDNS	= @SendDNS
                WHERE
            
                GroupID = @GroupID	
        End

    go

