
	Create PROCEDURE [dbo].[USP_TInterface_Insert]
		-- Add the parameters for the stored procedure here
		@InterfaceID as int,
		@InterfaceName as nvarchar(50),
		@InterfaceIPAddress as nvarchar(20)
	
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		declare @Statement as nvarchar(1000)
	
		set @Statement = 'insert into TInterface (InterfaceID , InterfaceName,InterfaceIPAddress ) values ('
		if(@InterfaceID is not null)
			set @Statement = isnull(@Statement ,'') + '  ''' + convert(nvarchar(20),@InterfaceID) + ''','
		if(@InterfaceName is not null)
			set @Statement = isnull(@Statement ,'') + ' ''' + @InterfaceName	+''','
		if(@InterfaceIPAddress is not null)
			set @Statement = isnull(@Statement ,'''') + ' ''' + @InterfaceIPAddress +''','
		set @Statement = SUBSTRING(@Statement ,1,len(@Statement) -1)
		set @Statement = @Statement + ')'
		exec sp_executesql @Statement
	END

  go

