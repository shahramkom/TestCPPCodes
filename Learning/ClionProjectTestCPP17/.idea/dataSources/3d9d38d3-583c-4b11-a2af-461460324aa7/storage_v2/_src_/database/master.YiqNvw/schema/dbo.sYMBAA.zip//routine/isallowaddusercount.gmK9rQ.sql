
	CREATE FUNCTION [dbo].[ISAllowAddUSerCount]()
	RETURNS BIT
	AS
	BEGIN
			DECLARE  @retValCount bit
			DECLARE  @nTotalCount int , @nTotalUser int 
			select @nTotalCount = count(*) from  TUser
			select @nTotalUser  = [value] from TSetting where Property = 'TotalUser'
			if (@nTotalUser < @nTotalCount + 1 )
				SET @retValCount = 0
			else
				SET @retValCount = 1
			return @retValCount 
	END
  go

