/******************************************************************************************************************************************************/--
CREATE FUNCTION dbo.checkInterfaceOperate(@TableName VARCHAR(50))
RETURNS BIT
BEGIN
	DECLARE @retval AS BIT
	IF(@TableName = 'TInterface' OR @TableName = 'TUserInterface' OR @TableName = 'TGroupInterface')
		SET @retval = 1
	ELSE
		SET @retval = 0
	RETURN @retval
END
go

