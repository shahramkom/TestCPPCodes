/*************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[USP_SelectUserFromtempUser] 
        @Replace int 
AS
BEGIN
    
    --SET NOCOUNT ON;
             
    declare  @UserID				int	, 
    @GroupID			nvarchar(max)	,	
    @UserName			nvarchar(200)	 , 
    @BindingStatus		nvarchar(50)	 , 
    @BindingPCID		nvarchar(100)	 ,
    @IPBindingStatus	nvarchar(20)	 , 
    @SubNetIP			nvarchar(50)	 ,
    @SubNetMask			nvarchar(50)	 ,
    @VirtualIPStatus	nvarchar(50)	 ,			
    @VirtualIP			nvarchar(15)	 , 

    @UserPIN			nvarchar(200)	, 
    @MasterPIN			nvarchar(200)	, 
    @AuthenticationKey	nvarchar(64)	,	 
    @MustChangePIN		bit			, 	
    @AccountDisable		tinyInt			,
    @RejOnKeepAliveFail bit		,
	@ShowUserPrivilege	bit		,	


    @FirstName			nvarchar(200)		, 			 
    @LastName			nvarchar(200)		, 
    @Gender				nvarchar(10)		, 
    @Company			nvarchar(200)		, 
    @Office				nvarchar(200)		, 
    @Province			nvarchar(200)		,
    @Town    			nvarchar(200)		,	
    @Notes	 			nvarchar(max)		, 
    @Email	 			nvarchar(200)		, 
    @Cell	 			nvarchar(50)		, 
    @PersonnelCode	 			nvarchar(10)		, 
    @Phone	 			nvarchar(200)		, 
    @NationalID				nvarchar(10)		, 
    @Adress				nvarchar(max)		, 
    @PostalCode			nvarchar(200)	,
    @Owner				int					,
    @Permission_ID		int					,
    @res				nvarchar(500)		,
    @UnBlockPIN         nvarchar(50)

Declare User_cursor Cursor 
    For
    Select     [UserID], 
                [GroupID]
                ,[UserName]
                ,[BindingStatus]
                ,[BindingPCID]
                ,[IPBindingStatus]
                ,[SubNetIP]
                ,[SubNetMask]
                ,[VirtualIPStatus]
                ,[VirtualIP]
                ,[UserPIN]
                ,[MasterPIN]
                ,[AuthenticationKey]
                ,[MustChangePIN]
                ,[AccountDisable]
                ,[RejOnKeepAliveFail]
				,[ShowUserPrivilege]
                ,[FirstName]
                ,[LastName]
                ,[Gender]
                ,[Company]
                ,[Office]
                ,[Province]
                ,[Town]
                ,[Notes]
                ,[Email]
                ,[Cell]
                ,[PersonnelCode]
                ,[Phone]
                ,[NationalID]
                ,[Adress]
                ,[PostalCode]
                ,[Owner]
                ,[Permission_ID]
                ,[UnBlockPIN]
    FROM [VPNDataBase].[dbo].[TempUser]
    

OPEN User_cursor

FETCH NEXT FROM User_cursor 
INTO @UserID,
        @GroupID
        ,@UserName
        ,@BindingStatus
        ,@BindingPCID
        ,@IPBindingStatus
        ,@SubNetIP
        ,@SubNetMask
        ,@VirtualIPStatus
        ,@VirtualIP
        ,@UserPIN
        ,@MasterPIN
        ,@AuthenticationKey
        ,@MustChangePIN
        ,@AccountDisable
        ,@RejOnKeepAliveFail
		,@ShowUserPrivilege
        ,@FirstName
        ,@LastName
        ,@Gender
        ,@Company
        ,@Office
        ,@Province
        ,@Town
        ,@Notes
        ,@Email
        ,@Cell
        ,@PersonnelCode
        ,@Phone
        ,@NationalID
        ,@Adress
        ,@PostalCode
        ,@Owner
        ,@Permission_ID
        ,@unBlockPIN

WHILE @@FETCH_STATUS = 0
    Begin
        
        select @GroupID = GroupID from TGroup where GroupName = @GroupID
    begin try
        exec  USP_temp_User_Insert @UserID
            ,@GroupID
            ,@UserName
            ,@BindingStatus
            ,@BindingPCID
            ,@IPBindingStatus
            ,@SubNetIP
            ,@SubNetMask
            ,@VirtualIPStatus
            ,@VirtualIP
            ,@UserPIN
            ,@MasterPIN
            ,@AuthenticationKey
            ,@MustChangePIN
            ,@AccountDisable
            ,@RejOnKeepAliveFail
			,@ShowUserPrivilege
            ,@FirstName
            ,@LastName
            ,@Gender
            ,@Company
            ,@Office
            ,@Province
            ,@Town
            ,@Notes
            ,@Email
            ,@Cell
            ,@PersonnelCode
            ,@Phone
            ,@NationalID
            ,@Adress
            ,@PostalCode
            ,@Owner
            ,@Permission_ID,
            @Replace,
            @UnBlockPIN 
    end try
    begin catch
        select error_message()
    end catch

    FETCH NEXT FROM User_cursor 
    INTO  @UserID
            ,@GroupID
            ,@UserName
            ,@BindingStatus
            ,@BindingPCID
            ,@IPBindingStatus
            ,@SubNetIP
            ,@SubNetMask
            ,@VirtualIPStatus
            ,@VirtualIP
            ,@UserPIN
            ,@MasterPIN
            ,@AuthenticationKey
            ,@MustChangePIN
            ,@AccountDisable
            ,@RejOnKeepAliveFail
			,@ShowUserPrivilege
            ,@FirstName
            ,@LastName
            ,@Gender
            ,@Company
            ,@Office
            ,@Province
            ,@Town
            ,@Notes
            ,@Email
            ,@Cell
            ,@PersonnelCode
            ,@Phone
            ,@NationalID
            ,@Adress
            ,@PostalCode
            ,@Owner
            ,@Permission_ID
            , @UnBlockPIN 

    END		 
CLOSE User_cursor;
DEALLOCATE User_cursor;

END
go

