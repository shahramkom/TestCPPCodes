
CREATE FUNCTION [dbo].[SelCheckHealthGroupsUsers](@PROFILE_ID int)
	RETURNS NVARCHAR(MAX)
	AS
	BEGIN
		DECLARE @RETENVALUE NVARCHAR(MAX)  SET @RETENVALUE = ' '
		DECLARE @GROUPNAMES NVARCHAR(MAX)
		DECLARE @USERNAMES  NVARCHAR(MAX)
		select @GROUPNAMES = 'Groups:'+ stuff ((SELECT    ', '+ dbo.TGroup.GroupName
		FROM         dbo.HealthCheckGroupAssign INNER JOIN
						  dbo.TGroup ON dbo.HealthCheckGroupAssign.GroupID = dbo.TGroup.GroupID
		WHERE     (dbo.HealthCheckGroupAssign.ProfileID = @PROFILE_ID) for xml path('')) , 1 ,1 , '') 
		select @USERNAMES = ' Users:'+ stuff ((SELECT    ', '+ dbo.TUser.UserName
		FROM         dbo.HealthCheckUserAssign INNER JOIN
				  dbo.TUser ON dbo.HealthCheckUserAssign.UserID = dbo.TUser.UserID
		WHERE     (dbo.HealthCheckUserAssign.ProfileID = @PROFILE_ID) for xml path('')) , 1 ,1 , '')
		if(@GROUPNAMES is not null)
			SET @RETENVALUE =  @RETENVALUE + @GROUPNAMES  
		if(@USERNAMES is not null)
			SET @RETENVALUE =  @RETENVALUE + @USERNAMES
		RETURN @RETENVALUE
	END
go

