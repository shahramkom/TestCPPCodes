

--///////////K E Y H A N  (5)  S T O R E D  P R O C E D U R E S/////////////////////////////////
CREATE PROCEDURE [dbo].[ReadConnectionData] 
    @userID  AS INT
AS
BEGIN
	-- Read GroupsID 
	DECLARE @groupIds AS NVARCHAR(100)
	SELECT @groupIds = dbo.GetGroupsParent(CAST(@userID AS NVARCHAR(10)))     
	
	--Extract InterfaceBinding
	DECLARE @interfaceIPs AS NVARCHAR(MAX)
    SELECT @interfaceIPs = COALESCE(@interfaceIPs + ', ', '') + InterfaceIPAddress
    FROM TInterface AS ti, TUserInterface AS tui
    WHERE (tui.UserID = @userID AND ti.InterfaceID = tui.InterfaceID)

	SELECT @interfaceIPs = COALESCE(@interfaceIPs + ', ', '') + InterfaceIPAddress
	FROM TInterface AS ti, dbo.TGroupInterface AS tui
	WHERE ((tui.GroupID IN (SELECT items FROM dbo.Splitfn(@groupIds,','))) AND ti.InterfaceID = tui.InterfaceID)

	DECLARE @InterfaceBindingStatus AS BIT
	SET @InterfaceBindingStatus = 0
	if (@interfaceIPs is not null or @interfaceIPs <> '')
		SET @InterfaceBindingStatus = 1
		
	--Extract TimeSet
	DECLARE @userTimeSets AS NVARCHAR(MAX)
	DECLARE @timeSets AS NVARCHAR(MAX)

    SELECT @timeSets = COALESCE(@timeSets + ', ', '') + TimeStr
    FROM TTimeRole AS ti, TUserTimeSet AS tui
    WHERE (tui.UserID = @userID AND ti.TRID = tui.TimeSetId)

	IF(@timeSets = '' OR  @timeSets is null)
	BEGIN
		DECLARE @grpTimeSets AS NVARCHAR(MAX)
		SELECT @grpTimeSets = COALESCE(@grpTimeSets + ', ', '') + TimeStr
		FROM TTimeRole AS ti, dbo.TGroupTimeSet AS tui
		WHERE ((tui.GroupID IN (SELECT items FROM dbo.Splitfn(@groupIds,','))) AND ti.TRID = tui.TRID)

		SET @timeSets = @grpTimeSets
	END

	DECLARE @PermID AS INT
	DECLARE @ViewConnectionsPermission AS BIT
	SET @PermID = 0
	SET @ViewConnectionsPermission = 0
	SELECT @PermID = Permission_ID FROM TUser WHERE UserID = @userID
	IF(@PermID != 0)
		SELECT @ViewConnectionsPermission = ViewConn FROM SpecialPermission WHERE ID = @PermID

	SELECT UserID, UserName, AccountDisable, ExpireDate, @PermID AS Permission_ID, MustChangePIN, BindingStatus, BindingPCID, IPBindingStatus, SubNetIP, SubNetMask
	, @InterfaceBindingStatus AS InterfaceBindingStatus, @interfaceIPs AS interfaceIPs, VersionBindingStatus, BindingVersion, AuthType, LoginType, Cell, CertType, CertValue
	, AuthenticationKey, DisableModernPolicy, SendDNS, VirtualIP, LockModule, RejOnKeepAliveFail, @timeSets AS timeSet , LastLoginTime, FirstName, 
	LastName, LastConnectedIP, @ViewConnectionsPermission AS ViewConnectionPermission, Version, DriverType
	FROM TUser WHERE UserID = @userID
END
go

