
    CREATE PROCEDURE   [dbo].[UPS_TUserFirewallPolicy_Insert]

        @UFPID						int  =NULL ,
        @PSID						int	=NULL ,
        @Ac_ActionType				nvarchar(50)	=NULL ,
        @Ac_VirtualIP_Status		NVARCHAR(50)	=NULL ,
        @Ac_VirtualIP				nvarchar(15)	=NULL ,
        @Ac_Tunnel_Source_Type		nvarchar(50)	=NULL ,
        @Ac_Tunnel_Source_IP		nvarchar(15)	=NULL ,
        @Ac_Tunnel_Dest_Type		nvarchar(50)	=NULL ,
        @Ac_Tunnel_Dest_IP			nvarchar(15)	=NULL ,
        @Ac_Key_ID					nvarchar(100)	=NULL ,
        @Ac_AthenticationType		nvarchar(150)=NULL ,
        @Ac_AthenticationKey		nvarchar(150)=NULL ,
        @Ac_EncryptionType			nvarchar(150)=NULL ,
        @Ac_EncryptionKey			nvarchar(150)=NULL ,
    
        @Fil_Direction				nvarchar(50)	=NULL ,
        @Fil_Source_AdressType		nvarchar(50)	=NULL ,
    
        @Fil_Source_IPAdress		nvarchar(15)	=NULL ,
        @Fil_Source_NetworkMask		nvarchar(15)	=NULL ,
        @Fil_Dest_Type				nvarchar(50)	=NULL ,
        @Fil_Dest_IPAdress			nvarchar(15)	=NULL ,
        @Fil_Dest_NetworkMask		nvarchar(15)	=NULL ,
        @Fil_Protocol_Code			nvarchar(50)	=NULL ,
        @Fil_Protocol_SourcePort	nvarchar(50)	=NULL ,
        @Fil_Protocol_DestPort		nvarchar(50)	=NULL ,
        @Fil_AllowNAT				bit	= NULL ,
		@Compression				bit = 0,
		@status						bit =1,
        @POrder						int	=NULL 
    AS

    BEGIN
		declare @CreateDateTime as nvarchar(20)
		select @CreateDateTime = CONVERT(nvarchar(20),GETDATE(),20)
        
		INSERT INTO  TUserFirewallPolicy

        (
        PSID		            ,
        Ac_ActionType		    , 
        Ac_VirtualIP_Status		,
        Ac_VirtualIP		    ,
        Ac_Tunnel_Source_Type	,
        Ac_Tunnel_Source_IP		,
        Ac_Tunnel_Dest_Type		,
        Ac_Tunnel_Dest_IP		,
        Ac_Key_ID		        ,
        Ac_AthenticationType    ,
        Ac_AthenticationKey	    ,
        Ac_EncryptionType	    ,
        Ac_EncryptionKey	    ,
    
        Fil_Direction		    ,
        Fil_Source_AdressType	,
        Fil_Source_IPAdress		,
        Fil_Source_NetworkMask	,
        Fil_Dest_Type	        ,
        Fil_Dest_IPAdress		,
        Fil_Dest_NetworkMask	,
        Fil_Protocol_Code		,
        Fil_Protocol_SourcePort	,
        Fil_Protocol_DestPort	,
        Fil_AllowNAT		    ,
		Compression				,
		CreateTime				,
		LastModifiedTime		,
		status					,
        POrder		
        )
        VALUES
        (
        @PSID		,
        @Ac_ActionType		,
        @Ac_VirtualIP_Status		,
        @Ac_VirtualIP		,
        @Ac_Tunnel_Source_Type		,
        @Ac_Tunnel_Source_IP		,
        @Ac_Tunnel_Dest_Type		,
        @Ac_Tunnel_Dest_IP		,
        @Ac_Key_ID		,
        @Ac_AthenticationType	,
        @Ac_AthenticationKey	,
        @Ac_EncryptionType	,
        @Ac_EncryptionKey	,	
        @Fil_Direction		,
        @Fil_Source_AdressType		,
        @Fil_Source_IPAdress		,
        @Fil_Source_NetworkMask		,
        @Fil_Dest_Type	,
        @Fil_Dest_IPAdress		,
        @Fil_Dest_NetworkMask		,
        @Fil_Protocol_Code		,
        @Fil_Protocol_SourcePort		,
        @Fil_Protocol_DestPort		,
        @Fil_AllowNAT				,
		@Compression				,
		@CreateDateTime				,
		@CreateDateTime				,
		@status						,	
        @POrder		
        )
        SET @UFPID = SCOPE_IDENTITY()
		select @UFPID

    END

    go

