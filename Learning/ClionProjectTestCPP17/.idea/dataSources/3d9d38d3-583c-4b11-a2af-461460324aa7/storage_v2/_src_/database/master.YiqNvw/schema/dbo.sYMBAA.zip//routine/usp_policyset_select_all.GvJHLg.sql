
    create PROCEDURE  [dbo].[USP_PolicySet_Select_All] 
    AS

    BEGIN

        SELECT  * from  TPolicySet 
    END

    go

