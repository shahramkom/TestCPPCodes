
    CREATE PROCEDURE  [dbo].[USP_TGroup_Filter]
        @GroupName   nvarchar(500) = null
    AS
    BEGIN
        --SET NOCOUNT ON;
    
        SELECT * from TGroup where GroupName = @GroupName
    END

    go

