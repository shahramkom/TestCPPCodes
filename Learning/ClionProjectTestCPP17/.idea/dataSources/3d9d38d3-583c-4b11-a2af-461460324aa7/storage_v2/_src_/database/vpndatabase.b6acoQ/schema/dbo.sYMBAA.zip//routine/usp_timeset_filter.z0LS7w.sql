
    CREATE PROCEDURE [dbo].[USP_Timeset_Filter]
        -- Add the parameters for the stored procedure here
        @TimeSetID int,
        @TimeSetName nvarchar(50)
    AS
    BEGIN
        SET NOCOUNT ON;
        -- Insert statements for procedure here
        if(@TimeSetID = 0)
            select TRID from TTimeRole where TimeSetName = @TimeSetName
        else if(@TimeSetName = 'Null')
            select TimeSetName from TTimeRole where TRID = @TimeSetID
    END


    go

