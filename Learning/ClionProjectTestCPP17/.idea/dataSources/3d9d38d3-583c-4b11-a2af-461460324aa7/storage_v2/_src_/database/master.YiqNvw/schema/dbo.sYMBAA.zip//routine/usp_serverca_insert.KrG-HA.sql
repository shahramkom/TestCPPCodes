
    CREATE PROCEDURE [dbo].[USP_ServerCA_Insert]
            @ServerCA nvarchar(MAX)
    AS
    BEGIN	
        insert into TServerCA (ServerCA) VALUES(@ServerCA)
    END

    go

