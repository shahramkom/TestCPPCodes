CREATE FUNCTION [dbo].[GetUserGroupGID]
(
	@userID INT  
)
RETURNS VARCHAR(25)
AS
BEGIN
	DECLARE @gid AS VARCHAR(25)
	SET @gid = NULL
	
	SELECT @gid = gid FROM dbo.TUserGroups WHERE UserID = @userID
	
	RETURN @gid
END
go

