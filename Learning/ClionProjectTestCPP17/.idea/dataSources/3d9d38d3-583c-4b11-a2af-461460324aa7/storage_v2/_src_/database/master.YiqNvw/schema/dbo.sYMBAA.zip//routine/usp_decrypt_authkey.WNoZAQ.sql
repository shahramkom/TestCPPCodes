
    CREATE proc [dbo].[USP_Decrypt_AuthKey] 
        @userID bigint
    as
    begin	
        declare @EncAuthKey nvarchar(64)
        begin try
            DROP TABLE #Table
        end try
        begin catch	
        end catch
        create table #Table(
            CommandLine nvarchar(200),
            Param1		nvarchar(200),
            [Output]	nvarchar(64)
        )


        select @EncAuthKey = AuthenticationKey from TUser where USerID = @userID	
        insert into #Table EXEC Master..XYRunProc 'UserLogin','keya'	
        insert into #Table EXEC Master..XYRunProc 'Decrypt' ,@EncAuthKey	
    
        select [output] from #Table where CommandLine = 'Decrypt'

        drop table #Table
    end

    go

