--------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ReadUserScripts] 
	@UserID INT
AS
BEGIN
	DECLARE @GroupsID VARCHAR(1000)
	SET @GroupsID = dbo.GetAllRelatedGroupsOfUser(@UserID);

	SELECT DISTINCT ScriptTitle,ScriptText FROM TScript 
		LEFT OUTER JOIN TUserscripts ON TScript.ScriptID = TUserscripts.ScriptID
		LEFT OUTER JOIN TGroupScript ON TScript.ScriptID = TGroupScript.ScriptID
		WHERE  (ScriptActivity = 1 AND ((TUserscripts.UserID = @UserID)
		OR (TGroupScript.GroupID IN (SELECT items FROM dbo.Splitfn(@GroupsID, ',')))))
	
END
go

