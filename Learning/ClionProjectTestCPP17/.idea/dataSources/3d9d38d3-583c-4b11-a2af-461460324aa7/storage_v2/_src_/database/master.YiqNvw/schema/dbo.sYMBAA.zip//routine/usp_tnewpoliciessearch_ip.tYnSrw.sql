
  Create PROCEDURE [dbo].[USP_TNewPoliciesSearch_IP] 
	@IP	nvarchar(50) 
AS
BEGIN
	if (@IP = '')
	begin
		exec USP_TNewPolicyMain_Select
		return
	end	
	SELECT *  ,dbo.SelModernPolGroupsUsers(MP.ID)AS Assignments
			FROM [dbo].[TNewPolicyMainTable] AS MP
		WHERE
		(dbo.fnIsInRangeIPDword(MP.SourceTunnelValue, @IP) = 1) OR
		(dbo.fnIsInRangeIPDword(MP.DestinationTunnelValue, @IP) = 1)
END

  go

