
	CREATE PROCEDURE [dbo].[USP_SelectTGroupInterfaceFromImportedBackupData] 
			-- Add the parameters for the stored procedure here
			 @Replace bit	
		AS
		BEGIN
			-- SET NOCOUNT ON added to prevent extra result sets from
			-- interfering with SELECT statements.
			SET NOCOUNT ON;
        
		declare @groupID nvarchar(200), @InterfaceID nvarchar(200),@InsertScript nvarchar(4000)

		 Declare TGroupInterface_cursor Cursor FAST_FORWARD
			For
			Select 
					 InterfaceID,GroupID,[output] 
				FROM tbl_InsertGroupScript   
				where tableName = 'TGroupInterface'
				OPEN TGroupInterface_cursor

		FETCH NEXT FROM TGroupInterface_cursor
		INTO @InterfaceID,@groupID,@InsertScript

		WHILE @@FETCH_STATUS = 0
		begin 
				BEGIN TRY
				if(exists (select InterfaceID from TInterface where InterfaceID = @InterfaceID ))
				begin
					if(exists (select * from TGroupInterface where InterfaceID = @InterfaceID  and GroupID = @groupID ))
					Begin
						if(@Replace = '1')
							 Delete from TGroupInterface   where InterfaceID = @InterfaceID  and GroupID = @groupID
					End
					--SET IDENTITY_INSERT TGroupInterface ON
					 exec sp_executesql @InsertScript
					--SET IDENTITY_INSERT TGroupInterface OFF
					update TGroup set InterfaceBindingStatus = 'True' where GroupID = @groupID	
				End
				END TRY
				BEGIN CATCH
				
					INSERT INTO [VPNDataBase].[dbo].[TSqlError]
				   ([userid]
				   ,[moment]
				   ,[operate]
				   ,[errorcode]
				   ,[errortext]
				   ,[comment])
			 VALUES
				   (1
				   ,getdate()
				   ,@InsertScript
				   ,@@Error
				   ,Error_MESSAGE()
				   ,N'USP_SelectTGroupInterfaceFromImportedBackupData')	   
				 END CATCH
                    
				FETCH NEXT FROM TGroupInterface_cursor 
				 INTO @InterfaceID,@groupID,@InsertScript
    
			end
			CLOSE TGroupInterface_cursor;
			DEALLOCATE TGroupInterface_cursor;		
		END

  go

