CREATE PROCEDURE [dbo].[USP_CompletUpdateUserinfo] 
	@UserID BIGINT,
	@UserIP varchar(20),
	@LoginTime varchar(20),
	@ChangeIP bit,
	@Version varchar(11)
AS
BEGIN
	if(@ChangeIP = 1)
		update TUSER SET LastConnectedIP = @UserIP , LastLoginTime = @LoginTime, Version = @Version WHERE UserID = @UserID
	else
		update TUSER SET LastLoginTime = @LoginTime, Version = @Version WHERE UserID = @UserID
END
go

