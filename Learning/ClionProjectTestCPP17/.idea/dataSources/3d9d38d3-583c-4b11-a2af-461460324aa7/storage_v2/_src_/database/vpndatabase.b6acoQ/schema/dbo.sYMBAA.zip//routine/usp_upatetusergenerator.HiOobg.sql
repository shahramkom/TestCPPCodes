
    
    CREATE PROCEDURE [dbo].[USP_UpateTUserGenerator]
     as
    
    begin try
            DROP TABLE #tbl_UpdateGroupScript
        end try
        begin catch
        --RAISERROR ('Error raised in TRY block.', 16, 1);
        end catch
        create table #tbl_UpdateGroupScript(
            [Output]	nvarchar(max)
        )
    --Declare a cursor to retrieve column specific information for the specified table
    DECLARE cursCol CURSOR FAST_FORWARD FOR 
    SELECT UserID,BindingStatus,BindingPCID FROM TUser  --where GroupID in(@GroupID)
    OPEN cursCol
    DECLARE @string nvarchar(3000) --for storing the first half of INSERT statement
    DECLARE @stringData nvarchar(3000) --for storing the data (VALUES) related statement




    SET @string='Update TUser SET  '
    SET @stringData=''

    declare @UserId int 
    declare @BindingStatus nvarchar(50)
    declare @BindingPCID nvarchar(100)

    FETCH NEXT FROM cursCol INTO @UserId,@BindingStatus,@BindingPCID

    IF @@fetch_status<>0
        begin
        print 'Table TUser'+' not found, processing skipped.'
        close curscol
        deallocate curscol
        return
    END

    WHILE @@FETCH_STATUS=0
    BEGIN

        if @BindingStatus is NULL
            set @string = @string + 'BindingStatus=' + isnull(@BindingStatus ,'NULL')+' , '	
        else 
			if(@BindingStatus != 'UnBound')
        		    set @string = @string + 'BindingStatus=''' + isnull(@BindingStatus ,'NULL') +''' , '
        
         if @BindingPCID is NULL
            set @string = @string + 'BindingPCID=' + isnull(@BindingPCID ,'NULL')+'  '	
        else 
			if(@BindingStatus != 'UnBound')
            		    set @string = @string + 'BindingPCID=''' + isnull(@BindingPCID ,'NULL')+'''  '	
    
        set @string = @string + ' where UserID='        + isnull(cast(@UserId as nvarchar(100)),'NULL') 
        insert #tbl_UpdateGroupScript([Output])values(@string)
        set @string = 'Update TUser SET  '

    FETCH NEXT FROM cursCol INTO  @UserId,@BindingStatus,@BindingPCID
    END


    CLOSE cursCol
    DEALLOCATE cursCol
    insert into TUser_Update_Script select * from #tbl_UpdateGroupScript


    go

