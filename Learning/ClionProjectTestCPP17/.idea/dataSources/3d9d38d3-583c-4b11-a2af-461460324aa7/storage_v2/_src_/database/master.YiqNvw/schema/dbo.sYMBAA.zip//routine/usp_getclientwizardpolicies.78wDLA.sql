
	Create PROCEDURE [dbo].[USP_GetClientWizardPolicies] 
		@UserID nvarchar(50),
		@UserIP nvarchar(50) = NULL
	AS
	BEGIN
	Declare @GroupsID Nvarchar(100)
	Declare @LastConnectedIP Nvarchar(20)
	SET @LastConnectedIP = NULL
	SET @GroupsID = dbo.GetGroupsParent( @UserID );
			
	with CTE_NewPolicy as
	(
		select ApplyTime
		from TNewPolicyMainTable
		group by ApplyTime
	)

	SELECT DISTINCT groupedPolicies.*,
	TNewPoliciesServices.ProtocolType,TNewPoliciesServices.SourcePort,TNewPoliciesServices.DestinationPort
	,TNewPoliciesAlgorithms.EncryptionAlgorithm,TNewPoliciesAlgorithms.IntegrityAlgorithm
	,TNewPoliciesDetails.AllowNat,TNewPoliciesDetails.VirtualIPType
	,TNewPoliciesDetails.VirtualIPValue,TNewPoliciesDetails.SourceTunnelType AS DetSourceTunnelType,TNewPoliciesDetails.SourceTunnelValue AS DetSourceTunnelValue,
	TNewPoliciesDetails.DestinationTunnelType AS DetDestinationTunnelType,TNewPoliciesDetails.DestinationTunnelValue AS DetDestinationTunnelValue
	FROM
	(
	SELECT newPolMain.ID,newPolMain.PolicyType,newPolMain.Name,newPolMain.Enablity
	,newPolMain.ServicesID,newPolMain.EncryptionID
	,newPolMain.Compression,newPolMain.PolicyOrder,newPolMain.ApplyTime
	,newPolMain.sourceTunnelType,newPolMain.sourceTunnelValue,newPolMain.DestinationTunnelType
	,newPolMain.DestinationTunnelValue,newPolMain.DirectionType
	,newPolMain.EncryptionKey,newPolMain.IntegrityKey,newPolMain.TunnelID
	FROM TNewPolicyMainTable AS newPolMain
	LEFT OUTER JOIN TNewPolicyUserAssign ON newPolMain.ID = TNewPolicyUserAssign.ModernPID
	LEFT OUTER JOIN TNewPolicyGroupAssign ON newPolMain.ID = TNewPolicyGroupAssign.ModernPID
	RIGHT OUTER JOIN CTE_NewPolicy ON CTE_NewPolicy.ApplyTime = newPolMain.ApplyTime
	WHERE (newPolMain.Enablity = 1)
	AND (( TNewPolicyUserAssign.UserID = cast(@UserID AS BIGINT) )
	OR ( TNewPolicyGroupAssign.GroupID IN (SELECT CAST(items AS BIGINT) from dbo.Splitfn(@GroupsID , ',')) ))
	) AS groupedPolicies
	LEFT OUTER JOIN TNewPoliciesServices ON groupedPolicies.ServicesID = TNewPoliciesServices.ID
	LEFT OUTER JOIN TNewPoliciesAlgorithms ON groupedPolicies.EncryptionID = TNewPoliciesAlgorithms.ID 
	LEFT OUTER JOIN TNewPoliciesDetails ON groupedPolicies.ID = dbo.TNewPoliciesDetails.MainID
	ORDER BY groupedPolicies.ApplyTime DESC, groupedPolicies.PolicyOrder ASC
	END

  go

