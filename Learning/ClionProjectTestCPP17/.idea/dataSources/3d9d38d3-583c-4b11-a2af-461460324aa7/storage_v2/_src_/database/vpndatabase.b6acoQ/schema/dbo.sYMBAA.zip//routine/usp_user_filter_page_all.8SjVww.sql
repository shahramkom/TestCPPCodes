   
CREATE PROCEDURE [dbo].[USP_USER_FILTER_Page_ALL]
    @UserID NVARCHAR(MAX) = NULL,
    @UserName NVARCHAR(MAX) = NULL,
    @LastName NVARCHAR(200) = NULL,
    @AccountDisable tinyInt = NULL,
    @GroupID INT = NULL,
    @BindingStatus NVARCHAR(50) = NULL,
    @BindingPCID NVARCHAR(100) = NULL,
    @VirtualIPStatus NVARCHAR(50) = NULL,
    @VirtualIP NVARCHAR(15) = NULL,
    @Owner INT = NULL,
    @UserPerm INT = NULL,
    @OrderField NVARCHAR(50) = NULL,
    @GroupIdList NVARCHAR(MAX) = NULL,
    @LoginTimeStr NVARCHAR(15) = NULL,
    @moreCretria NVARCHAR(500) = NULL,
    @ModuleSerial NVARCHAR(50) = NULL
AS
BEGIN
    DECLARE @ExecQuery AS NVARCHAR(MAX) 
    DECLARE @pagNum AS INT,
        @pagSize AS INT,
        @lbound AS INT,
        @ubound AS INT,
        @recct AS INT

    DECLARE @miniType AS INT 
    DECLARE @PemId AS INT
    DECLARE @filter AS NVARCHAR(MAX)
    DECLARE @selectFields AS NVARCHAR(MAX)

    DECLARE @UserCount AS INT
    SET @UserCount = 0
    DECLARE @SpecialpermGID AS INT	

    SELECT  @SpecialPermGID = GroupID
    FROM    TGroup
    WHERE   GroupName = 'Special Users'
    
    IF ( @UserPerm IS NULL
         OR @UserPerm = 1 )
        BEGIN 
            SET @SpecialPermGID = 0
        END
    ELSE
        BEGIN
            SELECT  @PemId = Permission_ID
            FROM    Tuser
            WHERE   UserID = @UserPerm
            SELECT  @miniType = MiniAdminType
            FROM    SpecialPermission
            WHERE   ID = @PemId
        END	
    IF ( @ModuleSerial IS NOT NULL )
        BEGIN
            SET @ExecQuery = 'select * from (
			Select TUser.UserID,UserName,BindingStatus,BindingPCID ,IPBindingStatus '
                + ',SubNetIP,SubNetMask,VirtualIPStatus,VirtualIP,UserPIN,MasterPIN,AuthenticationKey,MustChangePIN,AccountDisable  '
                + +',RejOnKeepAliveFail,ShowUserPrivilege,FirstName,LastName,Gender,Company,Office,Province,Town,Notes,Email,Cell,PersonnelCode,Phone,NationalID,Adress,
			PostalCode,Owner, Permission_ID,UnBlockPIN ,AuthType,CertType,CertValue,dbo.RetrieveGroupNames(TUser.UserID) as GroupNames,
			 dbo.RetrievePSNames(TUser.UserID)as UserPolicies,InterfaceBindingstatus,dbo.RetrieveInterfaceNames(TUser.UserID) as InterfaceNames,
			 LoginType,LockModule,ExpireDate,VersionBindingStatus,BindingVersion,CreateTime,LastModifiedTime,SendDNS,
			 DisableModernPolicy,LastConnectedIP,LastLoginTime,TUser.GID,Version,DriverType,DisableResult,(ROW_NUMBER() OVER(ORDER BY TUser.userID)) AS row '
                + 'FROM TUser 
			inner join TUserKeya on TUser.UserID = TUserKeya.UserID where (TUserKeya.KeyaSerial = ''' + @ModuleSerial
                + ''') '
        END
    ELSE
        BEGIN
            SET @ExecQuery = 'select * from (
				Select UserID,UserName,BindingStatus,BindingPCID ,IPBindingStatus '
                + ',SubNetIP,SubNetMask,VirtualIPStatus,VirtualIP,UserPIN,MasterPIN,AuthenticationKey,MustChangePIN,AccountDisable  '
                + +',RejOnKeepAliveFail,ShowUserPrivilege,FirstName,LastName,Gender,Company,Office,Province,Town,Notes,Email,Cell,PersonnelCode,Phone,NationalID,Adress,
				PostalCode,Owner, Permission_ID,UnBlockPIN ,AuthType,CertType,CertValue,dbo.RetrieveGroupNames(UserID) as GroupNames,
				 dbo.RetrievePSNames(UserID)as UserPolicies,InterfaceBindingstatus,dbo.RetrieveInterfaceNames(UserID) as InterfaceNames,
				 LoginType,LockModule,ExpireDate,VersionBindingStatus,BindingVersion,CreateTime,LastModifiedTime,SendDNS,
				 DisableModernPolicy,LastConnectedIP,LastLoginTime,TUser.GID,Version,DriverType,DisableResult,(ROW_NUMBER() OVER(ORDER BY userID)) AS row '
                + 'FROM TUser 
					Where (1=1) '
        END
			---------------------------------------------------------- 
			--Create filter query by splitting userIDs
    IF ( @UserID IS NOT NULL )
        BEGIN
            DECLARE UserIDs_cursor CURSOR
            FOR
            SELECT  *
            FROM    dbo.Splitfn(@UserID, ',')
            DECLARE @SplittedUID NVARCHAR(30)

            OPEN UserIDs_cursor

            FETCH NEXT FROM UserIDs_cursor 
			INTO @SplittedUID
            DECLARE @IDCount INT
            SET @IDCount = 1
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    IF ( @SplittedUID <> '' )
                        BEGIN
                            IF ( @IDCount = 1 )
								SET @ExecQuery = @ExecQuery + 'AND (( UserID LIKE N''%' + @SplittedUID + '%'') '
                            ELSE
                                SET @ExecQuery = @ExecQuery + 'OR ( UserID LIKE N''%' + @SplittedUID + '%'') '
                            SET @IDCount = @IDCount + 1
                        END
                    FETCH NEXT FROM UserIDs_cursor 
				INTO @SplittedUID
                END

            CLOSE UserIDs_cursor;
            DEALLOCATE UserIDs_cursor;
				
            SET @ExecQuery = @ExecQuery + ')'
        END
			---------------------------------------------------------- 
			--Create filter query by splitting usernames
    IF ( @Username IS NOT NULL )
        BEGIN
            DECLARE UserNames_cursor CURSOR
            FOR
            SELECT  *
            FROM    dbo.Splitfn(@Username, ',')
            DECLARE @SplittedUName NVARCHAR(30)

            OPEN UserNames_cursor

            FETCH NEXT FROM UserNames_cursor 
			INTO @SplittedUName
            DECLARE @NameCount INT
            SET @NameCount = 1
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    IF ( @SplittedUName <> '' )
                        BEGIN
                            IF ( @NameCount = 1 )
                                SET @ExecQuery = @ExecQuery + 'AND (( UserName LIKE N''%' + @SplittedUName + '%'') '
                            ELSE
                                SET @ExecQuery = @ExecQuery + 'OR ( UserName LIKE N''%' + @SplittedUName + '%'') '
                            SET @NameCount = @NameCount + 1
                        END
                    FETCH NEXT FROM UserNames_cursor 
				INTO @SplittedUName
                END

            CLOSE UserNames_cursor;
            DEALLOCATE UserNames_cursor;
				
            SET @ExecQuery = @ExecQuery + ')'
        END
			---------------------------------------------------------- 
    IF ( @GroupID IS  NOT NULL )
        BEGIN
            SET @ExecQuery = ISNULL(@ExecQuery, '')
                + 'AND(TUser.UserID in (select UserID from TUserGroups where GroupID ='
                + ISNULL(CAST(@GroupID AS NVARCHAR(100)), '') + '))' 
            SELECT  @UserCount = COUNT(*)
            FROM    TUserGroups
            WHERE   GroupID = @GroupID
        END
    IF ( @GroupID IS NULL )
        IF ( @UserPerm = 1 )
            SET @ExecQuery = ISNULL(@ExecQuery, '') + 'AND(TUser.UserID in( select UserID from TUser ))' 
        ELSE
            IF ( @miniType = 1 )--powered mini admin
                BEGIN
                    SET @ExecQuery = ISNULL(@ExecQuery, '')
                        + 'AND(TUser.UserID in(select UserID from TUser where UserID not in (select UserId from TuserGroups where GroupID = '
                        + ISNULL(CAST(@SpecialPermGID AS NVARCHAR(100)), '') + ')))' 
                END
            ELSE
                IF ( @miniType = 2
                     AND @GroupIdList IS NOT NULL )--limited mini admin
                    SET @ExecQuery = ISNULL(@ExecQuery, '')
                        + 'AND(TUser.UserID in(select UserID from TUser where UserID in (select UserId from TuserGroups where GroupID in( '
                        + ISNULL(CAST(@GroupIdList AS NVARCHAR(MAX)), '') + '))))' 
                ELSE
                    IF ( @GroupIdList IS NULL )
                        RETURN
	IF ( @BindingStatus IS NOT NULL AND charindex('Multi Bind', @BindingStatus) > 0 )
	BEGIN
		DECLARE @operaotr AS CHAR(2)
		SET @operaotr = substring(@BindingStatus ,12,2)
		SET @ExecQuery = @ExecQuery + 'AND (charindex(''Bind at'', BindingStatus) > 0 AND cast(substring(BindingStatus ,13,2) as int) '+ @operaotr + @BindingPCID +' ) '
	END
	IF ( @BindingStatus IS NOT NULL AND @BindingStatus = 'Bind at' )
        SET @ExecQuery = @ExecQuery + 'AND (BindingStatus LIKE N''%' + @BindingStatus + '%'') '
    
	IF ( @BindingPCID IS NOT NULL AND charindex('Multi Bind', @BindingStatus) <= 0 )
        SET @ExecQuery = @ExecQuery + 'AND (BindingPCID LIKE N''%' + @BindingPCID + '%'') '
    IF ( @VirtualIPStatus IS NOT NULL )
        SET @ExecQuery = @ExecQuery + 'AND (VirtualIPStatus = ''' + @VirtualIPStatus + ''') '
    IF ( ( @VirtualIP IS NOT NULL )
         AND ( @VirtualIP != '' ) )
        SET @ExecQuery = @ExecQuery + 'AND (VirtualIP = ''' + @VirtualIP + ''')'
    IF ( @AccountDisable IS NOT NULL )
	BEGIN
		IF ( @AccountDisable = 254 )
			SET @ExecQuery = @ExecQuery + 'AND (AccountDisable != 255) '
		ELSE
			SET @ExecQuery = @ExecQuery + 'AND (AccountDisable = ' + CAST(@AccountDisable AS NVARCHAR(5)) + ') '
	END
    IF ( @LastName IS NOT NULL )
        SET @ExecQuery = @ExecQuery + 'AND (LastName LIKE N''%' + @LastName + '%'') '
    IF ( @Owner IS NOT NULL )
        SET @ExecQuery = @ExecQuery + 'AND ([Owner]=' + CAST(@Owner AS NVARCHAR(10)) + ')'
    IF ( @moreCretria IS NOT NULL )
        SET @ExecQuery = @ExecQuery + 'AND (' + @moreCretria + ') '
    IF ( @LoginTimeStr IS NOT NULL )
        SET @ExecQuery = @ExecQuery + 'AND (substring(LastLoginTime,1,10)' + @LoginTimeStr + ') '
    SET @ExecQuery = @ExecQuery + '  )as tbl1'
    IF ( @OrderField IS NOT NULL )
        SET @ExecQuery = @ExecQuery + ' ORDER by ' + @OrderField + ' '
        
    EXEC dbo.sp_executesql @ExecQuery
    IF ( @GroupID IS NOT NULL )
        SELECT  @UserCount
END

/******************************************************************************************************************************************************/------------------------------------------------
go

