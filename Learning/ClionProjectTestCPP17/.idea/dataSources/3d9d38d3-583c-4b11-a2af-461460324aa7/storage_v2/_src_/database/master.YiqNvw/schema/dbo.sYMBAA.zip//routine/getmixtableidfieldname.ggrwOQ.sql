/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.GetMixTableIDFieldName(@TableName VARCHAR(50))
RETURNS VARCHAR(50)
BEGIN
	DECLARE @TableIDFieldName AS VARCHAR(50)
	SET @TableIDFieldName = 
	(CASE 	
			WHEN @TableName = 'TgroupScript' OR @TableName = 'TUserScripts' OR @TableName = 'TScript'
			THEN 'ScriptID'
			WHEN @TableName = 'TGroupPolicySet' OR @TableName = 'TUserPolicySet' OR @TableName = 'TPolicySet'
			THEN 'PSID'
			WHEN @TableName = 'TgroupDNS' OR @TableName = 'TUserDNS' OR @TableName = 'TDNS'
			THEN 'DNSID'
			WHEN @TableName = 'TUserKeya' OR @TableName = 'TUserGroups' OR @TableName = 'TUser'
			THEN 'UserID'
			WHEN @TableName = 'TgroupTimeset'  OR @TableName = 'TTimeRole'
			THEN 'TRID'
			WHEN @TableName = 'TGroupInterface' OR @TableName = 'TUserInterface' OR @TableName = 'TInterface'
			THEN 'InterfaceID'
			WHEN @TableName = 'TUserTimeSet'
			THEN 'TimeSetId'
			WHEN @TableName = 'TServerAccessPolicy' 
			THEN 'PolicyID'
			WHEN @TableName = 'TUserFirewallPolicy'
			THEN 'UFPID'
			WHEN @TableName = 'TGroup'
			THEN 'GroupID'
			WHEN @TableName = 'SpecialPermission'
			THEN 'ID'
			WHEN @TableName = 'TPermissionGroup'
			THEN 'Permission_ID'
	END)	
	RETURN @TableIDFieldName
END
go

