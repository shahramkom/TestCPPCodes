
        CREATE PROCEDURE USP_checkAndCorrect44SpecialPermissions 
    -- Add the parameters for the stored procedure here
    
		AS
		BEGIN
			-- SET NOCOUNT ON added to prevent extra result sets from
			-- interfering with SELECT statements.
			SET NOCOUNT ON;

			-- Insert statements for procedure here
			--check and correct log and reports  permissions 
			update SpecialPermission set [ViewAuthLog] = 'true',
										 [ExportAuthLog] = 'true',
										 [ViewKeyhanMngLog] = 'true',
										 [ViewSettingServerLog] = 'true',
										 [ViewUserReport] = 'true',
										 [ChangeDB] = 'true',
										 [ViewConn] = 'true'
										 where 
										 (([ViewAuthLog] = 'true' or
										 [ExportAuthLog] = 'true') and
										 [ViewKeyhanMngLog] = 'true' and 
										 [ViewSettingServerLog] = 'true' and
										 [ViewUserReport] = 'true' and [ViewConn] = 'true'	)
 
                                 
		--check and correct policy management  permissions 	                             
		update SpecialPermission set     [PolicyMngmnt]   = 'true',
										 [PolicyMngmntView]   = 'true',
										 [PolicyGrpMngmntView]   = 'true',
										 [PolicyGrpMngmnt]   = 'true',
										 [ChangeDB] = 'true'

										 where 
										 ([PolicyMngmnt]   = 'true' and
										 [PolicyMngmntView]   = 'true' and
										 [PolicyGrpMngmntView]   = 'true' and
										 [PolicyGrpMngmnt]   = 'true'  )	
                                                              
		update SpecialPermission set     [TimeMngmntView]    = 'true',
										 [TimeMngmnt]    = 'true',
										 [DNSMngmntView]    = 'true',
										 [DNSMngmnt]    = 'true',
										 [ScriptMngmnt] = 'true',
										 [ScriptMngmntView] = 'true',
										 [ChangeDB] = 'true'
										 where 
										 (([TimeMngmntView]    = 'true' and
										 [TimeMngmnt]    = 'true' ) and
										 ([DNSMngmntView]    = 'true' and
										 [DNSMngmnt]    = 'true') and
										 ([ScriptMngmnt] = 'true' and
										 [ScriptMngmntView] = 'true' ))
                                
		update SpecialPermission set     [UserMngmntView]      = 'true',
										 [UserMngmnt]      = 'true',
										 [ChangeDB] = 'true'
                                 
										 where 
										 ( [UserMngmntView]     = 'true' and
											[UserMngmnt]     = 'true')	
									 
		update SpecialPermission set     [GroupMngmnt]      = 'true',
										 [GroupMngmntView]      = 'true',
										 [ChangeDB] = 'true'
                                 
										 where 
										 ( [GroupMngmnt]     = 'true' and
										   [GroupMngmntView]     = 'true')

		update SpecialPermission set     [ExportImportUserInfo]      = 'true',
										 [ImportUserInfo]      = 'false',
										 [ExportUserInfo]      = 'false',
										 [DenyExportImportUserInfo]      = 'false',
										 [ChangeDB] = 'true'
                                 
										 where 
										 ( [ExportImportUserInfo]     = 'true' )

		update SpecialPermission set     [ExportImportUserInfo]      = 'false',
										 [ImportUserInfo]      = 'false',
										 [ExportUserInfo]      = 'false',
										 [DenyExportImportUserInfo]      = 'false',
										 [ChangeDB] = 'true'
                                 
										 where 
										 ( [ExportImportUserInfo]     = 'false' )									 		                             
                                 
    
        
		END

        go

