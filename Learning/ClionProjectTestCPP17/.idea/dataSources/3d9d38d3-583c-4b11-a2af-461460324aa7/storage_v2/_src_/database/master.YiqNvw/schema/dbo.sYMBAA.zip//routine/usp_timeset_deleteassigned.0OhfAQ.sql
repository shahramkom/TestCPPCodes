


    CREATE PROCEDURE [dbo].[USP_TimeSet_DeleteAssigned]
    @TRID int,
    @GroupID int
    AS
    BEGIN	
        Delete from TGroupTimeSet
            where TRID=@TRID and GroupID=@GroupID
    END

    go

