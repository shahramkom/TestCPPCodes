CREATE PROCEDURE [dbo].[sp_AddEdit_Sell]
	@Code           		int,
	@CustomerCode	int, 
	@ProductCode		int, 
	@SerialNumber		varchar(100),
	@InstallKey		varchar(100),
	@Number		int,
	@LoanFlag		bit,
	@DeliveryDate		datetime,
	@FactorDate		datetime,
	@FactorNumber		varchar(100),
	@Comment 		nvarchar(100)	


	
AS
	-- for Add
	if (@Code = 0)
	begin
		 Insert     Sells  (CustomerCode, ProductCode, SerialNumber, InstallKey, Number, LoanFlag, DeliveryDate, FactorDate, FactorNumber, Comment)
			values (@CustomerCode, @ProductCode, @SerialNumber, @InstallKey, @Number, @LoanFlag, @DeliveryDate, @FactorDate, @FactorNumber, @Comment	)
			select N'Successfully insert the record in to database.' as ErrMsg
		return ;
	end

	-- for Edit
	Update Sells   set
		ProductCode	 = @ProductCode,	
		CustomerCode	 = @CustomerCode,
		SerialNumber	= @SerialNumber,	
		InstallKey	= @InstallKey,		
		Number		= @Number,			
		LoanFlag	= @LoanFlag,		
		DeliveryDate	= @DeliveryDate,	
		FactorDate	= @FactorDate,		
		FactorNumber	= @FactorNumber	
	where 	(@Code = Code)

	select N'Successfully update the record.' as ErrMsg
go

