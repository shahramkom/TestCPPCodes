/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_InsertChangesToSecondaryReplog]
	@sActionType AS VARCHAR(50),
	@Command nvarchar(MAX),
	@RecordIDValue INT,
	@RecordGID VARCHAR(25),
	@UserAssignedGrps VARCHAR(MAX),
	@AssignedUsers VARCHAR(MAX) = NULL
AS
BEGIN
	DECLARE CursSecID CURSOR FAST_FORWARD FOR SELECT * FROM dbo.Splitfn(@UserAssignedGrps,',')
	OPEN CursSecID
	DECLARE @GroupID AS INT
	DECLARE @SecondaryID AS TINYINT
	DECLARE @RelatedTableName varchar(30)
	DECLARE @SecondaryCnt TINYINT
	
	DECLARE @TblRelatedServer TABLE(SrvID TINYINT)

	FETCH NEXT FROM CursSecID INTO @GroupID
	WHILE @@FETCH_STATUS=0
	BEGIN
		SELECT @SecondaryID = dbo.GetRelatedSecondaryID(@GroupID)

		SELECT  @SecondaryCnt = COUNT(*) FROM @TblRelatedServer WHERE SrvID = @SecondaryID
		IF(@SecondaryID <> 0 AND @SecondaryCnt = 0)
		BEGIN
			SET @RelatedTableName = 'RepSecLog' + CAST(@SecondaryID AS VARCHAR(5))
			EXEC USP_InsertUserChangesToRelatedReplog @RecordIDValue, @sActionType, @RelatedTableName, @Command, @RecordGID, @GroupID, @AssignedUsers 
			INSERT INTO @TblRelatedServer(SrvID) VALUES(@SecondaryID)
		END
		FETCH NEXT FROM CursSecID INTO @GroupID
	END
	CLOSE CursSecID
	DEALLOCATE CursSecID	
END
go

