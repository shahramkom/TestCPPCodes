
        CREATE PROCEDURE [dbo].[USP_SelectTUserTimeSetFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        
    declare @groupID nvarchar(200), @UserID nvarchar(200),@InsertScript nvarchar(4000)

     Declare TUserTimeSet_cursor Cursor FAST_FORWARD
        For
        Select 
                 UserID,GroupID,[output] 
            FROM tbl_InsertGroupScript   
            where tableName = 'TUserTimeSet'
            OPEN TUserTimeSet_cursor

    FETCH NEXT FROM TUserTimeSet_cursor
    INTO @UserID,@groupID,@InsertScript

    WHILE @@FETCH_STATUS = 0
    begin 

    --		if(exists (select UserID from TPolicySet where PSName = @PSName ))
    --		Begin
    --			if(@Replace = '1')
    --				 Delete from TPolicySet   where PSName = @PSName	
    --		End
            BEGIN TRY
             exec sp_executesql @InsertScript	
            END TRY
            BEGIN CATCH
				INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript 
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectTUserTimeSetFromImportedBackupData')
            END CATCH
        
            
            
            FETCH NEXT FROM TUserTimeSet_cursor 
             INTO @UserID,@groupID,@InsertScript
    
        end
        CLOSE TUserTimeSet_cursor;
        DEALLOCATE TUserTimeSet_cursor;		
    END

        go

