/******************************************************************************************************************************************************/-------------------------
CREATE PROCEDURE USP_CheckDeleteAllItem
 @ActionType  VARCHAR(50),
 @RecordID INT,
 @mode TINYINT = 1
 AS
 BEGIN
	IF(@ActionType = 'Delete-TUserGroups' AND @mode = 0)
    BEGIN
		DELETE  FROM TPolicySet WHERE   PSID NOT IN ( SELECT PSID  FROM TGroupPolicySet UNION SELECT PSID  FROM TUserPolicySet)
		DELETE  FROM TServerAccessPolicy WHERE   PSID NOT IN ( SELECT PSID  FROM TPolicySet)
        DELETE  FROM TUserFirewallPolicy WHERE   PSID NOT IN ( SELECT PSID  FROM TPolicySet)
		
		DELETE  FROM TScript	WHERE   ScriptID NOT IN ( SELECT ScriptID  FROM TUserscripts  UNION SELECT ScriptID  FROM TgroupScript)
		DELETE  FROM TDNS		WHERE   DNSID	 NOT IN ( SELECT DNSID     FROM TgroupDNS	  UNION SELECT DNSID     FROM TUserDNS)
		DELETE  FROM TTimeRole	WHERE   TRID	 NOT IN ( SELECT TRID      FROM TgroupTimeset UNION SELECT TimeSetId FROM TUserTimeSet)
    END
	DECLARE @CountUser AS INT 
	DECLARE @CountGroup AS INT 
	IF(@ActionType = 'Delete-TGroupPolicySet' OR @ActionType = 'Delete-TUserPolicySet' )
	BEGIN
		SELECT @CountUser = COUNT(*) FROM TGroupPolicySet WHERE PSID = @RecordID 
		SELECT @CountGroup = COUNT(*) FROM TUserPolicySet WHERE PSID = @RecordID
		IF(@CountUser + @CountGroup = 0)
		BEGIN
			DELETE FROM dbo.TPolicySet WHERE PSID = @RecordID
			DELETE FROM dbo.TServerAccessPolicy WHERE PSID = @RecordID
            DELETE FROM dbo.TUserFirewallPolicy WHERE PSID = @RecordID
		END
	END
	ELSE IF(@ActionType = 'Delete-TgroupScript' OR @ActionType = 'Delete-TUserscripts' )
	BEGIN
		SELECT @CountUser = COUNT(*) FROM TUserscripts WHERE ScriptID = @RecordID 
		SELECT @CountGroup = COUNT(*) FROM TgroupScript WHERE ScriptID = @RecordID
		IF(@CountUser + @CountGroup = 0)
			DELETE FROM dbo.TScript WHERE ScriptID = @RecordID
	END
	ELSE IF(@ActionType = 'Delete-TgroupTimeset' OR @ActionType = 'Delete-TUserTimeSet' )
	BEGIN
		SELECT @CountUser = COUNT(*) FROM TgroupTimeset WHERE TRID = @RecordID 
		SELECT @CountGroup = COUNT(*) FROM TUserTimeSet WHERE TimeSetId = @RecordID
		IF(@CountUser + @CountGroup = 0)
			DELETE FROM dbo.TTimeRole WHERE TRID = @RecordID
	END
	ELSE IF(@ActionType = 'Delete-TgroupDNS' OR @ActionType = 'Delete-TUserDNS' )
	BEGIN
		SELECT @CountUser = COUNT(*) FROM TgroupDNS WHERE DNSID = @RecordID 
		SELECT @CountGroup = COUNT(*) FROM TUserDNS WHERE DNSID = @RecordID
		IF(@CountUser + @CountGroup = 0)
			DELETE FROM dbo.TDNS WHERE DNSID = @RecordID
	END
 END
go

