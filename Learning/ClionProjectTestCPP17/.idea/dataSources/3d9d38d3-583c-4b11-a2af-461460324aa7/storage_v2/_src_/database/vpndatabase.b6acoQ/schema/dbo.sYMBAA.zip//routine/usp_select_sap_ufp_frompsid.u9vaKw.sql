
CREATE PROCEDURE [dbo].[USP_Select_SAP_UFP_FromPSID]
        @PSID as bigint
        AS
BEGIN
     exec UPS_Select_SAP @PSID
	 exec UPS_Select_UFP @PSID
END
go

