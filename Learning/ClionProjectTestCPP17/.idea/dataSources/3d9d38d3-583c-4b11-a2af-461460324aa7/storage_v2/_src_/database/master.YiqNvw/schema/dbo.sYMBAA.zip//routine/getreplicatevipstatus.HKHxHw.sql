
/*************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetReplicateVIPStatus](@DestinationServerID int)
RETURNS BIT
AS
BEGIN
	DECLARE @RetVal BIT
	SELECT @RetVal = ChangedVirtualIP FROM dbo.RepConfig WHERE ServerID = @DestinationServerID
	RETURN @RetVal
END
go

