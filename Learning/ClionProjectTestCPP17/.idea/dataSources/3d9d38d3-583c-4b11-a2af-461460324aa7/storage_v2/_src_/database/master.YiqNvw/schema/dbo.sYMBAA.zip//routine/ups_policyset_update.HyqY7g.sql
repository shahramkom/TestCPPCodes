
    CREATE PROCEDURE [dbo].[UPS_PolicySet_Update]
    
        @PSID	 INT ,
        @PSName  nvarchar(200) ,
		@PSDescription	nvarchar(500) = NULL

    AS
    BEGIN
        SET NOCOUNT ON;
        UPDATE TPolicySet
    
        SET
        PSName = @PSName ,
		PSDescription = @PSDescription
        WHERE	
        PSID = @PSID
    
    END

    go

