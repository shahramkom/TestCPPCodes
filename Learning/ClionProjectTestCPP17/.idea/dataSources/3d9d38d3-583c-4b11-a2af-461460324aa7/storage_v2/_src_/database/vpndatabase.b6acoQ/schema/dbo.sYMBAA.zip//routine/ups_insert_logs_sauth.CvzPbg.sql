
    CREATE PROCEDURE [dbo].[UPS_Insert_logs_sAuth] 
        -- Add the parameters for the stored procedure here
        @L_UserID int, 
        @L_userName nvarchar(200)=NULL,
        @L_Event int ,
        @L_HostName nvarchar(50)=NUll,
        @L_LoginName nvarchar(50)=NULl,
        @L_DomainName nvarchar(128)=NUll,
        @L_KeyASerial nvarchar(50)=Null,
        @L_RealIP nvarchar(20)=Null,
        @L_Type   int=Null,
        @strDate nvarchar(10)=Null,
        @strTime nvarchar(8),
        @macaddr nvarchar(17)=Null,
        @clientVer nvarchar(50)=Null,
		@VirtualIP nvarchar(50)=Null,
        @Description nvarchar(2000)=Null
    AS
BEGIN
	SET NOCOUNT ON;
    DECLARE @RecordCount AS INT
	SELECT  @RecordCount = s.row_count from sys.tables t
		JOIN sys.dm_db_partition_stats s
		ON t.object_id = s.object_id
		AND t.type_desc = 'USER_TABLE'
		AND t.name =  'sAuthLog'
		AND s.index_id = 1

    IF (@RecordCount > 1000000)
    BEGIN
		DELETE  FROM [sAuthLog] WHERE [NO] IN (SELECT TOP(500000) [No] FROM sAuthLog order by eventDate,eventTime)
    END
    insert into sAuthLog(userID,userName,Event,HostName,LoginName,DomainName,KeyASerial,RealIP,Type,eventDate,eventTime,macaddr,clientVer,VirtualIP,[Description])
    values(@L_UserID,@L_userName,@L_Event,@L_HostName,@L_LoginName,@L_DomainName,@L_KeyASerial,@L_RealIP,@L_Type,@strDate,@strTime,@macaddr,@clientVer,@VirtualIP,@Description);
END

    go

