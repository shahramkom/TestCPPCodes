
    CREATE PROCEDURE [dbo].[UPS_SetOrderPolicy]

        @PolicyID int,
        @POrder int,
        @PolicyID1 int,
        @POrder1 int
    AS
    BEGIN

        UPDATE TServerAccessPolicy 	
        SET
        POrder=@POrder
        where 
        PolicyID=@PolicyID

        UPDATE TServerAccessPolicy 	
        SET
        POrder=@POrder1
        where 
        PolicyID=@PolicyID1

    END

    go

