/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[getDataTypeString](@DataType varchar(100),@ColName varchar(100))
		RETURNS nvarchar(MAX)
	AS
	BEGIN
	DECLARE @StringData nvarchar(3000)
	SET @StringData  = ' '

	IF @dataType in ('varchar','char','nchar','nvarchar')
	BEGIN
		SET @stringData=@stringData+''''+'''+isnull(''N'''+'''''+'+@colName+'+'''''+''''',''NULL'')+'',''+'
	END
	ELSE
	if @dataType in ('text','ntext') --if the datatype is text or something else 
	BEGIN
		SET @stringData=@stringData+'''''''''+isnull(cast('+@colName+' as varchar(2000)),'''')+'''''',''+'
	END
	ELSE
	IF @dataType = 'money' --because money doesn't get converted from varchar implicitly
	BEGIN
		SET @stringData=@stringData+'''convert(money,''''''+isnull(cast('+@colName+' as varchar(200)),''0.0000'')+''''''),''+'
	END
	ELSE 
	IF @dataType='datetime'
	BEGIN
		SET @stringData=@stringData+'''convert(datetime,'+'''+isnull('''''+'''''+convert(varchar(200),'+@colName+',121)+'''''+''''',''NULL'')+'',121),''+'
	END
	ELSE 
	IF @dataType='image' 
	BEGIN
		SET @stringData=@stringData+'''''''''+isnull(cast(convert(varbinary,'+@colName+') as varchar(6)),''0'')+'''''',''+'
	END
	ELSE --presuming the data type is int,bit,numeric,decimal 
	BEGIN
	
		SET @stringData=@stringData+''''+'''+isnull('''''+'''''+convert(varchar(200),'+@colName+')+'''''+''''',''NULL'')+'',''+'
	END
	RETURN @StringData
END

go

