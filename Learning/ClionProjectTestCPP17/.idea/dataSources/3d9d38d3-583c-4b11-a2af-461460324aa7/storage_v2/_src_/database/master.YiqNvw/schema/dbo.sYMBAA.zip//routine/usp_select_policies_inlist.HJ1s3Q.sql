
    create PROCEDURE  [dbo].[USP_Select_Policies_InList] 
    
        @PS_List nvarchar(max)
    AS

    BEGIN

        execute ('select u.* from TUserFirewallPolicy as u inner join TPolicySet as p on u.PSID = p.PSID and u.Status = 1 and u.PSID IN (' + @PS_List +')' + 'ORDER BY p.PSID,u.POrder ')
    END

    go

