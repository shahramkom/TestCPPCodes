CREATE PROCEDURE [dbo].[USP_WipeDB_Rep]
    WITH RECOMPILE
AS
BEGIN
    DECLARE @specialPermission INT
    SET @specialPermission = 0
	
    IF EXISTS ( SELECT  * FROM    tbl_InsertGroupScript WHERE   GroupName LIKE N'%special users%' AND tableName = 'TGroup' )
    BEGIN
        SET @specialPermission = 1
    END

    EXEC USP_DisableAllTriggers
    EXEC dbo.USP_ChangeReplicationState  1
  	
    DELETE  FROM    managerLog
    DELETE  FROM    sAuthLog
    DELETE  FROM    settingServerLog
    DELETE  FROM    TSettingLog
    DELETE  FROM    TAllLogs
    
    EXEC            USP_WipeReplicationLog
    DELETE  FROM    RepServersState
    DELETE  FROM    RepServersGroups
    DELETE  FROM    RepConfig
	EXEC            USP_DropReplogTable

    DELETE  FROM	TNewPolicyMainTable
	DELETE  FROM	TNewPoliciesDetails
	DELETE  FROM	TNewPolicyGroupAssign
	DELETE  FROM	TNewPolicyUserAssign

	DELETE  FROM	HealthCheckUserAssign
	DELETE  FROM	HealthCheckGroupAssign
	DELETE  FROM	HealthCheckRules
	DELETE  FROM	HealthCheckProfiles

    DELETE  FROM    TUserKeya
    DELETE  FROM    TUserPolicySet 
    DELETE  FROM    TUserDNS
    DELETE  FROM    TUserTimeSet 
    IF ( @specialPermission = 0 )
        DELETE  FROM TUserInterface WHERE (userid NOT IN (SELECT userid FROM TUserGroups ug, TGroup g  WHERE ug.GroupID = g.GroupID AND g.GroupName = 'special users' ) )
    ELSE
        DELETE  FROM TUserInterface

    DELETE  FROM    TGroupScript
    DELETE  FROM    TGroupTimeSet
    DELETE  FROM    TGroupDNS
    DELETE  FROM    TGroupPolicySet WHERE   ( GroupID IN ( SELECT   GroupID FROM     TGroupPolicySet ) )
    IF ( @specialPermission = 0 )
        DELETE  FROM TGroupInterface  WHERE   ( groupid NOT IN ( SELECT   groupid FROM     Tgroup WHERE    GroupName = 'special users' ) )
    ELSE
        DELETE  FROM TGroupInterface	
    
    IF ( @specialPermission = 0 )
        DELETE  FROM TUserGroups WHERE   ( groupid NOT IN ( SELECT groupid FROM Tgroup WHERE    GroupName = 'special users' ) )
    ELSE
        DELETE  FROM TUserGroups
	
    DELETE  FROM    TSAPTempTable WHERE   ( PolicyID IN ( SELECT  PolicyID FROM    TSAPTempTable ) )
    DELETE  FROM    TADTempUser WHERE   ( UserName IN ( SELECT  UserName FROM    TADTempUser ) )

    DELETE  FROM    TTempUserFirewallPolicy WHERE   ( UFPID IN ( SELECT UFPID FROM   TTempUserFirewallPolicy ) )
    DELETE  FROM    TTempPolicySet WHERE   ( PSID IN ( SELECT  PSID  FROM    TTempPolicySet ) )
    DELETE  FROM    TTempGroup WHERE   ( GroupID IN ( SELECT   GroupID FROM     TTempGroup ) )
    DELETE  FROM    TempUser WHERE   ( UserID IN ( SELECT    UserID FROM      TempUser ) )
    DELETE  FROM    TTempDNS WHERE   ( DNSID IN ( SELECT DNSID FROM   TTempDNS ) )

    DELETE  FROM    TUserFirewallPolicy WHERE   ( UFPID IN ( SELECT UFPID FROM   TUserFirewallPolicy ) )
    DELETE  FROM    TServerAccessPolicy WHERE   ( Policyid IN ( SELECT  Policyid FROM    TServerAccessPolicy ) )
    DELETE  FROM    TScript
    DELETE  FROM    TDNS 
    DELETE  FROM    TTimeRole WHERE   ( TRID IN ( SELECT  TRID FROM    TTimeRole ) )
    DELETE  FROM    TPolicySet  WHERE   ( PSID IN ( SELECT  PSID  FROM    TPolicySet ) )
    
    IF ( @specialPermission = 1 )
        DELETE  FROM SpecialPermission

    IF ( @specialPermission = 0 )
        DELETE  FROM TUser WHERE( userid NOT IN (SELECT userid FROM  TUserGroups ug, TGroup g WHERE ug.GroupID = g.GroupID AND g.GroupName = 'special users' ) )
    ELSE
        DELETE  FROM TUser WHERE( userid IN ( SELECT userid FROM      TUser ) )
	   
    IF ( @specialPermission = 0 )
        DELETE  FROM Tgroup  WHERE( groupid NOT IN ( SELECT   groupid FROM Tgroup  WHERE GroupName = 'special users' ) )
    ELSE
        DELETE  FROM Tgroup 
END
/*************************************************************************************************************************************/
go

