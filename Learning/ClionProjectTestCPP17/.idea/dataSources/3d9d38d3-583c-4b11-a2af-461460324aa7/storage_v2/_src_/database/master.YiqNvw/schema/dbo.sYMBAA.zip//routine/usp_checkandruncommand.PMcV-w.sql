/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_CheckAndRunCommand]
	@IDValue INT,
	@ActionType  char(6),
	@GID VARCHAR(25),
	@UserAssignedGrps NVARCHAR(MAX)
	AS
	BEGIN
		DECLARE @RowServerID AS TINYINT
		DECLARE @Command NVARCHAR(MAX)
		DECLARE @sActionType as VARCHAR(50)
		SET @Command = ' '

		DECLARE @MyServerID TINYINT
		SELECT  @MyServerID = dbo.GetCurrentServerID()
		
		IF ( @ActionType = 'Insert' )
			SET @sActionType = 'Insert-TUser'
		ELSE IF ( @ActionType = 'Delete' )
		BEGIN
            SET @sActionType = 'Delete-TUserGroups'
			IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Temp_ChangeAssignedUserType]') AND type in (N'U'))
			BEGIN
				DECLARE @assignedType AS INT
				SELECT @assignedType = AssignedType FROM Temp_ChangeAssignedUserType
				IF (@assignedType = 1)
				BEGIN
					UPDATE Temp_ChangeAssignedUserType SET AssignedType = 0
					IF(dbo.IsPrimaryServer(@MyServerID) = 0)
						SET @sActionType = 'Update-TUserGroups'
					ELSE
						SET @sActionType = 'Update-TUserGroupsKeyA'
				END
			END
		END
		
		
		DECLARE CursAssignedGroups CURSOR FAST_FORWARD FOR
		SELECT items FROM dbo.splitfn(@UserAssignedGrps,',')
		OPEN CursAssignedGroups
		DECLARE @GrpID INT
		
		FETCH NEXT FROM CursAssignedGroups INTO @GrpID
		WHILE @@FETCH_STATUS=0
		BEGIN

		EXEC USP_GetUserRelatedQuery  @ActionType, @IDValue, @Command OUTPUT

		IF(dbo.HasSlaveServer(@MyServerID) = 1)
			EXEC USP_InsertUserChangesToRelatedReplog @IDValue,@sActionType,'RepSlaveLog', @Command, @GID, @GrpID

		SELECT @Command = dbo.getCorrectUserIntBindCommand(@sActionType,@Command)

		IF(dbo.IsRecordReplicatable(@GrpID) = 1)
		BEGIN
			SET @RowServerID = CONVERT(INT,SUBSTRING(@GID, 0, CHARINDEX(',', @GID )))
			EXEC USP_ProcessUserChanges @sActionType, @Command, @IDValue, @GID, @MyServerID, @GrpID, @RowServerID
		END
		
		FETCH NEXT FROM CursAssignedGroups INTO @GrpID
		END
		CLOSE CursAssignedGroups
		DEALLOCATE CursAssignedGroups
END
go

