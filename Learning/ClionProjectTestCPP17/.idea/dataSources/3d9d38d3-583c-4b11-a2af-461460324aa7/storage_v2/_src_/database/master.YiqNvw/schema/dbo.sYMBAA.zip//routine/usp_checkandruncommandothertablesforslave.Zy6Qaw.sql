/******************************************************************************************************************************************************/---------------------------------
CREATE PROCEDURE [dbo].[USP_CheckAndRunCommandOtherTablesForSlave]
	@IDValue INT,
	@ActionType  VARCHAR(6),
	@tableName   VARCHAR(20),
	@idfieldName varchar(20)
	AS
	BEGIN
		DECLARE @Command NVARCHAR(MAX)
		DECLARE @sActionType as VARCHAR(50)
		SET @Command = ' '
		
		SET @sActionType = @ActionType + '-' + @tableName

		DECLARE @MyServerID TINYINT
		SELECT  @MyServerID = dbo.GetCurrentServerID()

		IF(dbo.HasSlaveServer(@MyServerID) = 1)
		BEGIN
			EXEC USP_PrepareTableRelatedQuery @ActionType, @tableName, @idfieldName, @IDValue, @Command OUTPUT
			EXEC USP_InsertUserChangesToRelatedReplog @IDValue, @sActionType, 'RepSlaveLog', @Command, NULL, NULL, NULL
		END
	END
go

