/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetServerIDFromRepConfig](@MyServerIP VARCHAR(20))
RETURNS INT
AS
BEGIN
	DECLARE @RetVal INT
	SELECT @RetVal = ServerID FROM dbo.RepConfig WHERE ServerIP = @MyServerIP
	RETURN @RetVal
END
go

