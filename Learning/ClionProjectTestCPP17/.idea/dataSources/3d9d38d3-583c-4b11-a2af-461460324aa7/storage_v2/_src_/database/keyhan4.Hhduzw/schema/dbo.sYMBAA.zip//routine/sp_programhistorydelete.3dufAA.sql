
CREATE PROCEDURE [dbo].[sp_ProgramHistoryDELETE] 
	@HistoryID int
AS
	BEGIN
DELETE FROM [Keyhan4].[dbo].[ProgramHistory]
 WHERE ID = @HistoryID

	END

go

