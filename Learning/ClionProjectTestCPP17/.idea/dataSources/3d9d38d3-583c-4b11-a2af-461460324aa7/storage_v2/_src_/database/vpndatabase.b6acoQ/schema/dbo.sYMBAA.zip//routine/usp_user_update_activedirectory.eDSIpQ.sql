CREATE PROCEDURE [dbo].[USP_User_Update_ActiveDirectory]
    @UserName NVARCHAR(200) = NULL,
    @GroupId INT = NULL,
    @AccountDisable tinyInt = NULL,
    @FirstName NVARCHAR(200) = NULL,
    @LastName NVARCHAR(200) = NULL,
    @Company NVARCHAR(200) = NULL,
    @Office NVARCHAR(200) = NULL,
    @Province NVARCHAR(200) = NULL,
    @Town NVARCHAR(200) = NULL,
    @Notes NVARCHAR(MAX) = NULL,
    @Email NVARCHAR(200) = NULL,
    @Cell NVARCHAR(50) = NULL,
    @PersonnelCode NVARCHAR(10) = NULL,
    @Phone NVARCHAR(200) = NULL,
    @NationalID NVARCHAR(10) = NULL,
    @Adress NVARCHAR(MAX) = NULL,
    @PostalCode NVARCHAR(200) = NULL,
    @Owner INT = NULL
AS
BEGIN
    UPDATE  TUser
    SET     AccountDisable = @AccountDisable,
            FirstName = @FirstName,
            LastName = @LastName,
            Office = @Office,
            Company = @Company,
            Province = @Province,
            Town = @Town,
            Notes = @Notes,
            Email = @Email,
            Cell = @Cell,
            PersonnelCode = @PersonnelCode,
            Phone = @Phone,
            NationalID = @NationalID,
            Adress = @Adress,
            PostalCode = @PostalCode,
            [Owner] = @Owner
    WHERE   UserName = @UserName
            
    DECLARE @UserID AS INT
    DECLARE @gid AS VARCHAR(25)

	SELECT  @UserID = UserID, @gid = GID
    FROM    TUser
    WHERE   UserName = @UserName 

    DECLARE @selectCount AS INT
    SELECT  @selectCount = COUNT(*)
    FROM    TUserGroups
    WHERE   UserID = @UserId
            AND GroupID = @GroupID

    IF ( @selectCount = 0 )
        INSERT  INTO TUserGroups
                ( UserID, GroupID, GID )
        VALUES  ( @UserID, @GroupID, @gid )
END
/******************************************************************************************************************************************************/-------------------------
go

