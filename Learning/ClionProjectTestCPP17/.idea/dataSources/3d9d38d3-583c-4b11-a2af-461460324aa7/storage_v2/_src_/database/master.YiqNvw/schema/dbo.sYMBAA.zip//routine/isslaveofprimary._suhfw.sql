/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.isSlaveOFPrimary(@CurrentServerIP VARCHAR(20))
	RETURNS BIT
AS
BEGIN
	DECLARE @CurrentServerType AS INT
	SET @CurrentServerType = -1
	SELECT @CurrentServerType = ServerType  FROM RepConfig WHERE SlaveIP = @CurrentServerIP
	
	DECLARE @isSlavePrimary AS BIT
	if( @CurrentServerType = -1 )
		SET @isSlavePrimary = 0
	ELSE IF ( @CurrentServerType > 0 )
		SET @isSlavePrimary = 0
	ELSE IF ( @CurrentServerType = 0 )
		SET @isSlavePrimary = 1
	RETURN @isSlavePrimary
END
go

