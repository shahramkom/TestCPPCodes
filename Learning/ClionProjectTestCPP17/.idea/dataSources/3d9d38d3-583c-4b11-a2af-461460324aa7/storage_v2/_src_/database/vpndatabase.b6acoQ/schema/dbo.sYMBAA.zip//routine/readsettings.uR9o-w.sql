--------------------------------------------------------------------------------
CREATE PROCEDURE  [dbo].[ReadSettings]
AS
BEGIN	
	SELECT * FROM TSetting
END
go

