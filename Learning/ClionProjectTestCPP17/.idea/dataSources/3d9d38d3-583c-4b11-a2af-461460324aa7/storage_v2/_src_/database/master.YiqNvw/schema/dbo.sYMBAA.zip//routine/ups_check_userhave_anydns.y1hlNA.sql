CREATE PROCEDURE [dbo].[UPS_Check_UserHave_AnyDNS] 
	@UserID BIGINT ,
	@AllRelatedGroupsOfUser nvarchar(2000)
AS
BEGIN
	DECLARE @Count TINYINT
	SELECT @Count = COUNT(DNSID) FROM TUserDNS WHERE UserID = @UserID
	if( @Count > 0)
	BEGIN
		SELECT 1 AS DNS
		RETURN
	END	
	DECLARE @execSql  as NVARCHAR(2000)
	SET @execSql = 'SELECT @Count = COUNT(GroupID) FROM TGroupDNS WHERE GroupID in('+@AllRelatedGroupsOfUser+')'
	EXEC SP_EXECUTESQL @execSql, N'@Count TINYINT OUTPUT', @Count OUTPUT
	if( @Count > 0)
	BEGIN
		SELECT 1 AS DNS
		RETURN
	END	
	SELECT 0 AS DNS
END
go

