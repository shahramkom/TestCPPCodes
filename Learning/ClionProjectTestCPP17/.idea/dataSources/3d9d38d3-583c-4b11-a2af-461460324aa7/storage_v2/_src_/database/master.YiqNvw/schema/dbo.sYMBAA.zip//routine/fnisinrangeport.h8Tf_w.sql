
	CREATE FUNCTION [dbo].[fnIsInRangePort]
	(
		@UserPort VARCHAR(15),
		@TablePort VARCHAR(15)
	)
	RETURNS BIT
	AS
	BEGIN
		SELECT @UserPort= REPLACE(@UserPort ,'-' , '.')
		SELECT @TablePort= REPLACE(@TablePort ,'-' , '.')
		IF(CHARINDEX('.',@UserPort) > 0 AND CHARINDEX('.',@TablePort) > 0)
		BEGIN
			RETURN	CASE
					WHEN	CAST(PARSENAME(@UserPort, 1) AS INT) <= CAST(PARSENAME(@TablePort, 1) AS INT) 
						AND CAST(PARSENAME(@UserPort, 2) AS INT) >= CAST(PARSENAME(@TablePort, 2) AS INT)
					THEN	1
					ELSE	0
			END
		END
		IF(CHARINDEX('.',@UserPort) = 0 AND CHARINDEX('.',@TablePort) > 0)
		BEGIN
			RETURN	CASE
					WHEN	CAST(@UserPort AS INT) <= CAST(PARSENAME(@TablePort, 2) AS INT) 
						AND CAST(@UserPort AS INT) >= CAST(PARSENAME(@TablePort, 1) AS INT)
					THEN	1
					ELSE	0
			END
		END
		IF(CHARINDEX('.',@UserPort) > 0 AND CHARINDEX('.',@TablePort) = 0)
		BEGIN
			RETURN	CASE
					WHEN	CAST(@TablePort AS INT) <= CAST(PARSENAME(@UserPort, 1) AS INT) 
						AND CAST(@TablePort AS INT) >= CAST(PARSENAME(@UserPort, 2) AS INT)
					THEN	1
					ELSE	0
			END
		END
		IF(CHARINDEX('.',@UserPort) = 0 AND CHARINDEX('.',@TablePort) = 0)
		BEGIN
			RETURN	CASE
					WHEN	CAST(@UserPort AS INT) = CAST(@TablePort AS INT) 
					THEN	1
					ELSE	0
			END
		END
		RETURN 0
	END

  go

