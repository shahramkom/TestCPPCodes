
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesAlgorithms_Update] 
		@ID  bigint,
		@EncryptionAlgorithm nvarchar(50),
		@IntegrityAlgorithm  nvarchar(50)
		
   AS
   BEGIN

	UPDATE [dbo].[TNewPoliciesAlgorithms]
	   SET [EncryptionAlgorithm] = @EncryptionAlgorithm,
		   [IntegrityAlgorithm] =  @IntegrityAlgorithm
		   
	 WHERE ID = @ID

   END

   go

