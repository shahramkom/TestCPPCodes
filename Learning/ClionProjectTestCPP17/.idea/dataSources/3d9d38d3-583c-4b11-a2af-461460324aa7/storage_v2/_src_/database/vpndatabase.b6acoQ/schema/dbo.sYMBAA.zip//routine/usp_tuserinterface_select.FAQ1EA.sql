
	create PROCEDURE [dbo].[USP_TUserInterface_Select]
		-- Add the parameters for the stored procedure here
		@UserID as int
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		declare @Statement as nvarchar(1000)
	
		--set @Statement = 'select * from TUserInterface '
		set @Statement = 'select ti.* from TuserInterface tui inner join TInterface ti on (tui.InterfaceID = ti.InterfaceID) where tui.UserID = '
		set @Statement = isnull(@Statement ,'') + convert(nvarchar(50),@UserID)+ 'order by ti.InterfaceID'
		exec sp_executesql @Statement
	END

  go

