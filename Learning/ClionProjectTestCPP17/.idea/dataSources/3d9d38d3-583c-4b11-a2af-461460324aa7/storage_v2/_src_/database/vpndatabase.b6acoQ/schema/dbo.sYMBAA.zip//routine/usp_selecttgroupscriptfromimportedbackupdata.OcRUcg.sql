
        CREATE PROCEDURE [dbo].[USP_SelectTGroupScriptFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        
    declare @groupID nvarchar(200), @ScriptID nvarchar(200),@InsertScript nvarchar(4000)

     Declare TGroupScript_cursor Cursor FAST_FORWARD
        For
        Select 
                 ScriptID,GroupID,[output] 
            FROM tbl_InsertGroupScript   
            where tableName = 'TGroupScript'
            OPEN TGroupScript_cursor

    FETCH NEXT FROM TGroupScript_cursor
    INTO @ScriptID,@groupID,@InsertScript

    WHILE @@FETCH_STATUS = 0
    begin 

    --		if(exists (select UserID from TPolicySet where PSName = @PSName ))
    --		Begin
    --			if(@Replace = '1')
    --				 Delete from TPolicySet   where PSName = @PSName	
    --		End
            BEGIN TRY
             exec sp_executesql @InsertScript	
            END TRY
            BEGIN CATCH
				INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,getdate()
			   ,@InsertScript 
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectTGroupScriptFromImportedBackupData')


            END CATCH
        
            
            
            FETCH NEXT FROM TGroupScript_cursor 
             INTO @ScriptID,@groupID,@InsertScript
    
        end
        CLOSE TGroupScript_cursor;
        DEALLOCATE TGroupScript_cursor;		
    END


        go

