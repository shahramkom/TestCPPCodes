

    CREATE PROCEDURE  [dbo].[UPS_Select_SAP] 
    
    @PSID int =null
    with recompile
    AS
    BEGIN

        SELECT  * from  TServerAccessPolicy where (PSID = @PSID OR   @PSID IS NULL OR @PSID = 0) order by  POrder 
    END

    go

