
    Create PROCEDURE [dbo].[USP_DeletefromTimeSet]
    @TimeSetID int
    AS
    BEGIN	
        delete from TTimeRole where TRID in (@TimeSetID)
		delete from TUserTimeSet where TimeSetId = @TimeSetID
    END

    go

