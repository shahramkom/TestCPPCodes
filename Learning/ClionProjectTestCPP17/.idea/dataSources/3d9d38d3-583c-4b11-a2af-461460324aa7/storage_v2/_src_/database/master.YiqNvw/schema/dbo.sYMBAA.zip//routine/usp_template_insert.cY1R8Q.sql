
    CREATE PROCEDURE  [dbo].[USP_Template_Insert]

        @GroupID			nvarchar(max)	,	
        @BindingStatus		nvarchar(50)	 = NULL , 
        @IPBindingStatus	nvarchar(20)	 = NULL , 
        @SubNetIP			nvarchar(50)	 = NULL,
        @SubNetMask			nvarchar(50)	 = NULL,
        @VirtualIPStatus	nvarchar(50)	 = NULL,			 
        @UserPIN			nvarchar(200)	= NULL , 
        @MasterPIN			nvarchar(200)	= NULL , 
        @MustChangePIN		bit			= NULL , 	
        @LockModule			bit			= NULL ,
        @RejOnKeepAliveFail bit		= NULL ,
		@SendDNS			bit		= NULL ,
		@ShowUserPrivilege  bit		= NULL ,
        @Gender				nvarchar(10)		= NULL ,
        @UnBlockPIN			nvarchar(200)	= NULL ,
        @InterfaceBindingStatus as bit = 0 ,
        @interfaceNames		nvarchar(1000) = NULL,
		@LoginType          tinyint = 2,
		@DisableModernPolicy bit = 1

    AS
    BEGIN

        delete  from TTemplateUser

        Insert into TTemplateUser 
    
        (
        GroupID	 ,
        BindingStatus	 ,
        IPBindingStatus,
        SubNetIP,
        SubNetMask,
        VirtualIPStatus	,
        UserPIN	 ,
        MasterPIN,
        MustChangePIN	 ,
        LockModule	 ,
        RejOnKeepAliveFail,
		ShowUserPrivilege,
        Gender,
        UnBlockPIN,
        InterfaceBindingStatus,
        InterfaceNames,
		LoginType,
		SendDNS,
		DisableModernPolicy
        )
    
        values
        (
        @GroupID	 ,
        @BindingStatus	 ,
        @IPBindingStatus,
        @SubNetIP,
        @SubNetMask,	
        @VirtualIPStatus,	
        @UserPIN	 ,
        @MasterPIN,
        @MustChangePIN	 ,
        @LockModule	 ,
        @RejOnKeepAliveFail,
		@ShowUserPrivilege,
        @Gender	,
        @UnBlockPIN,
        @InterfaceBindingStatus,
        @interfaceNames,
		@LoginType,
		@SendDNS,
		@DisableModernPolicy
        )

        END

    go

