
Create PROCEDURE [dbo].[USP_Select_MiniAdminTypesUsers]
        AS
BEGIN
	SELECT        dbo.TUser.UserID, dbo.TUser.UserName, dbo.SpecialPermission.MiniAdminType, dbo.SpecialPermission.PermissionName
	FROM            dbo.TUser INNER JOIN
							 dbo.TUserGroups ON dbo.TUser.UserID = dbo.TUserGroups.UserID INNER JOIN
							 dbo.TGroup ON dbo.TUserGroups.GroupID = dbo.TGroup.GroupID INNER JOIN
							 dbo.SpecialPermission ON dbo.TUser.Permission_ID = dbo.SpecialPermission.ID
	WHERE        (dbo.TGroup.GroupName = N'special users') AND (dbo.SpecialPermission.MiniAdminType = 1)

	SELECT        dbo.TUser.UserID, dbo.TUser.UserName, dbo.SpecialPermission.MiniAdminType, dbo.SpecialPermission.PermissionName
	FROM            dbo.TUser INNER JOIN
							 dbo.TUserGroups ON dbo.TUser.UserID = dbo.TUserGroups.UserID INNER JOIN
							 dbo.TGroup ON dbo.TUserGroups.GroupID = dbo.TGroup.GroupID INNER JOIN
							 dbo.SpecialPermission ON dbo.TUser.Permission_ID = dbo.SpecialPermission.ID
	WHERE        (dbo.TGroup.GroupName = N'special users') AND (dbo.SpecialPermission.MiniAdminType = 2)
END
go

