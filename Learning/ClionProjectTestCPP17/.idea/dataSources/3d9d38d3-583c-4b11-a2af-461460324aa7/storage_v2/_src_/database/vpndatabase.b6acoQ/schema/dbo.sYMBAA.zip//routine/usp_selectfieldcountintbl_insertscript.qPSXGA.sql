
		CREATE PROCEDURE usp_selectFieldCountInTbl_InsertScript
		AS
		BEGIN
			SELECT COUNT(tbl_InsertGroupScript.Output) userCount FROM tbl_InsertGroupScript WHERE tbl_InsertGroupScript.tableName = 'TUser' 
			SELECT COUNT(tbl_InsertGroupScript.Output) grpCount FROM tbl_InsertGroupScript WHERE tbl_InsertGroupScript.tableName = 'TGroup' 
			SELECT COUNT(tbl_InsertGroupScript.Output) PolicySetCount FROM tbl_InsertGroupScript WHERE tbl_InsertGroupScript.tableName = 'TPolicySet' 
			SELECT COUNT(tbl_InsertGroupScript.Output) GroupPolicyCount FROM tbl_InsertGroupScript WHERE tbl_InsertGroupScript.tableName = 'TGroupPolicySet' 
			SELECT COUNT(tbl_InsertGroupScript.Output) UserPolicyCount FROM tbl_InsertGroupScript WHERE tbl_InsertGroupScript.tableName = 'TUserPolicySet' 
			SELECT COUNT(tbl_InsertGroupScript.Output) SAPCount FROM tbl_InsertGroupScript WHERE tbl_InsertGroupScript.tableName = 'TServerAccessPolicy' 
			SELECT COUNT(tbl_InsertGroupScript.Output) UFPCount FROM tbl_InsertGroupScript WHERE tbl_InsertGroupScript.tableName = 'TUserFirewallPolicy' 
		END

    go

