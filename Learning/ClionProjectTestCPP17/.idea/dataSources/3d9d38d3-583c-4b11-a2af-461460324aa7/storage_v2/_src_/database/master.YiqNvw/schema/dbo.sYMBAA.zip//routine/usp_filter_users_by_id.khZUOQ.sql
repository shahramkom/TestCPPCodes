CREATE PROCEDURE [dbo].[USP_FILTER_USERS_BY_ID]
    @UserID NVARCHAR(MAX) = NULL
AS
BEGIN
    DECLARE @ExecQuery AS NVARCHAR(MAX) 
    DECLARE @filter AS NVARCHAR(MAX)
    DECLARE @selectFields AS NVARCHAR(MAX)

    DECLARE @UserCount AS INT
    SET @UserCount = 0
    DECLARE @SpecialpermGID AS INT	
    SET @ExecQuery = 'Select UserID,UserName,BindingStatus,BindingPCID ,IPBindingStatus '
        + ',SubNetIP,SubNetMask,VirtualIPStatus,VirtualIP,UserPIN,MasterPIN,AuthenticationKey,MustChangePIN,AccountDisable  '
        + +',RejOnKeepAliveFail,ShowUserPrivilege,FirstName,LastName,Gender,Company,Office,Province,Town,Notes,Email,Cell,PersonnelCode,Phone,NationalID,Adress,
		PostalCode,Owner, Permission_ID,UnBlockPIN ,AuthType,CertType,CertValue,dbo.RetrieveGroupNames(UserID) as GroupNames,
		 dbo.RetrievePSNames(UserID)as UserPolicies,InterfaceBindingstatus,dbo.RetrieveInterfaceNames(UserID) as InterfaceNames,
		 LoginType,LockModule,ExpireDate,VersionBindingStatus,BindingVersion,CreateTime,LastModifiedTime,SendDNS,
		 DisableModernPolicy,LastConnectedIP,LastLoginTime,TUser.GID '
        + 'FROM TUser Where (1=1) '
    IF ( @UserID IS NOT NULL )
        BEGIN
            DECLARE UserIDs_cursor CURSOR
            FOR
            SELECT  *
            FROM    dbo.Splitfn(@UserID, ',')
            DECLARE @SplittedUID NVARCHAR(30)
            OPEN UserIDs_cursor
            FETCH NEXT FROM UserIDs_cursor 
			INTO @SplittedUID
            DECLARE @IDCount INT
            SET @IDCount = 1
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    IF ( @SplittedUID <> '' )
                        BEGIN
                            IF ( @IDCount = 1 )
                                SET @ExecQuery = @ExecQuery + 'AND (( UserID = ' + @SplittedUID + ') '
                            ELSE
                                SET @ExecQuery = @ExecQuery + 'OR ( UserID = ' + @SplittedUID + ') '
                            SET @IDCount = @IDCount + 1
                        END
                    FETCH NEXT FROM UserIDs_cursor 
				INTO @SplittedUID
                END
            CLOSE UserIDs_cursor;
            DEALLOCATE UserIDs_cursor;
            SET @ExecQuery = @ExecQuery + ')'
        END
	SET @ExecQuery= @ExecQuery+ ' ORDER BY userID '
    EXEC dbo.sp_executesql @ExecQuery
END
go

