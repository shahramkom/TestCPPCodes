CREATE PROCEDURE [dbo].[USP_GetUserPermissions] 
	@PermmisionID bigint
AS
BEGIN
	select * from SpecialPermission where ID = @PermmisionID
END
go

