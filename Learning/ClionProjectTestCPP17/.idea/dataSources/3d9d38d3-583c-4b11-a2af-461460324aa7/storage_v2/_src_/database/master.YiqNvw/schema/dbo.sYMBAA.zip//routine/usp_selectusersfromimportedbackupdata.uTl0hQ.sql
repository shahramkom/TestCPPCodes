CREATE PROCEDURE [dbo].[USP_SelectUsersFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
    @Replace AS BIT,
    @MergeIPHead AS BIGINT = NULL,
	@PlainAuthKey AS BIT = 0
AS
BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
    SET NOCOUNT ON;
    BEGIN TRY
        DROP TABLE #Table
    END TRY
    BEGIN CATCH	
    END CATCH

    CREATE TABLE #Table
    ( CommandLine NVARCHAR(200),
      Param1 NVARCHAR(200),
      [Output] NVARCHAR(64))
    
    DECLARE @UserName NVARCHAR(200)
    DECLARE @UserID NVARCHAR(200)
    DECLARE @InsertScript NVARCHAR(MAX)
    DECLARE @CNT AS INT --, @GroupID NVARCHAR(200)

	DECLARE @nTotalUser INT
	SELECT  @nTotalUser = [value] FROM TSetting WHERE Property = 'TotalUser'
    DECLARE User_cursor CURSOR FAST_FORWARD
    FOR
    SELECT  UserName, UserID, [output] FROM tbl_InsertGroupScript WHERE  tableName = 'TUser'
    OPEN User_cursor

    FETCH NEXT FROM User_cursor
    INTO @UserName, @UserID, @InsertScript

    WHILE @@FETCH_STATUS = 0
        BEGIN 
	    DECLARE @nTotalCount INT
        SELECT  @nTotalCount = COUNT(*) FROM tempUser
        IF ( @nTotalUser < @nTotalCount + 1 )
        BEGIN
		   RAISERROR ('Number of total user exceeded' , 16 , 10)
           RETURN
        END
	    IF (EXISTS(SELECT UserID  FROM  TUser WHERE userName = @UserName OR UserID = @UserID))
                BEGIN
                    IF ( @Replace = '1' )
				DELETE  FROM TUser WHERE userName = @userName OR UserID = @UserID	
        
                END
		
		SET @InsertScript = REPLACE(@InsertScript, 'Bind at next login', 'Bind at next 1 login(s)')
        
            DECLARE @rowLocal NVARCHAR(MAX)
            SET @rowLocal = @InsertScript
		if(@PlainAuthKey = 1)
		BEGIN
            DECLARE @i INT 
            SET @i = PATINDEX('%#$#%', @rowLocal) + 3
            SET @rowLocal = SUBSTRING(@rowLocal, ( PATINDEX('%#$#%', @rowLocal) + 3 ), 64)
            DECLARE @AuthenticationKey NVARCHAR(64)
            SET @AuthenticationKey = @rowLocal
            DECLARE @EncAuthKey NVARCHAR(64)	
    --		declare @PlainAuthKey nvarchar(128)	
    --		select @EncAuthKey = AuthenticationKey from TUser where UserID = @rowLocal
			INSERT  #Table EXEC Master..XYRunProc 'Encrypt', @AuthenticationKey 
			SELECT  @EncAuthKey = [Output] FROM #Table WHERE CommandLine = 'Encrypt'
			DELETE FROM #Table
        
            IF ( @EncAuthKey IS NULL )
                BEGIN
                    RAISERROR ('The Authentication key is null!  Please check server configs.',16,10)
        
                END
            ELSE
			BEGIN
                SET @InsertScript = REPLACE(@InsertScript, '#$#' + @AuthenticationKey, @AuthenticationKey)	
			END
		END
            IF ( @MergeIPHead IS NOT NULL )
                BEGIN
                    DECLARE @CommaINDX INT
                    DECLARE @VIPINDX INT
                    DECLARE @VIProwLocal NVARCHAR(MAX)
                    SET @VIProwLocal = @InsertScript
                    SET @VIPINDX = PATINDEX('%''Static'',N''SP:%', @VIProwLocal) - 1
                    IF ( @VIPINDX > 1 )
                        BEGIN
                            BEGIN TRY
                                SET @VIProwLocal = SUBSTRING(@VIProwLocal, @VIPINDX + 15, 13)
                                SET @CommaINDX = CHARINDEX(',', @VIProwLocal)
                                SET @VIProwLocal = LEFT(@VIProwLocal, @CommaINDX - 2)
                                DECLARE @NEWVIP AS BIGINT
                                SET @NEWVIP = CAST(@VIProwLocal AS BIGINT)
                                SET @NEWVIP = @NEWVIP + @MergeIPHead
                                DECLARE @LEFTSTR AS NVARCHAR(MAX)
                                DECLARE @RIGHTST AS NVARCHAR(MAX)
                                SET @LEFTSTR = LEFT(@InsertScript, @VIPINDX);
                                SET @RIGHTST = RIGHT(@InsertScript, LEN(@InsertScript) - @VIPINDX - 15 - @CommaINDX);
					SET @InsertScript = @LEFTSTR + '''Static'',N''' + CAST(@NEWVIP AS NVARCHAR(15)) + ''',N' + @RIGHTST;
                            END TRY
                            BEGIN CATCH
					INSERT  INTO [VPNDataBase].[dbo].[TSqlError] ([userid], [moment], [operate], [errorcode], [errortext], [comment])
					VALUES  ( 1, GETDATE(), @InsertScript,  @@Error, ERROR_MESSAGE(), N'USP_SelectUsersFromImportedBackupData' ) 
                            END CATCH
                        END
                END
            BEGIN TRY	
                --SET IDENTITY_INSERT TUser ON

				
                EXEC sp_executesql @InsertScript
			if(@PlainAuthKey = 1)
 
				UPDATE  tuser SET authenticationkey = @EncAuthKey WHERE   userID = @userid
        END TRY
        BEGIN CATCH
			if(@PlainAuthKey = 0)
                    BEGIN
                
				if(ERROR_MESSAGE() like '%Incorrect syntax near%')
                            BEGIN
					BEGIN TRY
						Set @InsertScript = REPLACE (@InsertScript ,'''','''''')
						SET @InsertScript = REPLACE (@InsertScript , ''''',',''',')
						SET @InsertScript = REPLACE (@InsertScript , ',N''''',',N''')
						SET @InsertScript = REPLACE (@InsertScript , ',''''',',''')
						SET @InsertScript = REPLACE (@InsertScript , ''''')',''')')
						SET @InsertScript = REPLACE (@InsertScript , 'VALUES(''''','VALUES(''')
						EXEC sp_executesql @InsertScript 	
            END TRY
            BEGIN CATCH
						INSERT  INTO [VPNDataBase].[dbo].[TSqlError]([userid], [moment], [operate], [errorcode], [errortext], [comment] )
            VALUES (1,  GETDATE(),  @InsertScript, @@Error, ERROR_MESSAGE(), N'USP_SelectUsersFromImportedBackupData Error in Key Bad Character' )
					END CATCH
				END
			END
			INSERT  INTO [VPNDataBase].[dbo].[TSqlError]([userid], [moment], [operate], [errorcode], [errortext], [comment] )
            VALUES (1,  GETDATE(),  @InsertScript, @@Error, ERROR_MESSAGE(), N'USP_SelectUsersFromImportedBackupData' )
            END CATCH	
            
            FETCH NEXT FROM User_cursor 
             INTO @UserName, @UserID, @InsertScript
    
        END
    DROP TABLE #Table
    CLOSE User_cursor;
    DEALLOCATE User_cursor;
	DECLARE @countVip AS INT
    DECLARE @VIP AS NVARCHAR(20)
	DECLARE @user_vip AS BIGINT
	DECLARE vip_cursor CURSOR FAST_FORWARD
    FOR
    SELECT VirtualIP, COUNT(Virtualip) FROM Tuser 
	WHERE virtualIPstatus = 'Static' 
	GROUP BY Virtualip HAVING (COUNT(Virtualip) > 1)
    OPEN vip_cursor
    FETCH NEXT FROM vip_cursor INTO @VIP, @countVip
	WHILE @@FETCH_STATUS = 0
    BEGIN 
		SELECT @user_vip = MAX(@UserID) FROM dbo.TUser WHERE VIRTUALIP = @VIP AND virtualIPstatus = 'Static' 
		UPDATE  tuser SET VirtualIPStatus = 'Dynamic', virtualIP = NULL, Notes = ' User static virtual IP changed during restore operation preventing conflict. Old Static Virtual IP was: ['+ @VIP + '] '
        WHERE   UserID = @user_vip
    END
	CLOSE vip_cursor;
    DEALLOCATE vip_cursor;
	UPDATE  tuser SET InterfaceBindingStatus = 'False'
END

/******************************************************************************************************************************************************/------------------
go

