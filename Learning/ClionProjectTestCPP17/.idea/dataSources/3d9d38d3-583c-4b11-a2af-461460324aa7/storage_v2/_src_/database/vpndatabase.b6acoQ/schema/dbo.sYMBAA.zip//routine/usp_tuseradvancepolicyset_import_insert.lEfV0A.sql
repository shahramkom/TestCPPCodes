/*************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[USP_TUserAdvancePolicySet_Import_Insert] 
    @UserID     int,
    @PSID	  int
AS
BEGIN

    SET NOCOUNT ON;
   
	declare @priority int
	set @priority = 0			
    select @priority = max(PolPriority) from TUserPolicySet where UserID = @UserID 
	    if(@Priority is null)
        set @Priority = 0
    set @priority = 	@priority + 1 	  
    Exec USP_TUserPolicySet_Insert @UserID,@PSID,@priority
end
go

