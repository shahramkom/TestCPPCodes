
    CREATE PROCEDURE [dbo].[USP_TScript_CountGroup] 
        -- Add the parameters for the stored procedure here
        @GroupID int
      
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        Select Count(GroupID) from TGroupScript
        Where GroupID = @GroupID
    END


    go

