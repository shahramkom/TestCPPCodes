
    CREATE PROCEDURE  [dbo].[USP_SAUTH_FILTER_EXPORT]
        @L_UserID		bigint=Null,
        @L_Enter		int=Null,
        @L_Exit			int=Null,
        @L_Error		int=Null,
		@L_HealthCheck	int=Null,
        @L_HostName		nvarchar(50)=NUll,
        @L_LoginName	nvarchar(50)=NULl,
        @L_DomainName	nvarchar(128)=NUll,
        @L_KeyASerial	nvarchar(50)=Null,
        @L_RealIP		nvarchar(20)=Null,
        @strDate		nvarchar(10)=Null,
        @strTime		nvarchar(8)=Null,	
        @endDate		nvarchar(10)=Null,
        @endTime		nvarchar(8)=Null,
		    @MiniAdminUID   int = 1
    AS
        SET NOCOUNT ON
      declare @filter nvarchar(max)
      if (@L_UserID is not null)
        set @filter = isnull(@filter ,'') +  '(userID = ' + isnull(cast(@L_UserID as nvarchar(100)) , '') +')AND'
    if (@L_HostName is not null)	
        set @filter = isnull(@filter ,'') +  '(HostName >= '''+@L_HostName+''')AND'
    if (@L_LoginName is not null)	
        set @filter = isnull(@filter ,'') +  '(LoginName >= '''+@L_LoginName+''')AND'
    if (@L_DomainName is not null)	
        set @filter = isnull(@filter ,'') +  '(DomainName >= '''+@L_DomainName+''')AND'	
    if (@L_KeyASerial is not null)	
        set @filter = isnull(@filter ,'') +  '(KeyASerial >= '''+@L_KeyASerial+''')AND'	
    if (@L_RealIP is not null)	
        set @filter = isnull(@filter ,'') +  '(RealIP >= '''+@L_RealIP+''')AND'			
    if (@strDate = @endDate)	
        set @filter = isnull(@filter ,'') +  '(eventDate = '''+@strDate+''' AND eventTime >= '''+ @strTime+''' AND eventTime <= '''+@endTime+''')AND'
    else
        set @filter = isnull(@filter ,'') +  '(((eventDate > '''+@strDate+''') AND (eventDate < '''+ @endDate  +''')) OR ((eventDate = '''+@strDate + ''' AND eventTime >= '''+ @strTime+''' )) OR '
            + ' ((eventDate = '''+@endDate + ''' AND eventTime <= '''+ @endTime+''' )))AND'

    set @filter = substring(@filter , 0 , LEN(@filter) - 2)
    if(@L_Exit is not null or  @L_Enter is not null or @L_Error is not null or @L_HealthCheck is not null)
    begin
    set @filter =  @filter + 'AND('
    if (@L_Exit is not null)
        set @filter = isnull(@filter ,'') +  '(Type = ' + isnull(cast(@L_Exit as nvarchar(100)) , '') +')OR'	
    if (@L_Enter is not null)
        set @filter = isnull(@filter ,'') +  '(Type = ' + isnull(cast(@L_Enter as nvarchar(100)) , '') +')OR'	
    if (@L_Error is not null)
        set @filter = isnull(@filter ,'') +  '(Type = ' + isnull(cast(@L_Error as nvarchar(100)) , '') +')OR'	
	if (@L_HealthCheck is not null)
        set @filter = isnull(@filter ,'') +  '(Type = ' + isnull(cast(@L_HealthCheck as nvarchar(100)) , '') +')OR'	
		
    set @filter = substring(@filter , 0 , LEN(@filter) - 1)	
    set @filter =  @filter + ')'
	if (@MiniAdminUID <> 1)
	BEGIN
		Declare  @MAType as nvarchar(10)
		SELECT   @MAType =  dbo.SpecialPermission.MiniAdminType	FROM         dbo.SpecialPermission INNER JOIN
                      dbo.TUser ON dbo.SpecialPermission.ID = dbo.TUser.Permission_ID
						WHERE     (dbo.TUser.UserID = @MiniAdminUID)
		IF(@MAType = 1) --1 Means power mini admin
		BEGIN
			SET @filter = @filter + 'AND(userID <> 1)'
		END
		ELSE
		BEGIN
			SET @filter = @filter + 'AND(UserID in(	SELECT dbo.TUser.UserID
						FROM     dbo.TUser INNER JOIN dbo.TUserGroups ON dbo.TUser.UserID = dbo.TUserGroups.UserID INNER JOIN dbo.TGroup ON dbo.TUserGroups.GroupID = dbo.TGroup.GroupID
						WHERE  (dbo.TGroup.GroupID in (	SELECT dbo.TPermissionGroup.Group_ID
						FROM     dbo.TPermissionGroup INNER JOIN dbo.SpecialPermission ON dbo.TPermissionGroup.Permission_ID = dbo.SpecialPermission.ID INNER JOIN
										  dbo.TUser ON dbo.SpecialPermission.ID = dbo.TUser.Permission_ID
						WHERE  (dbo.TUser.UserID = '+CAST(@MiniAdminUID as nvarchar(100))+')))))'
		END
	   END
    end
       declare 	@datasrc nvarchar(200)
       set 	@datasrc = ' sAuthLog '	
       declare @orderBy nvarchar(200)
       set @orderBy = ' eventDate DESC , eventTime DESC ' 
 
    declare  @fieldlist nvarchar(200) 
    set @fieldlist= 'Type,eventDate as Date,eventTime as Time,Event,userID,username,HostName,LoginName,DomainName,KeyASerial,RealIP,macaddr,clientVer,VirtualIP,Description'
      DECLARE
         @STMT nvarchar(max)         -- SQL to execute
        ,@recct int                  -- total # of records (for GridView paging interface)

        SET @STMT =  'SELECT   ' + @fieldlist + 
                     ' FROM     ' + @datasrc +
                     'WHERE    ' + @filter + 
                     'ORDER BY ' + @orderBy
              
         EXEC (@STMT)                 -- return requested records 

    go

