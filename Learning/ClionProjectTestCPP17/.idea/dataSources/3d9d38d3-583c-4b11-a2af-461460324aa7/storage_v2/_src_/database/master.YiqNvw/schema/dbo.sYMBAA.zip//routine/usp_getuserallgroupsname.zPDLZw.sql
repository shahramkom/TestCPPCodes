
  CREATE PROCEDURE [dbo].[USP_GetUserAllGroupsName]
	@UserID as bigint,
	@groupnames as nvarchar(max) OUTPUT
AS
BEGIN
DECLARE @PSIDs NVARCHAR(1000)	
	
	declare @groups as nvarchar(max)
	select @groups = STUFF ((SELECT ','+ CAST(GroupID AS VARCHAR(30)) FROM TUserGroups WHERE UserID = @userID FOR XML PATH('')) , 1 ,1 , '')
	declare @UserGroupsNames as nvarchar(max)
	declare @execStr as nvarchar(max)
	Set @execStr = 'SELECT @UserGroupsNames = STUFF ((SELECT '',''+ Groupname FROM tgroup WHERE groupid in ( ' +@groups+ '  ) FOR XML PATH('''')) , 1 ,1 , '''') '
	EXEC SP_EXECUTESQL @execStr, N'@UserGroupsNames NVARCHAR(max) OUTPUT', @UserGroupsNames OUTPUT
	SELECT @groupnames = @UserGroupsNames
end

  go

