
    CREATE PROCEDURE  [dbo].[USP_DNS_Delete]
    
        @DNSID	int		

    AS
    BEGIN
        SET NOCOUNT ON;
        DELETE FROM TDNS WHERE DNSID = @DNSID
		DELETE FROM TUserDNS WHERE DNSID = @DNSID		
    END


    go

