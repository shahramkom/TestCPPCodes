CREATE PROCEDURE [dbo].[USP_Insert_ActiveDirectory_Group]
        -- Add the parameters for the stored procedure here
    @UserName NVARCHAR(200),
    @GroupID NVARCHAR(50)
AS
BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
    SET NOCOUNT ON;

        -- Insert statements for procedure here
    DECLARE @UserID AS INT
	DECLARE @gid AS VARCHAR(25)

    SELECT  @UserID = UserID, @gid = GID
    FROM    TUser
    WHERE   UserName = @UserName
	 
    INSERT  INTO TUserGroups
            ( UserID, GroupID, GID )
    VALUES  ( @UserID, @GroupID, @gid )
END
/******************************************************************************************************************************************************/
go

