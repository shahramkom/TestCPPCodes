
CREATE PROCEDURE [dbo].[USP_User_Assigned_Policies] 

	@UserID as nvarchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @BaseSTM as nvarchar(MAX)
	SET @BaseSTM  = ''
		
	IF(@UserID IS  NULL)
		Raiserror ('UserID is NULL', 16 , 10)

	SET @BaseSTM =
		'WITH GroupIDTree (GroupID, ParentID,GroupName ,GPriority,  GLevel) AS 
   (    /*Anchor member definition*/ 
      SELECT    TGroup.GroupID,TGroup.ParentID,TGroup.GroupName,TUserGroups.GPriority ,1 as GLevel    
      FROM   TUser
             INNER JOIN          TUserGroups ON TUser.UserID = TUserGroups.UserID
             INNER JOIN          TGroup ON dbo.TUserGroups.GroupID = TGroup.GroupID       
             WHERE (TUser.UserID = '+@UserID+')
             
                 
             UNION ALL
             
             
              /*Recursive member definition*/    
             SELECT  TGroup.GroupID,TGroup.ParentID,TGroup.GroupName,GID.GPriority ,GLevel+1    
              FROM    TGroup      
              INNER JOIN  GroupIDTree as GID      ON (TGroup.GroupID = GID.ParentID)  
              )    
                              
              SELECT UnionTable.* FROM 
              (     
              
                 
             SELECT     TPolicySet.PSID  ,dbo.fnPolicyInheritedName( TPolicySet.PSName ,GIT.GroupName, GIT.GLevel)as PSName,GIT.GLevel ,TGroupPolicySet.PriorityOrder  
              FROM    TPolicySet INNER JOIN    
              TGroupPolicySet ON TPolicySet.PSID = TGroupPolicySet.PSID INNER JOIN    
              TGroup ON TGroupPolicySet.GroupID = TGroup.GroupID INNER JOIN    
              GroupIDTree as GIT  ON GIT.GroupID = TGroupPolicySet.GroupID  
                    
              UNION     
                  
             SELECT  TPolicySet.PSID ,dbo.fnPolicyInheritedName( TPolicySet.PSName ,'''',0)as PSName , 0 as Ulevel , TUserPolicySet.PolPriority
              FROM    TPolicySet INNER JOIN      
              TUserPolicySet ON TPolicySet.PSID = TUserPolicySet.PSID INNER JOIN      
              TUser ON dbo.TUserPolicySet.UserID = TUser.UserID    
              WHERE (TUser.UserID = '+@UserID+')
               ) 
              as UnionTable order by GLevel,PriorityOrder'
	
	--Excuting command
	--select @BaseSTM
	EXEC dbo.sp_executesql @BaseSTM  					
	
END
go

