CREATE PROCEDURE [dbo].[USP_GetAllUFPByPSID] 
	@PSID int
AS
BEGIN
	select * from TUserFirewallPolicy where PSID = @PSID and Status = 1 order by POrder
END
go

