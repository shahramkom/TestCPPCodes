/******************************************************************************************************************************************************/--
CREATE FUNCTION dbo.GetAssignType(@RecordAssignedGroups VARCHAR(MAX),@RecordAssignedUsers VARCHAR(MAX))
RETURNS VARCHAR(20)
BEGIN
	IF ((@RecordAssignedUsers IS NOT NULL AND @RecordAssignedUsers <> '') AND (@RecordAssignedGroups IS NOT NULL AND @RecordAssignedGroups <> ''))
		RETURN 'Assign-Users'
	ELSE IF ((@RecordAssignedUsers IS NULL OR @RecordAssignedUsers = '') AND (@RecordAssignedGroups IS NOT NULL AND @RecordAssignedGroups <> ''))
		RETURN 'Assign-Groups'
	RETURN ''
END
go

