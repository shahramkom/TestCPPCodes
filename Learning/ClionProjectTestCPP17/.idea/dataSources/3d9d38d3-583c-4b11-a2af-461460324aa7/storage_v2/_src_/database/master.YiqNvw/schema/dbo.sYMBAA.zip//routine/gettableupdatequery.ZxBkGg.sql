/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetTableUpdateQuery]( @TableName nvarchar(100), @IDFieldName nvarchar(100), @IDFieldValue varchar(20))
		RETURNS nvarchar(MAX)
	AS
	BEGIN
		DECLARE CursCol CURSOR FAST_FORWARD FOR 
		SELECT column_name,data_type FROM information_schema.columns WHERE table_name = @TableName AND ORDINAL_POSITION <> 1
		OPEN CursCol
		DECLARE @String nvarchar(MAX) --for storing the first half of INSERT statement
		DECLARE @StringData nvarchar(MAX) --for storing the data (VALUES) related statement
		DECLARE @DataType nvarchar(100) --data types returned for respective columns
		
		SET @StringData=' '

		DECLARE @ColName nvarchar(50)

		DECLARE @Query nvarchar(MAX)
		SET @Query = ' '
		FETCH NEXT FROM CursCol INTO @ColName, @DataType
		WHILE @@FETCH_STATUS=0
		BEGIN
			if(@TableName = 'TUser' AND @ColName = 'AuthenticationKey')
				SET @ColName = 'ENCRYPTEDUSERAUTHKEY'
			SET @StringData = [dbo].getDataTypeString(@DataType,@ColName)
			SET @Query = @Query + @ColName+  ' = ''+ ' + substring(@StringData,0,len(@StringData)-2)+',''+'''
			FETCH NEXT FROM CursCol INTO @ColName,@DataType
		END
		SET @Query = LEFT(@Query, LEN(@Query)-6)

		SET @Query = 'SELECT ''UPDATE '+@TableName+' SET ' + @Query +' From '  + @TableName + ' WHERE ' + @IDFieldName +' = ' + @IDFieldValue +''
		
		if(@TableName = 'TUser')
			SET @Query = REPLACE(@Query , 'ENCRYPTEDUSERAUTHKEY = ','AuthenticationKey = ')

		CLOSE CursCol
		DEALLOCATE CursCol
		return @Query
END
go

