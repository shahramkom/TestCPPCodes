
	create PROCEDURE [dbo].[USP_TInterface_Delete]
		-- Add the parameters for the stored procedure here
		@InterfaceID as nvarchar(max)
	
	AS
	BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;

		-- Insert statements for procedure here
		declare @Statement as nvarchar(max)
		declare @Statement2 as nvarchar(max)
		set @Statement = 'delete from TUserInterface where InterfaceID not in( '
		set @Statement = isnull(@Statement ,'') + convert(nvarchar(max),@InterfaceID )+ ')'
		--select @Statement;
		exec sp_executesql @Statement
	
		set @Statement2 = 'delete from TGroupInterface where InterfaceID not in( '
		set @Statement2 = isnull(@Statement2 ,'') + convert(nvarchar(max),@InterfaceID )+ ')'
		--select @Statement2;
		exec sp_executesql @Statement
	END

  go

