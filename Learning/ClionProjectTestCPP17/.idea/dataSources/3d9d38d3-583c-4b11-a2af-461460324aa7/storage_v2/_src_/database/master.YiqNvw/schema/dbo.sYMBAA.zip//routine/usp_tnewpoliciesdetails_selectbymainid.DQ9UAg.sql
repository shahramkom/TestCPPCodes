
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesDetails_SelectByMainID] 
   @MainID  bigint
   AS
   BEGIN
	SELECT [ID]
		  ,[MainID]
		  ,[AllowNat]
		  ,[NatIP]
		  ,[VirtualIPType]
		  ,[VirtualIPValue]
		  ,[SourceTunnelType]
		  ,[SourceTunnelValue]
		  ,[DestinationTunnelType]
		  ,[DestinationTunnelValue]
	  FROM [dbo].[TNewPoliciesDetails]
	  WHERE MainID = @MainID
   END

   go

