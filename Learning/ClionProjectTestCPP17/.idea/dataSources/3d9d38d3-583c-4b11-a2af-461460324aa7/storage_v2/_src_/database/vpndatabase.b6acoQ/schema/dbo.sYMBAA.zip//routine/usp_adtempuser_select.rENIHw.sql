
    CREATE PROCEDURE  [dbo].[USP_ADTempUser_Select]
    
    
    AS
    BEGIN
    SELECT  *
            FROM TADTempUser
    END

    go

