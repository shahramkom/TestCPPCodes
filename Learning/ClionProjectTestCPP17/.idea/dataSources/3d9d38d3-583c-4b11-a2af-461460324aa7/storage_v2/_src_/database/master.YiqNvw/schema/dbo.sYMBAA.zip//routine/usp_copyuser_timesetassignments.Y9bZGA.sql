
	CREATE PROCEDURE [dbo].[USP_CopyUser_TimeSetAssignments] 
    @OldUserID  bigint,
	@NewUserID  bigint
   AS
   BEGIN
		INSERT INTO TUserTimeSet (UserID	 , TimeSetId,TPriority)
		SELECT 	@NewUserID	 ,TimeSetId	,TPriority 
		FROM TUserTimeSet WHERE UserID = @OldUserID
   END

  go

