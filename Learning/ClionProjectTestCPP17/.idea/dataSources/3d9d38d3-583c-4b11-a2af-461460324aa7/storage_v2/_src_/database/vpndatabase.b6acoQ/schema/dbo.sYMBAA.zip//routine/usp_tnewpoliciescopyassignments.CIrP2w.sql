
	  CREATE PROCEDURE [dbo].[USP_TNewPoliciesCopyAssignments] 
        @ModernPolicyID int ,
		@CopiedModernPolicyID int 
    AS
    BEGIN
		INSERT INTO [dbo].[TNewPolicyGroupAssign] ([GroupID],[ModernPID],[PriorityOrder])
	    SELECT [GroupID],@CopiedModernPolicyID,[PriorityOrder] FROM TNewPolicyGroupAssign WHERE ModernPID = @ModernPolicyID

        INSERT INTO [dbo].[TNewPolicyUserAssign] ([UserID],[ModernPID],[PriorityOrder])
		SELECT [UserID],@CopiedModernPolicyID,[PriorityOrder] FROM TNewPolicyUserAssign WHERE ModernPID = @ModernPolicyID
    END

    go

