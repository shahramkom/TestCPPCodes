
    CREATE PROCEDURE  [dbo].[USP_TServerAccessPolicy_Select]
        
    AS
    BEGIN
        --SET NOCOUNT ON;
        SELECT TOP 1 PolicyID from TServerAccessPolicy 
        order by PolicyID  desc

    END

    go

