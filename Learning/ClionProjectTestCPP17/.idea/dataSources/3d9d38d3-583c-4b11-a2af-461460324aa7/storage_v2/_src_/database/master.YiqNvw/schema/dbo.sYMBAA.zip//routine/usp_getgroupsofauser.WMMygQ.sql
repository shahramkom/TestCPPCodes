/*************************************************************************************************************************************************************/
--New Queries Needed By Controller Service
/*************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[USP_getGroupsOfAUser] 
	@UserID BIGINT
AS
BEGIN
	select GroupID from TUserGroups where UserID =  @UserID order by GPriority
END
go

