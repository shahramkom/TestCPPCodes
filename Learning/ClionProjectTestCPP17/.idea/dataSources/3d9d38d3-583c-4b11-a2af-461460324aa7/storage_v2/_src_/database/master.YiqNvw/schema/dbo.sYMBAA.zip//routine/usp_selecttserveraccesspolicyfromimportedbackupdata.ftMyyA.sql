
    CREATE PROCEDURE [dbo].[USP_SelectTServerAccessPolicyFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        
    declare  @PSID nvarchar(200),@InsertScript nvarchar(4000)

     Declare TServerAccessPolicy_cursor Cursor FAST_FORWARD
        For
        Select 
                  PSID,[output] 
            FROM tbl_InsertGroupScript   
            where tableName = 'TServerAccessPolicy'
            OPEN TServerAccessPolicy_cursor

    FETCH NEXT FROM TServerAccessPolicy_cursor
    INTO @PSID,@InsertScript

    WHILE @@FETCH_STATUS = 0
    begin 

    ----		if(exists (select PSID from TServerAccessPolicy where PSName = @PSName ))
    ----		Begin
    ----			if(@Replace = '1')
    ----				 Delete from TServerAccessPolicy   where PSName = @PSName	
    ----		End
            BEGIN TRY
                SET IDENTITY_INSERT TServerAccessPolicy ON
                exec sp_executesql @InsertScript	
                SET IDENTITY_INSERT TServerAccessPolicy OFF	
            END TRY
            BEGIN CATCH
				 INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectTServerAccessPolicyFromImportedBackupData')
		    END CATCH
            
            
            FETCH NEXT FROM TServerAccessPolicy_cursor 
             INTO @PSID,@InsertScript
    
        end
        CLOSE TServerAccessPolicy_cursor;
        DEALLOCATE TServerAccessPolicy_cursor;			
    END


    go

