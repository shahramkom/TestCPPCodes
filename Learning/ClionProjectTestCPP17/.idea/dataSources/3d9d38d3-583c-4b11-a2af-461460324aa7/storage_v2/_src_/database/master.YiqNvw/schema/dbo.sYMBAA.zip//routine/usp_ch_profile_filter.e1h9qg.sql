CREATE PROCEDURE [dbo].[USP_CH_Profile_Filter]			
	@profileID int = Null
AS	
BEGIN
	IF(@profileID is null)
	     SELECT [ProfileID],[Name],[Description],[RuleIDs],[Activity],dbo.SelCheckHealthGroupsUsers(CH.ProfileID)AS Assignments FROM [dbo].[HealthCheckProfiles] AS CH
	ELSE
		SELECT [ProfileID],[Name],[Description],[RuleIDs],[Activity],dbo.SelCheckHealthGroupsUsers(CH.ProfileID)AS Assignments FROM [dbo].[HealthCheckProfiles]  AS CH WHERE [ProfileID] = @profileID
END

go

