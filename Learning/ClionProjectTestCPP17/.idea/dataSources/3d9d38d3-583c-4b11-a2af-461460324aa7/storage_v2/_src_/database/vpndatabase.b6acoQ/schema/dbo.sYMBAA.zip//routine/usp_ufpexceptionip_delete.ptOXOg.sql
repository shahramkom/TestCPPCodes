
    CREATE PROCEDURE [dbo].[USP_UFPExceptionIP_Delete]
    
        @UFPExID INT	

    AS
    BEGIN
        
        DELETE FROM TUFPExceptionIP
        WHERE UFPExID = @UFPExID 
    
    END

    go

