
    CREATE PROCEDURE [dbo].[USP_TSetting_UpdateValue]
        -- Add the parameters for the stored procedure here
        @value		nvarchar(4000),
        @Property	nvarchar(400)
    AS
    BEGIN
            UPDATE TSetting set value = @value 
            where Property = @Property
    END

    go

