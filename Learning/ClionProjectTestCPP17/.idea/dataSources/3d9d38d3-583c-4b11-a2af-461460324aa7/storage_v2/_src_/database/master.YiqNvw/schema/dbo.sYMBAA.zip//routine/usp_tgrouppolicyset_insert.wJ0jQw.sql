
    create PROCEDURE [dbo].[USP_TGroupPolicySet_Insert] 
        -- Add the parameters for the stored procedure here
        @groupID int,
        @PolicyNameList nvarchar(max)
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
        declare @policyName as nvarchar(50)
        declare @PolicyID as int
        declare @priority as int
        set @priority = 1
        
        declare policy_Cursor1 cursor for 
        SELECT * FROM dbo.Splitfn(@PolicyNameList,',')
        
        open policy_Cursor1
        fetch next from policy_Cursor1 into @policyName
        
        while @@FETCH_STATUS = 0
        begin
        select @PolicyID = PSID from TPolicySet where PSName = @policyName
        
        insert into  TGroupPolicySet 
        (GroupID,PSID,PriorityOrder) 
        values (@groupID,@PolicyID,@priority)
        
        set @priority = @priority + 1
        
        fetch next from policy_Cursor1 into @policyName
        end
        close policy_Cursor1
        DEALLOCATE policy_Cursor1
    END

    go

