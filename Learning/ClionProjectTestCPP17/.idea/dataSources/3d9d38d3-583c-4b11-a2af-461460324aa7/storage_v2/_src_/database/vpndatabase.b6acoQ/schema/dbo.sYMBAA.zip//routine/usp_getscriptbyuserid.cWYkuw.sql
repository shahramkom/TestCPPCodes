CREATE PROCEDURE [dbo].[USP_GetScriptByUserID] 
	@UserID bigint
AS
BEGIN
	select ScriptTitle,ScriptText from TScript inner join TUserscripts on TScript.ScriptID =  TUserscripts.ScriptID where TUserscripts.userID = @UserID and ScriptActivity=1
END
go

