
    create PROCEDURE [dbo].[Insert_TLogs]
    
        @Log nchar(1000),
        @LogID int =NULL OUTPUT

    AS
    BEGIN

        insert into TAllLogs
        (Log)
        values
        (@Log)

        SET @LogID = @@IDENTITY
    

    END
    go

