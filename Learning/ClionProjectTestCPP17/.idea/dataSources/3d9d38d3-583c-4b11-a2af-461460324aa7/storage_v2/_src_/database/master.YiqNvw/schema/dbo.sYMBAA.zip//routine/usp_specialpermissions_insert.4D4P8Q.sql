

    CREATE PROCEDURE [dbo].[USP_SpecialPermissions_INSERT] 

        @PermissionName	nvarchar(50),
        @Management	bit,
        @LimitedUserMngmntAdd bit,
        @LimitedUserMngmntEdit bit,
        @ChangeDB bit,
        @UserMngmnt bit,
        @GroupMngmnt bit,
        @TimeMngmnt bit,
        @BckupDB bit,
        @ImportAD bit,
        @PolicyMngmnt bit,
        @PolicyGrpMngmnt bit,
        @DNSMngmnt bit,
        @RestoreMngmnt bit,
        @Permission bit,
        @UserMngmntView bit,
        @GroupMngmntView bit,
        @TimeMngmntView bit,
        @PolicyMngmntView bit,
        @PolicyGrpMngmntView bit,
        @DNSMngmntView bit,
        @ScriptMngmntView bit,
        @ScriptMngmnt bit,
        @ViewAuthLog bit,
        @DeleteAuthLog bit,
        @ExportAuthLog bit,
        @ViewKeyhanMngLog bit,
        @DeleteKeyhanMngLog bit,
        @ViewSettingServerLog bit,
        @DeleteSettingServerLog bit,
        @ViewKIPSLog bit,
        @DeleteKIPSLog bit,
        @ViewUsrRepLog bit,
        @ViewConn bit,
        @RejectUser bit,
        @ProgModule bit,
        @ReadLog bit,
        @ServerMonitor bit,
        @RestartSystem bit,
        @RestartSettingServer bit,
        @RestartKIPS bit,
        @RestartWatchDog bit,
        @RestartDB bit,
        @RestartLogServer bit,
        @RestartController bit,
        @DenyExportImportUserInfo bit ,
        @ExportUserInfo bit ,
        @ImportUserInfo bit ,
        @ExportImportUserInfo bit ,
        @MiniAdminType	int		
    AS
    BEGIN
        declare @spcount int 
        select @spcount=count(*) from  SpecialPermission where PermissionName = @PermissionName 
        IF(@spcount > 0)
            begin
                Raiserror('The entered special permission name already exist. Please choose another name.', 16 , 10 )
                return
            end
        insert into SpecialPermission
         (PermissionName,Management,LimitedUserMngmntAdd,LimitedUserMngmntEdit,ChangeDB,UserMngmnt,GroupMngmnt,TimeMngmnt,BckupDB,
         ImportAD,PolicyMngmnt,PolicyGrpMngmnt,DNSMngmnt,RestoreMngmnt,Permission,UserMngmntView,GroupMngmntView,
         TimeMngmntView,PolicyMngmntView,PolicyGrpMngmntView,DNSMngmntView,ScriptMngmntView,ScriptMngmnt,ViewAuthLog,DeleteAuthLog,ExportAuthLog,ViewKeyhanMngLog,
         DeleteKeyhanMngLog,ViewSettingServerLog,DeleteSettingServerLog,ViewKIPSLog,DeleteKIPSLog,ViewUserReport,ViewConn,RejectUser,
         ProgModule,ReadLog,ServerMonitor,RestartSystem,RestartSettingServer,RestartKIPS,RestartWatchDog,RestartDB,RestartLogServer,
         RestartController,DenyExportImportUserInfo,ExportUserInfo,ImportUserInfo,ExportImportUserInfo,MiniAdminType) 
        values
         (@PermissionName,@Management,@LimitedUserMngmntAdd,@LimitedUserMngmntEdit,@ChangeDB,@UserMngmnt,@GroupMngmnt,@TimeMngmnt,@BckupDB,
         @ImportAD,@PolicyMngmnt,@PolicyGrpMngmnt,@DNSMngmnt,@RestoreMngmnt,@Permission,@UserMngmntView,@GroupMngmntView,
         @TimeMngmntView,@PolicyMngmntView,@PolicyGrpMngmntView,@DNSMngmntView,@ScriptMngmntView,@ScriptMngmnt,@ViewAuthLog,@DeleteAuthLog,@ExportAuthLog,@ViewKeyhanMngLog,
         @DeleteKeyhanMngLog,@ViewSettingServerLog,@DeleteSettingServerLog,@ViewKIPSLog,@DeleteKIPSLog,@ViewUsrRepLog,@ViewConn,@RejectUser,
         @ProgModule,@ReadLog,@ServerMonitor,@RestartSystem,@RestartSettingServer,@RestartKIPS,@RestartWatchDog,@RestartDB,@RestartLogServer,
         @RestartController,@DenyExportImportUserInfo,@ExportUserInfo,@ImportUserInfo,@ExportImportUserInfo,@MiniAdminType)
    END


    go

