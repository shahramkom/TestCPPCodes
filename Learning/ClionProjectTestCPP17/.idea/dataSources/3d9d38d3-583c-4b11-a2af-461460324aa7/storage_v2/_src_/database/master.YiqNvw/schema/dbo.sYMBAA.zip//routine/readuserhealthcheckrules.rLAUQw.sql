--------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[ReadUserHealthCheckRules] 
	@UserID INT
AS
BEGIN

	DECLARE @GroupsID VARCHAR(1000)
	SET @GroupsID = dbo.GetAllRelatedGroupsOfUser(@UserID);
	
	BEGIN TRY
    DROP TABLE #TableProfileRules
	END TRY
	BEGIN CATCH	
	END CATCH

	CREATE TABLE #TableProfileRules(TempID INT IDENTITY(1,1), TempRuleIDs VARCHAR(MAX))

	INSERT INTO #TableProfileRules 
	SELECT DISTINCT RuleIDs FROM HealthCheckProfiles AS profiles
	LEFT OUTER JOIN HealthCheckUserAssign ON profiles.ProfileID = HealthCheckUserAssign.ProfileID
	LEFT OUTER JOIN HealthCheckGroupAssign ON profiles.ProfileID = HealthCheckGroupAssign.ProfileID
	WHERE (profiles.Activity = 1)
	AND ((HealthCheckUserAssign.UserID = @UserID)
	OR (HealthCheckGroupAssign.GroupID IN (SELECT items FROM dbo.Splitfn(@GroupsID, ','))))
	
	DECLARE @count INT 
	DECLARE @RuleIDs VARCHAR(MAX)
	DECLARE @i INT
	SET @i = 1
	SELECT @count = COUNT(TempID) FROM #TableProfileRules

	DECLARE @OutputRulesInfo TABLE([RuleID] INT, [Category] TINYINT, [Action] TINYINT, [ActionParameter] NVARCHAR(MAX), [RuleType] TINYINT)
	
	WHILE (@i <= @count) 
	BEGIN 
		SELECT @RuleIDs = TempRuleIDs FROM #TableProfileRules WHERE #TableProfileRules.TempID = @i

		INSERT INTO @OutputRulesInfo([RuleID], [Category], [Action], [ActionParameter], [RuleType])
		SELECT HealthCheckRules.RuleID, HealthCheckRules.Category, HealthCheckRules.Action, HealthCheckRules.ActionParameter, HealthCheckRules.RuleType
		FROM HealthCheckRules INNER JOIN  dbo.Splitfn(@RuleIDs, ',') ON items = HealthCheckRules.RuleID
		WHERE NOT EXISTS (SELECT RuleID FROM @OutputRulesInfo ruleInfo WHERE ruleInfo.RuleID = HealthCheckRules.RuleID) 
		
		SET @i = @i + 1
	END

	SELECT * FROM @OutputRulesInfo
END

go

