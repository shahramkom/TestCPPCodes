 CREATE PROCEDURE [dbo].[USP_SelectTModuleBlockListFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
         @Replace bit	

    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        
    declare @keyaserial nvarchar(200) , @InsertScript nvarchar(4000)
    Declare TModuleBlockList_cursor Cursor FAST_FORWARD
        For
        Select 
                   keyaserial,[output]
            FROM tbl_InsertGroupScript   
            where tableName = 'TModuleBlockList'
            OPEN TModuleBlockList_cursor

    FETCH NEXT FROM TModuleBlockList_cursor
    INTO @keyaserial,@InsertScript

    WHILE @@FETCH_STATUS = 0
    begin 
                  
          
       if(exists (select * from TModuleBlockList where KeyaSerial = @keyaserial))
            Begin            
                if(@Replace = 1)
                    begin
                
                    Delete from TModuleBlockList  where KeyaSerial = @keyaserial
                    
                    end
            End
        
            BEGIN TRY            
                exec sp_executesql @InsertScript	
            END TRY
            BEGIN CATCH
				INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectTModuleBlockListFromImportedBackupData')
            END CATCH  	
            FETCH NEXT FROM TModuleBlockList_cursor 
            INTO @keyaserial,@InsertScript
        end
        CLOSE TModuleBlockList_cursor;
        DEALLOCATE TModuleBlockList_cursor;
                        
    END
 go

