/*************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[USP_InsertHealthCheckGenerator] 
	@GroupIDsStr as nvarchar(MAX)
AS
BEGIN
	DECLARE @tableName varchar(100)
	DECLARE @IDField varchar(100)
	DECLARE @NameField varchar(100)
	DECLARE @SecondNameField varchar(100)
	DECLARE @Query nvarchar(4000)

	SET @tableName = 'HealthCheckProfiles'
	SET @IDField = 'ProfileID'
	SET @NameField = 'Name'
	SET @query = dbo.GetTableColumns( @tableName, @IDField, @NameField )
	insert  tbl_InsertGroupScript( [output], HealthCheckID, HealthCheckName, tableName ) exec sp_executesql @query

	SET @tableName = 'HealthCheckRules'
	SET @IDField = 'RuleID'
	SET @NameField = 'Name'
	SET @query = dbo.GetTableColumns( @tableName, @IDField, @NameField )
	insert  tbl_InsertGroupScript( [output], HealthCheckID, HealthCheckName, tableName ) exec sp_executesql @query

	SET @tableName = 'HealthCheckGroupAssign'
	SET @IDField = 'ProfileID'
	SET @NameField = 'GroupID'
	SET @query = dbo.GetTableColumns( @tableName, @IDField, @NameField )+' WHERE GroupID in( '+@GroupIDsStr +')'
	insert  tbl_InsertGroupScript( [output], HealthCheckID, HealthCheckName, tableName ) exec sp_executesql @query

	SET @tableName = 'HealthCheckUserAssign'
	SET @IDField = 'ProfileID'
	SET @NameField = 'UserID'
	SET @query = dbo.GetTableColumns( @tableName, @IDField, @NameField )+' WHERE UserID in( SELECT UserID FROM TUserGroups WHERE GroupID IN ('+@GroupIDsStr +'))'
	insert  tbl_InsertGroupScript( [output], HealthCheckID, HealthCheckName, tableName ) exec sp_executesql @query

END
go

