/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.GetCurrentServerID()
	RETURNS tinyint
AS
BEGIN
		DECLARE @MyServerID as int
		SELECT  @MyServerID = [value] from TSetting Where [Property] = 'ServerID'
		RETURN @MyServerID
END
go

