--------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[ReadUserServerAccessPolicies] 
	@UserID INT
AS
BEGIN
	
BEGIN TRY
    DROP TABLE #UserAllSimplePolices
END TRY
BEGIN CATCH	
END CATCH

CREATE TABLE #UserAllSimplePolices(SAP_ID INT, SAP_NetworkIP NVARCHAR(15), SAP_NetworkMask NVARCHAR(15), SAP_Protocol NVARCHAR(10), SAP_Port NVARCHAR(50)
, SAP_PAction NVARCHAR(50), [SAP_Auth] NVARCHAR(200), [SAP_Encryption]NVARCHAR(200), [SAP_Compression] bit, SAP_IP_RangeType nvarchar(20), UserSap_Order int, SAP_Order int)
ALTER TABLE #UserAllSimplePolices ADD ID INT IDENTITY(1, 1) PRIMARY KEY;

INSERT INTO #UserAllSimplePolices
SELECT DISTINCT SAP.[PolicyID], SAP.[NetworkIP],SAP.[NetworkMask], SAP.[Protocol], SAP.[Port], SAP.[PAction]
, SAP.[Authentication], SAP.[Encryption], SAP.[Compression], SAP.[IP_RangeType], TUserPolicySet.PolPriority, SAP.POrder
FROM TUserPolicySet
JOIN TServerAccessPolicy AS SAP ON SAP.PSID = TUserPolicySet.PSID
WHERE SAP.Status = 1 AND (SAP.[ExpireDate] IS NULL OR SAP.[ExpireDate] >= CONVERT(NVARCHAR(10),GETDATE(),103)) AND userid = @UserID
ORDER BY TUserPolicySet.PolPriority, SAP.POrder

DECLARE @GroupsIDs NVARCHAR(100)
SET @GroupsIDs = dbo.GetAllRelatedGroupsOfUser( @UserID )

DECLARE @GroupsID NVARCHAR(10)
DECLARE Groups_Cursor CURSOR FOR SELECT * FROM dbo.Splitfn(@GroupsIDs,',')
OPEN Groups_Cursor
FETCH NEXT FROM Groups_Cursor INTO @GroupsID

WHILE @@FETCH_STATUS = 0
BEGIN
	INSERT INTO #UserAllSimplePolices
	SELECT DISTINCT SAP.[PolicyID], SAP.[NetworkIP],SAP.[NetworkMask], SAP.[Protocol]
	, SAP.[Port], SAP.[PAction]	, SAP.[Authentication]
	, SAP.[Encryption], SAP.[Compression], SAP.[IP_RangeType], TGroupPolicySet.PriorityOrder, SAP.POrder
	FROM TGroupPolicySet INNER JOIN TServerAccessPolicy AS SAP ON SAP.PSID = TGroupPolicySet.PSID
	WHERE TGroupPolicySet.GroupID = @GroupsID AND SAP.Status=1
	AND (SAP.[ExpireDate] IS NULL OR SAP.[ExpireDate] >= CONVERT(NVARCHAR(10),GETDATE(),103))
	AND (SAP.PolicyID NOT IN (SELECT SAP_ID FROM #UserAllSimplePolices))
	ORDER BY TGroupPolicySet.PriorityOrder, SAP.POrder

	FETCH NEXT FROM Groups_Cursor INTO @GroupsID
END

CLOSE Groups_Cursor;	
DEALLOCATE Groups_Cursor;

SELECT * FROM #UserAllSimplePolices
DROP TABLE #UserAllSimplePolices

END

go

