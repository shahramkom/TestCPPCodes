--------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[TestLinkServerConnection]
  @LinkServerObjectName NVARCHAR(100),
  @reternValue INT OUTPUT
AS
BEGIN
  DECLARE @sysservername sysname;
  SET @sysservername  = @LinkServerObjectName
  BEGIN TRY
	EXEC @reternValue = sys.sp_testlinkedserver @sysservername
  END TRY
  BEGIN CATCH
	SELECT @reternValue = ERROR_NUMBER()
  END CATCH
END
go

