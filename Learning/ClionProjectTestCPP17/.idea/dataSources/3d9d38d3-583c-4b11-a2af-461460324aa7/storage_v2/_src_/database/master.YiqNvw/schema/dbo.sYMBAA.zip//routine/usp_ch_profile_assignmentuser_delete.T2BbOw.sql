
CREATE PROCEDURE [dbo].[USP_CH_Profile_AssignmentUser_Delete]
  @CHP_ProfileID			int
AS
BEGIN
	DELETE FROM [HealthCheckUserAssign] WHERE [ProfileID] = @CHP_ProfileID
END
go

