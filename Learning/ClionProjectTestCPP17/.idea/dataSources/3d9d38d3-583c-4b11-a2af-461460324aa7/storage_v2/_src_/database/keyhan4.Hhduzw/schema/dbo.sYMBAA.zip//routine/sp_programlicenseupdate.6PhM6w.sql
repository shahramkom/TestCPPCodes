	CREATE PROCEDURE [dbo].[sp_ProgramLicenseUPDATE] 
	@lncID	int	,
	@ExpireDate	nvarchar(20),
	@LicenseID	varchar(64),
	@FileName nvarchar(500),
	@UserName nvarchar(150),
	@TotalUsers int,
	@OnlineUsers int,
	@USFPercent int,
	@NewFeatures Nvarchar(100)	
AS
BEGIN
	declare @CreateDate as nvarchar(20)
	select @CreateDate = CONVERT(nvarchar(20),GETDATE(),20)
	UPDATE [keyhan4].[dbo].[ProgramLicense]
    SET [CreateDate] = @CreateDate
      ,[ExpireDate] = @ExpireDate
      ,[LicenseID] = @LicenseID  
      ,[FileName]	= @FileName
	  ,[UserName] = @UserName
	  ,[TotalUsers] = @TotalUsers
	  ,[OnlineUsers] = @OnlineUsers
	  ,[USFPercent] = @USFPercent
	  ,[NewFeatures] = @NewFeatures
 WHERE ID = @lncID

END
  go

