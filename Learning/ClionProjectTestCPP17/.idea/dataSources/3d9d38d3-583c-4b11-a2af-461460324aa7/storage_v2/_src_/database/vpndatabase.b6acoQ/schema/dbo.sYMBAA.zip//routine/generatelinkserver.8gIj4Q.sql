--------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[GenerateLinkServer]
	@Server NVARCHAR(100)
	,@LinkServerName NVARCHAR(100)
AS
BEGIN	
	EXEC master.dbo.sp_addlinkedserver @server = @LinkServerName, @srvproduct=N'', @provider=N'SQLNCLI', @datasrc= @Server 
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'collation compatible', @optvalue=N'false'
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'data access', @optvalue=N'true'
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'dist', @optvalue=N'false'
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'pub', @optvalue=N'false'
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'rpc', @optvalue=N'true'
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'rpc out', @optvalue=N'true'
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'sub', @optvalue=N'false'
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'connect timeout', @optvalue=N'0'
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'collation name', @optvalue=null
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'lazy schema validation', @optvalue=N'false'
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'query timeout', @optvalue=N'0'
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'use remote collation', @optvalue=N'true'
	EXEC master.dbo.sp_serveroption @server= @LinkServerName, @optname=N'remote proc transaction promotion', @optvalue=N'true'
	EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname = @LinkServerName, @locallogin = NULL , @useself = N'False', @rmtuser = N'Keyhan4_Admin', @rmtpassword = N'H! 3v3ry B0dy 83'
END
go

