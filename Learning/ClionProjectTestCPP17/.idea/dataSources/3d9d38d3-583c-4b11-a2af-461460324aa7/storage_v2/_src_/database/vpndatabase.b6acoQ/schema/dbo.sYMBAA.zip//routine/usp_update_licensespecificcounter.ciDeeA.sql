
     Create PROCEDURE [dbo].[USP_Update_LicenseSpecificCounter]
	@count int = 0
    AS
    BEGIN
		if exists(select * from TSetting where [Property] = N'RemainingExpireDays')
			update TSetting set [value] = @count where [Property] = N'RemainingExpireDays'
		else
		    insert into TSetting (Property,value) values('RemainingExpireDays' , @count)
    END

     go

