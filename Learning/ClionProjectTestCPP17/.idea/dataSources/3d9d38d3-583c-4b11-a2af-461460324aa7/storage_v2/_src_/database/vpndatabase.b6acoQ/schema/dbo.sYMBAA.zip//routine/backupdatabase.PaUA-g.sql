--------------------------------------------------------------------------------

CREATE PROCEDURE  [dbo].[BackupDatabase]
	@BackupAddress AS varchar(1000)
AS
BEGIN	
	DECLARE @Result NVARCHAR(MAX)
	BEGIN TRY

	EXEC [VPNDataBase].[dbo].[SyncBackupDatabase]

	BACKUP DATABASE VPNDataBase TO DISK = @BackupAddress WITH INIT, NOSKIP, NOFORMAT

	SELECT @Result = 'Backup completed successfully.'

	END TRY  
	BEGIN CATCH
		SELECT @Result = 'Error occurred in backup: '+ ERROR_MESSAGE()
	END CATCH

	SELECT @Result

END
go

