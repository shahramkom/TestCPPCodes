
    Create PROCEDURE [dbo].[USP_ServerCA_Select]
    AS
    BEGIN	
        Select TOP(1) * FROM TServerCA
    END

    go

