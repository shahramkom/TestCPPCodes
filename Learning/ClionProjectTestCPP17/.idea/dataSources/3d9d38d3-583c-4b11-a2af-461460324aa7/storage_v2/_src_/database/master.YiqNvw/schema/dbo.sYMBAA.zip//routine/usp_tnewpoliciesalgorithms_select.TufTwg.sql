
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesAlgorithms_Select] 
   AS
   BEGIN
	SELECT [ID]
		  ,[EncryptionAlgorithm]
		  ,[IntegrityAlgorithm]
	  FROM [dbo].[TNewPoliciesAlgorithms]

   END

   go

