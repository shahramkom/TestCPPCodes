
   CREATE PROCEDURE [dbo].[USP_TNewPolicyMain_Select] 
   AS
   BEGIN
	SELECT [ID]
      ,[PolicyType]
      ,[Name]
      ,[Enablity]
      ,[ServicesID]
      ,[EncryptionID]
      ,[AdvancedDetailID]
      ,[Compression]
      ,[PolicyOrder]
      ,[CreateTime]
      ,[LastModifyTime]
      ,[Discription]
	  ,[ApplyTime]
      ,[sourceTunnelType]
      ,[sourceTunnelValue]
      ,[DestinationTunnelType]
      ,[DestinationTunnelValue]
      ,[DirectionType]
	  ,[EncryptionKey]
	  ,[IntegrityKey]
	  ,[TunnelID]
	  ,dbo.SelModernPolGroupsUsers(MP.ID)AS Assignments
   FROM [dbo].[TNewPolicyMainTable] AS MP
   ORDER BY ApplyTime DESC ,PolicyOrder ASC
   END

   go

