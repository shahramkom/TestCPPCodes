
    Create PROCEDURE [dbo].[USP_REPORT_FILTER_DisUSRS_EXP] 
        @startDate		nvarchar(10)=Null,
        @endDate		nvarchar(10)=Null
    AS
    BEGIN

        SET NOCOUNT ON;
        declare 
                @STMT		as nvarchar(max),
                @row			nvarchar(max),
                @descript		nvarchar(max),
                @opDate			nvarchar(10),
                @opTime			nvarchar(10),
                @tempUserID		nvarchar(max),
                @tempUserName	nvarchar(max),
                @tempFirstName	nvarchar(max),
                @tempLastName	nvarchar(max),
                @tempUserStatus	nvarchar(max)

        create table #tempTable(
            rowID			nvarchar(max),
            description		nvarchar(max),
            operationDate	nvarchar(10),
            operationTime	nvarchar(10)
        )
        set	 @STMT = 'select rowID,decription,operationDate,operationTime FROM managerLog where (operationDate >= '''+ @startDate + 
                     ''') AND (operationDate <= ''' + @endDate + 
                     ''') AND ((operationType = ''UPDATE'')OR(operationType = ''INSERT'')OR(operationType = ''MULTIEDIT'')) AND (logEvent = ''User'')
					 order by operationDate DESC , operationTime DESC'

        delete #tempTable
        delete  [VPNDataBase].[dbo].[TTempUserRep]

        insert #tempTable exec sp_executesql @STMT 

        declare @index1 as int


    DECLARE tableRow CURSOR FAST_FORWARD FOR
      select rowID ,description,operationDate,operationTime from #tempTable
    
    OPEN tableRow
        FETCH NEXT FROM tableRow INTO @row ,@descript,@opDate ,@opTime
        WHILE @@FETCH_STATUS=0
        BEGIN
    -------------finding userID in rowID------------------------------
        set @tempUserID = @row
        set @tempUserID = substring (@tempUserID, (patindex('%userID%', @tempUserID)+7) 
    ,(len(@tempUserID)- patindex('%userID=%', @tempUserID)+7))
        set @index1 = (CHARINDEX(';', @tempUserID))
        if @index1 <= 0
            set @index1 = 1
        declare @userIdStr nvarchar(200)
        set @userIdStr = @tempUserID
        set @userIdStr = substring (@userIdStr ,1,@index1-1)


    -------------finding userStatus in description---------------------
        set @tempUserStatus = @descript
        set @tempUserStatus = substring (@tempUserStatus, (patindex('%userStatus%', @tempUserStatus)+11) 
    ,(len(@tempUserStatus)- patindex('%UserStatus=%', @tempUserStatus)+11))
        set @index1 = (CHARINDEX(';', @tempUserStatus))
            if @index1 <= 0
                set @index1 = 1
        declare @userStatusStr nvarchar(200)
        set @userStatusStr = @tempUserStatus
        set @userStatusStr = substring (@userStatusStr ,1,200)

        if(@userStatusStr = 'Disable')
        begin
    
            if(@userIdStr not in(select userID from TTempUserRep))
            begin	
            -------------finding UserName in rowID-----------------------------
                set @tempUserName = @row 
                set @tempUserName = substring (@tempUserName, (patindex('%UserName%', @tempUserName)+9) 
            ,(len(@tempUserName)- patindex('%UserName=%', @tempUserName)+9))
                declare @userNameStr nvarchar(200)
                set @userNameStr = @tempUserName
                set @userNameStr = substring (@userNameStr ,1,200)

            -------------finding firstName in description----------------------
                set @tempFirstName = @descript
                set @tempFirstName = substring (@tempFirstName, (patindex('%FirstName%', @tempFirstName)+10) 
            ,(len(@tempFirstName)- patindex('%FirstName=%', @tempFirstName)+10))
                set @index1 = (CHARINDEX(';', @tempFirstName))
                if @index1 <= 0
                    set @index1 = 1
                declare @userFNameStr nvarchar(200)
                set @userFNameStr = @tempFirstName
                set @userFNameStr = substring (@userFNameStr ,1,@index1-1)

            -------------finding lastName in description----------------------
                set @tempLastName = @descript
                set @tempLastName = substring (@tempLastName, (patindex('%LastName%', @tempLastName)+9) 
            ,(len(@tempLastName)- patindex('%LastName=%', @tempLastName)+9))
                set @index1 = (CHARINDEX(';', @tempLastName))
                if @index1 <= 0
                    set @index1 = 1
                declare @userLNameStr nvarchar(200)
                set @userLNameStr = @tempLastName
                set @userLNameStr = substring (@userLNameStr ,1,@index1-1)

                INSERT into [VPNDataBase].[dbo].[TTempUserRep]
                    (
                    userID,		   
                    userName,	 
                    firstName,	  
                    lastName,	  
                    operationDate, 
                    operationTime 
                    )
                    values
                    (
                        @userIdStr,
                        @userNameStr,
                        @userFNameStr,
                        @userLNameStr,
                        @opDate,
                        @opTime
                    )
            end--inner if
            else 
            begin
                update [VPNDataBase].[dbo].[TTempUserRep]

                set 
                operationDate = @opDate,
                operationTime = @opTime

                where userID = @userIdStr
            end--inner else
            
        END--if
        else 
            delete from [VPNDataBase].[dbo].[TTempUserRep] where userID = @userIdStr

        FETCH NEXT FROM tableRow INTO @row,@descript,@opDate ,@opTime
        END--while
        select  *  FROM    TTempUserRep order by operationDate DESC , operationTime DESC
    END
    drop table #tempTable

    go

