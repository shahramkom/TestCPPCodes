	CREATE PROCEDURE [dbo].[checkUserPassValidity]
	@username nvarchar(50),
	@password nvarchar(50)
AS
BEGIN
	
	declare @tempuser nvarchar(50)
	select @tempuser = U_Name from Users where U_Name = @username and U_Password = @password
	if(@tempuser = @username)
	Begin
		select 'yes'
		select U_Mode from Users where U_Name = @username
	END
	ELSE
		Select 'No'
END
  go

