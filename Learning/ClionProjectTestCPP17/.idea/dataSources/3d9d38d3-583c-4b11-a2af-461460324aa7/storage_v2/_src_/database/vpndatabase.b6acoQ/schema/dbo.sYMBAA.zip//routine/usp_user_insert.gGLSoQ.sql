
/******************************************************************************************************************************************************/-----------------------------------------------------------------

CREATE PROCEDURE [dbo].[USP_User_Insert]
    @UserID INT, 
        --@GroupID			int	,	
    @UserName NVARCHAR(200) = NULL,
    @BindingStatus NVARCHAR(50) = NULL,
    @BindingPCID NVARCHAR(100) = NULL,
    @IPBindingStatus NVARCHAR(20) = NULL,
    @SubNetIP NVARCHAR(50) = NULL,
    @SubNetMask NVARCHAR(50) = NULL,
    @VirtualIPStatus NVARCHAR(50) = NULL,
    @VirtualIP NVARCHAR(15) = NULL,
    @UserPIN NVARCHAR(200) = NULL,
    @MasterPIN NVARCHAR(200) = NULL,
    @AuthenticationKey NVARCHAR(64) = NULL,
    @MustChangePIN BIT = NULL,
    @AccountDisable tinyInt = NULL,
    @RejOnKeepAliveFail BIT = NULL,
    @ShowUserPrivilege BIT = NULL,
    @AuthType TINYINT = NULL,
    @CertType NVARCHAR(50) = NULL,
    @CertValue NVARCHAR(64) = NULL,
    @FirstName NVARCHAR(200) = NULL,
    @LastName NVARCHAR(200) = NULL,
    @Gender NVARCHAR(10) = NULL,
    @Company NVARCHAR(200) = NULL,
    @Office NVARCHAR(200) = NULL,
    @Province NVARCHAR(200) = NULL,
    @Town NVARCHAR(200) = NULL,
    @Notes NVARCHAR(MAX) = NULL,
    @Email NVARCHAR(200) = NULL,
    @Cell NVARCHAR(50) = NULL,
    @PersonnelCode NVARCHAR(10) = NULL,
    @Phone NVARCHAR(200) = NULL,
    @NationalID NVARCHAR(10) = NULL,
    @Adress NVARCHAR(MAX) = NULL,
    @PostalCode NVARCHAR(200) = NULL,
    @Owner INT = NULL,
    @Permission_ID INT = NULL,
    @UnBlockPIN NVARCHAR(200) = NULL,
    @InterfaceBindingStatus AS BIT = 0,
    @LoginType AS TINYINT = 2,
    @LockModule AS BIT = 0,
    @ExpireDate NVARCHAR(20) = NULL,
    @VersionBindingStatus NVARCHAR(50) = 'Unbound',
    @BindingVersion NVARCHAR(10) = NULL,
    @SendDNS AS BIT = NULL,
    @DisableModernPolicy AS BIT = 1,
	@DriverType AS tinyInt = 0xFA
AS
BEGIN
    DECLARE @EncAuthKey NVARCHAR(64),
        @nTotalCount INT,
        @nTotalUser INT,
        @nRepUsers INT,
        @nDuplicateUsers INT 
    
    
    BEGIN TRY
        DROP TABLE #Table
    END TRY
    BEGIN CATCH
        --RAISERROR ('Error raised in TRY block.', 16, 1);
    END CATCH

    CREATE TABLE #Table
    (
      CommandLine NVARCHAR(200),
      Param1 NVARCHAR(200),
      [Output] NVARCHAR(64)
    )

    SELECT  @nTotalCount = COUNT(*)
    FROM    TUser
    SELECT  @nTotalUser = [value]
    FROM    TSetting
    WHERE   Property = 'TotalUser'
    IF ( @nTotalUser < @nTotalCount + 1 )
        BEGIN
            RAISERROR ('Number of total user exceeded' , 16 , 10)
            RETURN
        END
        
    IF ( @LoginType = 0 )
        BEGIN
            DECLARE @DefinedUsfCount INT,
                @PermittedUsfCount INT
            SET @DefinedUsfCount = 0
            SET @PermittedUsfCount = 0
            SELECT  @DefinedUsfCount = COUNT(*)
            FROM    TUser
            WHERE   LoginType = 0
            SELECT  @PermittedUsfCount = [value]
            FROM    TSetting
            WHERE   Property = 'UsfUserCount'
            IF ( @PermittedUsfCount < @DefinedUsfCount + 1 )
                BEGIN
                    RAISERROR ('Number of USF users exceeded.' , 16 , 10)
                    RETURN
                END
        END

	SET @nRepUsers = 0
    DECLARE @StartVirtualIpDWORD AS BIGINT
    DECLARE @StartVirtualIpString AS varchar(20)
	SELECT @StartVirtualIpString  = value from TSetting WHERE Property = 'UserVipPoolIp' 
	SET @StartVirtualIpDWORD = CAST( dbo.[ConvertIP2BigInt](@StartVirtualIpString) AS BIGINT)
	SELECT  @nRepUsers = COUNT(*) FROM TUser  WHERE VirtualIPStatus = 'static' AND VirtualIP IS NOT NULL AND  (VirtualIP = @VirtualIP OR @VirtualIP = CAST(CAST(VirtualIP as BIGINT)+@StartVirtualIpDWORD AS NVARCHAR(15)) OR @VirtualIP = CAST(CAST(VirtualIP as BIGINT)-@StartVirtualIpDWORD AS NVARCHAR(15))  )

    IF ( @nRepUsers > 0 )
        BEGIN
            RAISERROR ('The entered virtual ip assigned before. Please choose another ip .',16,10)
            RETURN
        END
    
    SET @nDuplicateUsers = 0
    SELECT  @nDuplicateUsers = COUNT(*)
    FROM    TUser
    WHERE   UserName IS NOT NULL
            AND UserName = @UserName
    IF ( @nDuplicateUsers > 0 )
        BEGIN
            RAISERROR ('The entered username assigned before. Please choose another username.',16,10)
            RETURN
        END
    
    INSERT  #Table
            EXEC Master..XYRunProc 'Encrypt', @AuthenticationKey
    SELECT  @EncAuthKey = [Output]
    FROM    #Table
    WHERE   CommandLine = 'Encrypt'	
    DROP TABLE #Table
    IF ( @EncAuthKey IS NULL )
        BEGIN
            RAISERROR ('The Authentication key is null!  Please check server configs.',16,10)
            RETURN		
        END
        --select @AuthenticationKey , @EncAuthKey

    IF ( @UserPIN IS NULL )
        SELECT  @UserPIN = [Value]
        FROM    TSetting
        WHERE   [property] = N'DefaultUserPIN'
    IF ( @MasterPIN IS NULL )
        SELECT  @MasterPIN = [Value]
        FROM    TSetting
        WHERE   [property] = N'DefaultMasterPIN'

    IF ( @UnBlockPIN IS NULL )
        SELECT  @UnBlockPIN = [Value]
        FROM    TSetting
        WHERE   [property] = N'DefaultUnBlockPIN'

    DECLARE @GID AS VARCHAR(25)
    SELECT  @GID = dbo.GenerateGID(-1, 0, NULL)
        
    DECLARE @CreateDateTime AS NVARCHAR(20)
    SELECT  @CreateDateTime = CONVERT(NVARCHAR(20), GETDATE(), 20)
    DECLARE  @newUserId AS INT
	SET @newUserId = dbo.CreateIdentity()
		
    INSERT  INTO TUser
            ( UserID		 ,
              UserName,
              BindingStatus,
              BindingPCID,
              IPBindingStatus,
              SubNetIP,
              SubNetMask,
              VirtualIPStatus,
              VirtualIP,
              UserPIN,
              MasterPIN,
              AuthenticationKey,
              MustChangePIN,
              AccountDisable,
              RejOnKeepAliveFail,
              ShowUserPrivilege,
              AuthType,
              CertType,
              CertValue,
              FirstName,
              LastName,
              Gender,
              Office,
              Province,
              Town,
              Company,
              Notes,
              Email,
              Cell,
              PersonnelCode,
              Phone,
              NationalID,
              Adress,
              PostalCode,
              [Owner],
              Permission_ID,
              UnBlockPIN,
              InterfaceBindingStatus,
              LoginType,
              LockModule,
              ExpireDate,
              VersionBindingStatus,
              BindingVersion,
              CreateTime,
              LastModifiedTime,
              SendDNS,
              DisableModernPolicy,
			  DriverType,
              GID )
    VALUES  ( @newUserId,
              @UserName,
              @BindingStatus,
              @BindingPCID,
              @IPBindingStatus,
              @SubNetIP,
              @SubNetMask,
              @VirtualIPStatus,
              @VirtualIP,
              @UserPIN,
              @MasterPIN,
              @EncAuthKey,
              @MustChangePIN,
              @AccountDisable,
              @RejOnKeepAliveFail,
              @ShowUserPrivilege,
              @AuthType,
              @CertType,
              @CertValue,
              @FirstName,
              @LastName,
              @Gender,
              @Office,
              @Province,
              @Town,
              @Company,
              @Notes,
              @Email,
              @Cell,
              @PersonnelCode,
              @Phone,
              @NationalID,
              @Adress,
              @PostalCode,
              @Owner,
              @Permission_ID,
              @UnBlockPIN,
              @InterfaceBindingStatus,
              @LoginType,
              @LockModule,
              @ExpireDate,
              @VersionBindingStatus,
              @BindingVersion,
              @CreateDateTime,
              @CreateDateTime,
              @SendDNS,
              @DisableModernPolicy,
			  @DriverType,
              @GID )
	SELECT @newUserId, @GID, @CreateDateTime
END
/******************************************************************************************************************************************************/----------------------
go

