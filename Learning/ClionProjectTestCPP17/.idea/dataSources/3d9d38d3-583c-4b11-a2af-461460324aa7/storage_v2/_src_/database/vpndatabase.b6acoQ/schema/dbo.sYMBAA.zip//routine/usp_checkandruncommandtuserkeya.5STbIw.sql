/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_CheckAndRunCommandTuserKeya]
	@ActionType  VARCHAR(6),
	@TableName   VARCHAR(20),
	@GID VARCHAR(25),
	@FirstIDFieldName varchar(20),
	@FirstIDFieldValue INT,
	@SecondIdFieldName varchar(20) = NULL,
	@SecondIdFieldValue varchar(50) = NULL,
	@SecondIdFieldOldValue varchar(50) = NULL
	AS
	BEGIN
		DECLARE @MyServerID TINYINT
		DECLARE @RowServerID AS TINYINT
		DECLARE @Command NVARCHAR(MAX)
		DECLARE @sActionType as VARCHAR(50)
		DECLARE @AssignedGrps VARCHAR(MAX)
		
		SET @Command = ' '
		SET @sActionType = @ActionType + '-' + @TableName
		SET @AssignedGrps = dbo.GetUserAssignGroups(@FirstIDFieldValue)
		SELECT @MyServerID = dbo.GetCurrentServerID()
		
		DECLARE @GrpID VARCHAR(20)
		DECLARE CursAssigned CURSOR FAST_FORWARD FOR
		SELECT items FROM dbo.splitfn(@AssignedGrps,',')
		OPEN CursAssigned
		
		FETCH NEXT FROM CursAssigned INTO @GrpID
		WHILE @@FETCH_STATUS=0
		BEGIN
		EXEC USP_PrepareTwoConditionRelatedQuery @ActionType, @TableName, @FirstIDFieldName, @FirstIDFieldValue, @SecondIdFieldName, @SecondIdFieldValue, @SecondIdFieldOldValue, @Command OUTPUT

		IF(dbo.HasSlaveServer(@MyServerID) = 1)
			EXEC USP_InsertUserChangesToRelatedReplog @FirstIDFieldValue, @sActionType, 'RepSlaveLog', @Command, @GID, @GrpID

		IF(dbo.IsRecordReplicatable(@GrpID) = 1)
		BEGIN
			SET @RowServerID = CONVERT(INT,SUBSTRING(@GID, 0, CHARINDEX(',', @GID )))
			EXEC USP_ProcessUserChanges @sActionType, @Command, @FirstIDFieldValue, @GID, @MyServerID, @GrpID, @RowServerID
		END
		
		FETCH NEXT FROM CursAssigned INTO @GrpID
		END
		CLOSE CursAssigned
		DEALLOCATE CursAssigned
END
go

