
CREATE PROCEDURE [dbo].[USP_BackupDatabase]
        @backupLocation nvarchar(1000)
    AS
    BEGIN
		SET NOCOUNT ON;
		-- Declare variables
		DECLARE @dateTime NVARCHAR(20)
		DECLARE @BackupName varchar(100)
		DECLARE @BackupFile varchar(100)
		DECLARE @sqlCommand NVARCHAR(1000)


		-- Set the current date and time n MMddyyyy_hhmmss format
		SET @dateTime = REPLACE(CONVERT(VARCHAR, GETDATE(),101),'/','') + '_' + REPLACE(CONVERT(VARCHAR, GETDATE(),108),':','')
		SET @BackupName = 'Backup_' + @dateTime
		SET @BackupFile = @backupLocation + @BackupName + '.BAK'
		SET @sqlCommand = 'BACKUP DATABASE VPNDataBase TO DISK = '''+@BackupFile+ ''' WITH INIT, NAME= ''' +@BackupName+''', NOSKIP, NOFORMAT'
		EXEC(@sqlCommand)
	END
go

