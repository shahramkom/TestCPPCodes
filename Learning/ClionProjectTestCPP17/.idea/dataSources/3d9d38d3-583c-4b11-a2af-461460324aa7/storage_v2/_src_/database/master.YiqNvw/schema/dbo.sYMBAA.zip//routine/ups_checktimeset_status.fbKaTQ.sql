CREATE PROCEDURE [dbo].[UPS_CheckTimeSet_Status] 
	@UserID BIGINT,
	@AllRelatedGroupsOfUser nvarchar(2000)
AS
BEGIN
	DECLARE @Count TINYINT
	SELECT @Count = COUNT(TimeSetId) FROM TUserTimeSet WHERE UserID = @UserID
	if( @Count > 0)
	BEGIN
		SELECT 1 AS TimeSet
		RETURN
	END	
	DECLARE @execSql NVARCHAR(4000)
	SET @execSql = 'SELECT @Count = COUNT(GroupID) FROM TGroupTimeSet WHERE GroupID in('+@AllRelatedGroupsOfUser+')'
	EXEC SP_EXECUTESQL @execSql, N'@Count TINYINT OUTPUT', @Count OUTPUT
	if( @Count > 0)
	BEGIN
		SELECT 1 AS TimeSet
		RETURN
	END	
	SELECT 0 AS TimeSet
END
go

