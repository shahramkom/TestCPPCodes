
  Create PROCEDURE [dbo].[USP_TNewPoliciesSearch_GroupName] 
  @GroupName nvarchar(200)
	AS
	BEGIN
		if (@GroupName = '')
		begin
			exec USP_TNewPolicyMain_Select
			return
		end	

		begin try
            DROP TABLE #Table
        end try
        begin catch
        --RAISERROR ('Error raised in TRY block.', 16, 1);
        end catch

        create table #Table(
            gID nvarchar(100)  
        )
		
		insert into #Table SELECT  CONVERT(nvarchar(20),GroupID) FROM TGroup WHERE GroupName like @GroupName

		SELECT     *, dbo.SelModernPolGroupsUsers(MP.ID) AS Assignments
		FROM         dbo.TNewPolicyMainTable AS MP INNER JOIN  dbo.TNewPolicyGroupAssign ON MP.ID = dbo.TNewPolicyGroupAssign.ModernPID
		WHERE     (dbo.TNewPolicyGroupAssign.GroupID in (select gID from #Table))
		ORDER BY MP.ApplyTime DESC, MP.PolicyOrder

		begin try
            DROP TABLE #Table
        end try
        begin catch
        --RAISERROR ('Error raised in TRY block.', 16, 1);
        end catch
	END

  go

