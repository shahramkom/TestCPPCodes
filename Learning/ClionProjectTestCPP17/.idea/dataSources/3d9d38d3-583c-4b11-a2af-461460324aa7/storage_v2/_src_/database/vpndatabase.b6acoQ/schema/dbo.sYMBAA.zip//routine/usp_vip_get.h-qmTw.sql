
    create PROCEDURE [dbo].[USP_VIP_Get]
        @minvip  bigint, 
        @maxvip  bigint
        with recompile
        AS
    BEGIN
        SET NOCOUNT ON;	
    declare @t as bigint
        select
              max((256*256*256)*CAST(PARSENAME(VirtualIP,4)AS bigint)
                +((256*256)*CAST(PARSENAME(VirtualIP,3)AS bigint))
                +(256 * CAST(PARSENAME(VirtualIP,2)AS bigint))
                +CAST(PARSENAME(VirtualIP,1)AS bigint))		 
               from  TUser
            where
            (((256*256*256)*CAST(PARSENAME(VirtualIP,4)AS bigint)
            +((256*256)*CAST(PARSENAME(VirtualIP,3)AS bigint))
            + (256 * CAST(PARSENAME(VirtualIP,2)AS bigint))
            +  CAST(PARSENAME(VirtualIP,1)AS bigint)) >= @minvip  ) 
             and 
            (((256*256*256)*CAST(PARSENAME(VirtualIP,4)AS bigint)
            +((256*256)*CAST(PARSENAME(VirtualIP,3)AS bigint))
            + (256 * CAST(PARSENAME(VirtualIP,2)AS bigint))
            +  CAST(PARSENAME(VirtualIP,1)AS bigint)	)<=@maxvip)			
    END

    go

