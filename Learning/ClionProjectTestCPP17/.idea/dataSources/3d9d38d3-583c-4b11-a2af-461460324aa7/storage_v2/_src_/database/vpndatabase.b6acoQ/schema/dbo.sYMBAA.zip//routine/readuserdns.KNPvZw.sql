--------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[ReadUserDNS] 
	@UserID INT
AS
BEGIN
	DECLARE @GroupsID VARCHAR(1000)
SET @GroupsID = dbo.GetAllRelatedGroupsOfUser(@UserID);

SELECT DISTINCT HostName,IP FROM TDNS 
	LEFT OUTER JOIN TUserDNS ON TDNS.DNSID = TUserDNS.DNSID
	LEFT OUTER JOIN TGroupDNS ON TDNS.DNSID = TGroupDNS.DNSID
	WHERE  ((TUserDNS.UserID = @UserID)
	OR (TGroupDNS.GroupID IN (SELECT items FROM dbo.Splitfn(@GroupsID, ','))))
	
END
go

