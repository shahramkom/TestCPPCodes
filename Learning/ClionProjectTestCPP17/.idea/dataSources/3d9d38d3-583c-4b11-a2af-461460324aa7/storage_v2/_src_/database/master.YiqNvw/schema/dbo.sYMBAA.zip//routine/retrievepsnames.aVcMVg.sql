
    create function RetrievePSNames(@UserID int)
    returns nvarchar(max)
    AS
    begin
    declare @PSNames as nvarchar(max)

    select @PSNames  = coalesce(@PSNames +',','')+ PSName from TUserPolicySet as UserPS, TPolicySet as PS 
    where UserID = @UserID and UserPS.PSID = PS.PSID

    return @PSNames 
    end
    go

