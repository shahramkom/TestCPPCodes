
    Create PROCEDURE [dbo].[USP_SelectTimeSet]
    AS
    BEGIN	
        select max(TRID) from TTimeRole
    END

    go

