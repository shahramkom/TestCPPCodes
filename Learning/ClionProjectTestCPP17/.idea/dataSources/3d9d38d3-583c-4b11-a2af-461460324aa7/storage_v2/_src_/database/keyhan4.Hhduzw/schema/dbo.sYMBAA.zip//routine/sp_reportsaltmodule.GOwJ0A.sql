CREATE PROCEDURE [dbo].[sp_ReportsAltModule]  
	@profileID int,
	@fromDate nvarchar(20),
	@toDate nvarchar(20)
AS
BEGIN
		IF (@profileID <> 0 AND @fromDate is not null )
		BEGIN
			SELECT dbo.AlternateModules.*, dbo.ProfileSetting.CustomerName FROM dbo.AlternateModules INNER JOIN
                  dbo.ProfileSetting ON dbo.AlternateModules.ProfileID = dbo.ProfileSetting.Code
				  WHERE dbo.AlternateModules.ProfileID = @profileID AND (dbo.AlternateModules.ProgramDate > @fromDate AND dbo.AlternateModules.ProgramDate < @toDate)
		END
		ELSE IF (@profileID <> 0 AND @fromDate is null )
		BEGIN
			SELECT dbo.AlternateModules.*, dbo.ProfileSetting.CustomerName FROM dbo.AlternateModules INNER JOIN
                  dbo.ProfileSetting ON dbo.AlternateModules.ProfileID = dbo.ProfileSetting.Code
				  WHERE dbo.AlternateModules.ProfileID = @profileID 
		END
		ELSE IF (@profileID = 0 AND @fromDate is not null )
		BEGIN
			SELECT dbo.AlternateModules.*, dbo.ProfileSetting.CustomerName FROM dbo.AlternateModules INNER JOIN
                  dbo.ProfileSetting ON dbo.AlternateModules.ProfileID = dbo.ProfileSetting.Code
				   WHERE dbo.AlternateModules.ProgramDate > @fromDate AND dbo.AlternateModules.ProgramDate < @toDate
		END
		ELSE IF (@profileID = 0 AND @fromDate is null )
		BEGIN
			SELECT dbo.AlternateModules.*, dbo.ProfileSetting.CustomerName FROM dbo.AlternateModules INNER JOIN
                  dbo.ProfileSetting ON dbo.AlternateModules.ProfileID = dbo.ProfileSetting.Code
		END
		
	END
go

