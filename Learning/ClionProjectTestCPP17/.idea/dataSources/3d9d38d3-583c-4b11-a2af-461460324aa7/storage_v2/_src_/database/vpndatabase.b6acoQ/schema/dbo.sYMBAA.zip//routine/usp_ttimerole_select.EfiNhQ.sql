
    Create PROCEDURE [dbo].[USP_TTimeRole_Select]
    with recompile
    AS
    BEGIN	
        select * from TTimeRole
    END

    go

