CREATE PROCEDURE USP_DropReplogTable 
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @tableName AS NVARCHAR(MAX)
    DECLARE @tableScript AS NVARCHAR(MAX)

    IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RepPrimaryLog]') AND type in (N'U'))
        DROP TABLE RepPrimaryLog 
     IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[RepSlaveLog]') AND type in (N'U'))
        DROP TABLE RepSlaveLog          

    DECLARE @counter AS INT
    SET @counter = 1
    WHILE (@counter < 255 )
    BEGIN
        SET @tableName = 'RepSecLog' + CONVERT(VARCHAR(3), @counter)
        IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].['+@tableName+']') AND type in (N'U'))
        BEGIN
            SET @tableScript = 'DROP TABLE [dbo].[' + @tableName + ']'
		    EXEC dbo.sp_executesql @statement = @tableScript
        END
	    SET @counter = @counter + 1
    END
END

/*************************************************************************************************************************************/
go

