/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_GetUserRelatedQuery]
	@ActionType varchar(6),
	@IDFieldValue int,
	@ReturnCommand nvarchar(MAX) OUTPUT
	AS
	BEGIN
		DECLARE @Query nvarchar(MAX)
		DECLARE @VIPCorrectedQuery nvarchar(MAX)
		SET @Query = ''
		SET @VIPCorrectedQuery = ''

		IF(@ActionType = 'Insert')
			SET @Query = dbo.GetTableInsertQuery( 'TUser', 'UserID', @IDFieldValue )
		ELSE IF(@ActionType = 'Update')
			SET @Query = dbo.GetTableUpdateQuery( 'TUser', 'UserID', @IDFieldValue )
		ELSE IF(@ActionType = 'Delete')
		BEGIN
			SET @Query = dbo.GetTableDeleteQuery( 'TUserGroups', 'UserID', @IDFieldValue )
			SELECT @ReturnCommand=@Query
			RETURN
		END

		SET @Query = REPLACE(@Query , 'ENCRYPTEDUSERAUTHKEY', ' ''[ENCRYPTEDUSERAUTHKEY]'' ')

		CREATE TABLE #tmpTbl([Command] nvarchar(MAX))
		CREATE TABLE #KeyTable([CommandLine] nvarchar(200),Param1	nvarchar(200),[Output] nvarchar(64))

		INSERT INTO #tmpTbl ([Command]) exec sp_executesql @Query 
		DECLARE @TmpQuery NVARCHAR(MAX)
		SELECT @TmpQuery = Command from #tmpTbl
		DECLARE @TmpKEY NVARCHAR(64)
		DECLARE @PlainKEY NVARCHAR(128)
		SELECT @TmpKEY = AuthenticationKey from TUser where UserID = @IDFieldValue
		INSERT INTO #KeyTable EXEC Master..XYRunProc 'Decrypt' ,@TmpKEY
		SELECT @PlainKEY = [Output] from #KeyTable where CommandLine='Decrypt'
		SET @Query = REPLACE(@TmpQuery , '[ENCRYPTEDUSERAUTHKEY]' , @PlainKEY)

		SET @Query = REPLACE(@Query , '''' , '''''')

		IF(@ActionType = 'Update')
		BEGIN
			DECLARE @WhereStatement AS VARCHAR(100)
			SET @WhereStatement = ' WHERE UserID= ' + CAST(@IDFieldValue AS VARCHAR(20))
			SET @Query = @Query + @WhereStatement
		END
		SELECT @ReturnCommand=@Query

		DROP TABLE #tmpTbl
		DROP TABLE #KeyTable
END
go

