
    CREATE PROCEDURE [dbo].[UPS_ServerAccessPolicy_Insert] 

       @PSID			int ,
       @NetworkIP		nvarchar(15) ,
       @NetworkMask		nvarchar(15) ,
       @Protocol		nvarchar(10) ,
       @Port			nvarchar(50) ,
       @PAction			nvarchar(50) ,
       @Authentication	nvarchar(100) =NULL,
       @Encryption		nvarchar(100)=NULL,
	   @Compression		bit = 0,
	   @IP_RangeType	nvarchar(20)='Network IP',
	   @status			bit = 1,	  
	   @ExpirationDate	nvarchar(20), 
       @POrder			smallint= NULL,
       @PolicyID		int =NULL output
        
    AS
    BEGIN
    SET NOCOUNT ON;
        declare @CreateDateTime as nvarchar(20)
		select @CreateDateTime = CONVERT(nvarchar(20),GETDATE(),20)
        INSERT INTO [VPNDataBase].[dbo].[TServerAccessPolicy]
               (
                PSID,			
                NetworkIP,
                NetworkMask,
                Protocol,
                Port,
                PAction,
                Authentication,
                Encryption,
				Compression,
				IP_RangeType,				
				CreateTime,
				LastModifiedTime,
				Status,
				ExpireDate,
                POrder
                )
         VALUES
               (           
               @PSID,
               @NetworkIP, 
               @NetworkMask, 
               @Protocol,
               @Port, 
               @PAction, 
               @Authentication, 
               @Encryption,
			   @Compression,
			   @IP_RangeType,
			   @CreateDateTime,
			   @CreateDateTime,
			   @status,
			   @ExpirationDate,
			   @POrder
               )
        SET @PolicyID = @@IDENTITY

    END

    go

