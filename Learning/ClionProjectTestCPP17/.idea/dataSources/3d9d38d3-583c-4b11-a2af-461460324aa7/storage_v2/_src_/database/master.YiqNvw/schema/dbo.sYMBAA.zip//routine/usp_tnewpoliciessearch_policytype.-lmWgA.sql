
	 Create PROCEDURE [dbo].[USP_TNewPoliciesSearch_PolicyType] 
	  @status nvarchar(10)
	AS
	BEGIN

		if (@status = 'Tunnel')
		begin
			SELECT * ,dbo.SelModernPolGroupsUsers(MP.ID)AS Assignments
			FROM [dbo].[TNewPolicyMainTable] AS MP  WHERE MP.PolicyType = 1 OR MP.PolicyType = 2
			ORDER BY ApplyTime DESC ,PolicyOrder ASC
		end
		else if (@status = 'Firewall')
		begin
			SELECT * ,dbo.SelModernPolGroupsUsers(MP.ID)AS Assignments
			FROM [dbo].[TNewPolicyMainTable] AS MP  WHERE MP.PolicyType = 3
			ORDER BY ApplyTime DESC ,PolicyOrder ASC
		end
		else
		begin
			exec USP_TNewPolicyMain_Select
		end
	END

   go

