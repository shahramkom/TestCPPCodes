
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesAlgorithms_Insert] 
		@EncryptionAlgorithm nvarchar(50),
		@IntegrityAlgorithm  nvarchar(50)
   AS
   BEGIN
	INSERT INTO [dbo].[TNewPoliciesAlgorithms]
           ([EncryptionAlgorithm]
           ,[IntegrityAlgorithm] )
     VALUES
           (@EncryptionAlgorithm ,
			@IntegrityAlgorithm )
	SELECT @@IDENTITY
   END

   go

