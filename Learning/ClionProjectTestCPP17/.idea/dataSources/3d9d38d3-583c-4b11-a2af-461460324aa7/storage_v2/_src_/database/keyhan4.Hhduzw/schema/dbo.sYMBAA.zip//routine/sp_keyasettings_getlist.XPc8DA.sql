CREATE PROCEDURE [dbo].[sp_KeyASettings_GetList]  
AS
	select 
		SettingCode                     as N'ßÏ', 
		SettingName   		as N'äÇã ÊäÙíã ',
		VersionName		as N'äÓÎå',
		FreeMemSize		as N'ÍÇÝÙå ÂÒÇÏ',
		SecureMemSize		as N'ÍÇÝÙå Çãä',
		DeveloperMemSize	as N'ÍÇÝÙå ÈÑäÇãå äæíÓ'
--		KVKeyNumber		as N'KV',
--		QureyKeyNumber	as N'Query'
	from  KeyASettings as T1, VersionsInfo as T2
	where (T1.Version = T2.VersionCode)
go

