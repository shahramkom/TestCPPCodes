CREATE PROCEDURE [dbo].[USP_ReadReplicationServersState]
	@serverID AS INT = -1
AS
BEGIN
    IF(@serverID = -1)
    BEGIN
        SELECT dbo.RepServersState.serverID, ServerIP, SlaveIP, LastSuccessfulRun, RunningState  
        FROM dbo.RepServersState INNER JOIN RepConfig 
        ON dbo.RepConfig.ServerID = dbo.RepServersState.ServerID 
    END
    ELSE
    BEGIN
        SELECT dbo.RepServersState.serverID, ServerIP, SlaveIP, LastSuccessfulRun, RunningState  
        FROM dbo.RepServersState INNER JOIN RepConfig 
        ON dbo.RepConfig.ServerID = dbo.RepServersState.ServerID WHERE RepServersState.ServerID = @serverID
    END
END
/******************************************************************************************************************************************************/----------------------------------------
go

