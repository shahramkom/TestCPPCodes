
CREATE PROCEDURE [dbo].[USP_CH_Rule_And_Assigns_Delete] 
    @RuleID int = 0
AS
	BEGIN
		declare @ProfileID as int
		declare @RuleIDs as nvarchar(500)
		declare HC_Profiles cursor for 
        SELECT ProfileID,RuleIDs FROM HealthCheckProfiles
        open HC_Profiles
        fetch next from HC_Profiles into @ProfileID,@RuleIDs
        while @@FETCH_STATUS = 0
        begin
			declare @tmpRules as nvarchar(500)
			SET @tmpRules = @RuleIDs
			Select @tmpRules = REPLACE (@tmpRules, cast(@RuleID as nvarchar(10))+',', '')
			Select @tmpRules = REPLACE (@tmpRules, ','+cast(@RuleID as nvarchar(10))+',', '')
			Select @tmpRules = REPLACE (@tmpRules, ','+cast(@RuleID as nvarchar(10)), '')
			Select @tmpRules = REPLACE (@tmpRules, cast(@RuleID as nvarchar(10)), '')
			if(@tmpRules is not null AND @tmpRules != '')
				UPDATE HealthCheckProfiles set RuleIDs = @tmpRules where  ProfileID = @ProfileID
			else
				delete HealthCheckProfiles where ProfileID = @ProfileID
        fetch next from HC_Profiles into @ProfileID,@RuleIDs
        end
        close HC_Profiles
        DEALLOCATE HC_Profiles
		
		exec USP_CH_Rule_Delete @RuleID
END
go

