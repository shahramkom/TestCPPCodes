
    CREATE PROCEDURE [dbo].[USP_MANAGERLOG_FILTER_EXP]
        @L_UserID		  bigint=NULL,
        @L_startDate	  nvarchar(10)=NULL,
        @L_startTime	  nvarchar(8)=NULL,
        @L_endDate		  nvarchar(10)=NULL,
        @L_endTime		  nvarchar(8)=NULL,
		@L_ClientID		  bigint = NULL
    AS
      SET NOCOUNT ON
      declare @filter nvarchar(max)
      if (@L_UserID is not null)
        set @filter = isnull(@filter ,'') +  '((userID = ' + isnull(cast(@L_UserID as nvarchar(20)) , '') +'))AND(' 
      else
        set @filter = isnull(@filter ,'') +  '('
	  if (@L_ClientID is not null)
        set @filter = isnull(@filter ,'') +  '((ClientID = ' + isnull(cast(@L_ClientID as nvarchar(20)) , '') +'))AND(' 
      else
        set @filter = isnull(@filter ,'') +  '('
      if (@L_startDate = @L_endDate)	
        set @filter = isnull(@filter ,'') +  '(operationDate = '''+@L_startDate+''' AND operationTime >= '''+ @L_startTime+''' AND operationTime <= '''+@L_endTime+'''))AND'
      else
        set @filter = isnull(@filter ,'') +  '((operationDate > '''+@L_startDate+''') AND (operationDate < '''+ @L_endDate  +''')) OR ((operationDate = '''+@L_startDate + ''' AND operationTime >= '''+ @L_startTime+''' )) OR '
            + ' ((operationDate = '''+@L_endDate + ''' AND operationTime <= '''+ @L_endTime+''' ))))AND'

        set @filter = substring(@filter , 0 , LEN(@filter) - 2)
            
          select @filter
           declare 	@datasrc nvarchar(200)
           set 	@datasrc = ' managerLog '	
           declare @orderBy nvarchar(200)
           set @orderBy = ' operationDate DESC, operationTime DESC ' 
     
        declare  @fieldlist nvarchar(200) 
        set @fieldlist= 'operationDate as Date,operationTime as Time,userID as ManagerID,ClientID as ClientID,operationType,logEvent,rowID,decription '
     
          DECLARE
             @STMT nvarchar(max)         -- SQL to execute
            

         IF LTRIM(RTRIM(@filter)) = '' SET @filter = '1 = 1'
            SET @STMT =  'SELECT   ' + @fieldlist + 
                         'FROM     ' + @datasrc +
                         'WHERE    ' + @filter + 
                         'ORDER BY ' + @orderBy
                  
             EXEC (@STMT)                 -- return requested records 		

    go

