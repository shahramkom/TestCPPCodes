CREATE PROCEDURE [dbo].[sp_ProgramHistorySELECTModuleSerial] 
	@ProfileID int
AS
BEGIN
	if(@ProfileID is not null)
	begin
		SELECT DISTINCT [ModuleSerial]
		FROM [Keyhan4].[dbo].[ProgramHistory]
		Where ProfileID = @ProfileID and valid = 1
	end
END
go

