CREATE PROCEDURE [dbo].[sp_Customers_Delete]  
	@CustomerCode int
AS
	delete from Customers where (CustomerCode = @CustomerCode)
go

