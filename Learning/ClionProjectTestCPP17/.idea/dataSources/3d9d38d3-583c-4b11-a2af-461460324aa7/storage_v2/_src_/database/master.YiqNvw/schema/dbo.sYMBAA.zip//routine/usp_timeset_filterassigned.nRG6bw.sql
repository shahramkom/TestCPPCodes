


    CREATE PROCEDURE [dbo].[USP_TimeSet_FilterAssigned]
    @TRID int
    AS
    BEGIN	
        select g.GroupID,g.GroupName from TGroupTimeSet gt inner join TGroup g 
            on gt.GroupID = g.GroupID
            where TRID=@TRID
    END

    go

