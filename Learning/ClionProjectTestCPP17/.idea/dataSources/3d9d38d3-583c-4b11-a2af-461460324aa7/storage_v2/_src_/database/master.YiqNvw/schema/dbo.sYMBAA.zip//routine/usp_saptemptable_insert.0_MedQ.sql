
    CREATE PROCEDURE [dbo].[USP_SAPTempTable_Insert] 
       @Keyhan3PolicyCode int ,
       @GroupID			int,
       @NetworkIP		nvarchar(15) ,
       @NetworkMask		nvarchar(15) ,
       @Protocol		nvarchar(10) ,
       @Port			nvarchar(5) ,
       @PAction			nvarchar(50) ,
       @Authentication	nvarchar(100) =NULL,
       @Encryption		nvarchar(100)=NULL
    

        
    AS
    BEGIN
    SET NOCOUNT ON;
	  declare @PSID int,@POrder int 
        set @PSID = @GroupID	
    
	    
       select @POrder =  max(POrder) from TServerAccessPolicy where PSID = @PSID 
		if(@POrder is null)
		begin
		  set @POrder = 1
		end
		else
		begin
			  set @POrder = @POrder + 1
		end
		 


            INSERT INTO [VPNDataBase].[dbo].[TServerAccessPolicy]
                          (
                PSID,
                NetworkIP,
                NetworkMask,
                Protocol,
                Port,
                PAction,
                Authentication,
                Encryption,
                POrder
                )
               VALUES
                  (
               @PSID,
               @NetworkIP, 
                       @NetworkMask, 
                       @Protocol,
                       @Port, 
                       @PAction, 
                       @Authentication, 
               @Encryption,
               @POrder
               )

    END

    go

