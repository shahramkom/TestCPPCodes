CREATE PROCEDURE [dbo].[USP_UpdateUserLastLoginTime] 
	@LastLoginTime varchar(20),
	@UserID bigint
AS
BEGIN
	UPDATE TUser SET LastLoginTime = @LastLoginTime WHERE UserID = @UserID
END
go

