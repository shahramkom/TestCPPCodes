
    CREATE PROCEDURE [dbo].[USP_Setting_Save]
        -- Add the parameters for the stored procedure here
        @Property	nvarchar(400),
        @value		nvarchar(4000)
    AS
    BEGIN
        if (Exists(select * from TSetting where [Property] = @Property))
        begin
            update TSetting set [value] = @value where [Property] = @Property
        end
        else
        begin
            Insert into TSetting ([Property],[value]) values (@Property , @Value)
        end
    END

    go

