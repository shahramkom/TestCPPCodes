/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_PreparePolicyTableRelateQuery]
@IDValue INT,
    @grpID VARCHAR(8),
	@ActionType  VARCHAR(50),
	@InputSActionType VARCHAR(50),
	@MyServerID TINYINT,
	@IsPolicyReplicatable INT
	AS
	BEGIN
	    DECLARE @sActionType AS  VARCHAR(50)
        DECLARE @Command NVARCHAR(MAX)
        DECLARE @strPsId AS VARCHAR(8)
        DECLARE @strPolicyId AS VARCHAR(8)
        DECLARE @psid AS INT
        DECLARE @policyid AS INT
        SET @Command = ' '

		DECLARE CursAssigned CURSOR FAST_FORWARD FOR
		SELECT PolicyID,PSID FROM dbo.TServerAccessPolicy WHERE PSID = @IDValue
		OPEN CursAssigned
		
		FETCH NEXT FROM CursAssigned INTO @policyid,@psid
		WHILE @@FETCH_STATUS=0
		BEGIN
            SET @sActionType = @ActionType + '-' + 'TServerAccessPolicy'
		    EXEC USP_PreparePolicyTableRelatedQuery @ActionType, 'TServerAccessPolicy', 'PSID', @IDValue,'PolicyID',@policyid, @Command OUTPUT
		    SET @strPsId     = CAST(@psid AS varchar(max))
		    SET @strPolicyId = CAST(@policyid AS varchar(max))
		    
			IF(dbo.HasSlaveServer(@MyServerID) = 1)
				EXEC USP_InsertUserChangesToRelatedReplog @policyid,@sActionType,'RepSlaveLog', @Command, NULL, @grpID, @strPsId
			IF (@IsPolicyReplicatable = 1 AND (@InputSActionType = 'Insert-TPolicySet'))
				EXEC USP_ProcessTableChanges @sActionType, @Command, @policyid, @MyServerID, @grpID, @strPsId

		    FETCH NEXT FROM CursAssigned INTO @policyid,@psid
		END
		CLOSE CursAssigned
		DEALLOCATE CursAssigned
        ------------------------------------------------------------------UFP------------------------------------------------------------------------
        DECLARE CursAssigned CURSOR FAST_FORWARD FOR
		SELECT UFPID,PSID FROM dbo.TUserFirewallPolicy WHERE PSID = @IDValue
		OPEN CursAssigned
		
        FETCH NEXT FROM CursAssigned INTO @policyid,@psid
		WHILE @@FETCH_STATUS=0
		BEGIN
            SET @sActionType = @ActionType + '-' + 'TUserFirewallPolicy'
		    EXEC USP_PreparePolicyTableRelatedQuery @ActionType, 'TUserFirewallPolicy', 'PSID', @IDValue,'UFPID',@policyid, @Command OUTPUT
		    SET @strPsId = CAST(@psid AS varchar(max))
		    IF(dbo.HasSlaveServer(@MyServerID) = 1)
				EXEC USP_InsertUserChangesToRelatedReplog @policyid,@sActionType,'RepSlaveLog', @Command, NULL, @grpID, @strPsId

			IF (@IsPolicyReplicatable = 1 AND (@InputSActionType = 'Insert-TPolicySet'))
				EXEC USP_ProcessTableChanges @sActionType, @Command, @policyid, @MyServerID, @grpID, @strPsId
				
		    FETCH NEXT FROM CursAssigned INTO @policyid,@psid
		END
		CLOSE CursAssigned
		DEALLOCATE CursAssigned
END
go

