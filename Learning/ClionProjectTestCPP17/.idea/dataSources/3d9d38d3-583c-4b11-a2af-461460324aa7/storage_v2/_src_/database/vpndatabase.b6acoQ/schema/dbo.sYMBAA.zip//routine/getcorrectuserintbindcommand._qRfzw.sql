/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.getCorrectUserIntBindCommand(@sActionType NVARCHAR(50), @command NVARCHAR(MAX))
RETURNS NVARCHAR(MAX)
BEGIN
	DECLARE @retval AS NVARCHAR(MAX)
	DECLARE @counter AS INT 
	SET @counter = 0
	DECLARE @i AS int
	
	IF(@sActionType = 'Insert-TUser')
	BEGIN
		 SELECT @i = CHARINDEX('VALUES(',@command,0)
		 WHILE(@counter < 37 )
		 BEGIN
			 SELECT @i = CHARINDEX(',',@command,@i+1)
			 SET @counter = @counter + 1
		 END
		SET @command = SUBSTRING(@command,0,@i+3) + '0''' + SUBSTRING(@command,@i+5,LEN(@command))
		SET @retval = @command
	END
	ELSE IF(@sActionType = 'Update-TUser')
	BEGIN
		SELECT @i = CHARINDEX('InterfaceBindingStatus = ',@command,0)
		SET @i = @i + LEN('InterfaceBindingStatus = ')
		SET @command = SUBSTRING(@command,0,@i+3) + '0' + SUBSTRING(@command,@i+4,LEN(@command))
		SET @retval = @command
	END
	ELSE 
	BEGIN
		SET @retval = @command
	END
	RETURN @retval
END
go

