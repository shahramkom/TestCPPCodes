


    create PROCEDURE [dbo].[UPS_Assign_Policyset_Group] 
        -- Add the parameters for the stored procedure here
        @groupID int , 
        @policySetID int
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
       declare @Prty int 
       declare @duplicateRelation int , @msg nvarchar(max)
       set @duplicateRelation=0
       select @duplicateRelation=count(*)from TGroupPolicySet where PSID=@policySetID
            and GroupID = @GroupID
       if(@duplicateRelation>0)
        begin
            set @msg = 'Policy set has been assigned to "';
            set @msg = @msg + @groupID +'" group before';
            Raiserror(@msg, 16 , 10 )
            return
        end
        else
        begin
            select @Prty = max(PriorityOrder) from TGroupPolicySet where GroupID = @GroupID
            if(@Prty is NULL)
                insert into TGroupPolicySet values(@groupID,@policySetID,1)
            else
            begin
                set @Prty = @Prty +1
                insert into TGroupPolicySet values(@groupID,@policySetID,@Prty)
            end
        end

    END

    go

