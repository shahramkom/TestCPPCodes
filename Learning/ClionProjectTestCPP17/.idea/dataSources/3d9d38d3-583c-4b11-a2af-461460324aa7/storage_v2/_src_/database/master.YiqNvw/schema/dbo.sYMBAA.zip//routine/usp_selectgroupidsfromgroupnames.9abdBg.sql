
Create PROCEDURE [dbo].[USP_SelectGroupIDsFromGroupNames] 
    -- Add the parameters for the stored procedure here
    @GroupNames nvarchar(max),
	@productname nvarchar(200)
AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    -- Insert statements for procedure here
            DECLARE @GrpVAL	nvarchar(50)
            DECLARE @GrpIds nvarchar(max)
            DECLARE @RESULT nvarchar(max)
            DECLARE @GRPID  int

            DECLARE GrpName_cursor Cursor For
            
            SELECT * FROM dbo.Splitfn(@GroupNames,',')

            set @RESULT = ''
            OPEN GrpName_cursor

            FETCH NEXT FROM GrpName_cursor 
            INTO @GrpVAL
            WHILE @@FETCH_STATUS = 0
            BEGIN
            if(@GrpVAL <> '')
            BEGIN
					if(@GrpVAL <> @productname )
						Begin
							select @GRPID = GroupID from TGroup where GroupName = @GrpVAL
							set @RESULT = @RESULT +cast( @GRPID as nvarchar(10)) + ','
						End
					else
						Begin
							set @RESULT = @RESULT +'0,'
						End
            END
            FETCH NEXT FROM GrpName_cursor 
                INTO @GrpVAL
            END

            CLOSE GrpName_cursor;
            DEALLOCATE GrpName_cursor;
            select @RESULT
END
go

