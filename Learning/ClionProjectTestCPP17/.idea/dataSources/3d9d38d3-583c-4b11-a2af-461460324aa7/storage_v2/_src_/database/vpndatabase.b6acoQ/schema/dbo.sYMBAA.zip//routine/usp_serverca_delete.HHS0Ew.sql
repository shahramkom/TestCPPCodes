
    CREATE PROCEDURE [dbo].[USP_ServerCA_Delete]
    AS
    BEGIN	
        DELETE FROM [TServerCA]           
    END

    go

