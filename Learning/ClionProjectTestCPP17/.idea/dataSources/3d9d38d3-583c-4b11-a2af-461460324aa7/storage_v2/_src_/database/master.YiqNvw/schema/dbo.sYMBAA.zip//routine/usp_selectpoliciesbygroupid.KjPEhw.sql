CREATE PROCEDURE [dbo].[USP_SelectPoliciesByGroupID] 
	@GroupID int
AS
BEGIN
	select UFP.* from TGroup g inner join TGroupPolicySet r on g.GroupID= r.GroupId inner join TUserFirewallPolicy UFP on UFP.PSID = r.PSID where g.GroupID = @GroupID and UFP.Status = 1 order by r.PriorityOrder , UFP.POrder 	
END
go

