
    CREATE PROCEDURE [dbo].[dropBackupPlainAuthTUser] 
    
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
        IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BackupPlainAuthTUser]') AND type in (N'U'))
        DROP TABLE [dbo].[BackupPlainAuthTUser]
    END


    go

