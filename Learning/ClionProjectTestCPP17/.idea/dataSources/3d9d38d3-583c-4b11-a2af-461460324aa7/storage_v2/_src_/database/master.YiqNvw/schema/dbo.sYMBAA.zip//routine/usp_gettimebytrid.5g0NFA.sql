CREATE PROCEDURE [dbo].[USP_GetTimeBYTRID] 
	@TRID int
AS
BEGIN
	select timeStr from TTimeRole where TRID = @TRID 
END
go

