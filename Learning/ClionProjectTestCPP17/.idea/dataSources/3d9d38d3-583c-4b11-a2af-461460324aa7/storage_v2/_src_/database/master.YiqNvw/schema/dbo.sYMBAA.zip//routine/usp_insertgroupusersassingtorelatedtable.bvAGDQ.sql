/******************************************************************************************************************************************************/---------------------------------
CREATE PROCEDURE USP_InsertGroupUsersAssingToRelatedTable
@TableName VARCHAR(50),
@Values VARCHAR(MAX)
AS
BEGIN
	DECLARE @ExecCommand AS NVARCHAR(MAX)
	SET @ExecCommand = ' INSERT ' + @TableName + ' VALUES('+@Values+')'
	EXEC SP_EXECUTESQL  @ExecCommand
END
go

