
CREATE PROCEDURE [dbo].[USP_Group_Assigned_Policies] 

	@GroupID as nvarchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @BaseSTM as nvarchar(MAX)
	SET @BaseSTM  = ''
		
	IF(@GroupID IS  NULL)
		Raiserror ('GroupID is NULL', 16 , 10)

	SET @BaseSTM ='
	WITH GroupIDTree (GroupID, ParentID , GroupName , GLevel) AS
		(
		/*Anchor member definition*/
		SELECT     TGroup.GroupID,TGroup.ParentID,TGroup.GroupName,1 as GLevel
		FROM       TGroup 
		WHERE     (TGroup.GroupID = '+@GroupID+')

		UNION ALL
		/*Recursive member definition*/
		SELECT  TGroup.GroupID,TGroup.ParentID,TGroup.GroupName,GLevel+1
		FROM    TGroup
				INNER JOIN  GroupIDTree as GID
				ON (TGroup.GroupID = GID.ParentID)
		)

	    SELECT     TPolicySet.PSID  ,dbo.fnPolicyInheritedName( TPolicySet.PSName ,GIT.GroupName, GIT.GLevel)
		FROM       TPolicySet INNER JOIN
		TGroupPolicySet ON TPolicySet.PSID = TGroupPolicySet.PSID INNER JOIN
		TGroup ON TGroupPolicySet.GroupID = TGroup.GroupID INNER JOIN
		GroupIDTree as GIT  ON GIT.GroupID = TGroupPolicySet.GroupID
		ORDER BY  GIT.GLevel,TGroupPolicySet.PriorityOrder
		'

	
	--Excuting command
	--select @BaseSTM
	EXEC dbo.sp_executesql @BaseSTM  					
	
END
go

