CREATE PROCEDURE [dbo].[UPS_Check_UserHave_AnySimplePolicy] 
	@AllPSID nvarchar(2000)
AS
BEGIN
	IF( CHARINDEX(',' , @AllPSID ) = 0 )
	BEGIN
		SELECT [dbo].[PSID_Have_AnySimple](@AllPSID) AS SimplePolicy
	END
	ELSE
	BEGIN
		declare @PSID as nvarchar(10)
		declare PSID_Cursor cursor for select * from dbo.Splitfn(@AllPSID,',')
		open PSID_Cursor
		fetch next from PSID_Cursor into @PSID
		while @@FETCH_STATUS = 0
		begin
		if(@PSID is not null)
		begin
			IF([dbo].[PSID_Have_AnySimple](@PSID) > 0)
			BEGIN
				SELECT 1 AS SimplePolicy
				CLOSE PSID_Cursor;	
				DEALLOCATE PSID_Cursor;
				RETURN
			END
		end
		fetch next from PSID_Cursor into @PSID
		end
		CLOSE PSID_Cursor;	
		DEALLOCATE PSID_Cursor;
		SELECT 0 AS SimplePolicy
	END
END
go

