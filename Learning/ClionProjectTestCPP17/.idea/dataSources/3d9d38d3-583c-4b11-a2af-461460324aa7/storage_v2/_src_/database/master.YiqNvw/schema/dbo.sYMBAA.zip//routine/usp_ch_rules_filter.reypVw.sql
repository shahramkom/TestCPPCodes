CREATE PROCEDURE [dbo].[USP_CH_Rules_Filter]			
	@RulesID nvarchar(max) = null
AS	
BEGIN
	DECLARE @STMT AS NVARCHAR(MAX)
	SET @STMT  = 'SELECT [RuleID],[Name],[Category],[Action],[ActionParameter],[RuleType] FROM [dbo].[HealthCheckRules]	WHERE RuleID in('+@RulesID+')'
	EXEC sp_executesql @STMT
END
go

