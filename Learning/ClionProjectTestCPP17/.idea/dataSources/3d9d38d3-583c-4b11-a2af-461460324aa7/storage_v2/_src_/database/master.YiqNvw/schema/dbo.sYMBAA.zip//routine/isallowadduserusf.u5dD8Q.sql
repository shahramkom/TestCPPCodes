
	CREATE FUNCTION [dbo].[ISAllowAddUSerUSF]()
	RETURNS BIT
	AS
	BEGIN
			DECLARE  @retValCount bit
			DECLARE  @nTotalCount int , @nTotalUser int 
			select @nTotalCount = count(*) from  TUser where LoginType = 0
			select @nTotalUser  = [value] from TSetting where Property = 'UsfUserCount'
			if (@nTotalUser < @nTotalCount + 1 )
				SET @retValCount = 0
			else
				SET @retValCount = 1
			return @retValCount 
	END

  go

