CREATE PROCEDURE [dbo].[sp_ProgramHistoryUPDATE] 
	@HistoryID int,
    @ModuleSerial nvarchar(20),
    @OnlineUsers  int,
    @TotalUsers int ,
    @Comment nvarchar(max),
	@UsfPercent tinyint,
    @Reserve1 varchar(1000),
    @Reserve2 nvarchar(1000) = '',
	@UserName nvarchar(150) = NULL
AS
	BEGIN
	declare @ProgramDate as nvarchar(20)
	select @ProgramDate = CONVERT(nvarchar(20),GETDATE(),20)
	UPDATE [Keyhan4].[dbo].[ProgramHistory]
   SET [ProgramDate] = @ProgramDate
      ,[ModuleSerial] = @ModuleSerial
      ,[OnlineUsers] = @OnlineUsers  
	  ,[TotalUsers]  =	@TotalUsers  
      ,[Comment] = @Comment
	  ,[UsfPercent] = @UsfPercent
	  ,[UserName] = @UserName
      ,[Reserve1] = @Reserve1
      ,[Reserve2] = @Reserve2
 WHERE ID = @HistoryID

	END
go

