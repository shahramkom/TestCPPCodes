
    Create PROCEDURE [dbo].[USP_Select_TScript]
    AS
    BEGIN	
        select * from TScript
    END

    go

