CREATE PROCEDURE [dbo].[sp_ProductTypeName_Select]  
	@ProductType int
AS
	SELECT TOP 1 ProductTypeName FROM ProfileSetting
	WHERE (ProductType = @ProductType)
go

