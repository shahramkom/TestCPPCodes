
    CREATE PROCEDURE [dbo].[USP_Delete_Log_SAuth] 

        @condition			nvarchar(3)	,
        @strDateCondition		nvarchar(10),
        @strTimeCondition		nvarchar(10)	
    
    
    AS
    BEGIN
        DECLARE @dateCondition		DATETIME
        SET @dateCondition = CAST(@strDateCondition AS DATETIME)
    
        DECLARE @timeCondition		DATETIME
        SET @timeCondition = CAST(@strTimeCondition AS DATETIME)

        IF(@condition='<')
            DELETE FROM sAuthLog  WHERE  (CAST(eventDate AS DATETIME) = @dateCondition AND   CAST(eventTime AS DATETIME) < @timeCondition)OR (CAST(eventDate AS DATETIME) < @strDateCondition )
        IF(@condition='>')
            DELETE FROM sAuthLog  WHERE  (CAST(eventDate AS DATETIME) = @dateCondition AND   CAST(eventTime AS DATETIME) > @timeCondition)OR (CAST(eventDate AS DATETIME) > @strDateCondition )
        IF(@condition='>=')
            DELETE FROM sAuthLog  WHERE (CAST(eventDate AS DATETIME) = @dateCondition AND   CAST(eventTime AS DATETIME) >= @timeCondition)OR (CAST(eventDate AS DATETIME) > @strDateCondition )
        IF(@condition='<=')
            DELETE FROM sAuthLog  WHERE (CAST(eventDate AS DATETIME) = @dateCondition AND   CAST(eventTime AS DATETIME) <= @timeCondition)OR (CAST(eventDate AS DATETIME) < @strDateCondition )
        IF(@condition='=')
            DELETE FROM sAuthLog  WHERE (CAST(eventDate AS DATETIME) = @dateCondition AND   CAST(eventTime AS DATETIME) = @timeCondition)

    END


    go

