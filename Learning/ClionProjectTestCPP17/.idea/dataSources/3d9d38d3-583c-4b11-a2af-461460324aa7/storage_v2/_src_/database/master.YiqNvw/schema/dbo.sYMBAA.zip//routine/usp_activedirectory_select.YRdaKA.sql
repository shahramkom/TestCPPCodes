
    CREATE PROCEDURE  [dbo].[USP_ActiveDirectory_Select]

     @UserName			nvarchar(200)	= NULL	
    
    
    AS
    BEGIN
    Declare Ad_cursor Cursor For
        Select UserName From TADTempUser
        
    OPEN Ad_cursor

    FETCH NEXT FROM Ad_cursor 
    INTO @UserName

    WHILE @@FETCH_STATUS = 0
    BEGIN

    declare @Exist_Status		bit	  
    set @Exist_Status=0
    if ((select COUNT (UserName) from TUser Where UserName=@UserName)!= 0) 
        BEGIN
        set @Exist_Status = 1 
        END
    
        update TADTempUser
        set 
        Exist_Status = @Exist_Status
        WHERE UserName=@UserName
    
        FETCH NEXT FROM Ad_cursor 
        INTO @UserName
    
    END

    CLOSE Ad_cursor;
    DEALLOCATE Ad_cursor;

    --Select * From TADTempUser;

    END


    go

