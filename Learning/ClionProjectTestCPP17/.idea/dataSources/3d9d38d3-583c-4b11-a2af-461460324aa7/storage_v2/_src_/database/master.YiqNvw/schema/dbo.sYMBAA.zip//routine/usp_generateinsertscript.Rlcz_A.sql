/*************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[USP_GenerateInsertScript] 
	@GroupIDsStr nvarchar(max),
	@SeprateVIPHead as bigint = NULL, 
	@MinIP as bigint = NULL,
	@MaxIP as bigint = NULL,
	@PlainAuthKey as bit = 1 
AS
BEGIN
	truncate  table tbl_InsertGroupScript
	if(@GroupIDsStr is null  or @GroupIDsStr = '''')
		return;
	exec USP_InsertTScriptGenerator @GroupIDsStr
		exec USP_InsertTGroupScriptGenerator @GroupIDsStr
		exec USP_InsertTTimeRoleGenerator @GroupIDsStr
		exec USP_InsertTGroupTimeSetGenerator @GroupIDsStr
		exec USP_InsertDNSGenerator	@GroupIDsStr
		exec USP_InsertTGroupGenerator	@GroupIDsStr
		exec USP_InsertTGroupPolicySetGenerator	  @GroupIDsStr 
		exec USP_InsertTPolicySetGenerator	 @GroupIDsStr 
		exec USP_InsertTServerAccessPolicyGenerator	@GroupIDsStr
		exec USP_InsertTUserFirewallPolicyGenerator @GroupIDsStr
	exec USP_InsertTUserGenerator @SeprateVIPHead ,@MinIP ,@MaxIP ,@GroupIDsStr ,@PlainAuthKey
		exec USP_InsertSpecialPermissionGenerator
		exec USP_InsertTUserGroupsGenerator @GroupIDsStr
		exec USP_InsertTDNSGroupGenerator @GroupIDsStr
		exec USP_InsertTUserKeyaGenerator @GroupIDsStr
		exec USP_InsertTUserDNSGenerator @GroupIDsStr
		exec USP_InsertTUserscriptsGenerator  @GroupIDsStr
		exec USP_InsertTUserTimeSetGenerator @GroupIDsStr
		exec USP_InsertTUserPolicySetGenerator @GroupIDsStr
		exec USP_InsertTPermissionGroupGenerator  @GroupIDsStr
		exec USP_InsertTUserInterfaceGenerator @GroupIDsStr
		exec USP_InsertTGroupInterfaceGenerator @GroupIDsStr
		exec USP_InsertNewPolicyGenerator @GroupIDsStr
		EXEC USP_InsertHealthCheckGenerator @GroupIDsStr
		exec USP_InsertTEMessageGenerator
		exec USP_InsertTModuleBlockListGenerator
END
go

