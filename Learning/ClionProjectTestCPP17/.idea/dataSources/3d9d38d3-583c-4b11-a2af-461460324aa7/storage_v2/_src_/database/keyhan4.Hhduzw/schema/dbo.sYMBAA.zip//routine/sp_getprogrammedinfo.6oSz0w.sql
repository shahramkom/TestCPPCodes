	Create PROCEDURE [dbo].[sp_getProgrammedInfo] 
	@ProfileID int
AS
	BEGIN 
		SELECT count([ID])  AS ClientCount FROM [Keyhan4Prog].[dbo].[ProgramHistory]  Where [ProfileID] = @ProfileID AND [Reserve1] Like 'Client%' 
		SELECT count([ID])  AS ManagerCount FROM [Keyhan4Prog].[dbo].[ProgramHistory]  Where [ProfileID] = @ProfileID AND [Reserve1] Like 'Manager Ver.%'
		SELECT count([ID])  AS MiniAdminCount FROM [Keyhan4Prog].[dbo].[ProgramHistory]  Where [ProfileID] = @ProfileID AND [Reserve1] Like 'MiniAdmin Ver.2%'
		SELECT count([ID])  AS ServerCount FROM [Keyhan4Prog].[dbo].[ProgramHistory]  Where [ProfileID] = @ProfileID AND [Reserve1] Like 'Server Ver%'
		SELECT count([ID])  AS SlaveServerCount FROM [Keyhan4Prog].[dbo].[ProgramHistory]  Where [ProfileID] = @ProfileID AND [Reserve1] Like 'Server Ver.2%-HA%'
		SELECT count([ID])  AS KRconfigCount FROM [Keyhan4Prog].[dbo].[ProgramHistory]  Where [ProfileID] = @ProfileID AND [Reserve1] Like 'KRConfig Ver%'
		SELECT count([ID])  AS LicenseCount FROM [Keyhan4Prog].[dbo].[ProgramLicense]  Where [ProfileID] = @ProfileID 
		SELECT count([ID])  AS AltManagerCount FROM [Keyhan4Prog].[dbo].[ProgramHistory]  Where [ProfileID] = @ProfileID AND [Reserve1] Like 'Manager Ver.2-TR%' 
		SELECT count([ID])  AS AltServerCount FROM [Keyhan4Prog].[dbo].[ProgramHistory]  Where [ProfileID] = @ProfileID AND [Reserve1] Like 'Server Ver.2-TR%'
	END
  go

