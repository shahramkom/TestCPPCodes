

	create PROCEDURE [dbo].[USP_REPORT_FILTER_INACtvUSRS] 
			@startDate		nvarchar(10)=Null,
			@endDate		nvarchar(10)=Null,
			@pageSize int = NULL,
			@pageNum int = 1
			--@startTime		nvarchar(8)=Null,	
			--@endTime		nvarchar(8)=Null
		AS
		BEGIN

			SET NOCOUNT ON;
			declare @selItems as nvarchar(max),
					@STMT as nvarchar(max),
					@datasrc as nvarchar(max),
					@selItems1 as nvarchar(max),
					@STMT1 as nvarchar(max),
					@query as nvarchar(max),

					@row			nvarchar(max),
					@descript		nvarchar(max),
					--@opDate			nvarchar(10),
					--@opTime			nvarchar(10),
					@tempUserID		nvarchar(max),
					@tempUserName	nvarchar(max),
					@tempFirstName	nvarchar(max),
					@tempLastName	nvarchar(max)
			--delete [TTempUserRepInactive]
		--finding maximum and minimum Size of Log perpage----------------
			DECLARE
			 @pagNum int,
			 @pagSize int,
			 @lbound int,
			 @ubound int,
			 @recct  int

			SET @pagNum = ABS(@pageNum)
			SET @pagSize = ABS(@pageSize)
			IF @pageNum < 1 SET @pageNum = 1
			IF @pageSize < 1 SET @pageSize = 1
			SET @lbound = ((@pageNum - 1) * @pageSize)
			SET @ubound = @lbound + @pageSize + 1

		----insert filtered data to table
			set	 @STMT = 'select distinct UserID FROM sAuthLog where (eventDate <= '''+ @startDate + 
						 ''') AND (eventDate >= ''' + @endDate + ''')'
			set	 @selItems1 = 'distinct userID ,userName ,FirstName,LastName,Company,Office,Province,'
			set  @selItems1  = @selItems1  + 'Town,Email , Cell , PersonnelCode,Phone ,NationalID , Adress , PostalCode'
			set  @datasrc = 'TUser '
			SET	 @STMT1 =  '
									SELECT  '+ @selItems1 +' 
									FROM  ' + @datasrc +
									' WHERE  UserID  NOT IN('+ @STMT +')
								)as tb1'
						  -- where 
                             
								 -- row + '+CONVERT(varchar(9), @i)+ '<' +CONVERT(varchar(9), @ubound)

		-------------------------------------------------------------------------	 
	   declare @statement as nvarchar(max)
		set  @statement = 'select * from
	(SELECT ROW_NUMBER() OVER(ORDER BY UserName DESC) as row,*
	   from ( '+@STMT1 +' )as tb2 
		where (tb2.row > '+ CONVERT(varchar(9), @lbound) + ')and (tb2.row <  '+CONVERT(varchar(9), @ubound)+')'
		exec sp_executesql @statement
		END

  go

