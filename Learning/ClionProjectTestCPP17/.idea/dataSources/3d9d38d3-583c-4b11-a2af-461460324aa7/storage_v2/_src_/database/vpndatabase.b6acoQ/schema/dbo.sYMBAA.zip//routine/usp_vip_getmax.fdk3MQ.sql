
    CREATE PROCEDURE [dbo].[USP_VIP_GetMAX]
        @OctNum as int
        with recompile
        AS
    BEGIN
    SET NOCOUNT ON;	
    DECLARE @RESULT AS bigint
    
    CREATE TABLE #TABLE(VIP nvarchar(20))

    DECLARE @DEFVIP	nvarchar(20)

insert into #table select VirtualIP from tuser where (len(VirtualIP) - len(replace(VirtualIP , '.' ,'')))+1 <= 3
    
        IF(@OctNum = 1)
            SELECT  
                    MAX(CAST(PARSENAME(VIP,1)AS bigint)) 
            FROM  #TABLE
        ELSE IF (@OctNum = 2)
        BEGIN	
            SELECT @RESULT =
                  MAX((256 * CAST(PARSENAME(VIP,2)AS bigint))
                    +CAST(PARSENAME(VIP,1)AS bigint))	
             FROM  #TABLE
             IF (@RESULT IS NULL)
                SELECT  
                    MAX(CAST(PARSENAME(VIP,1)AS bigint)) 
                FROM  #TABLE
             ELSE
                Select @RESULT
         END
         ELSE IF (@OctNum = 3)
         BEGIN		
            SELECT @RESULT =
                 MAX(((256*256)*CAST(PARSENAME(VIP,3)AS bigint))
                    +(256 * CAST(PARSENAME(VIP,2)AS bigint))
                    +CAST(PARSENAME(VIP,1)AS bigint))		 
            FROM  #TABLE
            IF (@RESULT IS NULL)
            BEGIN
                SELECT @RESULT =
                    MAX((256 * CAST(PARSENAME(VIP,2)AS bigint))
                    +CAST(PARSENAME(VIP,1)AS bigint))	
                FROM  #TABLE		
                IF (@RESULT IS NULL)
                    SELECT
                        MAX(CAST(PARSENAME(VIP,1)AS bigint))		 
                    FROM  #TABLE	
                ELSE
                SELECT @RESULT
            END
            ELSE
                SELECT @RESULT
         END

    DROP TABLE #TABLE
END
    go

