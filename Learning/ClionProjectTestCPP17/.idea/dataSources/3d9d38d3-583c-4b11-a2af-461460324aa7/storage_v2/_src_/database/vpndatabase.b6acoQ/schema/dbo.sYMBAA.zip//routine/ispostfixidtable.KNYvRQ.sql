/******************************************************************************************************************************************************/--
CREATE FUNCTION dbo.IsPostfixIDTable(@TableName VARCHAR(50))
RETURNS BIT
BEGIN
	IF (@TableName = 'TGroupPolicySet' OR @TableName = 'TUserPolicySet' OR @TableName = 'TUserScripts' OR @TableName = 'TUserTimeSet' OR @TableName = 'TUserDNS' OR @TableName = 'TGroupInterface' OR @TableName = 'TUserInterface')
		RETURN 1
	ELSE IF (@TableName = 'TgroupScript' OR @TableName = 'TgroupTimeset'OR @TableName = 'TgroupDNS')
		RETURN 0
	RETURN 0
END
go

