
    
    CREATE PROCEDURE [dbo].[USP_Select_Count] 
          
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
    
        SELECT COUNT(UserID) FROM TUser
    
    -- Insert statements for procedure here
    END


    go

