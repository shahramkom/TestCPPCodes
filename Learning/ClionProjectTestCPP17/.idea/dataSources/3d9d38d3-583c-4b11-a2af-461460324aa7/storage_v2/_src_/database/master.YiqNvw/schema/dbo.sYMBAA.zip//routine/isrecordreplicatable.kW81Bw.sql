/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.IsRecordReplicatable(@GroupID INT)
	RETURNS BIT
AS
BEGIN
	DECLARE @GroupIDs VARCHAR(MAX)
	SELECT @GroupIDs = dbo.GetGroupParents(@GroupID)
	
	IF EXISTS(SELECT RepGroupID from RepServersGroups WHERE RepGroupID IN (SELECT items FROM dbo.Splitfn(@GroupIDs,',')))
		RETURN 1	
	RETURN 0
END
go

