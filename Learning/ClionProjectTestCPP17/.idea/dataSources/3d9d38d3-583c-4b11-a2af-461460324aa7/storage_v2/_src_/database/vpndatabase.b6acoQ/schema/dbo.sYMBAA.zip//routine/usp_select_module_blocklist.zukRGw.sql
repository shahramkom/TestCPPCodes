CREATE PROCEDURE [dbo].[USP_Select_Module_BlockList]
AS
BEGIN
    -- Insert statements for procedure here
	SELECT KeyaSerial, [Date] FROM TModuleBlockList
	
END
/******************************************************************************************************************************************************/
go

