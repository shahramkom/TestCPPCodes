CREATE PROCEDURE [dbo].[USP_RestoreRepDataBackupFile]
    @Replace BIT,
	@PlainAuthKey AS BIT = 1
AS
BEGIN
	DECLARE @command VARCHAR(MAX)

    DECLARE @isDisableTrigger BIT
    SET @isDisableTrigger = 1
    SELECT @isDisableTrigger FROM sys.triggers WHERE name = 'trgTUserGroup'
    IF (@isDisableTrigger = 0)
    BEGIN
        SET @command = 'USP_DisableAllTriggers '
        EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'
    END

    SET @command = 'USP_SelectGroupFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectUsersFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace) +', '+ CONVERT(VARCHAR(5), @PlainAuthKey)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'
    
    SET @command = 'USP_SelectTUserGroupsFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile' 

    SET @command = 'USP_SelectTTimeRoleFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'     

    SET @command = 'USP_SelectTGroupTimeSetFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectTGroupInterfaceFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectTScriptFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectTGroupScriptFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectTPolicySetFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectTGroupPolicySetFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'
    
    SET @command = 'USP_SelectTServerAccessPolicyFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'
    
    SET @command = 'USP_SelectTUserFirewallPolicyFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'
    
    SET @command = 'USP_SelectTDNSFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectTDNSGroupFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectSpecialPermissionFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectTuserKeyaFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectTUserDNSFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectTUserscriptsFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectTUserPolicySetFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectTUserTimeSetFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'
   
    SET @command = 'USP_SelectTUserInterfaceFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectPermissionGroupFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

    SET @command = 'USP_SelectModernPolicyFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'

	SET @command = 'USP_SelectHealthCheckFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'
	
	SET @command = 'USP_SelectTModuleBlockListFromImportedBackupData ' + CONVERT(VARCHAR(5), @Replace)
    EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'
	
	IF (@isDisableTrigger = 0)
    BEGIN
        SET @command = 'USP_EnableAllTriggers '
        EXEC USP_ExecuteRestoreData @command, N'USP_RestoreRepDataBackupFile'
    END
END
go

