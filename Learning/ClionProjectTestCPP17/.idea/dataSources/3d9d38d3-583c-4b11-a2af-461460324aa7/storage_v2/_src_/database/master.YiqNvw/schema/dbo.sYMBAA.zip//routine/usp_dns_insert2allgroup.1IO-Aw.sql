
    create PROCEDURE  [dbo].[USP_DNS_Insert2AllGroup]
    @replace           int
    
    
    
    AS
    BEGIN

    declare 	 @DNSID             int  
     declare @HostName			nvarchar(300)	
     declare @ip				nvarchar(15)    
     declare @GroupID			int
    Declare Dns_cursor Cursor  FAST_FORWARD For
    
    Select HostName,IP,DNSID From TDNS
        
    OPEN Dns_cursor

    FETCH NEXT FROM Dns_cursor
    INTO @HostName,@ip,@DNSID

    WHILE @@FETCH_STATUS = 0
    BEGIN
        
        
            ----
            
            Declare GroupID_cursor Cursor FAST_FORWARD For
            Select GroupID From TGroup
            OPEN GroupID_cursor
            FETCH NEXT FROM GroupID_cursor
            INTO @GroupID
            WHILE @@FETCH_STATUS = 0
            BEGIN
        
        
              if  exists (select * from TGroupDNS where DNSID = @DNSID)   
              begin 
                 if(@Replace = 1)
                      begin
                        delete from TGroupDNS where DNSID = @DNSID and GroupID = @GroupID
                        insert into TGroupDNS(DNSID , GroupID) 
                            values (@DnsID , @GroupID)
                      end
              end 
              else
                    
                 begin
                    
                     insert into TGroupDNS(DNSID , GroupID) values (@DNSID , @groupid)
                 end
         
                FETCH NEXT FROM GroupID_cursor
                INTO @GroupID
    
            END


            CLOSE GroupID_cursor;
            DEALLOCATE GroupID_cursor;




        FETCH NEXT FROM Dns_cursor 
        INTO @HostName,@ip,@DNSID
    
    END


    CLOSE Dns_cursor;
    DEALLOCATE Dns_cursor;

    END

    go

