/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetVIPMinIP](@VIPHead AS BIGINT = NULL , @VIPMask AS BIGINT = NULL)
RETURNS BIGINT
AS
BEGIN
	DECLARE @RetVIP BIGINT
	SET @RetVIP = @VIPHead & @VIPMask
	RETURN @RetVIP
END
go

