
    CREATE PROCEDURE  [dbo].[USP_TUserPolicySet_SelectPSID]
        @UserID   int
    AS
    BEGIN
        SELECT PSID FROM  TUserPolicySet WHERE UserID = @UserID order by PolPriority
    END

    go

