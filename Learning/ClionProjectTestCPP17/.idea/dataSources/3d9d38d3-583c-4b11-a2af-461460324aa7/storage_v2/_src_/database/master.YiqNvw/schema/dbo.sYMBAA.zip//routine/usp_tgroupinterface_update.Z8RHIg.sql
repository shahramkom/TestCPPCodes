
	create PROCEDURE [dbo].[USP_TGroupInterface_Update] 
		-- Add the parameters for the stored procedure here
		@GroupID as int,
		@interfaceBindingStatus as bit,
		@interfaceIDs as nvarchar(1000)
	AS
	BEGIN

		SET NOCOUNT ON;
		select @GroupID,@interfaceBindingStatus,@interfaceIDs
		exec USP_TGroupInterface_Delete null, @GroupID	
		begin
			exec USP_TGroupInterface_Delete null, @GroupID
			declare @intfcID as nvarchar(50)
			declare interfaceb_cursor cursor for
			select * from dbo.Splitfn(@interfaceIDs , '#')
			open interfaceb_cursor
			fetch next from interfaceb_cursor into @intfcID
			while @@FETCH_STATUS = 0
			begin
				exec USP_TGroupInterface_Insert @intfcID , @GroupID
				fetch next from interfaceb_cursor into @intfcID
			end
			CLOSE interfaceb_cursor;	
			DEALLOCATE interfaceb_cursor;
		end	
	END

  go

