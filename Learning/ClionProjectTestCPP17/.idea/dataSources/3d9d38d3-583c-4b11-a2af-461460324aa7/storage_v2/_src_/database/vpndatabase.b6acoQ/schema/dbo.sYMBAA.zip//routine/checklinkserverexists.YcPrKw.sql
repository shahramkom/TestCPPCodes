--------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[CheckLinkServerExists]
  @Name NVARCHAR(100),
  @reternValue INT OUTPUT
AS
BEGIN
	if not exists (select * from sys.servers where name = @Name)
	BEGIN	
		SET @reternValue = 0;
		RETURN
	END
	SET @reternValue = 1;
END
go

