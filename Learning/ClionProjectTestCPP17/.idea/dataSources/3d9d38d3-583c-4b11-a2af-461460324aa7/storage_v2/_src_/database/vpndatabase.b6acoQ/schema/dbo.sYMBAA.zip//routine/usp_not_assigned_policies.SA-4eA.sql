
CREATE PROCEDURE [dbo].[USP_Not_Assigned_Policies] 

AS
BEGIN

SELECT  TPolicySet.* from TPolicySet
WHERE PSID	NOT IN
(
	SELECT PSID From TGroupPolicySet
	union
	SELECT PSID FRom TUserPolicySet
)				
	
END
go

