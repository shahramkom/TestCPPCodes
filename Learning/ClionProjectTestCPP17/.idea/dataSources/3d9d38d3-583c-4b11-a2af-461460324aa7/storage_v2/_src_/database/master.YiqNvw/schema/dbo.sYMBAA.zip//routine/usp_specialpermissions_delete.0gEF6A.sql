
    CREATE PROCEDURE [dbo].[USP_SpecialPermissions_Delete] 
        @PermissionName nvarchar(50)
    AS
    BEGIN
        Delete from SpecialPermission where PermissionName = @PermissionName
    END


    go

