CREATE PROCEDURE [dbo].[USP_CH_Profile_Count]
  @CHP_ProfileID			int
AS
BEGIN
	SELECT COUNT(*) FROM [HealthCheckProfiles]
END
go

