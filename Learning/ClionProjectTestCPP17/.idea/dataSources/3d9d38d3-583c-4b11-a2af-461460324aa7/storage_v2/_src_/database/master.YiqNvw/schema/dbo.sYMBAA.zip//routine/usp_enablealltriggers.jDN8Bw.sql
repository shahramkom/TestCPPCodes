/******************************************************************************************************************************************************/-------------------------------
CREATE Procedure USP_EnableAllTriggers
AS
BEGIN
	ENABLE TRIGGER [dbo].[trgTUser]                  ON TUser;
	ENABLE TRIGGER [dbo].[trgTUserGroup]			 ON TUserGroups;
	ENABLE TRIGGER [dbo].[trgTGroup]				 ON TGroup;
	ENABLE TRIGGER [dbo].[trgTUserKeyA]				 ON TUserKeya;
	ENABLE TRIGGER [dbo].[trgSpecialPermission]		 ON SpecialPermission;
	ENABLE TRIGGER [dbo].[trgTPermissionGroup]		 ON TPermissionGroup;
	ENABLE TRIGGER [dbo].[trgTUserPolicySet]		 ON TUserPolicySet;
	ENABLE TRIGGER [dbo].[trgTGroupPolicySet]		 ON TGroupPolicySet;
	ENABLE TRIGGER [dbo].[trgTPolicySet]			 ON TPolicySet;
	ENABLE TRIGGER [dbo].[trgTServerAccessPolicy]    ON TServerAccessPolicy;
	ENABLE TRIGGER [dbo].[trgTUserFirewallPolicy]	 ON TUserFirewallPolicy;
	ENABLE TRIGGER [dbo].[trgTGroupScript]			 ON TgroupScript;
	ENABLE TRIGGER [dbo].[trgTScript]				 ON TScript;
	ENABLE TRIGGER [dbo].[trgTUserScript]			 ON TUserScripts;
	ENABLE TRIGGER [dbo].[trgTUserTimeSet]			 ON TUserTimeSet;
	ENABLE TRIGGER [dbo].[trgTGroupTimeSet]			 ON TgroupTimeset;
	ENABLE TRIGGER [dbo].[trgTTimeRole]				 ON TTimeRole;
	ENABLE TRIGGER [dbo].[trgTUserDNS]				 ON TUserDNS;
	ENABLE TRIGGER [dbo].[trgTGroupDNS]			     ON TgroupDNS;
	ENABLE TRIGGER [dbo].[trgTDNS]                   ON TDNS;
END
go

