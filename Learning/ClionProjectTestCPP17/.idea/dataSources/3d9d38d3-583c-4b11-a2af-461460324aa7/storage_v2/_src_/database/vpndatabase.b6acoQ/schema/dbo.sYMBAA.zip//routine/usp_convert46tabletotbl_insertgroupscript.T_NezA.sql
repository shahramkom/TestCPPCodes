
	CREATE PROCEDURE [dbo].[USP_Convert46TableToTbl_InsertGroupScript] 
	AS
BEGIN
		-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
		SET NOCOUNT ON;
		BEGIN TRY
			INSERT INTO [VPNDataBase].[dbo].[tbl_InsertGroupScript]
			   ([Output]
			   ,[GroupID]
			   ,[GroupName]
			   ,[PSID]
			   ,[PSName]
			   ,[UserID]
			   ,[userName]
			   ,[hostname]
			   ,[tableName]
			   ,[ScriptTitle]
			   ,[PermissionName]
			   ,[KeyaSerial]
			   ,[DNSID]
			   ,[ScriptID]
			   ,[TimeSetName]
			   ,[TRID]
			   ,[PermissionID]
			   ,[InterfaceID] 
			   ,[MessageType] 
			   ,[UseDefault]
			   ,[ErrorMessage])
			SELECT * FROM [VPNDataBase].[dbo].[tbl_InsertGroupScript46]
		END TRY
		BEGIN CATCH
			INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
			VALUES
			   (1
			   ,GETDATE()
			   ,NULL 
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_Convert46TableToTbl_InsertGroupScript') 
		END CATCH
	END

  go

