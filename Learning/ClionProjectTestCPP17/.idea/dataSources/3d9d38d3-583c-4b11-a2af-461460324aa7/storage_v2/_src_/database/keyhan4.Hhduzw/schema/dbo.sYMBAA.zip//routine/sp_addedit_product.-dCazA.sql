CREATE PROCEDURE [dbo].[sp_AddEdit_Product]
	@PrdCode			int,
	@PrdName			nvarchar(200),
	@PrdVer			nvarchar(200),
	@PrdDescription  		nvarchar(200),
	@PrdLock			int, 
	@PrdSetting			int

 AS
	-- for Add
	declare 	@PrevCode int
	set @PrevCode = -1
	if (@PrdCode = 0)
	begin
		select @PrevCode = Code from Products where (ProductName=@PrdName and ProductVer=@PrdVer)
		if (@PrevCode  <> -1)
		begin
			select N'ãÍÕæá ÈÇ Çíä äÇã æ æäå ÏÑ ÇíÇå ÏÇÏå æÌæÏ ÏÇÑÏ.' as ErrMsg, 1 as ErrCode
			return ;
		end
		Insert Products  (ProductName, ProductVer, Description, ProductLock, SettingCode )
		values  	          (@PrdName, @PrdVer, @PrdDescription, @PrdLock, @PrdSetting)		
		select N'ãÍÕæá ãæÑÏ äÙÑ ÈÇ ãæÝÞíÊ Èå ÇíÇå ÏÇÏå ÇÖÇÝå ÔÏ.' as ErrMsg, 0 as ErrCode
		return ;
	end

	-- for Edit
	set @PrevCode = -1
	select @PrevCode = Code from Products where (ProductName=@PrdName and ProductVer=@PrdVer)
	if (@PrevCode  != @PrdCode  )
	begin
		select N'ãÍÕæá ÈÇ Çíä äÇã æ æäå ÏÑ ÇíÇå ÏÇÏå æÌæÏ ÏÇÑÏ.' as ErrMsg, 1 as ErrCode
		return ;
	end

	Update Products  
	set 
		ProductName  =  @PrdName,
		ProductVer      =  @PrdVer,
		Description      =  @PrdDescription,
		ProductLock   =  @PrdLock,
		SettingCode    =   @PrdSetting
	where 	(Code = @PrdCode)

	select N'Ñ˜æÑÏ ãæÑÏ äÙÑ ÈÇ ãæÝÞíÊ æíÑÇíÔ ÔÏ.' as ErrMsg, 0 as ErrCode
go

