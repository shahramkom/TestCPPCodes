/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.HasSlaveServer(@CurrentServerID tinyint)
	RETURNS BIT
AS
BEGIN
	DECLARE @MySlaveIP as CHAR(15)
	DECLARE @MyServerIP as CHAR(15)
	SELECT @MyServerIP = [value] FROM TSetting WHERE  [Property] = 'ServerIP'
	SELECT  @MySlaveIP = SlaveIP from RepConfig where ServerID = @CurrentServerID
	
	DECLARE @HasSlave as bit
	if( (LTRIM(@MySlaveIP) <> '' AND @MySlaveIP is not NULL) AND (@MySlaveIP <> @MyServerIP ))
		SET @HasSlave = 1
	else
		set @HasSlave = 0
	RETURN @HasSlave
END
go

