CREATE PROCEDURE [dbo].[USP_GroupAssigned_PoliciesSAP] 
	@GroupID int
AS
BEGIN
	select SAP.PolicyID, SAP.PSID, SAP.PolicyName, SAP.NetworkIP, SAP.NetworkMask, SAP.Protocol, SAP.Port, SAP.PAction, SAP.Authentication, SAP.Encryption, SAP.Compression, SAP.IP_RangeType, SAP.CreateTime, SAP.LastModifiedTime, SAP.Status, SAP.ExpireDate, SAP.POrder, SAP.PolicyDescription from TGroup g inner join TGroupPolicySet r on g.GroupID= r.GroupId inner join TServerAccessPolicy SAP on SAP.PSID = r.PSID where g.GroupID = @GroupID and SAP.Status=1 order by r.PriorityOrder, SAP.POrder asc
END
go

