
    CREATE PROCEDURE [dbo].[USP_TScript_FilterName]
    @ScriptTitle nvarchar(50)

    AS
    BEGIN	
        select ScriptID from TScript where ScriptTitle = @ScriptTitle
    END

    go

