CREATE PROCEDURE [dbo].[USP_UpdateUserStatus] 
	@accStatus tinyInt,
	@UserID bigint,
	@DisableDescription nvarchar(100)
AS
BEGIN
	Update TUser set AccountDisable = @accStatus, DisableResult = @DisableDescription where UserID = @UserID
END
go

