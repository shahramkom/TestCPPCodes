
      CREATE PROCEDURE [dbo].[USP_TNewPolicyMain_Insert] 
	  @PolicyType  tinyint,
	  @Name  nvarchar(50),
	  @Enablity  bit,
	  @ServicesID  int,
	  @EncryptionID  int,
	  @AdvancedDetailID  int,
	  @Compression  bit,
	  @PolicyOrder  tinyint,
	  @CreateTime  nvarchar(20),
	  @LastModifyTime  nvarchar(20),
	  @Discription  nvarchar(200),
	  @ApplyTime    tinyint ,
	  @sourceTunnelType  tinyint,
	  @sourceTunnelValue  nvarchar(150),
	  @DestinationTunnelType  tinyint,
	  @DestinationTunnelValue  nvarchar(150),
	  @DirectionType  tinyint,
	  @EncryptionKey  nvarchar(200),
	  @IntegrityKey  nvarchar(200),
	  @TunnelID		int
    AS
    BEGIN
		DECLARE @lastOrder as int
		SELECT @lastOrder = MAX (PolicyOrder) FROM [TNewPolicyMainTable] WHERE [ApplyTime] = @ApplyTime
		IF(@lastOrder IS NULL)
			SET @lastOrder = 1
		ELSE
			SET @lastOrder = @lastOrder  + 1 

		DECLARE @CreatedDateTimeNow AS NVARCHAR(20)
		SELECT @CreatedDateTimeNow = CONVERT(nvarchar(20),GETDATE(),20)	

		Declare @Real_Source_Value as nvarchar(100)
		Declare @Real_Destination_Value as nvarchar(100)

		SET @Real_Source_Value = @sourceTunnelValue
		SET @Real_Destination_Value = @DestinationTunnelValue

		if(@sourceTunnelType = 0 AND @Real_Source_Value != 'UseRs:AnY')--Source User_Type
			select 	@Real_Source_Value = UserID from TUSER WHERE UserName = @sourceTunnelValue		
		if(@sourceTunnelType = 1)--Source Group_Type
			select 	@Real_Source_Value = GroupID from TGroup WHERE GroupName = @sourceTunnelValue		

		if(@DestinationTunnelType = 0 AND @Real_Destination_Value != 'UseRs:AnY')--Destination User_Type
			select 	@Real_Destination_Value = UserID from TUSER WHERE UserName = @DestinationTunnelValue		
		if(@DestinationTunnelType = 1)--Destination Group_Type
			select 	@Real_Destination_Value = GroupID from TGroup WHERE GroupName = @DestinationTunnelValue		
		
		DECLARE @lastTunnelID as int 
		set @lastTunnelID = 0
		
		if( @PolicyType = 1 OR @PolicyType = 2)
		BEGIN
			select @lastTunnelID = [value] from TSetting where Property = 'LastTunnelID'
			 if(@lastTunnelID  = 0)
			 BEGIN
					select @lastTunnelID = max(TunnelID) from TNewPolicyMainTable
					if(@lastTunnelID = 0)
						set @lastTunnelID = 200
			 END
	         if( @lastTunnelID < 200 OR @lastTunnelID > 944)
		     BEGIN
				Raiserror('Tunnel ID value is not correct', 16 , 10 )
				return;
			END
		END
		
		INSERT INTO [dbo].[TNewPolicyMainTable]
			   ([PolicyType]
			   ,[Name]
			   ,[Enablity]
			   ,[ServicesID]
			   ,[EncryptionID]
			   ,[AdvancedDetailID]
			   ,[Compression]
			   ,[PolicyOrder]
			   ,[CreateTime]
			   ,[LastModifyTime]
			   ,[Discription]
			   ,[ApplyTime]
			   ,[sourceTunnelType]
			   ,[sourceTunnelValue]
			   ,[DestinationTunnelType]
			   ,[DestinationTunnelValue]
			   ,[DirectionType]
			   ,[EncryptionKey]
			   ,[IntegrityKey]
			   ,[TunnelID])
		 VALUES
			  (@PolicyType,
			   @Name,
			   @Enablity,
			   @ServicesID,
			   @EncryptionID,
			   @AdvancedDetailID,
			   @Compression,
			   @lastOrder,
			   @CreatedDateTimeNow,
			   @LastModifyTime,
			   @Discription,
			   @ApplyTime,
			   @sourceTunnelType,
			   @Real_Source_Value,
			   @DestinationTunnelType,
			   @Real_Destination_Value,
			   @DirectionType,
			   @EncryptionKey  ,
			   @IntegrityKey ,
			   @lastTunnelID )
	if( @PolicyType = 1 OR @PolicyType = 2)
	BEGIN
		if( @PolicyType = 1 )
			SET @lastTunnelID = @lastTunnelID + 2
		if( @PolicyType = 2 )
			SET @lastTunnelID = @lastTunnelID + 4
		update TSetting set [value] = @lastTunnelID where [Property] = 'LastTunnelID'
	END

	SELECT @@identity
    END

      go

