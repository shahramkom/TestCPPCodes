
    
    CREATE PROCEDURE [dbo].[USP_Generate_Update_Script] 
        -- Add the parameters for the stored procedure here
        @PCbinginsArt1 nvarchar(50) = null 
        ,@KeyASerial nvarchar(50) = null
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
        delete from TUser_Update_Script
        if(@PCbinginsArt1 is not null )
          exec USP_UpateTUserGenerator
          if(@KeyASerial is not null)
            exec USP_UpateTUserkeyAGenerator
    END


    go

