/******************************************************************************************************************************************************/
CREATE FUNCTION dbo.GetGroupChildren(@GroupID int)
	RETURNS varchar(MAX)
AS
BEGIN
	DECLARE @GroupIDs VARCHAR(MAX);
	
	with ChildsCTE as ( select GroupID, ParentID from TGroup where GroupID=@GroupID
	union all select TGroup.GroupID, TGroup.ParentID from TGroup join ChildsCTE on ChildsCTE.GroupID = TGroup.ParentID)

	SELECT @GroupIDs = STUFF ((SELECT ','+ CAST( ChildsCTE.GroupID AS VARCHAR(200))
	FROM ChildsCTE FOR XML PATH('')) , 1 ,1 , '')
	
	RETURN @GroupIDs
END
go

