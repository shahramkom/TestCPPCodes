/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetTwoConditionDeleteQuery]( @TableName nvarchar(100), @IDFieldName1 nvarchar(100), @IDFieldValue1 int, @IDFieldName2 nvarchar(100), @IDFieldValue2 varchar(50))
		RETURNS varchar(MAX)
AS
BEGIN
		DECLARE @CommandStr nvarchar(MAX)
		SET @CommandStr ='DELETE FROM ' +@TableName
		+ ' WHERE '+ @IDFieldName1 +' = ' + CAST(@IDFieldValue1 AS VARCHAR(30))
		+ ' AND '+ @IDFieldName2 +' = N''''' + @IDFieldValue2 +''''''
		return @CommandStr
END
go

