
		CREATE PROCEDURE usp_selectImportantTableContentsCount
		AS
		BEGIN
	   		SELECT COUNT(TGroup.GroupID)as Group# FROM tgroup 
			SELECT COUNT(tuser.userid) as User# FROM tuser 
	   		SELECT COUNT(TPolicySet.PSID)as PolicySet# FROM TPolicySet 
	   		SELECT COUNT(TGroupPolicySet.PSID)as GroupPolicy# FROM TGroupPolicySet
	   		SELECT COUNT(TUserPolicySet.PSID)as UserPolicy# FROM TUserPolicySet
	   		SELECT COUNT(TServerAccessPolicy.PolicyID)as SimplePol# FROM TServerAccessPolicy
	   		SELECT COUNT(TUserFirewallPolicy.UFPID)as AdvancePol# FROM TUserFirewallPolicy
	   		SELECT COUNT(TDNS.DNSID)as DNS# FROM TDNS
	   		SELECT COUNT(TTimeRole.TRID)as TimeSet# FROM TTimeRole
	   		SELECT COUNT(TScript.ScriptID)as Script# FROM TScript
		END

    go

