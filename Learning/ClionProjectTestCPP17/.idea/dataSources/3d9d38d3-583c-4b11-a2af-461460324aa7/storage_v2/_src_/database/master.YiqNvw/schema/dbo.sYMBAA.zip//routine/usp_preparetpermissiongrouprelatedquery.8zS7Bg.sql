/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_PrepareTPermissionGroupRelatedQuery]
	@ActionType varchar(20),
	@PermissionIDValue int,
	@GroupIDValue int,
	@ReturnCommand nvarchar(MAX) OUTPUT
	AS
	BEGIN
		DECLARE @Query nvarchar(MAX)
		IF(@ActionType = 'Insert')
			SET @Query = dbo.GetTPermissionGroupInsertQuery( @PermissionIDValue, @GroupIDValue )
		ELSE IF(@ActionType = 'Delete')
		BEGIN
			SET @Query = dbo.GetTableDeleteQuery('TPermissionGroup', 'Permission_ID', @PermissionIDValue )
			SELECT @ReturnCommand=@Query
			RETURN
		END

		CREATE TABLE #tmpTbl([Command] nvarchar(MAX))
		INSERT INTO #tmpTbl ([Command]) exec sp_executesql @Query 
		DECLARE @TmpQuery NVARCHAR(MAX)
		SELECT @TmpQuery = Command from #tmpTbl
		SET @Query = REPLACE(@TmpQuery , '''' , '''''')
		
		SELECT @ReturnCommand=@Query
		DROP TABLE #tmpTbl
END
go

