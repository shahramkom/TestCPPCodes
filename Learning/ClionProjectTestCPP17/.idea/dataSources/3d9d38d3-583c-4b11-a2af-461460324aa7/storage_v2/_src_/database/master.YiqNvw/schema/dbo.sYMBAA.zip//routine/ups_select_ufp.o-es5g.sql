

    CREATE PROCEDURE  [dbo].[UPS_Select_UFP] 
    
    @PSID int =null
    with recompile
    AS
    BEGIN
        SELECT  * from  TUserFireWallPolicy where (PSID = @PSID OR   @PSID IS NULL  OR @PSID = 0 ) order by  POrder 
    END

    go

