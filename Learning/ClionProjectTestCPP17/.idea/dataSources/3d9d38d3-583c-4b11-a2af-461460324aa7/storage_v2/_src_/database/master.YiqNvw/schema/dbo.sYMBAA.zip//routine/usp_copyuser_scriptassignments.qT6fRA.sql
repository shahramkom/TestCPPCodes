
	CREATE PROCEDURE [dbo].[USP_CopyUser_ScriptAssignments] 
    @OldUserID  bigint,
	@NewUserID  bigint
   AS
   BEGIN
		INSERT INTO TUserscripts (UserID	 , ScriptID)
		SELECT 	@NewUserID	 ,ScriptID	 
		FROM TUserscripts WHERE UserID = @OldUserID
   END

  go

