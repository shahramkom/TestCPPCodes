CREATE PROCEDURE [dbo].[UPS_Check_UserHave_AnyModernPolicy] 
	@UserID BIGINT,
	@AllRelatedGroupsOfUser nvarchar(2000)
AS
BEGIN
	DECLARE @NotAllow bit
	SELECT @NotAllow = DisableModernPolicy FROM Tuser WHERE UserID = @UserID
	IF(@NotAllow = 1)
	BEGIN
		SELECT 0 AS ModernPolicy
		RETURN
	END
	DECLARE @Count TINYINT
	SELECT @Count = COUNT(ModernPID) FROM TNewPolicyUserAssign WHERE UserID = @UserID
	if( @Count > 0)
	BEGIN
		SELECT 1 AS ModernPolicy
		RETURN
	END	
	DECLARE @execSql  as NVARCHAR(2000)
	SET @execSql = 'SELECT @Count = COUNT(ModernPID) FROM TNewPolicyGroupAssign WHERE GroupID in('+@AllRelatedGroupsOfUser+')'
	EXEC SP_EXECUTESQL @execSql, N'@Count TINYINT OUTPUT', @Count OUTPUT
	if( @Count > 0)
	BEGIN
		SELECT 1  AS ModernPolicy
		RETURN
	END	
	SELECT 0  AS ModernPolicy 
END
go

