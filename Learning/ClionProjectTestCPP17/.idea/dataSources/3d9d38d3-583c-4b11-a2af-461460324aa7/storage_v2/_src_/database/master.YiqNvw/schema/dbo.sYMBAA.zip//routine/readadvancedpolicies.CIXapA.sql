--------------------------------------------------------------------------------

CREATE PROCEDURE [dbo].[ReadAdvancedPolicies] 
	@UserID INT
AS
BEGIN
	
BEGIN TRY
    DROP TABLE #AdvancedPolices
END TRY
BEGIN CATCH	
END CATCH

CREATE TABLE #AdvancedPolices(AP_ID int, Ac_ActionType nvarchar(50),
	Ac_VirtualIP_Status nvarchar(50),Ac_VirtualIP nvarchar(15),Ac_Tunnel_Source_Type nvarchar(50),
	Ac_Tunnel_Source_IP nvarchar(15),Ac_Tunnel_Dest_Type nvarchar(50),Ac_Tunnel_Dest_IP nvarchar(15),
	Ac_Key_ID nvarchar(100),Ac_AthenticationType nvarchar(150),Ac_AthenticationKey nvarchar(150),
	Ac_EncryptionType nvarchar(150),Ac_EncryptionKey nvarchar(150),Fil_Direction nvarchar(50),
	Fil_Source_AdressType nvarchar(50),Fil_Source_IPAdress nvarchar(15),Fil_Source_NetworkMask nvarchar(15),
	Fil_Dest_Type nvarchar(50),Fil_Dest_IPAdress nvarchar(15),Fil_Dest_NetworkMask nvarchar(15),
	Fil_Protocol_Code nvarchar(50),Fil_Protocol_SourcePort nvarchar(50),Fil_Protocol_DestPort nvarchar(50),
	Fil_AllowNAT bit,Compression bit,UserAP_Order int, AP_Order int)
ALTER TABLE #AdvancedPolices ADD ID INT IDENTITY(1, 1) PRIMARY KEY;

INSERT INTO #AdvancedPolices
	SELECT DISTINCT UFP.UFPID, UFP.Ac_ActionType,UFP.Ac_VirtualIP_Status, UFP.Ac_VirtualIP, UFP.Ac_Tunnel_Source_Type, 
	UFP.Ac_Tunnel_Source_IP, UFP.Ac_Tunnel_Dest_Type,UFP.Ac_Tunnel_Dest_IP,UFP.Ac_Key_ID , UFP.Ac_AthenticationType, UFP.Ac_AthenticationKey,
	UFP.Ac_EncryptionType ,UFP.Ac_EncryptionKey ,UFP.Fil_Direction ,UFP.Fil_Source_AdressType ,UFP.Fil_Source_IPAdress ,UFP.Fil_Source_NetworkMask ,
	UFP.Fil_Dest_Type ,UFP.Fil_Dest_IPAdress ,UFP.Fil_Dest_NetworkMask ,UFP.Fil_Protocol_Code ,UFP.Fil_Protocol_SourcePort ,UFP.Fil_Protocol_DestPort ,
	UFP.Fil_AllowNAT ,UFP.Compression ,TUserPolicySet.PolPriority, UFP.POrder
	FROM TUserPolicySet
	JOIN TUserFirewallPolicy AS UFP ON UFP.PSID = TUserPolicySet.PSID
	WHERE UFP.Status = 1 AND UserID = @UserID
	ORDER BY TUserPolicySet.PolPriority, UFP.POrder

DECLARE @GroupsIDs NVARCHAR(100)
SET @GroupsIDs = dbo.GetAllRelatedGroupsOfUser( @UserID )

DECLARE @GroupsID NVARCHAR(10)
DECLARE Groups_Cursor CURSOR FOR SELECT * FROM dbo.Splitfn(@GroupsIDs,',')
OPEN Groups_Cursor
FETCH NEXT FROM Groups_Cursor INTO @GroupsID

WHILE @@FETCH_STATUS = 0
BEGIN
	INSERT INTO #AdvancedPolices
	SELECT DISTINCT UFP.PSID, UFP.Ac_ActionType,UFP.Ac_VirtualIP_Status, UFP.Ac_VirtualIP, UFP.Ac_Tunnel_Source_Type, 
	UFP.Ac_Tunnel_Source_IP, UFP.Ac_Tunnel_Dest_Type,UFP.Ac_Tunnel_Dest_IP,UFP.Ac_Key_ID , UFP.Ac_AthenticationType, UFP.Ac_AthenticationKey,
	UFP.Ac_EncryptionType ,UFP.Ac_EncryptionKey ,UFP.Fil_Direction ,UFP.Fil_Source_AdressType ,UFP.Fil_Source_IPAdress ,UFP.Fil_Source_NetworkMask ,
	UFP.Fil_Dest_Type ,UFP.Fil_Dest_IPAdress ,UFP.Fil_Dest_NetworkMask ,UFP.Fil_Protocol_Code ,UFP.Fil_Protocol_SourcePort ,UFP.Fil_Protocol_DestPort ,
	UFP.Fil_AllowNAT ,UFP.Compression , TGroupPolicySet.PriorityOrder, UFP.POrder
	FROM TGroupPolicySet INNER JOIN TUserFirewallPolicy AS UFP ON UFP.PSID = TGroupPolicySet.PSID
	WHERE TGroupPolicySet.GroupID = @GroupsID AND UFP.Status=1
	AND (UFP.UFPID NOT IN (SELECT AP_ID FROM #AdvancedPolices))
	ORDER BY TGroupPolicySet.PriorityOrder, UFP.POrder

	FETCH NEXT FROM Groups_Cursor INTO @GroupsID
END

CLOSE Groups_Cursor;	
DEALLOCATE Groups_Cursor;

SELECT * FROM #AdvancedPolices
DROP TABLE #AdvancedPolices

END

go

