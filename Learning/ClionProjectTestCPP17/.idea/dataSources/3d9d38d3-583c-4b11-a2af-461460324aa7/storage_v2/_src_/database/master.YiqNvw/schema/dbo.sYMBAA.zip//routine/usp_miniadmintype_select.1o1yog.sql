
    CREATE PROCEDURE [dbo].[USP_MiniAdminType_select] 
        -- Add the parameters for the stored procedure here
        @UserID as int
    AS
    BEGIN
        SET NOCOUNT ON;
        declare @Perm_ID as int 
        select @Perm_ID = Permission_ID from TUser where UserID = @UserID
        select MiniAdminType from SpecialPermission where ID = @Perm_ID

    END

    go

