/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[GetDateTimeFromGID](@GID VARCHAR(25))
RETURNS DATETIME
AS
BEGIN
		DECLARE @dateTime AS VARCHAR(12)
		DECLARE @second AS INT
		SET @second = CHARINDEX(',', @GID, CHARINDEX(',',@GID) + 1)
		SET @dateTime = RIGHT(@GID, LEN(@GID) - @second)
		
		RETURN dbo.UNIXToDateTime(@dateTime)
END
go

