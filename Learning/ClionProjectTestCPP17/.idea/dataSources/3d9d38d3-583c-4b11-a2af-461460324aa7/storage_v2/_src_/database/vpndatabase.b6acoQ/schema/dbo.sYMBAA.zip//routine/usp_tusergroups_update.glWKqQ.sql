/******************************************************************************************************************************************************/-------------------------------
CREATE PROCEDURE [dbo].[USP_TUserGroups_Update] 
    @UserID INT,
	@gid varchar(25)

AS
BEGIN
    SET NOCOUNT ON;
    
	UPDATE TUserGroups SET GID = @gid WHERE UserID = @UserID 
END

go

