
    CREATE PROCEDURE [dbo].[USP_SpecialPermissions_Select]
        @user_ID bigint = NULL
    AS
    BEGIN
        declare @per_id bigint
        if (@user_ID is NULL)
            SELECT * from  SpecialPermission
        else
            select @per_id = Permission_ID from TUser where UserID = @user_ID

        if (@per_id is NULL)
            return
    
        select * from SpecialPermission where ID = @per_id 

    END

    go

