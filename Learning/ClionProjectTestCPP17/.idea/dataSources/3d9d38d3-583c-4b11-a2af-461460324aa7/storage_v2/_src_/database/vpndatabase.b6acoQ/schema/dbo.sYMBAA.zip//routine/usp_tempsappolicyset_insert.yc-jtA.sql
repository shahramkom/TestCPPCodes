
    CREATE PROCEDURE [dbo].[USP_TempSAPPolicySet_Insert] 
        -- Add the parameters for the stored procedure here
        --@PSID int , 
        @oldPSID int ,
        @PSName nvarchar(100) = NULL ,
        @Replace int = 0
    
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
    
        if(not exists (select  PSID from TPolicySet where PSName = @PSName ))
           begin
            -- Insert statements for procedure here
                 INSERT INTO 
                   TPolicySet (/*PSID,*/PSName,oldPSID) values (/*@PSID,*/ @PSName,@oldPSID) 
            end
    END

    go

