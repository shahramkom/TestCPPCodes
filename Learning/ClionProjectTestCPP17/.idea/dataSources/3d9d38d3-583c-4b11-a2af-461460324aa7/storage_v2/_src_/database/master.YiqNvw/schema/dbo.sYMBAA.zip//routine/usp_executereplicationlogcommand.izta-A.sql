/*************************************************************************************************************************************/  
CREATE PROCEDURE [dbo].[USP_ExecuteReplicationLogCommand]
@RecordID INT,
@ActionType VARCHAR(50),
@Command   NVARCHAR(MAX),
@RecordGID VARCHAR(25),
@RecordAssignedGroups VARCHAR(MAX) = NULL,
@RecordAssignedUsers VARCHAR(MAX) = NULL
AS
BEGIN
	DECLARE @TableName AS VARCHAR(50)
	DECLARE @WantedPartOfCommand AS NVARCHAR(MAX)
	DECLARE @TmpPlainKey AS NVARCHAR(100)
	DECLARE @TmpVIPValue AS NVARCHAR(20)
	DECLARE @NewVIPValue AS NVARCHAR(20)
	DECLARE @PlainKey AS NVARCHAR(64)
	DECLARE @EncKey AS NVARCHAR(MAX)
	DECLARE @ResultMsg VARCHAR(500) 
	DECLARE @RetVal AS INT
	DECLARE @isExecutable AS BIT
	DECLARE @UserName  AS NVARCHAR(100)
	DECLARE @VirtualIP AS NVARCHAR(20)
	DECLARE @LoginType INT
	DECLARE @ConfResult AS INT
	DECLARE @ChangeUserVIP AS BIT

	SET @isExecutable = 1
	SET @PlainKey = NULL
	SET @TableName= SUBSTRING(@ActionType, 8, LEN(@ActionType))
	SET @ConfResult = -1

	DECLARE @ServerIP VARCHAR(20)
	DECLARE @ServerID INT
    SELECT @ServerIP = [value] FROM dbo.TSetting WHERE Property = 'ServerIP'
	SET @ServerID      = dbo.[GetServerIDFromRepConfig](@ServerIP)
	IF (@ActionType = 'Insert-TUser')
		SET @ChangeUserVIP = dbo.[GetReplicateVIPStatusByGroupID](CAST(@RecordAssignedGroups AS INT))
	ELSE IF (@ActionType = 'Update-Tuser')
		SET @ChangeUserVIP = 1
	

	IF(@ActionType = 'Update-TUser')
		SELECT @isExecutable = dbo.IsCommandExecutable(@RecordID, @RecordGID)

	IF(@ActionType = 'Insert-TUser')
	BEGIN
		DECLARE @RecCount AS TINYINT
		SELECT @RecCount = COUNT(*) from TUser WHERE UserID = @RecordID
		IF((@RecCount > 0) AND (@RecordAssignedGroups IS NOT NULL))
		BEGIN
			EXEC USP_PrepareAndAssignToRelatedGroupsUsers @TableName,@RecordID, @RecordAssignedGroups,@RecordAssignedUsers, @RecordGID
			RETURN
		END	
		SET @WantedPartOfCommand = SUBSTRING(@Command, CHARINDEX('values(', @Command )+8, len(@Command))
		SELECT @TmpPlainKey = (
		SELECT TOP(12) *  FROM    dbo.splitfn(@WantedPartOfCommand,',')
		EXCEPT
		SELECT TOP(11) *  FROM    dbo.splitfn(@WantedPartOfCommand,','))

		IF(@ChangeUserVIP = 1)
		BEGIN
			SELECT @TmpVIPValue = (
			SELECT TOP(9) *  FROM    dbo.splitfn(@WantedPartOfCommand,',')
			EXCEPT
			SELECT TOP(8) *  FROM    dbo.splitfn(@WantedPartOfCommand,','))
		END
	END
	ELSE IF(@ActionType = 'Update-TUser')
	BEGIN
		SET @TmpPlainKey = SUBSTRING(@Command, CHARINDEX('AuthenticationKey = ', @Command )+20, 67)
		IF(@ChangeUserVIP = 1)
		BEGIN
			DECLARE @VIPStartLocation INT
			DECLARE @VIPEndLocation INT
			SELECT  @VIPStartLocation = CHARINDEX('VirtualIP = ',@Command,0)
			SELECT  @VIPEndLocation = CHARINDEX(',',@Command,@VIPStartLocation+1)
			SELECT  @TmpVIPValue = SUBSTRING(@Command ,@VIPStartLocation+12, @VIPEndLocation- @VIPStartLocation-12)
			SELECT  @TmpVIPValue = 'N'+@TmpVIPValue
		END
	END
	IF(@ActionType = 'Insert-TUser' OR @ActionType = 'Update-TUser')
	BEGIN
		SET @PlainKey = SUBSTRING(@TmpPlainKey , 3, LEN(@TmpPlainKey)-3)
		IF(@ChangeUserVIP = 1)
		BEGIN
			IF(@TmpVIPValue IS NOT NULL AND @TmpVIPValue <> 'NULL')
				IF(@ActionType = 'Insert-TUser')
					SET @TmpVIPValue = SUBSTRING(@TmpVIPValue , 2, LEN(@TmpVIPValue)-2)
				ELSE IF (@ActionType = 'Update-TUser')
					SET @TmpVIPValue = SUBSTRING(@TmpVIPValue , 3, LEN(@TmpVIPValue)-3)
		END
		create table #Table(CommandLine nvarchar(200),Param1 nvarchar(200),[Output]	nvarchar(64))
		insert #Table EXEC Master..XYRunProc 'Encrypt' ,@PlainKey
        select @EncKey = [Output] from #Table where CommandLine='Encrypt'	
        drop table #Table
        if( @EncKey IS NULL)
        begin
            Raiserror ('The Authentication key is null!  Please check server configs.',16,10)
            return		
        end
		SET @EncKey = REPLACE(@EncKey, '''' , '''''')
		SET @Command = REPLACE(@Command, @PlainKey , @EncKey)

		IF(@ChangeUserVIP = 1)
		BEGIN
			IF(@TmpVIPValue IS NOT NULL AND @TmpVIPValue <> 'NULL')
			BEGIN
				SELECT @NewVIPValue = dbo.[GetCorrectIP]('RemoteMode', @TmpVIPValue)
				IF(@TmpVIPValue <> @NewVIPValue)
					SET @Command = REPLACE(@Command, @TmpVIPValue , @NewVIPValue)
			END
		END

		SELECT * INTO #tmpCommandTbl FROM dbo.TUser WHERE UserID = @RecordID
		DECLARE @tmpCommand NVARCHAR(MAX)
		SET @tmpCommand = REPLACE(@Command, @TableName, '#tmpCommandTbl')
		INSERT INTO #tmpCommandTbl EXEC sp_executesql @tmpCommand
		SELECT @UserName = UserName, @VirtualIP = VirtualIP, @LoginType = LoginType FROM #tmpCommandTbl
		DROP TABLE #tmpCommandTbl

		EXEC USP_CheckUserConstraints @ActionType, @RecordID, @UserName, @VirtualIP,@LoginType, @ResultMsg OUTPUT
		IF(@ResultMsg IS NOT NULL)
		BEGIN
			IF(@ResultMsg = '|Name_Conflict')
			BEGIN
			     DECLARE @NewName AS NVARCHAR(100)
			     SET @NewName = dbo.CopyUserName(@RecordID, @UserName)
			     DECLARE @Replacement AS NVARCHAR(300)
			     DECLARE @NewReplaceValue AS NVARCHAR(300)
			     IF(@ActionType = 'Insert-TUser')
			     BEGIN
					SET @Replacement='('''+CAST(@RecordID AS VARCHAR(20))+''',N'''+@UserName+''','
					SET @NewReplaceValue='('''+CAST(@RecordID AS VARCHAR(20))+''',N'''+@NewName+''','
					SET @Command = REPLACE(@Command, @Replacement , @NewReplaceValue)
			     END
			     ELSE IF (@ActionType = 'Update-TUser')
			     BEGIN
					SET @Replacement = 'UserName = N''' + @UserName + ''','
					SET @NewReplaceValue = 'UserName = N''' + @NewName + ''','
					SET @Command = REPLACE(@Command, @Replacement , @NewReplaceValue)
			     END
			     DECLARE @NewGID AS VARCHAR(25)
				 SET @NewGID = dbo.GenerateNewGID(@RecordID)
			     SET @Command = REPLACE(@Command, @RecordGID , @NewGID)
				 RAISERROR(@ResultMsg, 16, 10)
			     IF(@isExecutable = 1)
			     BEGIN
			   	 	 EXEC @ConfResult = SP_EXECUTESQL @Command
			   	 	 UPDATE TUserGroups SET GID = @NewGID WHERE UserID = @RecordID
			   	 END
			END
			ELSE IF(@ResultMsg = '|VIP_Conflict')
			BEGIN
			     IF(@ActionType = 'Insert-TUser')
				 BEGIN
					 SET @Command = REPLACE(@Command, 'N''Static''' , 'N''Dynamic''')
					 SET @Command = REPLACE(@Command, @VirtualIP , '')
				 END
				 ELSE IF(@ActionType = 'Update-TUser')
				 BEGIN
					 SET @Command = REPLACE(@Command, 'VirtualIPStatus = N''Static''' , 'VirtualIPStatus = N''Dynamic''')
					 SET @Command = REPLACE(@Command, 'VirtualIP = '''+@VirtualIP+ '''' , 'VirtualIP = ''''')
				 END
				 RAISERROR(@ResultMsg, 16, 10)
			     IF(@isExecutable = 1)
			   		 EXEC @ConfResult = SP_EXECUTESQL @Command
			END
		    ELSE
		    BEGIN
		    	RAISERROR(@ResultMsg, 16, 10)
		    	RETURN
		    END
		END
	END

	IF(@isExecutable = 1)
    BEGIN
		IF(@ConfResult = -1)
		BEGIN
			DECLARE @CheckDuplicatedRecordID AS BIT
			SET @CheckDuplicatedRecordID = 0
			IF(SUBSTRING(@ActionType,0,7)='Insert')
			BEGIN
				IF(@TableName = 'TUserKeya')
				BEGIN
					DECLARE @NewSerial AS VARCHAR(30)
					SELECT @NewSerial = dbo.GetKeyASerial(@Command)
					EXEC USP_CheckDuplicateRecordUserKeyA @TableName,@RecordID,@NewSerial,@CheckDuplicatedRecordID OUTPUT
				END
				ELSE IF(@TableName = 'TPermissionGroup')
					EXEC USP_CheckDuplicateRecord @TableName, 'Permission_ID', @RecordID, 'Group_ID', @RecordAssignedGroups, @CheckDuplicatedRecordID OUTPUT
				ELSE IF(@TableName <> 'TUser')
					EXEC USP_CheckDuplicateRecordID @TableName,@RecordID,@CheckDuplicatedRecordID OUTPUT
			END

			IF(@CheckDuplicatedRecordID = 0)
			BEGIN
				IF(SUBSTRING(@ActionType,0,7)='Insert')
					SELECT @Command = dbo.PrepareCommandIdentity(@Command, @ActionType, @TableName)
				IF(SUBSTRING(@ActionType,0,7)='Insert' OR SUBSTRING(@ActionType,0,7)='Update' OR @ActionType = 'Delete-TUserGroups')
				BEGIN
					EXEC @RetVal = SP_EXECUTESQL @Command	
					IF(@RetVal <> 0)
					BEGIN
						DECLARE @Ret VARCHAR(30)
						SET @Ret = '|Exec_Command:' + CAST(@RetVal AS VARCHAR(10))
						RAISERROR(@Ret, 16, 10)
						RETURN
					END	
				END

				ELSE IF (SUBSTRING(@ActionType,0,7)='Delete' AND @ActionType <> 'Delete-TUserGroups')
				BEGIN
						DECLARE @UserGroupID AS VARCHAR(20)
						IF(CHARINDEX ('user',SUBSTRING(@ActionType,8,LEN(@ActionType)))>0 OR @ActionType='Delete-TServerAccessPolicy' OR @ActionType = 'Delete-TUserFirewallPolicy')
							SET @UserGroupID = @RecordAssignedUsers
						ELSE
							SET @UserGroupID = @RecordAssignedGroups
					
						DECLARE @DeleteCommand AS NVARCHAR(1000)
						IF((((@RecordAssignedUsers IS NULL OR @RecordAssignedUsers = '') AND (@RecordAssignedGroups IS NULL OR @RecordAssignedGroups = ''))
                           OR (@ActionType='Delete-TServerAccessPolicy' OR @ActionType = 'Delete-TUserFirewallPolicy' OR @TableName = 'TGroup' OR @TableName = 'SpecialPermission'))
                          AND (@TableName <> 'TUserKeya'))
                        BEGIN
                            SET @DeleteCommand = 'DELETE FROM '+@TableName+' WHERE '+dbo.GetMixTableIDFieldName(@TableName)+' = '+CAST(@RecordID AS VARCHAR(20))
                        END
						ELSE IF(@TableName = 'TUserKeya')
						BEGIN
							DECLARE @DeletedSerial AS VARCHAR(50)
							DECLARE @KeyaSerialIndex INT
							SET @KeyaSerialIndex = CHARINDEX('KeyaSerial = N', @Command, 0)+15
							SELECT @DeletedSerial = SUBSTRING(@Command, @KeyaSerialIndex, LEN(@Command)-@KeyaSerialIndex)
							SET @DeleteCommand = 'DELETE FROM '+@TableName+' WHERE '+
											  dbo.GetMixTableIDFieldName(@TableName)+' = '+CAST(@RecordID AS VARCHAR(20))+' AND '+
											  dbo.GetTableGroupIDFieldName(@TableName)+' = N'''+@DeletedSerial + ''''
						END
						ELSE
							SET @DeleteCommand = 'DELETE FROM '+@TableName+' WHERE '+
											  dbo.GetMixTableIDFieldName(@TableName)+' = '+CAST(@RecordID AS VARCHAR(20))+' AND '+
											  dbo.GetTableGroupIDFieldName(@TableName)+' = '+@UserGroupID
						EXEC SP_EXECUTESQL @DeleteCommand
						IF (dbo.IsPrimaryServer(@ServerID) = 0 AND dbo.isSlaveOFPrimary(@ServerIP) = 0)
						    EXEC USP_CheckDeleteAllItem @ActionType , @RecordID
				END
			END
		END

		IF( dbo.IsTableAssignable(@TableName) = 0 )
		BEGIN
			IF((@ActionType = 'Delete-TUserGroups' OR @ActionType = 'Update-TUserGroupsKeyA') AND (@RecordAssignedGroups IS NULL OR @RecordAssignedGroups = ''))
            BEGIN
				IF(@ActionType = 'Delete-TUserGroups')
					EXEC USP_User_Delete @RecordID
				ELSE IF(@ActionType = 'Update-TUserGroupsKeyA')
					EXEC USP_User_Delete @RecordID, 0

                IF (dbo.IsPrimaryServer(@ServerID) = 0 AND dbo.isSlaveOFPrimary(@ServerIP) = 0)
					EXEC USP_CheckDeleteAllItem @ActionType , @RecordID, 0
            END

			IF(@ActionType = 'Update-TUser')
				UPDATE TUserGroups SET GID = @RecordGID WHERE UserID = @RecordID

			IF(SUBSTRING(@ActionType,0,7)<>'Delete' AND @TableName <> 'TGroup' AND ((@RecordAssignedGroups IS NOT NULL AND @RecordAssignedGroups <> '') OR (@RecordAssignedUsers IS NOT NULL AND @RecordAssignedUsers <> '')))
				EXEC USP_PrepareAndAssignToRelatedGroupsUsers @TableName,@RecordID, @RecordAssignedGroups,@RecordAssignedUsers, @RecordGID
		END
	END
END
go

