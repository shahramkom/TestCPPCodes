CREATE PROCEDURE [dbo].[USP_TUserscripts_Insert]
@UserID   int,
@ScriptID	  int,
@MaxUserScript int=3
AS
BEGIN
    declare @ScrCount int
    Select @ScrCount=Count(UserID) from TUserscripts
    Where UserID = @UserID
    if(@ScrCount>=@MaxUserScript)
        begin
            raiserror('Maximum script count for this user is used.', 16 , 10 )
            return
        end
	IF NOT EXISTS(SELECT * FROM TUserscripts WHERE UserID = @UserID AND ScriptID = @ScriptID)
		INSERT INTO TUserscripts VALUES(@UserID,@ScriptID)
	declare @CreateDateTime as nvarchar(20)
	select @CreateDateTime = CONVERT(nvarchar(20),GETDATE(),20)
	select @CreateDateTime
	Update Tuser set LastModifiedTime = @CreateDateTime where UserID = @UserID
END
go

