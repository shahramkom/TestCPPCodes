
    create PROCEDURE [dbo].[USP_TGroupScript_Insert] 
        -- Add the parameters for the stored procedure here
        @groupID int,
        @ScriptNameList nvarchar(max)
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
        declare @ScriptName as nvarchar(50)
        declare @ScriptID as int
        
        declare Script_Cursor1 cursor for 
        SELECT * FROM dbo.Splitfn(@ScriptNameList,',')
        
        open Script_Cursor1
        fetch next from script_Cursor1 into @ScriptName
        
        while @@FETCH_STATUS = 0
        begin
        select @ScriptID = ScriptID from TScript where ScriptTitle = @ScriptName
        
        insert into  TGroupScript 
        (ScriptID,GroupID) 
        values (@ScriptID,@groupID)
        
        fetch next from Script_Cursor1 into @ScriptName
        end
        close Script_Cursor1
        DEALLOCATE Script_Cursor1
    END

    go

