
    CREATE PROCEDURE  [dbo].[USP_Script_Delete]
        @ScriptID int		
    AS
    BEGIN
        SET NOCOUNT ON;
        DELETE FROM TScript WHERE ScriptID = @ScriptID
		DELETE FROM TUserscripts WHERE ScriptID = @ScriptID  
    END

    go

