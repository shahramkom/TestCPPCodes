CREATE PROCEDURE  [dbo].[USP_TUserTimeSet_Delete]
    @UserID   int
AS
BEGIN
	DECLARE @MyServerID TINYINT
	SELECT  @MyServerID = dbo.GetCurrentServerID()
    IF(dbo.IsPrimaryServer(@MyServerID) = 1)
	BEGIN
		DELETE FROM TUserTimeSet
		WHERE UserID = @UserID
		declare @CreateDateTime as nvarchar(20)
		select @CreateDateTime = CONVERT(nvarchar(20),GETDATE(),20)
		select @CreateDateTime
		Update Tuser set LastModifiedTime = @CreateDateTime where UserID = @UserID
	END
END
go

