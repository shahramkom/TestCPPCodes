

    
    CREATE PROCEDURE [dbo].[USP_TimeSet_AssignToGroup] 
        @TRID int,
        @GroupID int
      
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        declare @Prty int
        select @Prty = max(PriorityOrder) from TGroupTimeSet where GroupID = @GroupID
        if(@Prty is NULL)
        insert into TGroupTimeSet values(@TRID,@groupID,1)
        else
            begin
                set @Prty = @Prty +1
                INSERT INTO [VPNDatabase].[dbo].[TGroupTimeSet] 
                VALUES (@TRID,@GroupID,@Prty)
            end
    -- Insert statements for procedure here
    END

    go

