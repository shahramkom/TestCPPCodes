



    CREATE PROCEDURE  [dbo].[USP_READ_SERVERSETTING]
    
    --	@id		bigint			,	
    --	@Property nvarchar(400)	, 
    --	@value nvarchar(400) = NULL 
    
    AS
    BEGIN		
        SELECT * FROM TSetting 
    END

    go

