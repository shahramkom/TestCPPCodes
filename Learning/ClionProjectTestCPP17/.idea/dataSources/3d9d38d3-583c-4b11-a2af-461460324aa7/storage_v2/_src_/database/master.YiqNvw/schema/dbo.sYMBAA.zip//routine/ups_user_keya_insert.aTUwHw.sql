
    CREATE PROCEDURE  [dbo].[UPS_USER_KEYA_Insert]
    
        @UserID	int,	
        @KeyASerial  nvarchar(50)
    AS
    BEGIN
    declare @alreadyExist int 
    set @alreadyExist = null
    select @alreadyExist= UserID from TUserKeya where UserID=@UserID and   KeyASerial=@KeyASerial
    if(@alreadyExist is not null)
     return
    else
		begin
			declare @CurrentDate as nvarchar(10)
			select @CurrentDate = CONVERT(nvarchar(10),GETDATE(),20)	
			INSERT INTO TUserKeya  (UserID , KeyASerial,[Date]) VALUES (@UserID , @KeyASerial , @CurrentDate)
		end
    END

    go

