
    CREATE PROCEDURE [dbo].[USP_DeleteGroup] 
        -- Add the parameters for the stored procedure here
        @GroupID int = 0
      
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
    
       IF (EXISTS (SELECT GroupID FROM TNewPolicyGroupAssign WHERE GroupID = @GroupID ))
		BEGIN
			RAISERROR('Policies have been assigned to this group. Please deassign it first.', 16 , 1 )	
			RETURN
		END
		ELSE
		BEGIN
			Delete from TGroupPolicySet where GroupID =  @GroupID
			Delete from TUserGroups where GroupID =  cast(@GroupID as nvarchar(50))
			Delete from TGroup Where GroupID = @GroupID
			Delete from TGroupInterface Where GroupID = @GroupID
		END
    END


    go

