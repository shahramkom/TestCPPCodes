/******************************************************************************************************************************************************/
CREATE FUNCTION [dbo].[IPCorrector](@OperateType VARCHAR(20) , @VIP VARCHAR(20),@SeprateVIPHead as bigint = NULL,@MinIP as bigint = NULL , @MaxIP as bigint = NULL)
RETURNS VARCHAR(20)
AS
BEGIN
	DECLARE @RetVIP VARCHAR(20)
	SET @RetVIP = @VIP
	IF(@OperateType = 'InsertMode')
	BEGIN
		IF (CAST(@VIP AS BIGINT) > @MinIP AND CAST(@VIP AS BIGINT) < @MaxIP )
			SET @RetVIP = 'SP:'+ CAST((CAST(@VIP AS BIGINT) - @SeprateVIPHead)  AS VARCHAR(20)) 
	END
	ELSE
	BEGIN
		IF (CHARINDEX('SP:',@VIP,0) > 0 )
		BEGIN
			SET @VIP = SUBSTRING(@VIP,4,LEN(@VIP))
			SET @RetVIP = CAST( (@SeprateVIPHead + CAST(@VIP AS BIGINT)) AS VARCHAR(20))
		END
	END
	RETURN @RetVIP
END
go

