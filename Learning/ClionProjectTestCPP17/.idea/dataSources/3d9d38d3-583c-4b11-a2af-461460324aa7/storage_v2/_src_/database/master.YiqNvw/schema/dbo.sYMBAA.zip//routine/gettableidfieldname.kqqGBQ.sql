/******************************************************************************************************************************************************/--
CREATE FUNCTION dbo.GetTableIDFieldName(@TableName VARCHAR(50))
RETURNS VARCHAR(50)
BEGIN
	DECLARE @TableIDFieldName AS VARCHAR(50)
	SET @TableIDFieldName = 
	(CASE 	
			WHEN @TableName = 'TGroup' 
			THEN 'GroupID'
			WHEN @TableName = 'TScript' 
			THEN 'ScriptID'
			WHEN @TableName = 'TPolicySet'
			THEN 'PSID'
			WHEN @TableName = 'TDNS' 
			THEN 'DNSID'
			WHEN @TableName = 'TTimeRole'
			THEN 'TRID'
			WHEN @TableName = 'TServerAccessPolicy'
			THEN 'PolicyID'
			WHEN @TableName = 'TUserFirewallPolicy'
			THEN 'UFPID'
			WHEN @TableName = 'TUserKeya'
			THEN 'UserID'
			WHEN @TableName = 'SpecialPermission'
			THEN 'ID'
			WHEN @TableName = 'TPermissionGroup'
			THEN 'Permission_ID'
			WHEN @TableName = 'TInterface'
			THEN 'InterfaceID'
	END)
	RETURN @TableIDFieldName
END
go

