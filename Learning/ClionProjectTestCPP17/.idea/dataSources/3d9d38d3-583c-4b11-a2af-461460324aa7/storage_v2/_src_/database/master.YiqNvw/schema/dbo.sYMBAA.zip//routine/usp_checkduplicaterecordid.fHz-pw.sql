/******************************************************************************************************************************************************/---------------------------------
CREATE PROCEDURE USP_CheckDuplicateRecordID
@TableName VARCHAR(50),
@TableIDFieldValue INT,
@Outputval INT OUTPUT
AS
BEGIN
	DECLARE @TableIDFieldName AS VARCHAR(50)
	SELECT @TableIDFieldName = dbo.GetTableIDFieldName(@TableName)
	
	DECLARE @RecCount AS INT 

	DECLARE @ExecCommand AS NVARCHAR(MAX)
	SET @ExecCommand = ' SELECT @RecCount = COUNT(*) FROM ' + @TableName +
				       ' where ('+@TableIDFieldName+'='+CAST(@TableIDFieldValue AS VARCHAR(20))+')' 
	EXEC SP_EXECUTESQL  @ExecCommand
					  , N'@RecCount INT OUTPUT'
					  , @RecCount OUTPUT
	SELECT @Outputval = @RecCount
END
go

