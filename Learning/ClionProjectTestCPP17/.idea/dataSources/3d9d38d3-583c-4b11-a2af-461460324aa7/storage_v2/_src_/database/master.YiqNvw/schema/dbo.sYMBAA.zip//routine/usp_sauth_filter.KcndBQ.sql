
    create PROCEDURE [dbo].[USP_SAUTH_FILTER] 
        -- Add the parameters for the stored procedure here
        @L_UserID		  int=NULL,
        @L_startDate	  nvarchar(10)=NULL,
        @L_startTime	  nvarchar(8)=NULL,
        @L_endDate		  nvarchar(10)=NULL,
        @L_endTime		  nvarchar(8)=NULL	  									
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        --SET NOCOUNT ON;

        -- Insert statements for procedure here
        SELECT [Type],eventDate,eventTime,[Event],userID,LoginName,RealIP,KeyASerial,HostName,DomainName,macaddr,clientVer,VirtualIP FROM sAuthLog Where 
        (  @L_UserID              is     NULL        or	    userID=@L_UserID)AND  
        (  @L_startDate	          is     NULL 	     or		eventDate>=@L_startDate)AND
        (  @L_startTime			  is     NULL        or		eventTime>=@L_startTime )AND
        (  @L_endDate			  is     NULL        or		eventDate<=@L_endDate )AND
        (  @L_endTime			  is     NULL 	     or		eventTime<=@L_endTime )
    END

    go

