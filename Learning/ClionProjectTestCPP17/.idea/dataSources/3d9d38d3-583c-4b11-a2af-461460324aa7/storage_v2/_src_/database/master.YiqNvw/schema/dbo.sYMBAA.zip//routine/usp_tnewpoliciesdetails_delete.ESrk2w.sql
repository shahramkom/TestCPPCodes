
   CREATE PROCEDURE [dbo].[USP_TNewPoliciesDetails_Delete] 
   @ID  bigint
   AS
   BEGIN
		DELETE FROM [dbo].[TNewPoliciesDetails]  WHERE ID = @ID
   END

   go

