
	Create PROCEDURE [dbo].[USP_TNewPoliciesSearch_UserName] 
		@username nvarchar(200)
	AS
	BEGIN
		if (@username = '')
		begin
			exec USP_TNewPolicyMain_Select
			return
		end	
	
		begin try
	        DROP TABLE #Table
	    end try
	    begin catch
	    --RAISERROR ('Error raised in TRY block.', 16, 1);
	    end catch
	
	    create table #Table(uID nvarchar(100))
		
		insert into #Table SELECT  distinct(CONVERT(nvarchar(20),userid)) FROM tuser WHERE username like @username
	
		    SELECT distinct(ID), PolicyType, [Name], Enablity, ServicesID, EncryptionID, AdvancedDetailID, Compression, PolicyOrder, CreateTime, LastModifyTime, Discription, 
	                  ApplyTime, sourceTunnelType, sourceTunnelValue, DestinationTunnelType, DestinationTunnelValue, DirectionType, EncryptionKey, IntegrityKey, 
	                  TunnelID, dbo.SelModernPolGroupsUsers(MP.ID)AS Assignments 
			FROM      dbo.TNewPolicyMainTable AS MP FULL OUTER JOIN
	                  dbo.TNewPolicyUserAssign ON MP.ID = dbo.TNewPolicyUserAssign.ModernPID
			WHERE     (dbo.TNewPolicyUserAssign.UserID in (select uId from #Table)) OR
					  (MP.sourceTunnelValue in (select uId from #Table)) AND (MP.sourceTunnelType = 0) OR
					  (MP.DestinationTunnelValue in (select uId from #Table)) AND (MP.DestinationTunnelType = 0)
			--ORDER BY ApplyTime DESC ,PolicyOrder ASC
	
		begin try
	        DROP TABLE #Table
	    end try
	    begin catch
	    --RAISERROR ('Error raised in TRY block.', 16, 1);
	    end catch
	END

  go

