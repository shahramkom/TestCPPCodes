--------------------------------------------------------------------------------
CREATE PROCEDURE  [dbo].[SyncDatabases]
	@IsRestore bit = 0
AS
BEGIN	
	DECLARE @executeStr AS NVARCHAR(MAX)
	SET @executeStr = '
		BEGIN TRANSACTION SyncDbTrans
			DELETE FROM [VPNDataBase].[dbo].[TGroup]
			DELETE FROM [VPNDataBase].[dbo].[TPolicySet]
			DELETE FROM [VPNDataBase].[dbo].[TServerAccessPolicy]
			DELETE FROM [VPNDataBase].[dbo].[TUserFirewallPolicy]
			DELETE FROM [VPNDataBase].[dbo].[TGroupPolicySet]
			DELETE FROM [VPNDataBase].[dbo].[TUserPolicySet]
			DELETE FROM [VPNDataBase].[dbo].[TNewPoliciesAlgorithms]
			DELETE FROM [VPNDataBase].[dbo].[TNewPoliciesDetails]
			DELETE FROM [VPNDataBase].[dbo].[TNewPoliciesServices]
			DELETE FROM [VPNDataBase].[dbo].[TNewPolicyMainTable]
			DELETE FROM [VPNDataBase].[dbo].[TNewPolicyGroupAssign]
			DELETE FROM [VPNDataBase].[dbo].[TNewPolicyUserAssign]
			DELETE FROM [VPNDataBase].[dbo].[TUser]
			DELETE FROM [VPNDataBase].[dbo].[TUserGroups]
			DELETE FROM [VPNDataBase].[dbo].[TDNS]
			DELETE FROM [VPNDataBase].[dbo].[TGroupDNS]
			DELETE FROM [VPNDataBase].[dbo].[TUserDNS]
			DELETE FROM [VPNDataBase].[dbo].[TScript]
			DELETE FROM [VPNDataBase].[dbo].[TGroupScript]
			DELETE FROM [VPNDataBase].[dbo].[TUserscripts]
			DELETE FROM [VPNDataBase].[dbo].[TTimeRole]
			DELETE FROM [VPNDataBase].[dbo].[TGroupTimeSet]
			DELETE FROM [VPNDataBase].[dbo].[TUserTimeSet]
			DELETE FROM [VPNDataBase].[dbo].[HealthCheckProfiles]
			DELETE FROM [VPNDataBase].[dbo].[HealthCheckRules]
			DELETE FROM [VPNDataBase].[dbo].[HealthCheckGroupAssign]
			DELETE FROM [VPNDataBase].[dbo].[HealthCheckUserAssign]
			DELETE FROM [VPNDataBase].[dbo].[TUserKeya]
			DELETE FROM [VPNDataBase].[dbo].[TModuleBlockList]
			DELETE FROM [VPNDataBase].[dbo].[SpecialPermission]
			DELETE FROM [VPNDataBase].[dbo].[TPermissionGroup]
			DELETE FROM [VPNDataBase].[dbo].[TInterface]
			DELETE FROM [VPNDataBase].[dbo].[TGroupInterface]
			DELETE FROM [VPNDataBase].[dbo].[TUserInterface]
	BEGIN TRY
	'
	SET @executeStr += [dbo].[GetServerInsertString]('TGroup', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TPolicySet', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TServerAccessPolicy', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TUserFirewallPolicy', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TDNS', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TScript', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TTimeRole', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('HealthCheckProfiles', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('HealthCheckRules', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('SpecialPermission', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TNewPoliciesAlgorithms', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TNewPoliciesDetails', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TNewPoliciesServices', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TNewPolicyMainTable', 1, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TInterface', 1, @IsRestore)
			
	SET @executeStr += [dbo].[GetServerInsertString]('TGroupPolicySet', 0, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TUserPolicySet', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('TUser', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('TGroupDNS', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('TGroupScript', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('TGroupTimeSet', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('HealthCheckGroupAssign', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('TUserGroups', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('TUserDNS', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('TUserscripts', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('TUserTimeSet', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('HealthCheckUserAssign', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('TUserKeya', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('TModuleBlockList', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('TNewPolicyGroupAssign', 0, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TNewPolicyUserAssign', 0, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TPermissionGroup', 0, @IsRestore)		
	SET @executeStr += [dbo].[GetServerInsertString]('TGroupInterface', 0, @IsRestore)
	SET @executeStr += [dbo].[GetServerInsertString]('TUserInterface', 0, @IsRestore)
	
	SET @executeStr +='
		COMMIT TRANSACTION SyncDbTrans
	END TRY  
	BEGIN CATCH 
		DECLARE @ErrorMessage nvarchar(max), @ErrorSeverity int, @ErrorState int
		select @ErrorMessage = ERROR_MESSAGE(),	@ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE()
		ROLLBACK TRANSACTION SyncDbTrans;
		RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);	
	END CATCH'

	EXEC sp_executeSQL @executeStr
END
go

