

    CREATE PROCEDURE   [dbo].[UPS_TUserFirewallPolicy_Delete]

        @UFPID	int ,
        @GSID   int ,
        @order  int   
        AS

    BEGIN
        DELETE FROM  TUserFirewallPolicy WHERE 	@UFPID = UFPID
        DECLARE UFPID_cursor CURSOR FAST_FORWARD READ_ONLY FOR 
            select  UFPID from  TUserFirewallPolicy where PSID = @GSID   order by POrder asc
        
    declare @RowNumber int 
    set @RowNumber = 1
    OPEN UFPID_cursor

    FETCH NEXT FROM UFPID_cursor
    into @UFPID

    if @@FETCH_STATUS != 0
    begin
        close UFPID_cursor
        DEALLOCATE UFPID_cursor  
        return	
    end
    WHILE @@FETCH_STATUS = 0
    BEGIN
    
        update TUserFirewallPolicy set POrder = @RowNumber where UFPID = @UFPID 
        set @RowNumber = @RowNumber + 1
    FETCH NEXT FROM UFPID_cursor
    into @UFPID
    END
    close UFPID_cursor
    DEALLOCATE UFPID_cursor
    END

    go

