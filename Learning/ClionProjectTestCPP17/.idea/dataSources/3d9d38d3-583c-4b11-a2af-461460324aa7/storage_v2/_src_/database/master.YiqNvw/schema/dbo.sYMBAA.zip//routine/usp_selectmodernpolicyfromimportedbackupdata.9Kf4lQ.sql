
   CREATE PROCEDURE [dbo].[USP_SelectModernPolicyFromImportedBackupData] 
	@Replace bit
	AS
	BEGIN
		SET NOCOUNT ON;
		declare @InsertScript nvarchar(4000)
		declare @tableName nvarchar(4000)
		declare @ModernPolicyID nvarchar(4000)
		declare @ModernPolicyName nvarchar(4000)

		Declare ModernPolicy_cursor Cursor FAST_FORWARD
		For
		Select [output], tableName, ModernPolicyID, ModernPolicyName 
			FROM tbl_InsertGroupScript   
			where  tableName = 'TNewPolicyMainTable' 
				or tableName = 'TNewPoliciesServices'
				or tableName = 'TNewPoliciesDetails'
				or tableName = 'TNewPoliciesAlgorithms'
				or tableName = 'TNewPolicyGroupAssign'
				or tableName = 'TNewPolicyUserAssign'

		OPEN ModernPolicy_cursor

		FETCH NEXT FROM ModernPolicy_cursor
		INTO @InsertScript, @tableName, @ModernPolicyID, @ModernPolicyName

		WHILE @@FETCH_STATUS = 0
		begin 
			if ( @tableName =  'TNewPolicyMainTable')
			begin
			if(exists (select ID from TNewPolicyMainTable where Name = @ModernPolicyName ))
				Begin
					if(@Replace = '1') 	Delete from TNewPolicyMainTable   where ID = @ModernPolicyID	
					BEGIN TRY
						SET IDENTITY_INSERT TNewPolicyMainTable ON
						exec sp_executesql @InsertScript	
						SET IDENTITY_INSERT TNewPolicyMainTable OFF
					END TRY
					BEGIN CATCH
						INSERT INTO [VPNDataBase].[dbo].[TSqlError]
						([userid]
						,[moment]
						,[operate]
						,[errorcode]
						,[errortext]
						,[comment])
					VALUES
						(1
						,GETDATE()
						,@InsertScript
						,@@Error
						,Error_MESSAGE()
						,N'USP_SelectModernPolicyFromImportedBackupData')   	
					END CATCH
				End
				else
				begin
					BEGIN TRY
						SET IDENTITY_INSERT TNewPolicyMainTable ON
						exec sp_executesql @InsertScript	
						SET IDENTITY_INSERT TNewPolicyMainTable OFF
					END TRY
					BEGIN CATCH
						INSERT INTO [VPNDataBase].[dbo].[TSqlError]
						([userid]
						,[moment]
						,[operate]
						,[errorcode]
						,[errortext]
						,[comment])
					VALUES
						(1
						,GETDATE()
						,@InsertScript
						,@@Error
						,Error_MESSAGE()
						,N'USP_SelectModernPolicyFromImportedBackupData')   	
					END CATCH
				end
			end
			else if ( @tableName =  'TNewPoliciesServices')
			begin
				if(exists (select ID from TNewPoliciesServices where ProtocolName = @ModernPolicyName ))
				Begin
					if(@Replace = '1') 	Delete from TNewPoliciesServices	where ProtocolName = @ModernPolicyName	
					BEGIN TRY
						SET IDENTITY_INSERT TNewPoliciesServices ON
						exec sp_executesql @InsertScript	
						SET IDENTITY_INSERT TNewPoliciesServices OFF
					END TRY
					BEGIN CATCH
						INSERT INTO [VPNDataBase].[dbo].[TSqlError]
						([userid]
						,[moment]
						,[operate]
						,[errorcode]
						,[errortext]
						,[comment])
					VALUES
						(1
						,GETDATE()
						,@InsertScript
						,@@Error
						,Error_MESSAGE()
						,N'USP_SelectModernPolicyFromImportedBackupData')   	
					END CATCH
				End
				else
				begin
					BEGIN TRY
						SET IDENTITY_INSERT TNewPoliciesServices ON
						exec sp_executesql @InsertScript	
						SET IDENTITY_INSERT TNewPoliciesServices OFF
					END TRY
					BEGIN CATCH
						INSERT INTO [VPNDataBase].[dbo].[TSqlError]
						([userid]
						,[moment]
						,[operate]
						,[errorcode]
						,[errortext]
						,[comment])
					VALUES
						(1
						,GETDATE()
						,@InsertScript
						,@@Error
						,Error_MESSAGE()
						,N'USP_SelectModernPolicyFromImportedBackupData')   	
					END CATCH
				end
			end
			else if ( @tableName =  'TNewPoliciesDetails')
			begin
				if(exists (select ID from TNewPoliciesDetails where MainID = convert(bigint, @ModernPolicyName )))
				Begin
					if(@Replace = '1') 	Delete from TNewPoliciesDetails   where MainID = @ModernPolicyName	
					BEGIN TRY
						SET IDENTITY_INSERT TNewPoliciesDetails ON
						exec sp_executesql @InsertScript	
						SET IDENTITY_INSERT TNewPoliciesDetails OFF
					END TRY
					BEGIN CATCH
						INSERT INTO [VPNDataBase].[dbo].[TSqlError]
						([userid]
						,[moment]
						,[operate]
						,[errorcode]
						,[errortext]
						,[comment])
					VALUES
						(1
						,GETDATE()
						,@InsertScript
						,@@Error
						,Error_MESSAGE()
						,N'USP_SelectModernPolicyFromImportedBackupData')   	
					END CATCH
				End
				else
				begin
					BEGIN TRY
						SET IDENTITY_INSERT TNewPoliciesDetails ON
						exec sp_executesql @InsertScript	
						SET IDENTITY_INSERT TNewPoliciesDetails OFF
					END TRY
					BEGIN CATCH
						INSERT INTO [VPNDataBase].[dbo].[TSqlError]
						([userid]
						,[moment]
						,[operate]
						,[errorcode]
						,[errortext]
						,[comment])
					VALUES
						(1
						,GETDATE()
						,@InsertScript
						,@@Error
						,Error_MESSAGE()
						,N'USP_SelectModernPolicyFromImportedBackupData')   	
					END CATCH
				end
			end
			else if ( @tableName =  'TNewPoliciesAlgorithms')
			begin
				declare @end int
				declare @encryptionAlgorithm nvarchar(50)
				declare @integrityAlgorithm  nvarchar(50)
				set @encryptionAlgorithm = ''
				set @integrityAlgorithm = ''
				set @end = CHARINDEX('*', @ModernPolicyName)
				if (@end > 0)
				begin
					set @encryptionAlgorithm = SUBSTRING(@ModernPolicyName, 0, @end)
					set @integrityAlgorithm = SUBSTRING(@ModernPolicyName, @end + 1 , LEN(@ModernPolicyName))
				end

				if(exists (select ID from TNewPoliciesAlgorithms where EncryptionAlgorithm = @encryptionAlgorithm and IntegrityAlgorithm = @integrityAlgorithm ))
				Begin
					if(@Replace = '1')
					begin
				 		Delete from TNewPoliciesAlgorithms  where EncryptionAlgorithm = @encryptionAlgorithm and IntegrityAlgorithm = @integrityAlgorithm	
						BEGIN TRY
							SET IDENTITY_INSERT TNewPoliciesAlgorithms ON
							exec sp_executesql @InsertScript	
							SET IDENTITY_INSERT TNewPoliciesAlgorithms OFF
						END TRY
						BEGIN CATCH
							INSERT INTO [VPNDataBase].[dbo].[TSqlError]
							([userid]
							,[moment]
							,[operate]
							,[errorcode]
							,[errortext]
							,[comment])
						VALUES
							(1
							,GETDATE()
							,@InsertScript
							,@@Error
							,Error_MESSAGE()
							,N'USP_SelectModernPolicyFromImportedBackupData')   	
						END CATCH
					end
				End
				else
				begin
					 BEGIN TRY
						SET IDENTITY_INSERT TNewPoliciesAlgorithms ON
						exec sp_executesql @InsertScript
						SET IDENTITY_INSERT TNewPoliciesAlgorithms OfF						
					END TRY
					BEGIN CATCH
						INSERT INTO [VPNDataBase].[dbo].[TSqlError]
						([userid]
						,[moment]
						,[operate]
						,[errorcode]
						,[errortext]
						,[comment])
					VALUES
						(1
						,GETDATE()
						,@InsertScript
						,@@Error
						,Error_MESSAGE()
						,N'USP_SelectModernPolicyFromImportedBackupData')   	
					END CATCH
				end
			end
			else if ( @tableName =  'TNewPolicyGroupAssign')
			begin
				if(exists (select GroupID from TNewPolicyGroupAssign where GroupID = @ModernPolicyName and ModernPID = @ModernPolicyID ))
				Begin
					if(@Replace = '1')
					begin
				 		Delete from TNewPolicyGroupAssign  where GroupID = @ModernPolicyName and ModernPID = @ModernPolicyID	
						BEGIN TRY
							--SET IDENTITY_INSERT TNewPolicyGroupAssign ON
							exec sp_executesql @InsertScript	
							--SET IDENTITY_INSERT TNewPolicyGroupAssign OFF
						END TRY
						BEGIN CATCH
							INSERT INTO [VPNDataBase].[dbo].[TSqlError]
							([userid]
							,[moment]
							,[operate]
							,[errorcode]
							,[errortext]
							,[comment])
						VALUES
							(1
							,GETDATE()
							,@InsertScript
							,@@Error
							,Error_MESSAGE()
							,N'USP_SelectModernPolicyFromImportedBackupData')   	
						END CATCH
					end
				End
				else
				begin
					 BEGIN TRY
						--SET IDENTITY_INSERT TNewPolicyGroupAssign ON
						exec sp_executesql @InsertScript
						--SET IDENTITY_INSERT TNewPolicyGroupAssign OfF						
					END TRY
					BEGIN CATCH
						INSERT INTO [VPNDataBase].[dbo].[TSqlError]
						([userid]
						,[moment]
						,[operate]
						,[errorcode]
						,[errortext]
						,[comment])
					VALUES
						(1
						,GETDATE()
						,@InsertScript
						,@@Error
						,Error_MESSAGE()
						,N'USP_SelectModernPolicyFromImportedBackupData')   	
					END CATCH
				end
			end
						else if ( @tableName =  'TNewPolicyUserAssign')
			begin
				if(exists (select UserID from TNewPolicyUserAssign where UserID = @ModernPolicyName and ModernPID = @ModernPolicyID ))
				Begin
					if(@Replace = '1')
					begin
				 		Delete from TNewPolicyUserAssign  where UserID = @ModernPolicyName and ModernPID = @ModernPolicyID	
						BEGIN TRY
							--SET IDENTITY_INSERT TNewPolicyUserAssign ON
							exec sp_executesql @InsertScript	
							--SET IDENTITY_INSERT TNewPolicyUserAssign OFF
						END TRY
						BEGIN CATCH
							INSERT INTO [VPNDataBase].[dbo].[TSqlError]
							([userid]
							,[moment]
							,[operate]
							,[errorcode]
							,[errortext]
							,[comment])
						VALUES
							(1
							,GETDATE()
							,@InsertScript
							,@@Error
							,Error_MESSAGE()
							,N'USP_SelectModernPolicyFromImportedBackupData')   	
						END CATCH
					end
				End
				else
				begin
					 BEGIN TRY
						--SET IDENTITY_INSERT TNewPolicyUserAssign ON
						exec sp_executesql @InsertScript
						--SET IDENTITY_INSERT TNewPolicyUserAssign OfF						
					END TRY
					BEGIN CATCH
						INSERT INTO [VPNDataBase].[dbo].[TSqlError]
						([userid]
						,[moment]
						,[operate]
						,[errorcode]
						,[errortext]
						,[comment])
					VALUES
						(1
						,GETDATE()
						,@InsertScript
						,@@Error
						,Error_MESSAGE()
						,N'USP_SelectModernPolicyFromImportedBackupData')   	
					END CATCH
				end
			end
			FETCH NEXT FROM ModernPolicy_cursor 
				INTO @InsertScript, @tableName, @ModernPolicyID, @ModernPolicyName
		end
		CLOSE ModernPolicy_cursor;
		DEALLOCATE ModernPolicy_cursor;		
	END

   go

