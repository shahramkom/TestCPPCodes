
CREATE PROCEDURE  [dbo].[USP_PrepareAssignedVIPs]
    @OldHeadVIP AS BIGINT,--Head Vip For Seprate this
    @NewHeadVIP AS BIGINT,--Head Vip For Merge this
    @FirstVIP AS BIGINT,--First Vip in defined Ranege
    @EndVIP AS BIGINT--End Vip in defined Ranege
AS
BEGIN
    BEGIN TRANSACTION	
    UPDATE Tuser SET VirtualIP = ((VirtualIP - @OldHeadVIP)+@NewHeadVIP) WHERE ((VirtualIP > @FirstVIP)AND(VirtualIP < @EndVIP)) 
    Select @@ROWCOUNT
    IF @@ERROR = 0
        BEGIN
            COMMIT TRANSACTION
        END
    ELSE
        BEGIN
            ROLLBACK TRANSACTION
            SELECT	-1
        END
    
    END

go

