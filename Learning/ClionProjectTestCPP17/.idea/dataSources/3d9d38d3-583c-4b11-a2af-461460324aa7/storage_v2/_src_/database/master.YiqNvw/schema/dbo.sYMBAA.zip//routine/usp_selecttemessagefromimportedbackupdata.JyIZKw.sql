
	           Create PROCEDURE [dbo].[USP_SelectTEMessageFromImportedBackupData] 
        -- Add the parameters for the stored procedure here
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;
        
    declare @InsertScript nvarchar(4000)

     Declare TEMessage_cursor Cursor FAST_FORWARD
        For
        Select 
                 [output] 
            FROM tbl_InsertGroupScript   
            where tableName = 'TEMessage'
            OPEN TEMessage_cursor

    FETCH NEXT FROM TEMessage_cursor
    INTO @InsertScript

    WHILE @@FETCH_STATUS = 0
    begin 

    --		if(exists (select UserID from TPolicySet where PSName = @PSName ))
    --		Begin
    --			if(@Replace = '1')
    --				 Delete from TPolicySet   where PSName = @PSName	
    --		End
            BEGIN TRY
             exec sp_executesql @InsertScript	
            END TRY
            BEGIN CATCH
				 INSERT INTO [VPNDataBase].[dbo].[TSqlError]
			   ([userid]
			   ,[moment]
			   ,[operate]
			   ,[errorcode]
			   ,[errortext]
			   ,[comment])
		 VALUES
			   (1
			   ,GETDATE()
			   ,@InsertScript
			   ,@@Error
			   ,Error_MESSAGE()
			   ,N'USP_SelectTEMessageFromImportedBackupData')   	
			
		    END CATCH
        
            
            
            FETCH NEXT FROM TEMessage_cursor 
             INTO @InsertScript
    
        end
        CLOSE TEMessage_cursor;
        DEALLOCATE TEMessage_cursor;		
    END


             go

