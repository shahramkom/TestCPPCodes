
    CREATE PROCEDURE [dbo].[USP_UpdateSysLogConnectionStatus]
        @ConnectionStatusInit		nvarchar(50)	= NULL,
        @ConnectionStatusFinal		nvarchar(50)	= NULL,
        @ConectionPort				nvarchar(50)	= NULL
    
    AS
    BEGIN
    DECLARE @Tcount int
        SELECT @Tcount = COUNT(*) FROM TSysLogTCPConnectionStatus 
    IF(@Tcount> 0)
     BEGIN	
        if @ConnectionStatusInit is NOT NULL
        UPDATE TSysLogTCPConnectionStatus 
        SET
         ConnectionStatusInit=@ConnectionStatusInit
     
        if @ConnectionStatusFinal is NOT NULL
        UPDATE TSysLogTCPConnectionStatus 
        SET
         ConnectionStatusFinal=@ConnectionStatusFinal
    
        if @ConectionPort is NOT NULL	
        UPDATE TSysLogTCPConnectionStatus 
        SET
         ConectionPort=@ConectionPort
     END
    ELSE
     BEGIN
        INSERT INTO TSysLogTCPConnectionStatus 
        (ConnectionStatusInit , ConnectionStatusFinal , ConectionPort)	
        VALUES(@ConnectionStatusInit,@ConnectionStatusFinal,@ConectionPort)
     END	
    END

    go

