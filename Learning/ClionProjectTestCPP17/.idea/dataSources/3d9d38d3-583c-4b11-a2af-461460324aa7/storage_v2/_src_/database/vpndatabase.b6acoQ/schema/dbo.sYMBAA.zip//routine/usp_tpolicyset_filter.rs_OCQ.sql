
    CREATE PROCEDURE  [dbo].[USP_TPolicySet_Filter]
    @PSName nvarchar(100)
        
    AS
    BEGIN
        --SET NOCOUNT ON;
        select PSID from TPolicySet
        where PSName = @PSName

    END

    go

