/******************************************************************************************************************************************************/

CREATE FUNCTION [dbo].[GetTPermissionGroupInsertQuery]( @PermissionIDValue int, @GroupIDValue int)
		RETURNS nvarchar(MAX)
	AS
	BEGIN
		DECLARE CursCol CURSOR FAST_FORWARD FOR 
		SELECT column_name,data_type FROM information_schema.columns WHERE table_name = 'TPermissionGroup' 
		OPEN CursCol
		DECLARE @String nvarchar(MAX) 
		DECLARE @StringData nvarchar(MAX) 
		DECLARE @DataType nvarchar(100)
		
		SET @String='INSERT TPermissionGroup('
		SET @StringData=' '

		DECLARE @ColName nvarchar(50)

		FETCH NEXT FROM CursCol INTO @ColName, @DataType

		WHILE @@FETCH_STATUS=0
		BEGIN
			SET @StringData = @StringData + [dbo].getDataTypeString(@DataType,@ColName)
			SET @String = @String + @ColName + ','
			FETCH NEXT FROM CursCol INTO @ColName,@DataType
		END
		CLOSE CursCol
		DEALLOCATE CursCol
		DECLARE @Query nvarchar(MAX)
		
		SET @Query ='SELECT '''+substring(@String,0,len(@String))+') VALUES(''+ ' + substring(@StringData,0,len(@StringData)-2)
		+'''+'')'' FROM TPermissionGroup WHERE Permission_ID = ' + CAST(@PermissionIDValue AS VARCHAR(20)) +' AND Group_ID = ' + CAST(@GroupIDValue AS VARCHAR(20))

		return @Query
END
go

