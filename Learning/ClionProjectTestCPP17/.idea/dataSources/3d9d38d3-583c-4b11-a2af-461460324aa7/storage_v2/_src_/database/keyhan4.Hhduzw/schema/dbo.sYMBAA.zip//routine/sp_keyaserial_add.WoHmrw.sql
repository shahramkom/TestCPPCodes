CREATE PROCEDURE [dbo].[sp_KeyASerial_Add] 
	@SellCode 	int, 
	@SerialNumber varchar(20)
AS
	declare @PrevCode int
	set @PrevCode  = 0
	select @PrevCode = SellCode from KeyASerial where SerialNumber = @SerialNumber
	if  (@PrevCode  = 0)
	begin
		Insert keyASerial (SellCode, SerialNumber, ProgramTime)
		values  (@SellCode, @SerialNumber, GetDate())
	end
	else
	begin
		Update  keyASerial  set 
			SellCode = @SellCode,
			 ProgramTime = GetDate(),
			nProgramCount = nProgramCount + 1
		where (SerialNumber = @SerialNumber)
	end
go

