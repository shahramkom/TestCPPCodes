CREATE PROCEDURE [dbo].[USP_TUserTimeSet_Insert]
@UserID   int,
@TimeSetId	  int,
@Priority int
AS
BEGIN
	IF NOT EXISTS(SELECT * FROM TUserTimeSet WHERE UserID = @UserID AND TimeSetId = @TimeSetId AND TPriority = @Priority)
		INSERT INTO TUserTimeSet (UserID,TimeSetId,TPriority) VALUES(@UserID,@TimeSetId,@Priority)
	declare @CreateDateTime as nvarchar(20)
	select @CreateDateTime = CONVERT(nvarchar(20),GETDATE(),20)
	select @CreateDateTime
	Update Tuser set LastModifiedTime = @CreateDateTime where UserID = @UserID
END
go

