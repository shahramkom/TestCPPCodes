
    CREATE PROCEDURE  [dbo].[USP_TempUser_Insert]

    
        @UserID				int					, 
        @GroupID			nvarchar(200) = null	,	
        @UserName			nvarchar(200)=Null	, 
        @BindingStatus		nvarchar(50)=Null	 , 
        @BindingPCID		nvarchar(100)=Null	,
        @IPBindingStatus	nvarchar(20)=Null	, 
        @SubNetIP			nvarchar(50)=Null	,
        @SubNetMask			nvarchar(50)=Null	,
        @VirtualIPStatus	nvarchar(50)=Null	,			
        @VirtualIP			nvarchar(15)=Null	, 

        @UserPIN			nvarchar(200)=Null	, 
        @MasterPIN			nvarchar(200)=Null	, 
        @AuthenticationKey	nvarchar(64), 
        @MustChangePIN		bit		=Null	, 	
        @AccountDisable		tinyInt	=Null	,
        @RejOnKeepAliveFail bit		=Null,
		@ShowUserPrivilege bit		=Null,

        @FirstName nvarchar(200)=Null	, 			 
        @LastName nvarchar(200)		=Null, 
        @Gender	 nvarchar(10)		=Null, 
        @Company	 nvarchar(200)	=Null, 
        @Office	 nvarchar(200)		=Null, 
        @Province nvarchar(200)		=Null,
        @Town     nvarchar(200)		=Null,	
        @Notes	 nvarchar(max)		=Null, 
        @Email	 nvarchar(200)		=Null, 
        @Cell	 nvarchar(50)		=Null, 
        @PersonnelCode	 nvarchar(10)		=Null, 
        @Phone	 nvarchar(200)		=Null, 
        @NationalID	     nvarchar(10)	=Null, 
        @Adress	 nvarchar(max)		=Null, 
        @PostalCode	nvarchar(200)=Null	,
        @Owner	int					=Null,
        @Replace int = 0				 ,
        @PUKPIN nvarchar(50)			 	
    AS
    BEGIN

        declare @EncAuthKey nvarchar(64) 
        , @nTotalCount int , @nTotalUser int
        , @nRepUsers int
        , @nDuplicateUsers int 
    
    
        begin try
            DROP TABLE #Table
        end try
        begin catch
        --RAISERROR ('Error raised in TRY block.', 16, 1);
        end catch

        create table #Table(
            CommandLine nvarchar(200),
            Param1		nvarchar(200),
            [Output]	nvarchar(64)
        )

        select @nTotalCount = count(*) from  tempUser
        select @nTotalUser  = [value] from TSetting where Property = 'TotalUser'
        if (@nTotalUser < @nTotalCount + 1 )
        begin
            Raiserror ('Number of total user exceeded' , 16 , 10)
            return
        end
        
        set @nRepUsers = 0
        select @nRepUsers = count(*) from tempUser where VirtualIP IS NOT NULL AND VirtualIP  = @VirtualIP and UserName != @UserName
        if(@nRepUsers > 0)
        begin
            Raiserror ('The entered virtual ip assigned before. Please choose another ip .',16,10)
            return
        end
        if(@VirtualIPStatus =N'Disable')
            set @VirtualIP = NULL
        set @nDuplicateUsers = 0
        select @nDuplicateUsers = count(*) from tempUser where UserName IS NOT NULL AND UserName  = @UserName
        if(@nDuplicateUsers > 0 )
        begin
        if(@Replace = 1) 
                delete from tempUser where UserName  = @UserName
            else
            begin
                --Raiserror ('The entered username assigned before. Please choose another username.',16,10)
                return
            end		
        end
    
        insert #Table EXEC Master..XYRunProc 'Encrypt' ,@AuthenticationKey
        select @EncAuthKey = [Output] from #Table where CommandLine='Encrypt'
        drop table #Table
        if( @EncAuthKey is null)
        begin
            Raiserror ('The Authentication key is null!  Please check server configs.',16,10)
            return		
        end

        if (@UserPIN is null)
            select @UserPIN = [Value] from TSetting where [property] = N'DefaultUserPIN'
        if (@MasterPIN is null)
            select @MasterPIN = [Value] from TSetting where [property] = N'DefaultMasterPIN'
        --declare @newGroupID int 
        --select  @newGroupID =  GroupID from TGroup where oldGroupID = @GroupID  
		 if NOT EXISTS (select *  from tempUser where UserID = @UserID) 
         begin
      
        
                        Insert into tempUser
                        (
                        UserID		 ,
                        GroupID	 ,
                        UserName	 ,
                        BindingStatus	 ,
                        BindingPCID ,
                        IPBindingStatus,
                        SubNetIP,
                        SubNetMask,
                        VirtualIPStatus	,
                        VirtualIP	 ,

                        UserPIN	 ,
                        MasterPIN,
                        AuthenticationKey ,
                        MustChangePIN	 ,
                        AccountDisable	 ,
                        RejOnKeepAliveFail,
						ShowUserPrivilege,

                        FirstName    ,
                        LastName	 ,
                        Gender		 ,
                        Office		 ,
                        Province	 ,
                        Town		 ,
                        Company	     ,
                        Notes		 ,
                        Email		 ,
                        Cell		 ,
                        PersonnelCode		 ,
                        Phone		 ,
                        NationalID			 ,
                        Adress		 ,
                        PostalCode	 ,
                        [Owner]	     ,
                        [UnBlockPIN] 
                        )
                    
                        values
                        (
                        @UserID		 ,
                        @GroupID	 ,--@newGroupID
                        @UserName	 ,
                        @BindingStatus	 ,
                        @BindingPCID,
                        @IPBindingStatus,
                        @SubNetIP,
                        @SubNetMask,	
                        @VirtualIPStatus,	
                        @VirtualIP	 ,

                        @UserPIN	 ,
                        @MasterPIN,
                        @EncAuthKey,
                        @MustChangePIN	 ,
                        @AccountDisable	 ,
                        @RejOnKeepAliveFail,
						@ShowUserPrivilege,


                        @FirstName   ,
                        @LastName	 ,
                        @Gender		 ,
                        @Office		 ,
                        @Province	 ,
                        @Town		 ,
                        @Company	 ,
                        @Notes		 ,
                        @Email		 ,
                        @Cell		 ,
                        @PersonnelCode		 ,
                        @Phone		 ,
                        @NationalID		 ,
                        @Adress		 ,
                        @PostalCode	 ,
                        @Owner	     ,
                        @PUKPIN 
                        )
        end
    end

    go

