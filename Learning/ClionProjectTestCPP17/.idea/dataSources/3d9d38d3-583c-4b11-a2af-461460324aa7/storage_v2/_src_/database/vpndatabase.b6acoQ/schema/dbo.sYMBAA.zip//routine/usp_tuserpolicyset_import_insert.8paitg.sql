/*************************************************************************************************************************************************************/
CREATE PROCEDURE [dbo].[USP_TUserPolicySet_Import_Insert] 
    -- Add the parameters for the stored procedure here
        @UserID     int,
        @oldPSID	  int,
        @Priority   int 	
AS
BEGIN
    SET NOCOUNT ON;
   
    Declare @PSID int 
        
    Select @PSID = PSID from  TPolicySet where oldPSID = @oldPSID
	select @priority = max(PolPriority) from TUserPolicySet where UserID = @UserID  
	    if(@Priority is null)
        set @Priority = 0
    set @priority = 	@priority + 1 	  
    Exec USP_TUserPolicySet_Insert @UserID,@PSID,@Priority
END
go

