
    CREATE PROCEDURE [dbo].[UPS_PolicySet_Delete]
    
        @PSID	 INT 
    
    AS
    BEGIN
        if exists (select * from TServerAccessPolicy  where PSID = @PSID)
            begin
            Raiserror ('There are some server access policies in the selected group policy.', 16 , 10)
                return
            end
        if exists (select * from TUserFirewallPolicy  where PSID = @PSID)
            begin
            Raiserror ('There are some user firewall policies in the selected group policy.', 16 , 10)
                return
            end
        DELETE FROM TPolicySet 	WHERE PSID = @PSID
        Delete from TGroupPolicySet where PSID = @PSID
        DELETE FROM  TUserPolicySet WHERE PSID = @PSID 
    END

    go

