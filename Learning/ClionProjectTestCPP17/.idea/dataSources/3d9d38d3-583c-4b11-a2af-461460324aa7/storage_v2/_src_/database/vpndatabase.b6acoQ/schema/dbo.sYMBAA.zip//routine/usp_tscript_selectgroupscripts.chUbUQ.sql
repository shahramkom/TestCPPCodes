
    Create PROCEDURE [dbo].[USP_TScript_SelectGroupScripts]
    @GroupID int

    AS
    BEGIN	
        select * from TScript where ScriptID in
            (select ScriptID from TGroupScript where GroupID = @GroupID)
    END

    go

