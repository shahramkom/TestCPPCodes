
	CREATE PROCEDURE [dbo].[USP_TNewPoliciesGrpModernPol_Insert] 
        -- Add the parameters for the stored procedure here
        @ModernPolicyID int,
        @GroupNameList nvarchar(max)
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        -- Insert statements for procedure here
        declare @GroupName as nvarchar(50)
        declare @GroupID as int
        declare @priority as int
        set @priority = 1
        
        declare policy_CursorGroup cursor for 
        SELECT * FROM dbo.Splitfn(@GroupNameList,',')
        
        open policy_CursorGroup
        fetch next from policy_CursorGroup into @GroupName
        
        while @@FETCH_STATUS = 0
        begin
        select @GroupID = GroupID from TGroup where GroupName = @GroupName
        
		INSERT INTO [dbo].[TNewPolicyGroupAssign]
           ([GroupID],[ModernPID],[PriorityOrder])
		VALUES
           (@GroupID ,@ModernPolicyID  , @priority )
        
        set @priority = @priority + 1
        
        fetch next from policy_CursorGroup into @GroupName
        end
        close policy_CursorGroup
        DEALLOCATE policy_CursorGroup
    END

  go

