
    Create PROCEDURE [dbo].[USP_LicenseSetting]
        @expireDate nvarchar(10),
        @RemainingDays int
    AS
    BEGIN
		Declare @oldExpireDate nvarchar(10)
		Declare @oldRemainingDays int

		set @oldExpireDate = ''
		set @oldRemainingDays = Null

		select @oldExpireDate = [value] from TSetting Where [Property] = N'ExpireDate'		
		select @oldRemainingDays = [value] from TSetting Where [Property] = N'RemainingExpireDays'
	
		if @oldExpireDate <> ''
		begin
			if @oldExpireDate <> @expireDate
			begin
				update TSetting set [value] = @expireDate where [Property] = N'ExpireDate'
				if @oldRemainingDays is not Null
				begin
					update TSetting set [value] = @RemainingDays where [Property] = N'RemainingExpireDays'
				end
				else
				begin
					insert into TSetting (Property,value) values('RemainingExpireDays' , @RemainingDays)
				end
				select @RemainingDays
			end
			else
			begin
				if @oldRemainingDays is Null
				begin
					insert into TSetting (Property,value) values('RemainingExpireDays' , @RemainingDays)
					select @RemainingDays
				end
				else
				begin
					select @oldRemainingDays
				end
			end
		end
		else
		begin
			insert into TSetting (Property,value) values('ExpireDate' , @expireDate)
			if @oldRemainingDays is not Null
			begin
				update TSetting set [value] = @RemainingDays where [Property] = N'RemainingExpireDays'
			end
			else
			begin
				insert into TSetting (Property,value) values('RemainingExpireDays' , @RemainingDays)
			end
			select @RemainingDays
		end
    END

    go

