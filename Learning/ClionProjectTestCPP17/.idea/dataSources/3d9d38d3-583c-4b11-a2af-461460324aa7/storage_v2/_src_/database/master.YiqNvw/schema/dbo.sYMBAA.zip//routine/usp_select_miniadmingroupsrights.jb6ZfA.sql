
 
CREATE PROCEDURE [dbo].[USP_Select_MiniAdminGroupsRights]
	   @MiniAdminType as int,
       @UserID as bigint
        AS
BEGIN
    IF(@MiniAdminType = 1)	--#define POWERED_MINIADMIN
	BEGIN
		BEGIN TRY
            DROP TABLE #ResultTBL
        END TRY
        BEGIN CATCH
        --RAISERROR ('Error raised in TRY block.', 16, 1);
        END CATCH
		
		CREATE TABLE #ResultTBL(
            GroupMngmntView bit,
            GroupMngmnt		bit )
		
		INSERT #ResultTBL
			SELECT        dbo.SpecialPermission.GroupMngmntView, dbo.SpecialPermission.GroupMngmnt
			FROM            dbo.TUser INNER JOIN
							 dbo.SpecialPermission ON dbo.TUser.Permission_ID = dbo.SpecialPermission.ID
			WHERE        (dbo.SpecialPermission.MiniAdminType = 1) AND (dbo.TUser.UserID = @UserID)
			
		DECLARE @GMV AS BIT
		SET @GMV = 0
		DECLARE @GM AS BIT
		SET @GM = 0
		SELECT @GMV =  GroupMngmntView FROM #ResultTBL
		SELECT @GM =   GroupMngmnt	   FROM #ResultTBL

		IF (@GM = 1 and @GMV = 1)
			SELECT 'All of defined groups'
		ELSE
			SELECT 'None of define groups'
	END

	ELSE IF(@MiniAdminType = 2)-- #define LIMITED_MINIADMIN 
	
	BEGIN
		SELECT         dbo.TPermissionGroup.Group_ID, dbo.TGroup.GroupName
		FROM            dbo.TUser INNER JOIN
								 dbo.SpecialPermission ON dbo.TUser.Permission_ID = dbo.SpecialPermission.ID INNER JOIN
								 dbo.TPermissionGroup ON dbo.SpecialPermission.ID = dbo.TPermissionGroup.Permission_ID INNER JOIN
								 dbo.TGroup ON dbo.TPermissionGroup.Group_ID = dbo.TGroup.GroupID
		WHERE        (dbo.SpecialPermission.MiniAdminType = 2) AND (dbo.TUser.UserID = @UserID)
	END
END
go

