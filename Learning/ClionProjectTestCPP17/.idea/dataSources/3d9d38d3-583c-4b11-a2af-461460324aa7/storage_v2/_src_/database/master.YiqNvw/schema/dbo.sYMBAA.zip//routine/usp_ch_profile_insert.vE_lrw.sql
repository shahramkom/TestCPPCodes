
CREATE PROCEDURE [dbo].[USP_CH_Profile_Insert]
    @CHP_Name		    nvarchar(50),
    @CHP_Description	nvarchar(100),
    @CHP_RuleIDs		nvarchar(500),
	@activity			bit
AS
BEGIN
INSERT INTO [dbo].[HealthCheckProfiles]
       ([Name]
       ,[Description]
       ,[RuleIDs]
	   ,[Activity])
 VALUES
       (@CHP_Name , @CHP_Description , @CHP_RuleIDs, @activity)
    select @@IDENTITY

END
go

