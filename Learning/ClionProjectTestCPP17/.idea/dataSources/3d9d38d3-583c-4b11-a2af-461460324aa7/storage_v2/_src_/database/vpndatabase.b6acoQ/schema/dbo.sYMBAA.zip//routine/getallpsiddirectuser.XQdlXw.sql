CREATE FUNCTION [dbo].[GetAllPSIDDirectUser](@UserID BIGINT)
RETURNS VARCHAR(1000)
AS
BEGIN
	DECLARE @PSIDs NVARCHAR(1000)
	SELECT @PSIDs = STUFF ((SELECT    ','+ CAST( dbo.TUserPolicySet.PSID AS NVARCHAR(10))
	FROM dbo.TUserPolicySet	WHERE  (dbo.TUserPolicySet.UserID = @UserID) for xml path('')) , 1 ,1 , '') 
	RETURN @PSIDs 
END
go

