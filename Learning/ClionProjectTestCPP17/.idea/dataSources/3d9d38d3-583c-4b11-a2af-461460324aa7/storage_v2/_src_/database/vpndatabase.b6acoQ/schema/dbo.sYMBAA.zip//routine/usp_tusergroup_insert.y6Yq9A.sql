CREATE PROCEDURE [dbo].[USP_TUserGroup_Insert]
    -- Add the parameters for the stored procedure here
    @UserID int,
    @GroupID int,
    @Priority int,
	@gid varchar(25) = NULL
        
AS
BEGIN
    SET NOCOUNT ON;
	declare @CreateDateTime as nvarchar(20)
	select @CreateDateTime = CONVERT(nvarchar(20),GETDATE(),20)
	select @CreateDateTime
	
	--if(@gid is NULL)
	SET @gid = dbo.GenerateNewGID(@UserID) 

	Update Tuser set LastModifiedTime = @CreateDateTime, GID = @gid where UserID = @UserID
	Insert Into TUserGroups (UserID,GroupID,GPriority,GID) values(@UserID,@GroupID,@Priority,@gid)
END

/******************************************************************************************************************************************************/
go

