CREATE PROCEDURE [dbo].[USP_InsertTUserGenerator]
    @SeprateVIPHead AS BIGINT = NULL,
    @MinIP AS BIGINT = NULL,
    @MaxIP AS BIGINT = NULL,
    @filterGroupID NVARCHAR(MAX) = NULL,
	@isPlainAuthKey as bit = 0 
AS
BEGIN
	DECLARE @tableName VARCHAR(100)
	SET @tableName = 'TVIPS2DUser'
    
	BEGIN TRY
		DROP TABLE #tbl_InsertGroupScript
		DROP TABLE TVIPS2DUser
	END TRY
	BEGIN CATCH
			--RAISERROR ('Error raised in TRY block.', 16, 1);
	END CATCH
	BEGIN TRY
        
		DROP TABLE TVIPS2DUser
	END TRY
	BEGIN CATCH
			--RAISERROR ('Error raised in TRY block.', 16, 1);
	END CATCH


	CREATE TABLE #tbl_InsertGroupScript ( [Output] NVARCHAR(MAX) )
    
	CREATE TABLE [dbo].[TVIPS2DUser]
	(
	  [UserID] [int] NOT NULL,
	  [UserName] [nvarchar](200) NULL,
	  [BindingStatus] [nvarchar](50) NULL,
	  [BindingPCID] [nvarchar](100) NULL,
	  [IPBindingStatus] [nvarchar](20) NULL,
	  [SubNetIP] [nvarchar](50) NULL,
	  [SubNetMask] [nvarchar](50) NULL,
	  [VirtualIPStatus] [nvarchar](50) NULL,
	  [VirtualIP] [nvarchar](15) NULL,
	  [UserPIN] [nvarchar](200) NULL,
	  [MasterPIN] [nvarchar](200) NULL,
	  [AuthenticationKey] [nvarchar](64) NULL,
	  [MustChangePIN] [bit] NULL,
	  [AccountDisable] [bit] NULL,
	  [RejOnKeepAliveFail] [bit] NULL,
	  [ShowUserPrivilege] [bit] NULL,
	  [FirstName] [nvarchar](200) NULL,
	  [LastName] [nvarchar](200) NULL,
	  [Gender] [nvarchar](10) NULL,
	  [Company] [nvarchar](200) NULL,
	  [Office] [nvarchar](200) NULL,
	  [Province] [nvarchar](200) NULL,
	  [Town] [nvarchar](200) NULL,
	  [Notes] [nvarchar](2000) NULL,
	  [Email] [nvarchar](200) NULL,
	  [Cell] [nvarchar](50) NULL,
	  [PersonnelCode] [nvarchar](10) NULL,
	  [Phone] [nvarchar](200) NULL,
	  [NationalID] [nvarchar](10) NULL,
	  [Adress] [nvarchar](2000) NULL,
	  [PostalCode] [nvarchar](200) NULL,
	  [Owner] [int] NULL,
	  [Permission_ID] [int] NULL,
	  [UnBlockPIN] [nvarchar](200),
	  [AuthType] [tinyint] NULL,
	  [CertType] [nvarchar](50) NULL,
	  [CertValue] [nvarchar](400) NULL,
	  [InterfaceBindingStatus] [bit] NOT NULL, --CONSTRAINT [DF_TVIPS2DUser_InterfaceBindingStatus]  DEFAULT ((0))
	  [LoginType] [tinyint] NULL,
	  [LockModule] [bit] NULL,
	  [ExpireDate] [nvarchar](20) NULL,
	  [VersionBindingStatus] [nvarchar](50) NULL,
	  [BindingVersion] [nvarchar](10) NULL,
	  [CreateTime] [nvarchar](20) NULL,
	  [LastModifiedTime] [nvarchar](20) NULL,
	  [SendDNS] [bit] NULL,
	  [DisableModernPolicy] [bit] NOT NULL,
	  [LastConnectedIP] [nvarchar](20) NULL,
	  [LastLoginTime] [nvarchar](20) NULL,
	  [GID]	[nvarchar](50) NULL				
	)
	INSERT  INTO TVIPS2DUser
			SELECT  UserID,
					UserName,
					BindingStatus,
					BindingPCID,
					IPBindingStatus,
					SubNetIP,
					SubNetMask,
					VirtualIPStatus,
					VirtualIP,
					UserPIN,
					MasterPIN,
					AuthenticationKey,
					MustChangePIN,
					AccountDisable,
					RejOnKeepAliveFail,
					ShowUserPrivilege,
					FirstName,
					LastName,
					Gender,
					Company,
					Office,
					Province,
					Town,
					Notes,
					Email,
					Cell,
					PersonnelCode,
					Phone,
					NationalID,
					Adress,
					PostalCode,
					Owner,
					Permission_ID,
					UnBlockPIN,
					AuthType,
					CertType,
					CertValue,
					InterfaceBindingStatus,
					LoginType,
					LockModule,
					ExpireDate,
					VersionBindingStatus,
					BindingVersion,
					CreateTime,
					LastModifiedTime,
					SendDNS,
					DisableModernPolicy,
					LastConnectedIP,
					LastLoginTime,
					GID
			FROM    TUser
	IF ((@SeprateVIPHead IS NOT NULL) AND (@MinIP IS NOT NULL) AND (@MaxIP IS NOT NULL))
		UPDATE  TVIPS2DUser SET VirtualIP = 'SP:' + CAST(( VirtualIP - @SeprateVIPHead ) AS NVARCHAR(20)) WHERE ((CAST(VirtualIP AS BIGINT) > @MinIP) AND (CAST(VIRTUALIP AS BIGINT) < @MaxIP))
	
		--Declare a cursor to retrieve column specific information for the specified table
	DECLARE cursCol CURSOR FAST_FORWARD
	FOR
	SELECT  column_name,data_type FROM  information_schema.COLUMNS WHERE  table_name = @tableName
	OPEN cursCol
	DECLARE @string NVARCHAR(3000) --for storing the first half of INSERT statement
	DECLARE @stringData NVARCHAR(3000) --for storing the data (VALUES) related statement
	DECLARE @dataType NVARCHAR(MAX) --data types returned for respective columns
	SET @string = 'INSERT ' + 'TUser' + '('
	SET @stringData = ''

	DECLARE @colName NVARCHAR(50)

	FETCH NEXT FROM cursCol INTO @colName, @dataType

	IF @@fetch_status <> 0
		BEGIN
			PRINT 'Table ' + @tableName + ' not found, processing skipped.'
			CLOSE curscol
			DEALLOCATE curscol
			RETURN
		END

	WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @dataType IN ( 'varchar', 'char', 'nchar', 'nvarchar' )
				BEGIN
					DECLARE @authkeystr NVARCHAR(MAX)
					SET @authkeystr = '''USP_Get_User_AuthKey'''
					IF ( @colName = 'AuthenticationKey' )
				BEGIN
					if(@isPlainAuthKey = 1)
					BEGIN
						SET @stringData = @stringData + '''' + '''+isnull(''N''' + '''''+' + @authkeystr + '+'''''+ ''''',''NULL'')+'',''+'
					END
					ELSE
					BEGIN
						SET @stringData = @stringData + '''' + '''+isnull(''N''' + '''''+' + @colName + '+'''''+ ''''',''NULL'')+'',''+'
					END
				END
				ELSE
					SET @stringData = @stringData + '''' + '''+isnull(''N''' + '''''+' + @colName + '+'''''+ ''''',''NULL'')+'',''+'
				END
			ELSE
				IF @dataType IN ( 'text', 'ntext' ) --if the datatype is text or something else 
					BEGIN
						SET @stringData = @stringData + '''''''''+isnull(cast(' + @colName
							+ ' as varchar(2000)),'''')+'''''',''+'
					END
				ELSE
					IF @dataType = 'money' --because money doesn't get converted from varchar implicitly
						BEGIN
							SET @stringData = @stringData + '''convert(money,''''''+isnull(cast(' + @colName
								+ ' as varchar(200)),''0.0000'')+''''''),''+'
						END
					ELSE
						IF @dataType = 'datetime'
							BEGIN
								SET @stringData = @stringData + '''convert(datetime,' + '''+isnull('''''
									+ '''''+convert(varchar(200),' + @colName + ',121)+''''' + ''''',''NULL'')+'',121),''+'
  
							END
						ELSE
							IF @dataType = 'image'
								BEGIN
									SET @stringData = @stringData + '''''''''+isnull(cast(convert(varbinary,' + @colName
										+ ') as varchar(6)),''0'')+'''''',''+'
								END
							ELSE --presuming the data type is int,bit,numeric,decimal 
								BEGIN
    
									SET @stringData = @stringData + '''' + '''+isnull(''''' + '''''+convert(varchar(200),'
										+ @colName + ')+''''' + ''''',''NULL'')+'',''+'
								END

			SET @string = @string + @colName + ','

			FETCH NEXT FROM cursCol INTO @colName, @dataType
		END

	DECLARE @Query NVARCHAR(MAX)
	DECLARE @WhereSTM NVARCHAR(MAX)
		IF ( @filterGroupId LIKE '0%' OR @filterGroupId LIKE '%,0%' )
		SET @WhereSTM = ''
	ELSE
			SET @WhereSTM = ' where UserID IN (Select UserID from TUserGroups where GroupID IN (' + @filterGroupId + ') or 0 in(' + @filterGroupId + '))'
	
		SET @query = 'SELECT ''' + SUBSTRING(@string, 0, LEN(@string)) + ') VALUES(''+ ' + SUBSTRING(@stringData, 0, LEN(@stringData) - 2)	+ '''+'')'' FROM ' + @tableName + @WhereSTM

		INSERT  #tbl_InsertGroupScript	EXEC sp_executesql @query


	CLOSE cursCol
	DEALLOCATE cursCol



	DECLARE @row NVARCHAR(MAX)
	DECLARE @authkey NVARCHAR(64)

	BEGIN TRY
		DROP TABLE #Table
        
	END TRY
	BEGIN CATCH	
        
	END CATCH
    
	BEGIN TRY
        
		DROP TABLE TVIPS2DUser
	END TRY
	BEGIN CATCH	
		SELECT  'not drop TVIPS2DUser'
	END CATCH


	CREATE TABLE #Table
	(
	  CommandLine NVARCHAR(200),
	  Param1 NVARCHAR(200),
	  [Output] NVARCHAR(64)
	)


	DECLARE TuserRow CURSOR FAST_FORWARD
	FOR
	SELECT  [output]
	FROM    #tbl_InsertGroupScript
	OPEN TuserRow
	FETCH NEXT FROM TuserRow INTO @row
	WHILE @@FETCH_STATUS = 0
		BEGIN
			DELETE  FROM #Table

			DECLARE @rowLocal NVARCHAR(MAX)
			SET @rowLocal = @row
			SET @rowLocal = SUBSTRING(@rowLocal, ( PATINDEX('%VALUES%', @rowLocal) + 8 ), ( LEN(@rowLocal) - PATINDEX('%VALUES(%', @rowLocal) + 8 ))
			DECLARE @i INT 
			SET @i = ( CHARINDEX(',', @rowLocal) + 1 )
			DECLARE @userNameStr NVARCHAR(MAX)
			SET @userNameStr = SUBSTRING(@rowLocal, @i + 1, ( LEN(@rowLocal) - ( @i + 1 ) ))
			SET @userNameStr = SUBSTRING(@userNameStr, 0, CHARINDEX(',', @userNameStr) - 1)
			SET @userNameStr = REPLACE(@userNameStr, '''', '')
				--to do:comment next line
				--select  @userNameStr
        
			SET @rowLocal = SUBSTRING(@rowLocal, 0, ( CHARINDEX(',', @rowLocal) - 1 ))
        
			if(@isPlainAuthKey = 1)
			BEGIN
			DECLARE @EncAuthKey NVARCHAR(64)	
			DECLARE @PlainAuthKey NVARCHAR(128)	
				SELECT  @EncAuthKey = AuthenticationKey	FROM TUser WHERE UserID = @rowLocal
        
				INSERT  #Table	EXEC Master..XYRunProc 'Decrypt', @EncAuthKey
        
        		SELECT  @PlainAuthKey = [Output] FROM  #Table WHERE CommandLine = 'Decrypt'	
        
			SET @row = REPLACE(@row, 'USP_Get_User_AuthKey', ( '#$#' + @PlainAuthKey ))		
                            
			END

			INSERT  tbl_InsertGroupScript([output],	tableName, userName, UserID )
			VALUES  ( @row,	'TUser', @userNameStr,	@rowLocal) 	
			FETCH NEXT FROM TuserRow INTO @row
		END
	DROP TABLE #Table
	DROP TABLE #tbl_InsertGroupScript
        
    
	CLOSE TuserRow
	DEALLOCATE TuserRow
END
go

