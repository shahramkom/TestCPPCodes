
	create PROCEDURE [dbo].[USP_SelectTUserInterfaceFromImportedBackupData]
		-- Add the parameters for the stored procedure here
			@Replace bit	
		AS
		BEGIN
			-- SET NOCOUNT ON added to prevent extra result sets from
			-- interfering with SELECT statements.
			SET NOCOUNT ON;
        
		declare @InterfaceID nvarchar(200), @UserID nvarchar(200),@InsertScript nvarchar(4000)

		 Declare TUserInterface_cursor Cursor FAST_FORWARD
			For
			Select 
					 UserID,InterfaceID,[output] 
				FROM tbl_InsertGroupScript   
				where tableName = 'TUserInterface'
				OPEN TUserInterface_cursor

		FETCH NEXT FROM TUserInterface_cursor
		INTO @UserID,@InterfaceID,@InsertScript

		WHILE @@FETCH_STATUS = 0
		begin 
				BEGIN TRY
				if(exists (select InterfaceID from TInterface where InterfaceID = @InterfaceID ))
				begin
					if(exists (select UserID from TUserInterface where InterfaceID = @InterfaceID and UserID = @UserID))
					Begin
						if(@Replace = '1')
							 Delete from TUserInterface  where InterfaceID = @InterfaceID and UserID = @UserID
					end
					--SET IDENTITY_INSERT TUserinterface ON
					 exec sp_executesql @InsertScript
					--SET IDENTITY_INSERT TUserinterface OFF
					update tuser set InterfaceBindingStatus = 'True' where UserID = @UserID
				end	
				END TRY
				BEGIN CATCH
					INSERT INTO [VPNDataBase].[dbo].[TSqlError]
				   ([userid]
				   ,[moment]
				   ,[operate]
				   ,[errorcode]
				   ,[errortext]
				   ,[comment])
				VALUES
				   (1
				   ,GETDATE()
				   ,@InsertScript 
				   ,@@Error
				   ,Error_MESSAGE()
				   ,N'USP_SelectTUserInterfaceFromImportedBackupData')
				END CATCH
        
            
            
				FETCH NEXT FROM TUserInterface_cursor 
				 INTO @UserID,@InterfaceID,@InsertScript
    
			end
			CLOSE TUserInterface_cursor;
			DEALLOCATE TUserInterface_cursor;		
	  END

  go

