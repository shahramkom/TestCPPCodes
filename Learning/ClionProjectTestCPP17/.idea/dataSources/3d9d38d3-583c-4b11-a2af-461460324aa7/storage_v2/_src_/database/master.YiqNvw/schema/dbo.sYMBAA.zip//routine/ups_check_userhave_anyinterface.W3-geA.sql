CREATE PROCEDURE [dbo].[UPS_Check_UserHave_AnyInterface] 
	@UserID BIGINT ,
	@AllRelatedGroupsOfUser nvarchar(2000)
AS
BEGIN
	DECLARE @Count TINYINT
	SELECT @Count = COUNT(InterfaceID) FROM TUserInterface WHERE UserID = @UserID
	if( @Count > 0)
	BEGIN
		SELECT 1 as Interface
		RETURN
	END	
	DECLARE @execSql  as NVARCHAR(2000)
	SET @execSql = 'SELECT @Count = COUNT(InterfaceID) FROM TGroupInterface WHERE GroupID in('+@AllRelatedGroupsOfUser+')'
	EXEC SP_EXECUTESQL @execSql, N'@Count TINYINT OUTPUT', @Count OUTPUT
	if( @Count > 0)
	BEGIN
		SELECT 1 as Interface
		RETURN
	END	
	SELECT 0 as Interface
END
go

