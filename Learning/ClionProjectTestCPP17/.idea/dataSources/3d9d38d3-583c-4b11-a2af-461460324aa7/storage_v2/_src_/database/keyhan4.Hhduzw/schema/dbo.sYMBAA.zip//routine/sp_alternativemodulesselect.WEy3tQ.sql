CREATE PROCEDURE [dbo].[sp_AlternativeModulesSELECT] 
		@ProfileID int,
	@forExport bit,
	@UserName nvarchar(150)
AS
	BEGIN
	if(@forExport = 1)
	BEGIN
		if(@UserName is not null)
			SELECT   dbo.ProfileSetting.CustomerName, dbo.AlternateModules.ProgramDate, dbo.AlternateModules.ModuleSerial, dbo.AlternateModules.ModuleType, dbo.AlternateModules.PIN, dbo.AlternateModules.UserName
			FROM      dbo.AlternateModules INNER JOIN dbo.ProfileSetting ON dbo.AlternateModules.ProfileID = dbo.ProfileSetting.Code
			WHERE   (dbo.AlternateModules.ProfileID = @ProfileID and dbo.AlternateModules.UserName = @UserName)
		else
			SELECT   dbo.ProfileSetting.CustomerName, dbo.AlternateModules.ProgramDate, dbo.AlternateModules.ModuleSerial, dbo.AlternateModules.ModuleType, dbo.AlternateModules.PIN, dbo.AlternateModules.UserName
			FROM      dbo.AlternateModules INNER JOIN dbo.ProfileSetting ON dbo.AlternateModules.ProfileID = dbo.ProfileSetting.Code
			WHERE   (dbo.AlternateModules.ProfileID = @ProfileID)
	END
	ELSE
	BEGIN
		if(@UserName is not null)
			SELECT [ID],[ProfileID],[ProgramDate],[ModuleSerial],[ModuleType],[PIN],[UserName] FROM [dbo].[AlternateModules] Where ProfileID = @ProfileID and UserName = @UserName
		else
			SELECT [ID],[ProfileID],[ProgramDate],[ModuleSerial],[ModuleType],[PIN],[UserName] FROM [dbo].[AlternateModules] Where ProfileID = @ProfileID
	END

END
go

