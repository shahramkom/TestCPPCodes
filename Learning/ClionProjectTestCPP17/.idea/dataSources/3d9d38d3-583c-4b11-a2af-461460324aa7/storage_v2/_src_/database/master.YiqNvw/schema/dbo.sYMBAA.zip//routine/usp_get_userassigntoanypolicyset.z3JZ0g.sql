CREATE PROCEDURE [dbo].[USP_Get_UserAssignToAnyPolicySet]
@UserID bigint,
@AllGroups NVARCHAR(2000),
@OutVal INT OUTPUT
AS
BEGIN
	DECLARE @CountUser INT
	DECLARE @CountGroup INT
	SELECT @CountUser  = COUNT(PSID) FROM TUserPolicySet WHERE UserID = @UserID
	
	DECLARE @execSql  as NVARCHAR(2000)
	SET @execSql = 'SELECT @CountGroup = COUNT(PSID) FROM TGroupPolicySet WHERE GroupID in('+@AllGroups+')'
	EXEC SP_EXECUTESQL @execSql, N'@CountGroup TINYINT OUTPUT', @CountGroup OUTPUT
	SELECT @OutVal = @CountUser + @CountGroup 
END
go

