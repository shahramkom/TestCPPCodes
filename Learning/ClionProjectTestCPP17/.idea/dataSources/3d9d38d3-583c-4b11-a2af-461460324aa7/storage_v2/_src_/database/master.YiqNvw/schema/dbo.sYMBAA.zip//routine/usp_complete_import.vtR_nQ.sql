
		
    CREATE PROCEDURE [dbo].[USP_Complete_Import] 
        -- Add the parameters for the stored procedure here
    
    AS
    BEGIN
        -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
        SET NOCOUNT ON;

        declare @groupID int 
      select @groupID  = GroupID from TGroup where GroupName = N'keyhan3'  
   declare @PSID int , @oldPSID int ,@porder int,@policyid int,@UFPID int 

    Declare PolicySet_cursor Cursor fast_forward
     For
        Select 
                   [PSID],[oldPSID]
            FROM [VPNDataBase].[dbo].[TPolicySet]	   
				where oldPSID is not null
            OPEN PolicySet_cursor

    FETCH NEXT FROM PolicySet_cursor
    INTO @PSID,@oldPSID

    WHILE @@FETCH_STATUS = 0
        Begin
          	update TserverAccessPolicy set PSID = @PSID where PSID = @oldPSID
             
            FETCH NEXT FROM PolicySet_cursor 
            INTO @PSID,@oldPSID
        End
    
        CLOSE PolicySet_cursor;
        DEALLOCATE PolicySet_cursor;

        update TPolicyset set oldPSID = NULL
    

	   --
       Declare PolicySet_cursor Cursor fast_forward
     For
        Select 
                   [PSID]
            FROM [VPNDataBase].[dbo].[TPolicySet]	   
				
            OPEN PolicySet_cursor

    FETCH NEXT FROM PolicySet_cursor
    INTO @PSID

    WHILE @@FETCH_STATUS = 0
        Begin
        
			        
				  Declare TserverAccessPolicy_cursor Cursor fast_forward
				 For
					Select 
							  policyid,ROW_NUMBER() OVER (ORDER BY policyid) AS 'RowNumber'  
						FROM [VPNDataBase].[dbo].[TServerAccessPolicy] 	   
							where PSID = @PSID
						OPEN TserverAccessPolicy_cursor

				FETCH NEXT FROM TserverAccessPolicy_cursor
				INTO @policyID, @porder

				WHILE @@FETCH_STATUS = 0
					Begin
          				update TserverAccessPolicy set POrder = @porder where PolicyID = @policyID
			             
						FETCH NEXT FROM TserverAccessPolicy_cursor 
						INTO @policyID, @porder

					End
			    
					CLOSE TserverAccessPolicy_cursor;
					DEALLOCATE TserverAccessPolicy_cursor;
        
        
        
        ---
        
         Declare TUserFirewallPolicy_cursor Cursor fast_forward
				 For
					Select 
							  UFPID,ROW_NUMBER() OVER (ORDER BY UFPID) AS 'RowNumber'  
						FROM [VPNDataBase].[dbo].[TUserFirewallPolicy]  	   
							where PSID = @PSID
						OPEN TUserFirewallPolicy_cursor

				FETCH NEXT FROM TUserFirewallPolicy_cursor
				INTO @UFPID, @porder

				WHILE @@FETCH_STATUS = 0
					Begin
          				update TUserFirewallPolicy set POrder = @porder where UFPID = @UFPID
			             
						FETCH NEXT FROM TUserFirewallPolicy_cursor 
						INTO @UFPID, @porder

					End
			    
					CLOSE TUserFirewallPolicy_cursor;
					DEALLOCATE TUserFirewallPolicy_cursor;
        
        ---
        
             FETCH NEXT FROM PolicySet_cursor
             INTO @PSID
        End
    
        CLOSE PolicySet_cursor;
        DEALLOCATE PolicySet_cursor;
      

    END

    go

