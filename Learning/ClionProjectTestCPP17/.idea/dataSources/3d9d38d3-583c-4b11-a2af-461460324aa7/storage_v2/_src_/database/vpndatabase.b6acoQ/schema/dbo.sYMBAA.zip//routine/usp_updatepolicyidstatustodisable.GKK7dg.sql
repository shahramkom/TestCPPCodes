CREATE PROCEDURE [dbo].[USP_UpdatePolicyIDStatusToDisable] 
	@PolicyID int
AS
BEGIN
	Update TServerAccessPolicy set Status = 0 where PolicyID = @PolicyID
END
go

