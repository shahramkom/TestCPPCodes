CREATE PROCEDURE [dbo].[sp_SelledKeyA_GetList]   
AS
	select  
		PurchaseCode                 as 'ßÏ ÝÑæÔ', 
		CustomerName                as  'ÎÑíÏÇÑ', 
		SettingName                    as 'ÊäÙíã', 
		Number			as 'ÊÚÏÇÏ',
		--LoanFlag		as 'ÇãÇäÊ',
		DeliveryDate		as 'ÊÇÑíÎ ÊÍæíá',			
		--FactorDate		as 'ÊÇÑíÎ ÝÇ˜ÊæÑ', 
		WarrantyRevokeDate	as 'ÇäÞÖÇÁ ÖãÇäÊ'
	from  PurchasedKeyA, Customers, CustomerSettings
	where (DeleteFlag = 0 and PurchasedKeyA.CustomerCode = Customers.CustomerCode and PurchasedKeyA.SettingCode =CustomerSettings.SettingCode)
go

