
	Create PROCEDURE [dbo].[USP_LastConnectedIP_Select] 
			@UserID   int
	AS
	BEGIN
		 SELECT LastConnectedIP FROM TUser WHERE UserID = @UserID
	END

  go

