
    
    CREATE PROCEDURE [dbo].[UPS_TimeSet_Insert] 
        @TimeSetName nvarchar(300),
        @timeStr nvarchar(50),
        @timeDescription nvarchar(max)
    AS
    BEGIN
            -- SET NOCOUNT ON added to prevent extra result sets from
        -- interfering with SELECT statements.
    
        INSERT INTO [VPNDatabase].[dbo].[TTimeRole] 
            ([TimeSetName]
            ,[timeStr]
            ,[TimeDescription])
            VALUES 
            (@TimeSetName
            ,@timeStr
            ,@timeDescription)
        
    END

    go

